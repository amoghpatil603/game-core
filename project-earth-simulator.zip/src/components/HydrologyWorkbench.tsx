import React, { useState, useMemo, useEffect } from 'react';
import {
  Waves,
  GitFork,
  Compass,
  Droplets,
  Layers,
  Activity,
  AlertTriangle,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Gauge,
  Sliders,
  ChevronRight,
  TrendingDown,
  CloudRain,
  ShieldAlert,
  ArrowDownRight,
  Maximize2
} from 'lucide-react';

import { HydrologyEngine } from '../services/hydrology/hydrologyEngine';
import { HydrologyAutomatedSuite, HydrologyTestCaseResult } from '../services/hydrology/hydrologyAutomatedSuite';
import { RiverNode, RiverSegment, WatershedBasin, SimulationTier } from '../services/hydrology/hydrologyTypes';
import { REAL_TILES } from '../data/realEarthData';

type WorkbenchTab = 
  | 'RIVER_GRAPH' 
  | 'WATERSHED_BASIN' 
  | 'HYDRAULIC_PROFILE' 
  | 'CROSS_SECTION' 
  | 'FLOOD_SIMULATOR' 
  | 'GROUNDWATER_QUERY' 
  | 'VERIFICATION_SUITE';

export const HydrologyWorkbench: React.FC = () => {
  const engine = useMemo(() => HydrologyEngine.getInstance(), []);
  const suite = useMemo(() => new HydrologyAutomatedSuite(engine), [engine]);

  // Tab & Basin State
  const [activeTab, setActiveTab] = useState<WorkbenchTab>('RIVER_GRAPH');
  const [selectedBasinId, setSelectedBasinId] = useState<string>('BASIN_VIRGIN_RIVER_01');
  const [activeTier, setActiveTier] = useState<SimulationTier>(0);

  // Graph Selection
  const [selectedNodeId, setSelectedNodeId] = useState<string>('NODE_VR_04');
  const [selectedSegmentId, setSelectedSegmentId] = useState<string>('SEG_VR_03');

  // Interactive Manning Calculator
  const [manningQ, setManningQ] = useState<number>(3.85);
  const [manningW, setManningW] = useState<number>(14.5);
  const [manningS, setManningS] = useState<number>(0.0073);
  const [manningN, setManningN] = useState<number>(0.038);

  // Flood Simulation Controls
  const [rainIntensity, setRainIntensity] = useState<number>(25.0);
  const [stormDuration, setStormDuration] = useState<number>(3.5);
  const [soilMoisture, setSoilMoisture] = useState<'Dry' | 'Moderate' | 'Saturated'>('Moderate');
  const [floodPlayTime, setFloodPlayTime] = useState<number>(4.0);
  const [isFloodPlaying, setIsFloodPlaying] = useState<boolean>(false);

  // Spatial Groundwater Query Tool
  const [querySurfaceElev, setQuerySurfaceElev] = useState<number>(1260.0);
  const [queryDistToStream, setQueryDistToStream] = useState<number>(45.0);
  const [querySlopePercent, setQuerySlopePercent] = useState<number>(8.0);

  // Automated Verification Suite Results
  const [testResults, setTestResults] = useState<HydrologyTestCaseResult[]>([]);
  const [isRunningTests, setIsRunningTests] = useState<boolean>(false);

  // Sync basin switch
  useEffect(() => {
    engine.setActiveBasin(selectedBasinId);
    const nodes = engine.getNodesForActiveBasin();
    const segs = engine.getSegmentsForActiveBasin();
    if (nodes.length > 0) setSelectedNodeId(nodes[0].nodeId);
    if (segs.length > 0) {
      setSelectedSegmentId(segs[0].segmentId);
      setManningQ(segs[0].currentDischargeM3S);
      setManningW(segs[0].bankfullWidthMeters);
      setManningS(segs[0].gradientPercent / 100);
      setManningN(segs[0].manningRoughnessN);
    }
  }, [selectedBasinId, engine]);

  // Sync simulation tier
  useEffect(() => {
    engine.setSimulationTier(activeTier);
  }, [activeTier, engine]);

  // Flood simulation timer
  useEffect(() => {
    let timer: any;
    if (isFloodPlaying) {
      timer = setInterval(() => {
        setFloodPlayTime(prev => {
          if (prev >= 24.0) {
            setIsFloodPlaying(false);
            return 24.0;
          }
          return Math.round((prev + 0.5) * 10) / 10;
        });
      }, 400);
    }
    return () => clearInterval(timer);
  }, [isFloodPlaying]);

  // Run all verification tests
  const handleRunTests = () => {
    setIsRunningTests(true);
    setTimeout(() => {
      const res = suite.runAllHydrologyTests();
      setTestResults(res);
      setIsRunningTests(false);
    }, 150);
  };

  // Run tests on initial mount if empty
  useEffect(() => {
    if (testResults.length === 0) {
      setTestResults(suite.runAllHydrologyTests());
    }
  }, [suite, testResults.length]);

  // Derived data
  const currentBasin: WatershedBasin = engine.getActiveBasin();
  const currentNodes: RiverNode[] = engine.getNodesForActiveBasin();
  const currentSegments: RiverSegment[] = engine.getSegmentsForActiveBasin();
  const selectedNode = currentNodes.find(n => n.nodeId === selectedNodeId) || currentNodes[0];
  const selectedSegment = currentSegments.find(s => s.segmentId === selectedSegmentId) || currentSegments[0];

  // Manning Calculation output
  const manningResult = useMemo(() => {
    return engine.calculateManningHydraulics(manningQ, manningW, manningS, manningN);
  }, [engine, manningQ, manningW, manningS, manningN]);

  // Hydrograph data
  const hydrographPoints = useMemo(() => {
    return engine.generateStormHydrograph({
      rainfallIntensityMmHr: rainIntensity,
      stormDurationHours: stormDuration,
      antecedentMoistureCondition: soilMoisture,
      activeBasinId: selectedBasinId,
      returnPeriodYears: 10,
      hydroFlatteningEnabled: true
    });
  }, [engine, rainIntensity, stormDuration, soilMoisture, selectedBasinId]);

  const activeHydroPoint = useMemo(() => {
    return hydrographPoints.find(p => Math.abs(p.timeHours - floodPlayTime) < 0.3) || hydrographPoints[0];
  }, [hydrographPoints, floodPlayTime]);

  // 2D Flood Inundation Grid
  const flood2DGrid = useMemo(() => {
    const baseDEM = REAL_TILES[0]?.heightMatrix || [];
    return engine.generate2DFloodInundationGrid(activeHydroPoint.dischargeM3S, baseDEM);
  }, [engine, activeHydroPoint.dischargeM3S]);

  // Groundwater calculation output
  const groundwaterResult = useMemo(() => {
    return engine.estimateGroundwaterDepth(querySurfaceElev, queryDistToStream, querySlopePercent);
  }, [engine, querySurfaceElev, queryDistToStream, querySlopePercent]);

  // Metrics summary
  const metrics = useMemo(() => engine.computeMetricsSummary(), [engine, selectedBasinId, activeTier]);

  // Pass count for test suite
  const passedCount = testResults.filter(t => t.status === 'PASS').length;

  return (
    <div id="hydrology-workbench-root" className="flex flex-col h-full bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Top Header Banner */}
      <div id="hydro-header" className="flex items-center justify-between px-6 py-3.5 bg-slate-900/90 border-b border-slate-800 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/20 border border-cyan-500/30 rounded-lg text-cyan-400">
            <Waves className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold tracking-tight text-white">Project Earth: Hydrology & Water Surface Engine</h1>
              <span className="px-2 py-0.5 text-xs font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 rounded">
                Phase 5 Active
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Real Earth USGS NHD river graphs, open-channel Manning hydraulics, Leopold-Maddock geometry, and 2D flood dynamics
            </p>
          </div>
        </div>

        {/* Basin Switcher & Tier Controls */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <Compass className="w-4 h-4 text-cyan-400" />
            <span className="text-xs text-slate-400">Basin:</span>
            <select
              id="basin-selector"
              value={selectedBasinId}
              onChange={(e) => setSelectedBasinId(e.target.value)}
              className="bg-transparent text-xs font-medium text-cyan-300 focus:outline-none cursor-pointer"
            >
              <option value="BASIN_VIRGIN_RIVER_01" className="bg-slate-900 text-white">Virgin River (Zion Canyon, UT)</option>
              <option value="BASIN_COLUMBIA_GORGE_02" className="bg-slate-900 text-white">Columbia River (Cascade Gorge, OR/WA)</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <span className="px-2 text-slate-500 font-mono">Tier:</span>
            {[0, 1, 2, 3].map((t) => (
              <button
                key={t}
                id={`tier-btn-${t}`}
                onClick={() => setActiveTier(t as SimulationTier)}
                className={`px-2.5 py-1 rounded font-medium transition-all ${
                  activeTier === t 
                    ? 'bg-cyan-600 text-white shadow-sm' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                T{t}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 pl-2 border-l border-slate-800 text-xs">
            <div className="flex items-center gap-1.5 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="font-mono font-bold">{metrics.hydraulicPerformanceFps.toFixed(1)} FPS</span>
            </div>
            <span className="text-slate-600">|</span>
            <span className="text-slate-400 font-mono">ΔQ: {metrics.massConservationDeltaM3S.toFixed(3)} m³/s</span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div id="hydro-tabs" className="flex items-center gap-1 px-6 bg-slate-900 border-b border-slate-800 text-xs overflow-x-auto shrink-0">
        {[
          { id: 'RIVER_GRAPH', label: 'River Graph (DAG)', icon: GitFork },
          { id: 'WATERSHED_BASIN', label: 'Watershed & Drainage Basin', icon: Layers },
          { id: 'HYDRAULIC_PROFILE', label: 'Manning Hydraulic Profile', icon: Activity },
          { id: 'CROSS_SECTION', label: 'Channel Cross-Section & Stage', icon: Gauge },
          { id: 'FLOOD_SIMULATOR', label: '2D Flash Flood Simulator', icon: CloudRain },
          { id: 'GROUNDWATER_QUERY', label: 'Groundwater & TWI Query', icon: Droplets },
          { id: 'VERIFICATION_SUITE', label: `Verification Suite (${passedCount}/15 PASS)`, icon: CheckCircle2 }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`tab-btn-${tab.id}`}
              onClick={() => setActiveTab(tab.id as WorkbenchTab)}
              className={`flex items-center gap-2 px-4 py-2.5 font-medium border-b-2 transition-all whitespace-nowrap ${
                isActive
                  ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Content Area */}
      <div id="hydro-tab-content" className="flex-1 overflow-y-auto p-6">
        
        {/* ========================================================================= */}
        {/* 1. RIVER GRAPH (DAG) VIEW */}
        {/* ========================================================================= */}
        {activeTab === 'RIVER_GRAPH' && (
          <div id="river-graph-view" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Topological DAG Visualizer (2 Cols) */}
            <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-xl p-5 flex flex-col">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <div className="flex items-center gap-2">
                  <GitFork className="w-4 h-4 text-cyan-400" />
                  <h2 className="text-sm font-semibold text-white">Spatial River Directed Acyclic Graph (DAG)</h2>
                </div>
                <span className="text-xs px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono">
                  {currentSegments.length} Segments • {currentNodes.length} Nodes • Monotonic Downhill
                </span>
              </div>

              {/* Interactive Topological Diagram */}
              <div className="flex-1 min-h-[380px] bg-slate-950/90 rounded-lg border border-slate-800/80 p-4 relative overflow-hidden flex flex-col justify-between">
                {/* SVG Connecting Flowlines */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none">
                  <defs>
                    <linearGradient id="riverGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.8" />
                      <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.9" />
                    </linearGradient>
                  </defs>
                  {/* Dynamic branch connectors */}
                  <path d="M 120 70 C 180 120, 220 160, 280 170" stroke="#0284c7" strokeWidth="4" fill="none" strokeDasharray="6 3" />
                  <path d="M 520 70 C 420 120, 360 160, 280 170" stroke="#0ea5e9" strokeWidth="3" fill="none" strokeDasharray="4 2" />
                  <path d="M 280 170 C 300 230, 310 270, 320 330" stroke="url(#riverGrad)" strokeWidth="6" fill="none" />
                </svg>

                {/* Upstream Nodes */}
                <div className="flex justify-between items-center z-10 pt-2 px-8">
                  {currentNodes.filter(n => n.isSource).map((node) => (
                    <div
                      key={node.nodeId}
                      id={`node-btn-${node.nodeId}`}
                      onClick={() => setSelectedNodeId(node.nodeId)}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        selectedNodeId === node.nodeId
                          ? 'bg-cyan-950/80 border-cyan-400 ring-2 ring-cyan-500/30'
                          : 'bg-slate-900/90 border-slate-700 hover:border-slate-500'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-cyan-300">
                        <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                        {node.nodeName.split('(')[0]}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1 font-mono">
                        Elev: {node.bedElevationMeters}m • Q: {node.strahlerOrder === 2 ? '0.65 - 1.85' : '3.85'} m³/s
                      </div>
                    </div>
                  ))}
                </div>

                {/* Intermediate Confluence Nodes */}
                <div className="flex justify-center items-center z-10 py-4">
                  {currentNodes.filter(n => n.isConfluence).map((node) => (
                    <div
                      key={node.nodeId}
                      id={`node-btn-${node.nodeId}`}
                      onClick={() => setSelectedNodeId(node.nodeId)}
                      className={`p-3.5 rounded-lg border cursor-pointer transition-all max-w-sm ${
                        selectedNodeId === node.nodeId
                          ? 'bg-cyan-950/80 border-cyan-400 ring-2 ring-cyan-500/30'
                          : 'bg-slate-900/90 border-slate-700 hover:border-slate-500'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 text-xs font-semibold text-emerald-400">
                        <span className="flex items-center gap-1.5">
                          <GitFork className="w-3.5 h-3.5" />
                          Confluence: {node.nodeName}
                        </span>
                        <span className="px-1.5 py-0.5 bg-emerald-950 border border-emerald-700 rounded text-[10px] text-emerald-300 font-mono">
                          Order {node.strahlerOrder}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-300 mt-1 font-mono">
                        Bed: {node.bedElevationMeters}m • Water Stage: {node.waterSurfaceElevationMeters}m
                      </div>
                    </div>
                  ))}
                </div>

                {/* Outflow Terminal Node */}
                <div className="flex justify-center items-center z-10 pb-2">
                  {currentNodes.filter(n => n.isOutflow).map((node) => (
                    <div
                      key={node.nodeId}
                      id={`node-btn-${node.nodeId}`}
                      onClick={() => setSelectedNodeId(node.nodeId)}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        selectedNodeId === node.nodeId
                          ? 'bg-blue-950/80 border-blue-400 ring-2 ring-blue-500/30'
                          : 'bg-slate-900/90 border-slate-700 hover:border-slate-500'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-blue-300">
                        <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                        Outflow: {node.nodeName}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1 font-mono">
                        Base Level: {node.bedElevationMeters}m • Cumulative Discharge: {metrics.totalActiveDischargeM3S} m³/s
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* River Segments Selection Strip */}
              <div className="mt-4">
                <span className="text-xs text-slate-400 font-medium">Select River Segment:</span>
                <div className="flex gap-2 mt-2 overflow-x-auto pb-1">
                  {currentSegments.map((seg) => (
                    <button
                      key={seg.segmentId}
                      id={`seg-btn-${seg.segmentId}`}
                      onClick={() => {
                        setSelectedSegmentId(seg.segmentId);
                        setManningQ(seg.currentDischargeM3S);
                        setManningW(seg.bankfullWidthMeters);
                        setManningS(seg.gradientPercent / 100);
                        setManningN(seg.manningRoughnessN);
                      }}
                      className={`px-3 py-2 rounded-lg border text-left shrink-0 transition-all text-xs ${
                        selectedSegmentId === seg.segmentId
                          ? 'bg-cyan-950 border-cyan-400 text-cyan-200'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-900'
                      }`}
                    >
                      <div className="font-semibold text-white truncate max-w-[180px]">{seg.segmentName}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        L: {(seg.lengthMeters / 1000).toFixed(1)}km • S: {seg.gradientPercent}% • n: {seg.manningRoughnessN}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Node & Segment Inspector Details (1 Col) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                  <h3 className="text-sm font-semibold text-white">Hydraulic Attribute Inspector</h3>
                  <span className="text-xs px-2 py-0.5 bg-cyan-950 text-cyan-300 rounded border border-cyan-800 font-mono">
                    {selectedSegment.segmentId}
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Segment Name</span>
                    <span className="font-semibold text-white text-sm">{selectedSegment.segmentName}</span>
                    <div className="flex gap-2 mt-1.5">
                      <span className="px-2 py-0.5 bg-slate-800 rounded text-slate-300 font-mono text-[10px]">
                        Strahler Order {selectedSegment.strahlerOrder}
                      </span>
                      <span className="px-2 py-0.5 bg-slate-800 rounded text-cyan-400 font-mono text-[10px]">
                        {selectedSegment.flowRegime}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 font-mono">
                    <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                      <span className="text-slate-500 text-[10px] block">Discharge (Q)</span>
                      <span className="text-cyan-300 font-bold text-sm">{selectedSegment.currentDischargeM3S.toFixed(2)} m³/s</span>
                    </div>
                    <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                      <span className="text-slate-500 text-[10px] block">Velocity (v)</span>
                      <span className="text-emerald-300 font-bold text-sm">{selectedSegment.flowVelocityMS.toFixed(2)} m/s</span>
                    </div>
                    <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                      <span className="text-slate-500 text-[10px] block">Channel Width (W)</span>
                      <span className="text-slate-200 font-bold text-sm">{selectedSegment.bankfullWidthMeters.toFixed(1)} m</span>
                    </div>
                    <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                      <span className="text-slate-500 text-[10px] block">Water Depth (d)</span>
                      <span className="text-slate-200 font-bold text-sm">{selectedSegment.currentDepthMeters.toFixed(2)} m</span>
                    </div>
                    <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                      <span className="text-slate-500 text-[10px] block">Gradient Slope (S)</span>
                      <span className="text-amber-300 font-bold text-sm">{selectedSegment.gradientPercent.toFixed(2)}%</span>
                    </div>
                    <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                      <span className="text-slate-500 text-[10px] block">Manning Roughness (n)</span>
                      <span className="text-amber-300 font-bold text-sm">{selectedSegment.manningRoughnessN.toFixed(3)}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Selected Node Details</span>
                    <span className="font-semibold text-cyan-200">{selectedNode.nodeName}</span>
                    <div className="mt-2 grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-300">
                      <div>Bed Elev: <span className="text-white">{selectedNode.bedElevationMeters}m</span></div>
                      <div>Surface Elev: <span className="text-white">{selectedNode.waterSurfaceElevationMeters}m</span></div>
                      <div>Depth: <span className="text-white">{selectedNode.waterDepthMeters}m</span></div>
                      <div>Width: <span className="text-white">{selectedNode.channelWidthMeters}m</span></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Validated DAG topology with continuous upstream-downstream mass balance.</span>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 2. WATERSHED & DRAINAGE BASIN VIEW */}
        {/* ========================================================================= */}
        {activeTab === 'WATERSHED_BASIN' && (
          <div id="watershed-basin-view" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-xl p-5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-cyan-400" />
                  <h2 className="text-sm font-semibold text-white">Drainage Catchment & Macro-Basin Profile</h2>
                </div>
                <span className="text-xs px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono">
                  {currentBasin.macroRegion}
                </span>
              </div>

              {/* Geographic Bounding Extents Map / Visualization */}
              <div className="bg-slate-950 rounded-lg border border-slate-800 p-4 relative min-h-[300px] flex flex-col justify-between">
                <div className="flex justify-between items-start text-xs">
                  <div>
                    <span className="text-slate-400">Catchment Name:</span>
                    <h3 className="text-base font-bold text-white mt-0.5">{currentBasin.basinName}</h3>
                  </div>
                  <div className="text-right font-mono">
                    <span className="text-slate-400 text-[11px]">Drainage Area</span>
                    <div className="text-lg font-bold text-cyan-400">{currentBasin.drainageAreaKm2.toLocaleString()} km²</div>
                  </div>
                </div>

                {/* Bounding Polygon Diagram */}
                <div className="my-4 h-44 bg-slate-900/60 rounded border border-slate-800/80 relative flex items-center justify-center overflow-hidden">
                  <svg className="w-full h-full">
                    {/* Catchment Polygon */}
                    <polygon
                      points="120,40 380,30 480,110 360,150 140,130"
                      fill="rgba(6, 182, 212, 0.12)"
                      stroke="#06b6d4"
                      strokeWidth="2"
                      strokeDasharray="4 2"
                    />
                    {/* Mainstem River */}
                    <path d="M 380 40 Q 320 90 280 140" stroke="#38bdf8" strokeWidth="4" fill="none" />
                    {/* Tributary */}
                    <path d="M 440 80 Q 340 100 280 140" stroke="#7dd3fc" strokeWidth="2" fill="none" />
                  </svg>
                  <div className="absolute top-2 left-3 text-[11px] font-mono text-slate-400">
                    Catchment Perimeter: {currentBasin.boundingPolyCoordinates.length} Geodetic Vertices
                  </div>
                  <div className="absolute bottom-2 right-3 text-[11px] font-mono text-cyan-300">
                    Drainage Density: {currentBasin.drainageDensityKmPerKm2} km/km²
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 text-xs font-mono">
                  <div className="p-2.5 bg-slate-900/80 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">Mean Elevation</span>
                    <span className="text-white font-bold">{currentBasin.meanElevationMeters} m</span>
                  </div>
                  <div className="p-2.5 bg-slate-900/80 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">Elevation Relief</span>
                    <span className="text-white font-bold">{currentBasin.maxElevationMeters - currentBasin.minElevationMeters} m</span>
                  </div>
                  <div className="p-2.5 bg-slate-900/80 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">Mean Annual Precip</span>
                    <span className="text-cyan-300 font-bold">{currentBasin.meanAnnualPrecipitationMm} mm/yr</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Basin Hydrologic Response Characteristics */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white pb-3 border-b border-slate-800 mb-4">
                  Basin Response & Runoff Physics
                </h3>

                <div className="space-y-3.5 text-xs font-mono">
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Time of Concentration (tc):</span>
                      <span className="text-amber-400 font-bold">{currentBasin.timeOfConcentrationHours} Hours</span>
                    </div>
                    <p className="text-[10px] text-slate-500 font-sans mt-1">
                      Time required for runoff from the most hydrologically distant point to reach the basin outlet.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Runoff Coefficient (C):</span>
                      <span className="text-cyan-400 font-bold">{currentBasin.averageRunoffCoefficient}</span>
                    </div>
                    <p className="text-[10px] text-slate-500 font-sans mt-1">
                      Proportion of total storm rainfall converted directly into streamflow vs infiltration.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Baseflow Contribution:</span>
                      <span className="text-emerald-400 font-bold">{currentBasin.baseflowContributionPercent}%</span>
                    </div>
                    <p className="text-[10px] text-slate-500 font-sans mt-1">
                      Perennial stream discharge sustained by groundwater seepage between precipitation events.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Aquifer Recharge:</span>
                      <span className="text-blue-400 font-bold">{currentBasin.aquiferRechargeRateMmYear} mm/yr</span>
                    </div>
                    <p className="text-[10px] text-slate-500 font-sans mt-1">
                      Net annual precipitation infiltrating through bedrock strata into deep groundwater reservoirs.
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400">
                Data calibrated from USGS Streamgage networks & HydroSHEDS topological basin delineations.
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 3. MANNING HYDRAULIC PROFILE VIEW */}
        {/* ========================================================================= */}
        {activeTab === 'HYDRAULIC_PROFILE' && (
          <div id="hydraulic-profile-view" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Interactive Calculator Controls (1 Col) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-sm font-semibold text-white">Manning Hydraulic Controls</h3>
                </div>
              </div>

              <div className="space-y-4 text-xs">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Discharge Q (m³/s):</span>
                    <span className="font-mono text-cyan-400 font-bold">{manningQ.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="50.0"
                    step="0.1"
                    value={manningQ}
                    onChange={(e) => setManningQ(parseFloat(e.target.value))}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Channel Width W (m):</span>
                    <span className="font-mono text-cyan-400 font-bold">{manningW.toFixed(1)}</span>
                  </div>
                  <input
                    type="range"
                    min="2.0"
                    max="50.0"
                    step="0.5"
                    value={manningW}
                    onChange={(e) => setManningW(parseFloat(e.target.value))}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Bed Slope S (dh/dL):</span>
                    <span className="font-mono text-amber-400 font-bold">{(manningS * 100).toFixed(2)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.001"
                    max="0.08"
                    step="0.001"
                    value={manningS}
                    onChange={(e) => setManningS(parseFloat(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Manning Roughness n:</span>
                    <span className="font-mono text-amber-400 font-bold">{manningN.toFixed(3)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.020"
                    max="0.075"
                    step="0.002"
                    value={manningN}
                    onChange={(e) => setManningN(parseFloat(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-[11px] text-slate-400">
                  <div className="font-semibold text-slate-200 mb-1">Open-Channel Equation:</div>
                  <div className="font-mono text-cyan-300">v = (1 / n) • R_h^(2/3) • S^(1/2)</div>
                  <div className="font-mono text-cyan-300 mt-0.5">Q = v • A = v • (W • d)</div>
                </div>
              </div>
            </div>

            {/* Hydraulic Results & Longitudinal Profile (2 Cols) */}
            <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                  <h3 className="text-sm font-semibold text-white">Instantaneous Open-Channel Hydraulic Solution</h3>
                  <span className={`text-xs px-2.5 py-1 rounded font-mono font-bold ${
                    manningResult.flowRegime === 'Supercritical'
                      ? 'bg-rose-950 text-rose-300 border border-rose-800'
                      : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  }`}>
                    {manningResult.flowRegime} Flow (Fr = {manningResult.froudeNumberFr})
                  </span>
                </div>

                {/* Hydraulic Metric Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs mb-6">
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">Flow Velocity (v)</span>
                    <span className="text-emerald-400 font-bold text-lg">{manningResult.flowVelocityV} m/s</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">Water Depth (d)</span>
                    <span className="text-cyan-400 font-bold text-lg">{manningResult.waterDepthD} m</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">Hydraulic Radius (Rh)</span>
                    <span className="text-blue-400 font-bold text-lg">{manningResult.hydraulicRadiusRh} m</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">Wetted Area (A)</span>
                    <span className="text-slate-200 font-bold text-lg">{manningResult.crossSectionalAreaA} m²</span>
                  </div>
                </div>

                {/* Longitudinal Stream Bed & Water Surface Chart */}
                <div className="p-4 bg-slate-950 rounded-lg border border-slate-800">
                  <div className="flex justify-between items-center text-xs mb-2">
                    <span className="font-semibold text-slate-300">Longitudinal Elevation Profile (Upstream → Downstream)</span>
                    <div className="flex gap-4 text-[11px] font-mono">
                      <span className="flex items-center gap-1.5 text-amber-400">
                        <span className="w-2.5 h-0.5 bg-amber-400"></span> Channel Bed
                      </span>
                      <span className="flex items-center gap-1.5 text-cyan-400">
                        <span className="w-2.5 h-0.5 bg-cyan-400"></span> Water Surface (Hydro-flattened)
                      </span>
                    </div>
                  </div>

                  <div className="h-44 w-full relative flex items-end">
                    <svg className="w-full h-full">
                      {/* Bed Profile */}
                      <path
                        d="M 20 20 L 150 50 L 320 90 L 480 120 L 620 150"
                        stroke="#f59e0b"
                        strokeWidth="3"
                        fill="none"
                      />
                      {/* Water Surface Profile */}
                      <path
                        d="M 20 16 L 150 46 L 320 85 L 480 114 L 620 144"
                        stroke="#06b6d4"
                        strokeWidth="3"
                        fill="none"
                      />
                      {/* Water Body Fill */}
                      <polygon
                        points="20,16 150,46 320,85 480,114 620,144 620,150 480,120 320,90 150,50 20,20"
                        fill="rgba(6, 182, 212, 0.25)"
                      />
                    </svg>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
                <span>Froude Number Fr = v / √(g • d) validates hydraulic transition states.</span>
                <span className="font-mono text-cyan-300">Newton-Raphson Converged</span>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 4. CHANNEL CROSS-SECTION & STAGE VIEW */}
        {/* ========================================================================= */}
        {activeTab === 'CROSS_SECTION' && (
          <div id="cross-section-view" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-xl p-5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <div className="flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-cyan-400" />
                  <h2 className="text-sm font-semibold text-white">Channel Bathymetry & Stage Cross-Section</h2>
                </div>
                <span className="text-xs px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono">
                  {selectedSegment.segmentName}
                </span>
              </div>

              {/* Cross-Sectional Diagram */}
              <div className="h-64 bg-slate-950 rounded-lg border border-slate-800 p-4 relative flex items-center justify-center overflow-hidden">
                <svg className="w-full h-full" viewBox="0 0 500 200">
                  {/* Bankfull / Terraced Canyon Bed */}
                  <polygon
                    points="40,30 110,130 180,170 320,170 390,130 460,30 460,200 40,200"
                    fill="#1e293b"
                    stroke="#475569"
                    strokeWidth="2"
                  />
                  {/* Active Water Surface */}
                  <polygon
                    points="120,130 180,170 320,170 380,130"
                    fill="rgba(6, 182, 212, 0.35)"
                    stroke="#06b6d4"
                    strokeWidth="3"
                  />
                  {/* Floodplain Inundation Stage */}
                  <line x1="80" y1="90" x2="420" y2="90" stroke="#f43f5e" strokeWidth="2" strokeDasharray="4 2" />
                  <text x="85" y="82" fill="#f43f5e" fontSize="10" fontFamily="monospace">100-Yr Flood Stage (Stage Rise +2.4m)</text>
                  <text x="130" y="122" fill="#06b6d4" fontSize="10" fontFamily="monospace">Bankfull Baseflow Stage (d = {manningResult.waterDepthD}m)</text>
                </svg>
              </div>

              <div className="mt-4 grid grid-cols-3 gap-3 text-xs font-mono">
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Top Width (W)</span>
                  <span className="text-white font-bold">{manningW.toFixed(1)} meters</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Bankfull Depth (D)</span>
                  <span className="text-cyan-400 font-bold">{selectedSegment.bankfullDepthMeters.toFixed(2)} meters</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Wetted Perimeter (P)</span>
                  <span className="text-blue-400 font-bold">{(manningW + 2 * manningResult.waterDepthD).toFixed(2)} meters</span>
                </div>
              </div>
            </div>

            {/* Leopold-Maddock Downstream Hydraulic Scaling (1 Col) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white pb-3 border-b border-slate-800 mb-4">
                  Leopold-Maddock Geometry Laws
                </h3>

                <div className="space-y-3 text-xs font-mono">
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[10px] block">Width Law (W = a • Q^0.5)</span>
                    <span className="text-cyan-300 font-bold">W ∝ Q^0.50</span>
                    <p className="text-[10px] text-slate-500 font-sans mt-1">
                      Channel width expands with the square root of discharge downstream.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[10px] block">Depth Law (D = c • Q^0.4)</span>
                    <span className="text-emerald-300 font-bold">D ∝ Q^0.40</span>
                    <p className="text-[10px] text-slate-500 font-sans mt-1">
                      Water depth scales with 0.4 exponent to conserve open-channel conveyance.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[10px] block">Velocity Law (v = k • Q^0.1)</span>
                    <span className="text-amber-300 font-bold">v ∝ Q^0.10</span>
                    <p className="text-[10px] text-slate-500 font-sans mt-1">
                      Flow velocity increases gradually downstream as channel resistance drops.
                    </p>
                  </div>

                  <div className="p-2.5 bg-cyan-950/40 border border-cyan-800/60 rounded text-[10px] text-cyan-300 font-sans">
                    Exponent Conservation: 0.50 + 0.40 + 0.10 = 1.00 (Mass Continuously Conserved)
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400">
                Prevents unphysical water pooling or artificial canyon river widening.
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 5. 2D FLASH FLOOD & RUNOFF SIMULATOR */}
        {/* ========================================================================= */}
        {activeTab === 'FLOOD_SIMULATOR' && (
          <div id="flood-simulator-view" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Storm Event Parameters (1 Col) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <div className="flex items-center gap-2">
                  <CloudRain className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-sm font-semibold text-white">Storm Precipitation Controls</h3>
                </div>
              </div>

              <div className="space-y-4 text-xs">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Rainfall Intensity:</span>
                    <span className="font-mono text-cyan-400 font-bold">{rainIntensity} mm/hr</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="80"
                    step="5"
                    value={rainIntensity}
                    onChange={(e) => setRainIntensity(parseFloat(e.target.value))}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Storm Duration:</span>
                    <span className="font-mono text-cyan-400 font-bold">{stormDuration} Hours</span>
                  </div>
                  <input
                    type="range"
                    min="1.0"
                    max="12.0"
                    step="0.5"
                    value={stormDuration}
                    onChange={(e) => setStormDuration(parseFloat(e.target.value))}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div>
                  <span className="text-slate-300 block mb-1.5">Antecedent Moisture:</span>
                  <div className="grid grid-cols-3 gap-2">
                    {(['Dry', 'Moderate', 'Saturated'] as const).map((m) => (
                      <button
                        key={m}
                        onClick={() => setSoilMoisture(m)}
                        className={`py-1.5 rounded border text-center transition-all ${
                          soilMoisture === m
                            ? 'bg-cyan-950 border-cyan-400 text-cyan-300 font-semibold'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-900'
                        }`}
                      >
                        {m}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Timeline Slider */}
                <div className="pt-2 border-t border-slate-800">
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span className="flex items-center gap-1">
                      <span>Simulation Timeline:</span>
                    </span>
                    <span className="font-mono text-emerald-400 font-bold">t = {floodPlayTime.toFixed(1)} h</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="24"
                    step="0.5"
                    value={floodPlayTime}
                    onChange={(e) => setFloodPlayTime(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />

                  <div className="flex gap-2 mt-3">
                    <button
                      onClick={() => setIsFloodPlaying(!isFloodPlaying)}
                      className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg font-semibold text-xs transition-all ${
                        isFloodPlaying
                          ? 'bg-amber-600 text-white'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                      }`}
                    >
                      <Play className="w-3.5 h-3.5" />
                      {isFloodPlaying ? 'Pause Simulation' : 'Run Storm Timeline'}
                    </button>
                    <button
                      onClick={() => setFloodPlayTime(0)}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 font-mono text-[11px] space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Current Q(t):</span>
                    <span className="text-cyan-300 font-bold">{activeHydroPoint.dischargeM3S.toFixed(1)} m³/s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Water Stage:</span>
                    <span className="text-amber-300 font-bold">+{activeHydroPoint.waterStageMeters.toFixed(2)} m</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Inundated Area:</span>
                    <span className="text-rose-300 font-bold">{(activeHydroPoint.inundatedAreaM2 / 1000).toFixed(0)}k m²</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Hydrograph Curve & 2D Raster Inundation Heatmap (2 Cols) */}
            <div className="lg:col-span-2 space-y-6">
              {/* Unit Hydrograph Curve */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                  <h3 className="text-sm font-semibold text-white">Storm Discharge Hydrograph (SCS Unit Formulation)</h3>
                  <span className="text-xs text-slate-400 font-mono">Q_peak: {Math.max(...hydrographPoints.map(p => p.dischargeM3S)).toFixed(1)} m³/s</span>
                </div>

                <div className="h-36 bg-slate-950 rounded-lg border border-slate-800 p-3 relative flex items-end">
                  <svg className="w-full h-full" viewBox="0 0 500 120">
                    {/* Hydrograph Curve */}
                    <path
                      d="M 10 110 Q 80 105 140 25 T 260 85 T 490 110"
                      stroke="#06b6d4"
                      strokeWidth="3"
                      fill="none"
                    />
                    <polygon
                      points="10,110 80,105 140,25 260,85 490,110 490,115 10,115"
                      fill="rgba(6, 182, 212, 0.18)"
                    />
                    {/* Current time marker */}
                    <line
                      x1={`${(floodPlayTime / 24) * 480 + 10}`}
                      y1="0"
                      x2={`${(floodPlayTime / 24) * 480 + 10}`}
                      y2="120"
                      stroke="#10b981"
                      strokeWidth="2"
                      strokeDasharray="3 3"
                    />
                  </svg>
                  <div className="absolute top-2 right-3 text-[10px] font-mono text-emerald-400">
                    Active Cursor: t = {floodPlayTime.toFixed(1)}h
                  </div>
                </div>
              </div>

              {/* 2D 32x32 Cellular Inundation Grid Heatmap */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-rose-400" />
                    <h3 className="text-sm font-semibold text-white">2D Diffusive Wave Cellular Inundation Grid (32×32)</h3>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-mono">
                    <span className="flex items-center gap-1 text-cyan-400">
                      <span className="w-2 h-2 rounded-sm bg-cyan-600"></span> Channel
                    </span>
                    <span className="flex items-center gap-1 text-rose-400">
                      <span className="w-2 h-2 rounded-sm bg-rose-600"></span> Floodplain Overflow
                    </span>
                  </div>
                </div>

                {/* 32x32 Grid Rendering */}
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex justify-center">
                  <div className="grid grid-cols-32 gap-[1px] bg-slate-900 p-1 rounded max-w-full overflow-hidden" style={{ gridTemplateColumns: 'repeat(32, minmax(0, 1fr))' }}>
                    {flood2DGrid.map((row, r) =>
                      row.map((cell, c) => {
                        let bg = 'bg-slate-800/40';
                        if (cell.isChannelCell) bg = 'bg-cyan-500';
                        else if (cell.isInundated) {
                          if (cell.waterDepthMeters > 1.5) bg = 'bg-rose-500';
                          else if (cell.waterDepthMeters > 0.6) bg = 'bg-amber-500';
                          else bg = 'bg-blue-500';
                        }
                        return (
                          <div
                            key={`${r}-${c}`}
                            title={`Cell [${r},${c}] Depth: ${cell.waterDepthMeters}m`}
                            className={`w-2.5 h-2.5 ${bg} rounded-[0.5px] transition-colors`}
                          />
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 6. GROUNDWATER & TWI QUERY TOOL */}
        {/* ========================================================================= */}
        {activeTab === 'GROUNDWATER_QUERY' && (
          <div id="groundwater-query-view" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5">
              <h3 className="text-sm font-semibold text-white pb-3 border-b border-slate-800 mb-4">
                Spatial Point Hydrologic Query
              </h3>

              <div className="space-y-4 text-xs">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Surface Elevation:</span>
                    <span className="font-mono text-cyan-400 font-bold">{querySurfaceElev} m</span>
                  </div>
                  <input
                    type="range"
                    min="1190"
                    max="2200"
                    step="10"
                    value={querySurfaceElev}
                    onChange={(e) => setQuerySurfaceElev(parseFloat(e.target.value))}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Distance to Stream:</span>
                    <span className="font-mono text-cyan-400 font-bold">{queryDistToStream} m</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="1000"
                    step="5"
                    value={queryDistToStream}
                    onChange={(e) => setQueryDistToStream(parseFloat(e.target.value))}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Local Terrain Slope:</span>
                    <span className="font-mono text-amber-400 font-bold">{querySlopePercent}%</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="80"
                    step="1"
                    value={querySlopePercent}
                    onChange={(e) => setQuerySlopePercent(parseFloat(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-[11px] text-slate-400">
                  <div className="font-semibold text-slate-200 mb-1">Topographic Wetness Index (TWI):</div>
                  <div className="font-mono text-cyan-300">TWI = ln( a / tan(β) )</div>
                  <p className="text-[10px] text-slate-500 font-sans mt-1">
                    Quantifies topographic control on hydrological processes and water table depth.
                  </p>
                </div>
              </div>
            </div>

            {/* Groundwater Output & Aquifer Cells (2 Cols) */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5">
                <h3 className="text-sm font-semibold text-white pb-3 border-b border-slate-800 mb-4">
                  Estimated Water Table & Soil Saturation
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs mb-4">
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">Water Table Depth</span>
                    <span className="text-cyan-400 font-bold text-lg">{groundwaterResult.waterTableDepthMeters} m</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">Water Table Elev</span>
                    <span className="text-white font-bold text-lg">{groundwaterResult.waterTableElevationMeters} m</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">Soil Saturation</span>
                    <span className="text-emerald-400 font-bold text-lg">{groundwaterResult.saturationPercent}%</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">Topographic Wetness</span>
                    <span className="text-blue-400 font-bold text-lg">{groundwaterResult.topographicWetnessIndex}</span>
                  </div>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-lg border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
                  <div>
                    <span className="text-slate-500 text-[10px] block">Aquifer Hydrogeology</span>
                    <span className="font-semibold text-cyan-200">Zion Navajo Sandstone Aquifer Formation</span>
                  </div>
                  <div className="text-right font-mono text-[11px] text-slate-400">
                    Hydraulic Conductivity: 1.45 m/day • Porosity: 28%
                  </div>
                </div>
              </div>

              {/* Verified Benchmark Aquifer Ingest Cells */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5">
                <h4 className="text-xs font-semibold text-slate-300 mb-3">Documented Field Piezometer Cells</h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                  {engine.getAquiferCells().map((cell) => (
                    <div key={cell.cellId} className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                      <div className="text-cyan-300 font-semibold mb-1">{cell.cellId}</div>
                      <div className="text-slate-400 text-[11px]">Surface: {cell.groundSurfaceElevationMeters}m</div>
                      <div className="text-emerald-400 text-[11px]">Water Table Depth: {cell.waterTableDepthMeters}m</div>
                      <div className="text-slate-500 text-[10px] mt-1">Baseflow: {cell.baseflowSeepageM3SPerKm2} m³/s/km²</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 7. VERIFICATION SUITE (TC-501 to TC-515) */}
        {/* ========================================================================= */}
        {activeTab === 'VERIFICATION_SUITE' && (
          <div id="verification-suite-view" className="space-y-6">
            {/* Test Summary Header */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-base font-bold text-white">Phase 5 Automated Hydrology Test Suite</h2>
                  <span className="px-2.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono text-xs font-bold">
                    {passedCount} / 15 TESTS PASSING
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Rigorous automated assertions for DAG topology, open-channel Manning hydraulics, mass balance, flood dynamics, and cross-phase regression immunity.
                </p>
              </div>

              <button
                id="run-tests-btn"
                onClick={handleRunTests}
                disabled={isRunningTests}
                className="flex items-center gap-2 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-sm transition-all"
              >
                <RotateCcw className={`w-3.5 h-3.5 ${isRunningTests ? 'animate-spin' : ''}`} />
                {isRunningTests ? 'Executing Suite...' : 'Re-Run All 15 Tests'}
              </button>
            </div>

            {/* Test Case Results Table */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase font-mono text-[11px]">
                    <tr>
                      <th className="py-3 px-4">Test ID</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4">Verification Scope</th>
                      <th className="py-3 px-4">Measured vs Expected</th>
                      <th className="py-3 px-4">Tolerance</th>
                      <th className="py-3 px-4 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-sans">
                    {testResults.map((test) => (
                      <tr key={test.id} id={`test-row-${test.id}`} className="hover:bg-slate-800/30 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-cyan-300 whitespace-nowrap">
                          {test.id}
                        </td>
                        <td className="py-3 px-4 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                          {test.category}
                        </td>
                        <td className="py-3 px-4 max-w-xs">
                          <div className="font-semibold text-slate-200">{test.name}</div>
                          <div className="text-[11px] text-slate-400 mt-0.5">{test.description}</div>
                        </td>
                        <td className="py-3 px-4 font-mono text-[11px] max-w-sm">
                          <div className="text-emerald-300 font-medium truncate">{test.measuredValue}</div>
                          <div className="text-slate-500 text-[10px] truncate">{test.expectedValue}</div>
                        </td>
                        <td className="py-3 px-4 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                          {test.tolerance}
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded font-mono text-[11px] font-bold ${
                            test.status === 'PASS'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-rose-950 text-rose-400 border border-rose-800'
                          }`}>
                            {test.status === 'PASS' ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <XCircle className="w-3.5 h-3.5 text-rose-400" />
                            )}
                            {test.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
