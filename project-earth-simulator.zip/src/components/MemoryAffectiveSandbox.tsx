import { useState, useMemo, FormEvent } from 'react';
import { CognitiveMemory, PADState } from '../types';
import { 
  Brain, 
  Search, 
  Plus, 
  Clock, 
  Sparkles, 
  RefreshCcw, 
  Activity, 
  TrendingUp, 
  Zap, 
  Heart, 
  Flame, 
  Smile, 
  HelpCircle,
  Eye,
  EyeOff,
  User,
  CheckCircle2,
  AlertTriangle,
  Moon,
  Info,
  Layers,
  MapPin,
  Compass
} from 'lucide-react';

const INITIAL_MEMORIES: CognitiveMemory[] = [
  // 1. Sensory Memory Traces (Very temporary, high flow)
  {
    id: 'sens-1',
    description: 'A swift flash of crimson taillights in the thick evening river mist',
    category: 'Sensory Trace',
    timestamp: 11,
    baseSalience: 0.4,
    valence: -0.1,
    layer: 'sensory',
    decayFactor: 0.15
  },
  {
    id: 'sens-2',
    description: 'The cold damp smell of moss and wet limestone near the riverbank',
    category: 'Sensory Trace',
    timestamp: 12,
    baseSalience: 0.5,
    valence: 0.1,
    layer: 'sensory',
    decayFactor: 0.25
  },
  // 2. Working Memory Nodes (Immediate attentional focus)
  {
    id: 'work-1',
    description: 'Checking the silver pocket watch to meet Chloe Sterling at exactly 18:00',
    category: 'Attentional Focus',
    timestamp: 12,
    baseSalience: 0.9,
    valence: 0.2,
    layer: 'working',
    decayFactor: 0.85,
    associatedEntityId: 'Chloe Sterling'
  },
  // 3. Short-Term Memories (Intermediate buffer)
  {
    id: 'st-1',
    description: 'Reviewed cartographic GIS coordinates for the regional watershed model',
    category: 'Intellectual',
    timestamp: 10,
    baseSalience: 0.65,
    valence: 0.3,
    layer: 'short-term',
    decayFactor: 0.68
  },
  {
    id: 'st-2',
    description: 'Shared an animated discussion regarding urban zoning borders at the local pub',
    category: 'Social',
    timestamp: 8,
    baseSalience: 0.72,
    valence: 0.6,
    layer: 'short-term',
    decayFactor: 0.54,
    associatedEntityId: 'Dr. Sterling'
  },
  // 4. Long-Term Episodic Memories (Detailed narrative personal history)
  {
    id: 'ep-1',
    description: 'Spent a quiet evening drinking warm cinnamon coffee with Chloe Sterling at the neighborhood cafe',
    category: 'Social',
    timestamp: 2,
    baseSalience: 0.9,
    valence: 0.95,
    layer: 'episodic',
    decayFactor: 0.92,
    associatedEntityId: 'Chloe Sterling',
    reinforcementCount: 3
  },
  {
    id: 'ep-2',
    description: 'Fierce argument regarding office rent sharing and workspace tidiness at the collective office',
    category: 'Conflict',
    timestamp: 5,
    baseSalience: 0.85,
    valence: -0.75,
    layer: 'episodic',
    decayFactor: 0.88,
    associatedEntityId: 'Dr. Sterling',
    reinforcementCount: 1
  },
  // 5. Semantic Memories (Abstracted facts, concepts, identity schemas)
  {
    id: 'sem-1',
    description: 'Chloe Sterling is an expert mapmaker who values precision and enjoys high-grade coffee',
    category: 'Relational Schema',
    timestamp: 1,
    baseSalience: 0.95,
    valence: 0.8,
    layer: 'semantic',
    decayFactor: 1.0,
    associatedEntityId: 'Chloe Sterling'
  },
  {
    id: 'sem-2',
    description: 'Rent is due on the 1st of each month; utility invoices arrive digitally via bank prompt',
    category: 'Systemic Schema',
    timestamp: 1,
    baseSalience: 0.8,
    valence: 0.0,
    layer: 'semantic',
    decayFactor: 1.0
  },
  // 6. Procedural Memories (Skills, habits, automation sequences)
  {
    id: 'proc-1',
    description: 'Skill: Cartographic GIS Layer Alignment (Saves 25% energy during mapping tasks)',
    category: 'Skill Mastery',
    timestamp: 1,
    baseSalience: 0.9,
    valence: 0.5,
    layer: 'procedural',
    decayFactor: 1.0,
    associatedSkill: 'Cartography'
  },
  {
    id: 'proc-2',
    description: 'Habit: Deep breathing exercises triggered automatically when stress levels exceed 0.75',
    category: 'Stress Regulation',
    timestamp: 1,
    baseSalience: 0.85,
    valence: 0.6,
    layer: 'procedural',
    decayFactor: 1.0
  },
  // 7. Emotional Memories (Deep conditioned affective states, triggers, traumas)
  {
    id: 'emo-1',
    description: 'Trauma: Slipped on a loose limestone slab and nearly fell into the swollen, roaring river',
    category: 'Survival Threat',
    timestamp: 12,
    baseSalience: 0.98,
    valence: -0.95,
    layer: 'emotional',
    decayFactor: 0.97,
    isSuppressed: false,
    reinforcementCount: 5
  }
];

interface StimulusEvent {
  id: string;
  name: string;
  description: string;
  deltaP: number;
  deltaA: number;
  deltaD: number;
  icon: string;
}

const STIMULUS_EVENTS: StimulusEvent[] = [
  {
    id: 'praise',
    name: 'Receive Sincere Praise',
    description: 'Elevates pleasure, raises arousal, and increases feeling of control/dominance.',
    deltaP: 0.4,
    deltaA: 0.2,
    deltaD: 0.3,
    icon: '🌸'
  },
  {
    id: 'criticism',
    name: 'Severe Technical Criticism',
    description: 'Reduces pleasure, spikes arousal, and diminishes dominance/confidence.',
    deltaP: -0.4,
    deltaA: 0.5,
    deltaD: -0.3,
    icon: '💥'
  },
  {
    id: 'danger',
    name: 'Encounter Active Hazard',
    description: 'Deeply negative pleasure, extreme arousal, and low dominance.',
    deltaP: -0.6,
    deltaA: 0.8,
    deltaD: -0.5,
    icon: '⚡'
  },
  {
    id: 'windfall',
    name: 'Secure Financial Windfall',
    description: 'Increases security, spikes pleasure and dominance.',
    deltaP: 0.5,
    deltaA: 0.3,
    deltaD: 0.4,
    icon: '💰'
  },
  {
    id: 'meditation',
    name: 'Enter State of Meditation',
    description: 'Slows down arousal, increases pleasure, and brings balanced dominance.',
    deltaP: 0.3,
    deltaA: -0.5,
    deltaD: 0.2,
    icon: '🧘'
  },
  {
    id: 'overload',
    name: 'Sensory Cognitive Overload',
    description: 'Neutral/negative pleasure, very high arousal, but very low feelings of control.',
    deltaP: -0.2,
    deltaA: 0.7,
    deltaD: -0.4,
    icon: '🧠'
  }
];

export default function MemoryAffectiveSandbox() {
  // Memory States
  const [memories, setMemories] = useState<CognitiveMemory[]>(INITIAL_MEMORIES);
  const [newDesc, setNewDesc] = useState('');
  const [newCat, setNewCat] = useState('Social');
  const [newLayer, setNewLayer] = useState<'sensory' | 'working' | 'short-term' | 'episodic' | 'semantic' | 'procedural' | 'emotional'>('working');
  const [newValence, setNewValence] = useState(0.5);
  const [newSalience, setNewSalience] = useState(0.8);
  const [newEntity, setNewEntity] = useState('None');
  const [timeStep, setTimeStep] = useState(12); // current simulation hour index
  const [searchQuery, setSearchQuery] = useState('');

  // RAG Context Settings
  const [activeGoalFilter, setActiveGoalFilter] = useState<'None' | 'Survive' | 'Socialize' | 'Earn Money' | 'Work'>('None');
  const [activeNeedFilter, setActiveNeedFilter] = useState<'None' | 'Social Belonging' | 'Physiological' | 'Safety' | 'Esteem'>('None');
  const [activeNearbyFilter, setActiveNearbyFilter] = useState<'None' | 'Chloe Sterling' | 'Dr. Sterling' | 'John Doe'>('None');

  // Personality sliders
  const [neuroticism, setNeuroticism] = useState(0.45); // modulates traumatic suppression & forgetting speed
  const [suppressTrauma, setSuppressTrauma] = useState(true);

  // PAD Emotional Coordinates
  const [pad, setPad] = useState<PADState>({
    pleasure: 0.2,
    arousal: 0.1,
    dominance: 0.3
  });

  const [lastEvent, setLastEvent] = useState<string>('System Initialized: Seven-Layer Memory Architecture Online.');
  const [consolidationLogs, setConsolidationLogs] = useState<string[]>([
    'System initialization: Pre-populated 7 discrete cognitive memory classes.',
    'Formulated memory dynamics model with emotional decay coupling.',
    'Contextual multi-factor RAG vector matching loaded.'
  ]);

  // Adjust PAD Slider directly
  const handlePADChange = (key: keyof PADState, value: number) => {
    setPad((prev) => ({
      ...prev,
      [key]: Math.max(-1.0, Math.min(1.0, value))
    }));
  };

  const addLog = (log: string) => {
    setConsolidationLogs((prev) => [log, ...prev].slice(0, 20));
  };

  // Inject a custom memory
  const handleAddMemory = (e: FormEvent) => {
    e.preventDefault();
    if (!newDesc.trim()) return;

    const newMem: CognitiveMemory = {
      id: `mem-${Date.now()}`,
      description: newDesc,
      category: newCat,
      timestamp: timeStep,
      baseSalience: newSalience,
      valence: newValence,
      layer: newLayer,
      decayFactor: 1.0,
      associatedEntityId: newEntity !== 'None' ? newEntity : undefined,
      reinforcementCount: 0,
      distortionCount: 0
    };

    setMemories((prev) => [newMem, ...prev]);
    setNewDesc('');
    setLastEvent(`Injected experiential node into Layer [${newMem.layer.toUpperCase()}]: "${newMem.description.substring(0, 30)}..."`);
    addLog(`[INJECTION] Manual entry added directly to ${newMem.layer.toUpperCase()} Layer.`);
  };

  // Delete/Prune specific memory
  const handleDeleteMemory = (id: string) => {
    setMemories((prev) => prev.filter((m) => m.id !== id));
    addLog(`[PRUNE] Manually erased cognitive element.`);
  };

  // Emotional Event Stimulus Trigger
  const triggerStimulus = (event: StimulusEvent) => {
    setPad((prev) => {
      const nextP = Math.max(-1.0, Math.min(1.0, prev.pleasure + event.deltaP));
      const nextA = Math.max(-1.0, Math.min(1.0, prev.arousal + event.deltaA));
      const nextD = Math.max(-1.0, Math.min(1.0, prev.dominance + event.deltaD));
      return { pleasure: nextP, arousal: nextA, dominance: nextD };
    });

    setLastEvent(`Triggered environmental stimulus: ${event.name}`);

    // Create sensory memory traces instantly
    const sensoryTrace: CognitiveMemory = {
      id: `sens-tr-${Date.now()}`,
      description: `Raw sensory shock wave from: ${event.name}`,
      category: 'Sensory Trace',
      timestamp: timeStep,
      baseSalience: 0.9,
      valence: event.deltaP,
      layer: 'sensory',
      decayFactor: 0.95
    };

    // Create an active working memory focus
    const workingFocus: CognitiveMemory = {
      id: `work-focus-${Date.now()}`,
      description: `Actively focusing on emotional response to: ${event.name}`,
      category: 'Attentional Focus',
      timestamp: timeStep,
      baseSalience: Math.abs(event.deltaP * 1.5),
      valence: event.deltaP,
      layer: 'working',
      decayFactor: 1.0
    };

    // If highly emotional, also trigger emotional conditioning (Layer 7)
    const emotionalConditioning: CognitiveMemory | null = Math.abs(event.deltaP) > 0.5 ? {
      id: `emo-cond-${Date.now()}`,
      description: `Conditioned reflex: ${event.name} triggers autonomic PAD shift [P:${event.deltaP}, A:${event.deltaA}, D:${event.deltaD}]`,
      category: 'Conditioned Emotion',
      timestamp: timeStep,
      baseSalience: Math.abs(event.deltaP),
      valence: event.deltaP,
      layer: 'emotional',
      decayFactor: 0.98
    } : null;

    setMemories((prev) => {
      const list = [sensoryTrace, workingFocus, ...prev];
      if (emotionalConditioning) {
        list.unshift(emotionalConditioning);
      }
      return list;
    });

    addLog(`[STIMULUS] Reacted to ${event.name}. Sensory & Working focus layers updated.`);
  };

  // Simulate Time Progression & Continuous Memory Decay
  const handleTimeStep = () => {
    setTimeStep((prev) => prev + 1);

    setMemories((prevMems) => {
      return prevMems
        .map((mem) => {
          let nextLayer = mem.layer;
          let nextDecay = mem.decayFactor;
          let isSuppressed = mem.isSuppressed;

          // 1. Sensory Memory decays at an ultra-fast rate
          if (mem.layer === 'sensory') {
            nextDecay = mem.decayFactor * 0.15; // 거의 즉시 소실
          } 
          // 2. Working Memory decays extremely fast
          else if (mem.layer === 'working') {
            nextDecay = mem.decayFactor * 0.4;
            // Consolidation check: If attentional focus had high salience, transfer to short-term
            if (nextDecay < 0.2 && mem.baseSalience >= 0.5) {
              nextLayer = 'short-term';
              nextDecay = 0.85;
              addLog(`[CONSOLIDATION] Working focus "${mem.description.substring(0, 25)}..." promoted to Short-Term Memory.`);
            }
          } 
          // 3. Short-Term decays moderately
          else if (mem.layer === 'short-term') {
            // Neuroticism speeds up decay of mundane memories, but locks negative ones
            const rate = mem.valence < -0.4 ? (0.8 + neuroticism * 0.1) : (0.75 - neuroticism * 0.1);
            nextDecay = mem.decayFactor * rate;

            // Promote to Episodic if highly salient or reinforced
            if (nextDecay < 0.25 && mem.baseSalience >= 0.7) {
              nextLayer = 'episodic';
              nextDecay = 0.95;
              addLog(`[CONSOLIDATION] Short-term event "${mem.description.substring(0, 25)}..." promoted to Episodic Memory.`);
            }
          } 
          // 4. Episodic decays slowly (unless reinforced)
          else if (mem.layer === 'episodic') {
            nextDecay = mem.decayFactor * 0.96;
          }
          // 5. Semantic / Procedural / Emotional layers are structurally permanent
          else if (mem.layer === 'semantic' || mem.layer === 'procedural') {
            nextDecay = 1.0; // permanent
          } else if (mem.layer === 'emotional') {
            nextDecay = Math.max(0.9, mem.decayFactor * 0.995); // Deep emotional triggers barely fade
            
            // Traumatic Defense Suppression logic
            if (suppressTrauma && mem.valence < -0.8 && neuroticism > 0.4) {
              isSuppressed = true;
            }
          }

          return {
            ...mem,
            layer: nextLayer,
            decayFactor: nextDecay,
            isSuppressed
          };
        })
        // Filter out completely forgotten memories
        .filter((mem) => {
          if (mem.layer === 'sensory' && mem.decayFactor < 0.05) return false;
          if (mem.layer === 'working' && mem.decayFactor < 0.08 && mem.baseSalience < 0.5) return false;
          if (mem.layer === 'short-term' && mem.decayFactor < 0.08) return false;
          if (mem.layer === 'episodic' && mem.decayFactor < 0.15 && mem.baseSalience < 0.6) return false;
          return true;
        });
    });

    setLastEvent(`Simulation clock advanced. Recalculated exponential memory decay curves.`);
  };

  // Simulate Night of Sleep (Consolidation, Pruning, False Memory Formation, Semantic Abstraction)
  const handleSleepPhase = () => {
    setTimeStep((prev) => prev + 8); // Sleep takes 8 hours

    setMemories((prevMems) => {
      const consolidatedList: CognitiveMemory[] = [];
      const stGroup: CognitiveMemory[] = [];
      const epGroup: CognitiveMemory[] = [];

      prevMems.forEach((mem) => {
        if (mem.layer === 'sensory') {
          // Sensory memories are totally wiped/pruned during sleep
          return;
        }
        if (mem.layer === 'working') {
          // Working memories are consolidated to Short-term or forgotten
          if (mem.baseSalience >= 0.6) {
            consolidatedList.push({
              ...mem,
              layer: 'short-term',
              decayFactor: 0.9,
              reinforcementCount: (mem.reinforcementCount || 0) + 1
            });
          }
          return;
        }
        if (mem.layer === 'short-term') {
          stGroup.push(mem);
          return;
        }
        if (mem.layer === 'episodic') {
          epGroup.push(mem);
          return;
        }
        // Others (Semantic, Procedural, Emotional) are carried forward untouched
        consolidatedList.push(mem);
      });

      // 1. Process Short-Term memories
      stGroup.forEach((mem) => {
        if (mem.baseSalience >= 0.55) {
          // Promoted to Episodic
          consolidatedList.push({
            ...mem,
            layer: 'episodic',
            decayFactor: 0.95,
            reinforcementCount: (mem.reinforcementCount || 0) + 1
          });
        } else {
          // Pruned/forgotten
          addLog(`[SLEEP PRUNING] Junk short-term memory deleted: "${mem.description.substring(0, 30)}..."`);
        }
      });

      // 2. Process Episodic Memories to formulate Semantic Facts & create False composite memories
      const mergedIndices = new Set<string>();
      
      for (let i = 0; i < epGroup.length; i++) {
        if (mergedIndices.has(epGroup[i].id)) continue;

        const currentEp = epGroup[i];

        // Semantic Abstraction: If we have highly emotional or repeated meetings with an entity, abstract to semantic
        if (currentEp.associatedEntityId && (currentEp.reinforcementCount || 0) >= 2) {
          const semanticFactExists = consolidatedList.some(
            (m) => m.layer === 'semantic' && m.associatedEntityId === currentEp.associatedEntityId && m.description.includes('companion')
          );
          if (!semanticFactExists) {
            consolidatedList.push({
              id: `sem-abs-${Date.now()}-${i}`,
              description: `Abstraction: Repeated high-value encounters signify ${currentEp.associatedEntityId} is an influential figure in daily patterns.`,
              category: 'Relational Schema',
              timestamp: timeStep,
              baseSalience: 0.85,
              valence: currentEp.valence,
              layer: 'semantic',
              decayFactor: 1.0,
              associatedEntityId: currentEp.associatedEntityId
            });
            addLog(`[SEMANTIC ABSTRACTION] Abstracted semantic schema from repeated episodes with ${currentEp.associatedEntityId}.`);
          }
        }

        // Composite/False Memory Formation: Look for similar category/valence memories to merge
        let didMerge = false;
        for (let j = i + 1; j < epGroup.length; j++) {
          if (mergedIndices.has(epGroup[j].id)) continue;

          const comparisonEp = epGroup[j];

          if (currentEp.category === comparisonEp.category && Math.abs(currentEp.valence - comparisonEp.valence) < 0.3) {
            // Merge them into a single, slightly distorted (False) composite memory
            const compositeDescription = `Composite: Recalling blended moments of ${currentEp.category.toLowerCase()} encounters (Originally: "${currentEp.description.substring(0, 25)}" & "${comparisonEp.description.substring(0, 25)}")`;
            
            consolidatedList.push({
              ...currentEp,
              id: `composite-false-${Date.now()}-${i}`,
              description: compositeDescription,
              isFalseMemory: true,
              distortionCount: (currentEp.distortionCount || 0) + 1,
              decayFactor: 0.98,
              baseSalience: Math.min(1.0, currentEp.baseSalience * 1.1)
            });

            mergedIndices.add(currentEp.id);
            mergedIndices.add(comparisonEp.id);
            didMerge = true;
            addLog(`[FALSE MEMORY] Merged similar episodes into a composite memory due to semantic interference.`);
            break;
          }
        }

        if (!didMerge) {
          // Push episodic memory with standard slow decay refresh from sleep consolidation
          consolidatedList.push({
            ...currentEp,
            decayFactor: Math.min(1.0, currentEp.decayFactor + 0.1) // consolidate/strengthen
          });
        }
      }

      return consolidatedList;
    });

    setLastEvent('Simulated overnight REM Sleep. Pruned sensory buffers, abstract semantic rules, and consolidated episodic nodes.');
  };

  // Helper to categorize mood based on PAD coordinate boundaries
  const currentMood = useMemo(() => {
    const { pleasure, arousal, dominance } = pad;
    
    if (pleasure >= 0.1 && arousal >= 0.1 && dominance >= 0.1) {
      return {
        name: 'Exuberant / Happy',
        color: 'text-pink-400 border-pink-500/30 bg-pink-500/10 shadow-[0_0_12px_rgba(236,72,153,0.15)]',
        description: 'Vibrant and fully engaged. Facilitates creative actualization actions and social utility gains.',
        vocalTone: 'Resonant, expressive, accelerated tempo',
        bias: 'GOAP priority: Social +40%, Self-Purpose +25%'
      };
    }
    if (pleasure <= -0.1 && arousal >= 0.1 && dominance >= 0.1) {
      return {
        name: 'Hostile / Angry',
        color: 'text-red-400 border-red-500/30 bg-red-500/10 shadow-[0_0_12px_rgba(239,68,68,0.15)]',
        description: 'Under conflict or perceived opposition. Lowers cooperation threshold and increases stress index.',
        vocalTone: 'Harsh, intense, abrupt consonants',
        bias: 'GOAP priority: Conflict/Defensive actions +50%, Socialization -80%'
      };
    }
    if (pleasure <= -0.1 && arousal >= 0.1 && dominance <= -0.1) {
      return {
        name: 'Anxious / Fearful',
        color: 'text-amber-400 border-amber-500/30 bg-amber-500/10 shadow-[0_0_12px_rgba(245,158,11,0.15)]',
        description: 'Sensing high uncertainty and vulnerability. Suspends long-term self-purpose and locks goals.',
        vocalTone: 'Tremulous, high pitch, rapid inhalations',
        bias: 'GOAP priority: Safety +60%, Financial Planning +30%'
      };
    }
    if (pleasure <= -0.1 && arousal <= -0.1 && dominance <= -0.1) {
      return {
        name: 'Bored / Melancholic',
        color: 'text-indigo-400 border-indigo-500/30 bg-indigo-500/10 shadow-[0_0_12px_rgba(99,102,241,0.15)]',
        description: 'Lacking stimulation and agency. Reduces overall drive restoration rate; lethargy set.',
        vocalTone: 'Flat, slow, prolonged trailing syllables',
        bias: 'GOAP priority: Sleep/Rest +40%, Work -50%'
      };
    }
    if (pleasure >= 0.1 && arousal <= -0.1 && dominance >= 0.1) {
      return {
        name: 'Relaxed / Peaceful',
        color: 'text-cyan-400 border-cyan-500/30 bg-cyan-500/10 shadow-[0_0_12px_rgba(6,182,212,0.15)]',
        description: 'Secure, content, and tranquil. Increases learning rate parameters and habit reinforcement.',
        vocalTone: 'Soft, slow, warm timbre',
        bias: 'GOAP priority: Rest +30%, Reading/Intellectual +35%'
      };
    }
    if (pleasure >= 0.1 && arousal <= -0.1 && dominance <= -0.1) {
      return {
        name: 'Submissive / Docile',
        color: 'text-teal-400 border-teal-500/30 bg-teal-500/10 shadow-[0_0_12px_rgba(20,184,166,0.15)]',
        description: 'Agreeable but low on personal agency. Amplifies conformity and peer social influences.',
        vocalTone: 'Quiet, hesitant, rising inflections',
        bias: 'GOAP priority: Altruism +40%, Ambition -30%'
      };
    }
    return {
      name: 'Neutral / Focused',
      color: 'text-slate-300 border-white/10 bg-white/5',
      description: 'Balanced objective baseline state. Actions driven purely by standard needs deficits.',
      vocalTone: 'Unbiased, natural tempo, controlled pitch',
      bias: 'GOAP priority: Unmodified'
    };
  }, [pad]);

  // Redesigned Context-Aware RAG Memory Retrieval
  // Calculates scoring based on: Semantic Match + Goal Match + Need Match + Relationship Match + Emotional Congruency
  const searchResults = useMemo(() => {
    if (!searchQuery.trim() && activeGoalFilter === 'None' && activeNeedFilter === 'None' && activeNearbyFilter === 'None') {
      return [];
    }

    const padIntensity = Math.sqrt(
      Math.pow(pad.pleasure, 2) + 
      Math.pow(pad.arousal, 2) + 
      Math.pow(pad.dominance, 2)
    ) || 0.5;

    const terms = searchQuery.toLowerCase().split(/\s+/).filter(Boolean);

    return memories
      .map((mem) => {
        // Hide suppressed memories
        if (mem.isSuppressed) return { memory: mem, score: -1, components: null };

        const descLower = mem.description.toLowerCase();
        const catLower = mem.category.toLowerCase();

        // 1. Semantic Similarity Score
        let matchCount = 0;
        terms.forEach((term) => {
          if (descLower.includes(term)) matchCount += 1.5;
          if (catLower.includes(term)) matchCount += 0.5;
        });
        const semanticSim = terms.length > 0 ? matchCount / (terms.length + 1) : 0;

        // 2. Goal Congruency Bonus
        let goalBonus = 0;
        if (activeGoalFilter !== 'None') {
          if (activeGoalFilter === 'Socialize' && (catLower.includes('social') || catLower.includes('relation'))) goalBonus = 0.5;
          if (activeGoalFilter === 'Earn Money' && (catLower.includes('economic') || catLower.includes('finance') || descLower.includes('rent') || descLower.includes('bill'))) goalBonus = 0.6;
          if (activeGoalFilter === 'Survive' && (catLower.includes('threat') || catLower.includes('safety') || descLower.includes('river'))) goalBonus = 0.8;
          if (activeGoalFilter === 'Work' && (catLower.includes('intellectual') || catLower.includes('skill') || descLower.includes('cartograph') || descLower.includes('gis'))) goalBonus = 0.5;
        }

        // 3. Need Deficiency Alignment
        let needBonus = 0;
        if (activeNeedFilter !== 'None') {
          if (activeNeedFilter === 'Social Belonging' && (catLower.includes('social') || descLower.includes('coffee') || descLower.includes('sterling'))) needBonus = 0.5;
          if (activeNeedFilter === 'Safety' && (catLower.includes('threat') || catLower.includes('safety') || descLower.includes('hazard'))) needBonus = 0.6;
          if (activeNeedFilter === 'Esteem' && catLower.includes('esteem')) needBonus = 0.4;
        }

        // 4. Interpersonal Relationship Context Match
        let relationshipBonus = 0;
        if (activeNearbyFilter !== 'None' && mem.associatedEntityId === activeNearbyFilter) {
          relationshipBonus = 0.8;
        }

        // 5. Emotional State Congruency (Memory valence matching Pleasure dimension of PAD)
        const valenceMatch = Math.max(0, 1.0 - Math.abs(mem.valence - pad.pleasure));
        const emotionalRecallBias = valenceMatch * (1.0 + Math.abs(mem.valence) * pad.arousal);

        // Exponential Decay influence
        const ageModifier = mem.layer === 'sensory' || mem.layer === 'working' ? mem.decayFactor : (mem.decayFactor * 0.95);

        // Final score blending components
        const w_sem = 0.4;
        const w_goal = 0.2;
        const w_need = 0.2;
        const w_rel = 0.3;
        const w_emo = 0.2;

        const score = (
          (semanticSim * w_sem) + 
          (goalBonus * w_goal) + 
          (needBonus * w_need) + 
          (relationshipBonus * w_rel) + 
          (emotionalRecallBias * w_emo)
        ) * ageModifier;

        return {
          memory: mem,
          score,
          components: {
            semantic: semanticSim * w_sem,
            goal: goalBonus * w_goal,
            need: needBonus * w_need,
            relationship: relationshipBonus * w_rel,
            emotion: emotionalRecallBias * w_emo,
            decay: ageModifier
          }
        };
      })
      .filter((res) => res.score > 0.05)
      .sort((a, b) => b.score - a.score);
  }, [searchQuery, memories, pad, activeGoalFilter, activeNeedFilter, activeNearbyFilter]);

  // Relationship Memory analysis dossier per unique target NPC
  const relationshipDossier = useMemo(() => {
    const list = ['Chloe Sterling', 'Dr. Sterling', 'John Doe'];
    return list.map((npc) => {
      const npcMems = memories.filter((m) => m.associatedEntityId === npc);
      const positiveCount = npcMems.filter((m) => m.valence > 0).length;
      const negativeCount = npcMems.filter((m) => m.valence < 0).length;
      const totalCount = npcMems.length;
      
      // Calculate dynamic relational indicators parsed directly from experiential memory history
      let basicAffinity = 0;
      let basicTrust = 0.2;
      let basicConflict = 0.05;

      npcMems.forEach((m) => {
        basicAffinity += m.valence * m.baseSalience * m.decayFactor * 0.3;
        if (m.category === 'Conflict') {
          basicTrust -= 0.25 * m.decayFactor;
          basicConflict += 0.35 * m.decayFactor;
        } else if (m.valence > 0) {
          basicTrust += 0.12 * m.decayFactor;
        }
      });

      return {
        npc,
        memoriesCount: totalCount,
        positiveCount,
        negativeCount,
        affinity: Math.max(-1.0, Math.min(1.0, basicAffinity)),
        trust: Math.max(-1.0, Math.min(1.0, basicTrust)),
        conflict: Math.max(0.0, Math.min(1.0, basicConflict)),
        significantEpisode: npcMems.sort((a, b) => b.baseSalience - a.baseSalience)[0]?.description || 'No significant incidents logged'
      };
    });
  }, [memories]);

  // Memory Layer partitions
  const sensoryLayer = memories.filter((m) => m.layer === 'sensory');
  const workingLayer = memories.filter((m) => m.layer === 'working');
  const shortTermLayer = memories.filter((m) => m.layer === 'short-term');
  const episodicLayer = memories.filter((m) => m.layer === 'episodic');
  const semanticLayer = memories.filter((m) => m.layer === 'semantic');
  const proceduralLayer = memories.filter((m) => m.layer === 'procedural');
  const emotionalLayer = memories.filter((m) => m.layer === 'emotional');

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="memory-affective-root">
      {/* LEFT COLUMN: Emotional PAD, Personality & Cognitive Sleep Center (4 Cols) */}
      <div className="lg:col-span-4 space-y-6" id="pad-column">
        {/* Sleep and Consolidation Center */}
        <div className="glass-panel border border-pink-500/20 rounded-2xl p-5 bg-gradient-to-b from-indigo-950/40 to-slate-900/40" id="sleep-consolidation-card">
          <h3 className="text-sm font-bold text-white font-serif flex items-center gap-2 mb-2">
            <Moon className="text-pink-400 h-4.5 w-4.5" id="moon-icon" /> Sleep Consolidation Module
          </h3>
          <p className="text-xs text-slate-300 leading-normal mb-4">
            Simulates a night of restorative sleep to execute synaptic pruning, abstract episodic events into semantic rules, and compress redundant records.
          </p>
          <div className="flex gap-2" id="sleep-buttons">
            <button
              id="sleep-phase-btn"
              onClick={handleSleepPhase}
              className="flex-1 py-2.5 bg-gradient-to-r from-pink-500/80 via-purple-600/80 to-indigo-500/80 hover:from-pink-500 hover:to-indigo-500 text-white font-bold rounded-xl text-xs hover:shadow-[0_0_12px_rgba(236,72,153,0.3)] transition-all flex items-center justify-center gap-2"
            >
              <Moon className="h-4 w-4" /> Trigger 8H REM Sleep
            </button>
            <button
              id="time-step-btn-2"
              onClick={handleTimeStep}
              className="px-3.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 rounded-xl text-xs transition-colors"
              title="Advance 1 Hour"
            >
              +1H
            </button>
          </div>
        </div>

        {/* PAD Sliders */}
        <div className="glass-panel rounded-2xl p-5" id="pad-meters-card">
          <h3 className="text-sm font-bold text-white font-serif flex items-center gap-2 mb-4">
            <Activity className="text-pink-500 h-4.5 w-4.5" id="activity-icon" /> Affective PAD Vectors
          </h3>

          <div className="space-y-4" id="pad-sliders">
            {/* Pleasure Slider */}
            <div className="space-y-1.5" id="pleasure-wrapper">
              <div className="flex justify-between text-xs" id="pleasure-info">
                <span className="font-semibold text-slate-300">Pleasure / Valence (P)</span>
                <span className={`font-mono font-bold ${pad.pleasure >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {pad.pleasure >= 0 ? '+' : ''}{pad.pleasure.toFixed(2)}
                </span>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-slate-400" id="pleasure-labels">
                <span>Displeasure (-1)</span>
                <input
                  id="pad-slider-pleasure"
                  type="range"
                  min="-1"
                  max="1"
                  step="0.05"
                  value={pad.pleasure}
                  onChange={(e) => handlePADChange('pleasure', parseFloat(e.target.value))}
                  className="flex-1 accent-pink-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                />
                <span>Ecstasy (+1)</span>
              </div>
            </div>

            {/* Arousal Slider */}
            <div className="space-y-1.5" id="arousal-wrapper">
              <div className="flex justify-between text-xs" id="arousal-info">
                <span className="font-semibold text-slate-300">Arousal / Activation (A)</span>
                <span className={`font-mono font-bold ${pad.arousal >= 0 ? 'text-orange-400' : 'text-blue-400'}`}>
                  {pad.arousal >= 0 ? '+' : ''}{pad.arousal.toFixed(2)}
                </span>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-slate-400" id="arousal-labels">
                <span>Drowsy (-1)</span>
                <input
                  id="pad-slider-arousal"
                  type="range"
                  min="-1"
                  max="1"
                  step="0.05"
                  value={pad.arousal}
                  onChange={(e) => handlePADChange('arousal', parseFloat(e.target.value))}
                  className="flex-1 accent-orange-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                />
                <span>Frenetic (+1)</span>
              </div>
            </div>

            {/* Dominance Slider */}
            <div className="space-y-1.5" id="dominance-wrapper">
              <div className="flex justify-between text-xs" id="dominance-info">
                <span className="font-semibold text-slate-300">Dominance / Agency (D)</span>
                <span className={`font-mono font-bold ${pad.dominance >= 0 ? 'text-cyan-400' : 'text-purple-400'}`}>
                  {pad.dominance >= 0 ? '+' : ''}{pad.dominance.toFixed(2)}
                </span>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-slate-400" id="dominance-labels">
                <span>Submissive (-1)</span>
                <input
                  id="pad-slider-dominance"
                  type="range"
                  min="-1"
                  max="1"
                  step="0.05"
                  value={pad.dominance}
                  onChange={(e) => handlePADChange('dominance', parseFloat(e.target.value))}
                  className="flex-1 accent-cyan-400 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                />
                <span>Authoritative (+1)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Synthesized Mood & Vocal State */}
        <div className={`glass-panel border rounded-2xl p-5 ${currentMood.color}`} id="mood-synthesizer-card">
          <div className="text-[10px] uppercase font-bold tracking-widest text-slate-400 mb-1" id="mood-label">Affective Mood Synthesis</div>
          <h4 className="text-lg font-bold font-serif mb-2" id="mood-name">{currentMood.name}</h4>
          <p className="text-xs text-slate-300 leading-normal mb-3" id="mood-desc">{currentMood.description}</p>
          
          <div className="border-t border-white/10 pt-3 mt-3 space-y-2 text-[11px]" id="mood-meta">
            <div className="flex justify-between" id="mood-vocal">
              <span className="text-slate-400 font-sans">Synthesized Vocal Tone:</span>
              <span className="font-mono text-white text-right max-w-[180px] truncate">{currentMood.vocalTone}</span>
            </div>
            <div className="flex justify-between" id="mood-bias">
              <span className="text-slate-400 font-sans">Behavioral Bias:</span>
              <span className="font-mono font-bold text-white text-right">{currentMood.bias}</span>
            </div>
          </div>
        </div>

        {/* Personality & Trauma Suppression Panel */}
        <div className="glass-panel rounded-2xl p-5 space-y-4" id="cognitive-bias-panel">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Cognitive Bias & Traits</h3>
          
          <div className="space-y-1.5" id="neuroticism-slider">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">Neuroticism / Stress Sensitivity</span>
              <span className="font-mono font-bold text-pink-400">{(neuroticism * 100).toFixed(0)}%</span>
            </div>
            <input
              id="trait-neuroticism"
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={neuroticism}
              onChange={(e) => setNeuroticism(parseFloat(e.target.value))}
              className="w-full accent-pink-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
            />
            <p className="text-[10px] text-slate-400 leading-tight">
              High neuroticism accelerates the suppression of traumatic episodes while raising stress-induced memory distortion rate.
            </p>
          </div>

          <div className="flex items-center justify-between border-t border-white/10 pt-3" id="suppress-toggle-wrapper">
            <div className="space-y-0.5">
              <span className="text-xs font-semibold text-slate-200 flex items-center gap-1">
                <EyeOff className="h-3.5 w-3.5 text-pink-400" /> Defense Mechanism
              </span>
              <span className="text-[10px] text-slate-400 block">Suppress traumatic memories from cognitive retrieval.</span>
            </div>
            <button
              id="toggle-suppress-btn"
              onClick={() => setSuppressTrauma(!suppressTrauma)}
              className={`px-3 py-1.5 rounded-lg font-bold text-[10px] transition-colors border ${
                suppressTrauma 
                  ? 'bg-pink-500/15 border-pink-500/30 text-pink-400' 
                  : 'bg-white/5 border-white/10 text-slate-400'
              }`}
            >
              {suppressTrauma ? 'Active' : 'Bypassed'}
            </button>
          </div>
        </div>

        {/* Environmental Stimuli triggers */}
        <div className="glass-panel rounded-2xl p-5" id="stimuli-triggers-card">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Environmental Stimuli</h3>
          <div className="grid grid-cols-2 gap-2" id="stimuli-buttons">
            {STIMULUS_EVENTS.map((event) => (
              <button
                id={`stimulus-btn-${event.id}`}
                key={event.id}
                onClick={() => triggerStimulus(event)}
                className="p-2.5 bg-white/5 border border-white/10 rounded-xl text-left hover:bg-white/10 hover:border-white/20 transition-all flex flex-col gap-1 text-slate-200"
              >
                <div className="flex items-center gap-1 text-xs font-bold" id={`stimulus-title-${event.id}`}>
                  <span>{event.icon}</span>
                  <span className="truncate">{event.name}</span>
                </div>
                <span className="text-[9px] text-slate-400 leading-tight block truncate" id={`stimulus-desc-${event.id}`}>
                  {event.description}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: The Seven-Layer Memory Viewer & Redesigned RAG (8 Cols) */}
      <div className="lg:col-span-8 space-y-6" id="memory-column">
        {/* Core Seven-Layer Memory Board */}
        <div className="glass-panel rounded-2xl p-6" id="memory-board-card">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4" id="memory-header">
            <div>
              <h2 className="text-lg font-bold text-white font-serif flex items-center gap-2">
                <Layers className="h-5 w-5 text-pink-500" /> Seven-Layer Cognitive Architecture
              </h2>
              <p className="text-slate-400 text-xs mt-0.5">
                Simulated biological cascade of Project Earth NPCs. Tracks decay constants, consolidation vectors, and retention half-lives.
              </p>
            </div>
            <div className="flex items-center gap-2 text-[11px] font-mono bg-pink-500/10 text-pink-400 px-3 py-1 rounded-full border border-pink-500/20">
              <Clock className="h-3.5 w-3.5 animate-spin-slow" /> TIME: {timeStep} HR ELAPSED
            </div>
          </div>

          {/* Layer List with beautiful accordions/expanders */}
          <div className="space-y-3" id="seven-layers-accordion">
            {/* 1. Sensory Memory */}
            <div className="border border-white/10 bg-white/2 rounded-xl overflow-hidden" id="layer-sensory-panel">
              <div className="flex justify-between items-center px-4 py-3 bg-pink-500/5 hover:bg-pink-500/10 transition-colors">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-500 font-mono">L1</span>
                  <h4 className="text-xs font-bold text-slate-200 uppercase tracking-widest font-mono">Sensory Memory</h4>
                  <span className="text-[9px] bg-white/5 px-1.5 py-0.5 rounded text-slate-400 font-mono">T1/2: ~200ms</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono font-bold">{sensoryLayer.length} Traces</span>
              </div>
              <div className="p-3 grid grid-cols-1 md:grid-cols-2 gap-2" id="sensory-traces-wrapper">
                {sensoryLayer.map((mem) => (
                  <div key={mem.id} className="p-2 bg-white/5 border border-white/10 rounded-lg text-xs relative flex justify-between items-center">
                    <span className="text-slate-300 leading-normal max-w-[85%]">{mem.description}</span>
                    <span className="font-mono text-[9px] text-pink-400 shrink-0">{(mem.decayFactor * 100).toFixed(0)}%</span>
                  </div>
                ))}
                {sensoryLayer.length === 0 && (
                  <div className="col-span-2 text-center py-2 text-slate-500 text-[10px] italic">No active raw sensory stimuli traces. Trigger an environmental stimulus!</div>
                )}
              </div>
            </div>

            {/* 2. Working Memory */}
            <div className="border border-white/10 bg-white/2 rounded-xl overflow-hidden" id="layer-working-panel">
              <div className="flex justify-between items-center px-4 py-3 bg-pink-500/5 hover:bg-pink-500/10 transition-colors">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-500 font-mono">L2</span>
                  <h4 className="text-xs font-bold text-pink-400 uppercase tracking-widest font-mono">Working Memory</h4>
                  <span className="text-[9px] bg-pink-500/15 text-pink-400 px-1.5 py-0.5 rounded font-mono">T1/2: ~30s</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono font-bold">{workingLayer.length} Attentional Focus</span>
              </div>
              <div className="p-3 space-y-2" id="working-mems-wrapper">
                {workingLayer.map((mem) => (
                  <div key={mem.id} className="p-3 bg-white/5 border border-white/10 rounded-xl flex justify-between items-start gap-4">
                    <div>
                      <span className="text-[9px] bg-pink-500/20 text-pink-400 px-1.5 py-0.5 rounded font-bold font-mono uppercase tracking-wider">{mem.category}</span>
                      <p className="text-xs text-slate-200 mt-1">{mem.description}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="font-mono text-xs text-pink-400 font-semibold block">{(mem.decayFactor * 100).toFixed(0)}%</span>
                      <button onClick={() => handleDeleteMemory(mem.id)} className="text-[10px] text-slate-500 hover:text-red-400 mt-1">Prune</button>
                    </div>
                  </div>
                ))}
                {workingLayer.length === 0 && (
                  <div className="text-center py-3 text-slate-500 text-xs italic">Working registry clear. Pre-attentional pipeline holding.</div>
                )}
              </div>
            </div>

            {/* 3. Short-Term Memory */}
            <div className="border border-white/10 bg-white/2 rounded-xl overflow-hidden" id="layer-shortterm-panel">
              <div className="flex justify-between items-center px-4 py-3 bg-pink-500/5 hover:bg-pink-500/10 transition-colors">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-500 font-mono">L3</span>
                  <h4 className="text-xs font-bold text-orange-400 uppercase tracking-widest font-mono">Short-Term Memory</h4>
                  <span className="text-[9px] bg-orange-500/15 text-orange-400 px-1.5 py-0.5 rounded font-mono">T1/2: ~4h</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono font-bold">{shortTermLayer.length} Buffer Nodes</span>
              </div>
              <div className="p-3 grid grid-cols-1 md:grid-cols-2 gap-2" id="shortterm-mems-wrapper">
                {shortTermLayer.map((mem) => (
                  <div key={mem.id} className="p-3 bg-white/5 border border-white/10 rounded-xl flex justify-between items-start gap-2">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] font-bold text-orange-400 uppercase tracking-wider">{mem.category}</span>
                        {mem.associatedEntityId && <span className="text-[9px] bg-white/10 px-1 rounded text-slate-300 font-mono">@ {mem.associatedEntityId}</span>}
                      </div>
                      <p className="text-xs text-slate-200 mt-1.5 leading-snug">{mem.description}</p>
                    </div>
                    <div className="text-right shrink-0 font-mono text-[10px]">
                      <span className="text-slate-400 block">{(mem.decayFactor * 100).toFixed(0)}%</span>
                      <button onClick={() => handleDeleteMemory(mem.id)} className="text-red-400/80 hover:text-red-400 mt-2">Prune</button>
                    </div>
                  </div>
                ))}
                {shortTermLayer.length === 0 && (
                  <div className="col-span-2 text-center py-4 text-slate-500 text-xs italic">Short-Term cache consolidated. Sleep triggers write promote cycles.</div>
                )}
              </div>
            </div>

            {/* 4. Episodic Memory */}
            <div className="border border-white/10 bg-white/2 rounded-xl overflow-hidden" id="layer-episodic-panel">
              <div className="flex justify-between items-center px-4 py-3 bg-pink-500/5 hover:bg-pink-500/10 transition-colors">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-500 font-mono">L4</span>
                  <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-widest font-mono">Long-Term Episodic</h4>
                  <span className="text-[9px] bg-cyan-500/15 text-cyan-400 px-1.5 py-0.5 rounded font-mono">T1/2: ~365d</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono font-bold">{episodicLayer.length} Autobiographies</span>
              </div>
              <div className="p-3 space-y-2" id="episodic-mems-wrapper">
                {episodicLayer.map((mem) => (
                  <div key={mem.id} className="p-3 bg-slate-900/40 border border-white/10 rounded-xl flex justify-between items-center gap-4">
                    <div>
                      <div className="flex items-center gap-2 text-[9px] font-mono">
                        <span className="text-cyan-400 font-bold uppercase">{mem.category}</span>
                        {mem.associatedEntityId && <span className="bg-cyan-950 text-cyan-300 px-1 rounded font-bold">Rel: {mem.associatedEntityId}</span>}
                        {mem.isFalseMemory && <span className="bg-amber-950 text-amber-300 px-1 rounded font-bold uppercase tracking-wider flex items-center gap-0.5"><AlertTriangle className="h-2.5 w-2.5" /> Distorted Composite</span>}
                      </div>
                      <p className="text-xs text-slate-100 mt-1.5 leading-snug font-serif">{mem.description}</p>
                    </div>
                    <div className="text-right shrink-0 font-mono text-[10px] space-y-0.5 text-slate-400">
                      <span className="block font-bold text-slate-300">Retention: {(mem.decayFactor * 100).toFixed(0)}%</span>
                      <span className="block">Rehearsed: {mem.reinforcementCount || 0}x</span>
                      <button onClick={() => handleDeleteMemory(mem.id)} className="text-slate-500 hover:text-red-400">Prune</button>
                    </div>
                  </div>
                ))}
                {episodicLayer.length === 0 && (
                  <div className="text-center py-4 text-slate-500 text-xs italic">Episodic archive empty. Promoting short-term experiences populates personal narrative layers.</div>
                )}
              </div>
            </div>

            {/* 5. Semantic Memory */}
            <div className="border border-white/10 bg-white/2 rounded-xl overflow-hidden" id="layer-semantic-panel">
              <div className="flex justify-between items-center px-4 py-3 bg-pink-500/5 hover:bg-pink-500/10 transition-colors">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-500 font-mono">L5</span>
                  <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-widest font-mono">Semantic Facts Schema</h4>
                  <span className="text-[9px] bg-indigo-500/15 text-indigo-400 px-1.5 py-0.5 rounded font-mono">Permanent (No Decay)</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono font-bold">{semanticLayer.length} Rules</span>
              </div>
              <div className="p-3 grid grid-cols-1 md:grid-cols-2 gap-2.5" id="semantic-mems-wrapper">
                {semanticLayer.map((mem) => (
                  <div key={mem.id} className="p-3 bg-indigo-950/20 border border-indigo-500/20 rounded-xl relative">
                    <span className="text-[9px] font-mono text-indigo-400 font-bold uppercase tracking-wider block">{mem.category}</span>
                    <p className="text-xs text-slate-200 mt-1.5 leading-normal">{mem.description}</p>
                    {mem.associatedEntityId && <span className="absolute bottom-2 right-2 text-[8px] bg-indigo-900/40 px-1 rounded text-indigo-300 font-mono">Fact about: {mem.associatedEntityId}</span>}
                  </div>
                ))}
              </div>
            </div>

            {/* 6. Procedural Memory */}
            <div className="border border-white/10 bg-white/2 rounded-xl overflow-hidden" id="layer-procedural-panel">
              <div className="flex justify-between items-center px-4 py-3 bg-pink-500/5 hover:bg-pink-500/10 transition-colors">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-500 font-mono">L6</span>
                  <h4 className="text-xs font-bold text-teal-400 uppercase tracking-widest font-mono">Procedural Skills & Habits</h4>
                  <span className="text-[9px] bg-teal-500/15 text-teal-400 px-1.5 py-0.5 rounded font-mono">Permanent (No Decay)</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono font-bold">{proceduralLayer.length} Automations</span>
              </div>
              <div className="p-3 grid grid-cols-1 md:grid-cols-2 gap-2.5" id="procedural-mems-wrapper">
                {proceduralLayer.map((mem) => (
                  <div key={mem.id} className="p-3 bg-teal-950/15 border border-teal-500/20 rounded-xl">
                    <div className="flex items-center justify-between text-[9px] font-mono">
                      <span className="text-teal-400 font-bold uppercase">{mem.category}</span>
                      {mem.associatedSkill && <span className="text-teal-300 font-bold bg-teal-950 px-1 rounded">Module: {mem.associatedSkill}</span>}
                    </div>
                    <p className="text-xs text-slate-200 mt-1.5 leading-normal">{mem.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* 7. Emotional Memory */}
            <div className="border border-white/10 bg-white/2 rounded-xl overflow-hidden" id="layer-emotional-panel">
              <div className="flex justify-between items-center px-4 py-3 bg-pink-500/5 hover:bg-pink-500/10 transition-colors">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-500 font-mono">L7</span>
                  <h4 className="text-xs font-bold text-purple-400 uppercase tracking-widest font-mono">Emotional Association / Trauma</h4>
                  <span className="text-[9px] bg-purple-500/15 text-purple-400 px-1.5 py-0.5 rounded font-mono">Extremely Resistant</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono font-bold">{emotionalLayer.length} Conditioned Core</span>
              </div>
              <div className="p-3 space-y-2" id="emotional-mems-wrapper">
                {emotionalLayer.map((mem) => (
                  <div key={mem.id} className={`p-3 border rounded-xl flex justify-between items-center ${mem.isSuppressed ? 'bg-purple-950/5 border-purple-500/10 opacity-40' : 'bg-purple-950/20 border-purple-500/30'}`}>
                    <div>
                      <div className="flex items-center gap-1.5 text-[9px] font-mono">
                        <span className="text-purple-400 font-bold uppercase">{mem.category}</span>
                        {mem.isSuppressed && <span className="bg-rose-950 text-rose-300 px-1 rounded font-bold uppercase flex items-center gap-0.5">Suppressed Trauma</span>}
                      </div>
                      <p className={`text-xs mt-1 leading-snug font-serif ${mem.isSuppressed ? 'text-purple-400/50 line-through blur-[1.5px] select-none' : 'text-slate-100'}`}>
                        {mem.description}
                      </p>
                    </div>
                    <div className="text-right shrink-0 font-mono text-[10px]">
                      <span className={`font-bold ${mem.valence > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        Valence: {mem.valence > 0 ? `+${mem.valence.toFixed(1)}` : mem.valence.toFixed(1)}
                      </span>
                      <span className="block text-slate-400 text-[9px] mt-0.5">Strength: {(mem.decayFactor * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Context-Aware RAG Memory Retrieval Redesign */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="rag-and-injector-row">
          
          {/* EXPERIENTIAL SENSORY INJECTOR */}
          <div className="glass-panel rounded-2xl p-5 flex flex-col justify-between" id="sensory-injector-card">
            <h3 className="text-sm font-bold text-white font-serif mb-4 flex items-center gap-1.5">
              <Plus className="h-4.5 w-4.5 text-pink-500" id="plus-icon" /> Experiential Sensory Injector
            </h3>
            <form onSubmit={handleAddMemory} className="space-y-3" id="injector-form">
              <div className="space-y-1" id="field-desc">
                <label className="text-xs text-slate-400 font-medium" htmlFor="mem-desc">Experiential Description</label>
                <input
                  id="mem-desc"
                  type="text"
                  placeholder="e.g. Slipped and lost footing during the mapping survey near safety ropes..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full text-xs py-2 px-3 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-pink-500 text-white placeholder-slate-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3" id="injector-row-2">
                <div className="space-y-1" id="field-layer">
                  <label className="text-xs text-slate-400 font-medium" htmlFor="mem-layer">Cognitive Target Layer</label>
                  <select
                    id="mem-layer"
                    value={newLayer}
                    onChange={(e) => setNewLayer(e.target.value as any)}
                    className="w-full text-xs py-2 px-2 bg-slate-900 border border-white/10 rounded-xl focus:outline-none focus:border-pink-500 text-white"
                  >
                    <option value="sensory">L1: Sensory Memory</option>
                    <option value="working">L2: Working Memory</option>
                    <option value="short-term">L3: Short-Term Memory</option>
                    <option value="episodic">L4: Episodic Memory</option>
                    <option value="semantic">L5: Semantic Fact</option>
                    <option value="procedural">L6: Procedural Skill</option>
                    <option value="emotional">L7: Emotional Trauma</option>
                  </select>
                </div>

                <div className="space-y-1" id="field-cat">
                  <label className="text-xs text-slate-400 font-medium" htmlFor="mem-cat">Category Type</label>
                  <select
                    id="mem-cat"
                    value={newCat}
                    onChange={(e) => setNewCat(e.target.value)}
                    className="w-full text-xs py-2 px-2 bg-slate-900 border border-white/10 rounded-xl focus:outline-none focus:border-pink-500 text-white"
                  >
                    <option value="Social">Social Encounter</option>
                    <option value="Intellectual">Intellectual Work</option>
                    <option value="Conflict">Relational Conflict</option>
                    <option value="Economic">Economic Incident</option>
                    <option value="Survival Threat">Safety Threat</option>
                    <option value="Skill Mastery">Skill mastery</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3" id="injector-row-3">
                <div className="space-y-1" id="field-entity">
                  <label className="text-xs text-slate-400 font-medium" htmlFor="mem-entity">Associated Entity</label>
                  <select
                    id="mem-entity"
                    value={newEntity}
                    onChange={(e) => setNewEntity(e.target.value)}
                    className="w-full text-xs py-2 px-2 bg-slate-900 border border-white/10 rounded-xl focus:outline-none focus:border-pink-500 text-white"
                  >
                    <option value="None">No Entity Relation</option>
                    <option value="Chloe Sterling">Chloe Sterling</option>
                    <option value="Dr. Sterling">Dr. Sterling</option>
                    <option value="John Doe">John Doe</option>
                  </select>
                </div>

                <div className="space-y-1" id="field-valence">
                  <div className="flex justify-between">
                    <label className="text-xs text-slate-400 font-medium" htmlFor="mem-valence">Valence (Affect)</label>
                    <span className="text-[10px] text-pink-400 font-mono font-bold">{newValence > 0 ? `+${newValence.toFixed(1)}` : newValence.toFixed(1)}</span>
                  </div>
                  <input
                    id="mem-valence"
                    type="range"
                    min="-1"
                    max="1"
                    step="0.1"
                    value={newValence}
                    onChange={(e) => setNewValence(parseFloat(e.target.value))}
                    className="w-full accent-pink-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer mt-2"
                  />
                </div>
              </div>

              <div className="space-y-1" id="field-salience">
                <div className="flex justify-between">
                  <label className="text-xs text-slate-400 font-medium" htmlFor="mem-salience">Experience Salience</label>
                  <span className="text-[10px] text-cyan-400 font-mono font-bold">{(newSalience * 100).toFixed(0)}%</span>
                </div>
                <input
                  id="mem-salience"
                  type="range"
                  min="0.1"
                  max="1.0"
                  step="0.05"
                  value={newSalience}
                  onChange={(e) => setNewSalience(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer mt-1"
                />
              </div>

              <button
                id="submit-mem-btn"
                type="submit"
                className="w-full py-2 bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/30 text-white font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-1 shadow-sm mt-1"
              >
                <Plus className="h-4 w-4" /> Inject Experience
              </button>
            </form>
          </div>

          {/* REDESIGNED CONTEXT-AWARE RAG RETRIEVER */}
          <div className="glass-panel rounded-2xl p-5 flex flex-col justify-between bg-gradient-to-b from-slate-900/40 to-indigo-950/40 border border-indigo-500/20" id="rag-query-card">
            <div>
              <h3 className="text-sm font-bold text-white font-serif mb-1 flex items-center gap-1.5">
                <Search className="h-4.5 w-4.5 text-pink-500" id="search-icon" /> Redesigned Contextual RAG
              </h3>
              <p className="text-slate-400 text-[11px] mb-3">
                Fetches memories dynamically utilizing semantic cosine overlap, active goals, physiological drives, nearby entity profiles, and emotional congruency.
              </p>
            </div>

            {/* Context Filters */}
            <div className="grid grid-cols-3 gap-2 mb-3" id="rag-context-filters">
              <div className="space-y-0.5">
                <label className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">Active Goal</label>
                <select
                  id="rag-goal-filter"
                  value={activeGoalFilter}
                  onChange={(e) => setActiveGoalFilter(e.target.value as any)}
                  className="w-full text-[10px] py-1 px-1 bg-slate-950 border border-white/10 rounded text-slate-300 focus:outline-none"
                >
                  <option value="None">None</option>
                  <option value="Survive">Survive Hazard</option>
                  <option value="Socialize">Socialize</option>
                  <option value="Earn Money">Earn Money</option>
                  <option value="Work">Study/Work</option>
                </select>
              </div>

              <div className="space-y-0.5">
                <label className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">Need Deficit</label>
                <select
                  id="rag-need-filter"
                  value={activeNeedFilter}
                  onChange={(e) => setActiveNeedFilter(e.target.value as any)}
                  className="w-full text-[10px] py-1 px-1 bg-slate-950 border border-white/10 rounded text-slate-300 focus:outline-none"
                >
                  <option value="None">None</option>
                  <option value="Social Belonging">Belonging</option>
                  <option value="Safety">Safety</option>
                  <option value="Esteem">Esteem</option>
                </select>
              </div>

              <div className="space-y-0.5">
                <label className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">Nearby NPC</label>
                <select
                  id="rag-entity-filter"
                  value={activeNearbyFilter}
                  onChange={(e) => setActiveNearbyFilter(e.target.value as any)}
                  className="w-full text-[10px] py-1 px-1 bg-slate-950 border border-white/10 rounded text-slate-300 focus:outline-none"
                >
                  <option value="None">None</option>
                  <option value="Chloe Sterling">Chloe Sterling</option>
                  <option value="Dr. Sterling">Dr. Sterling</option>
                  <option value="John Doe">John Doe</option>
                </select>
              </div>
            </div>

            <div className="relative mb-3" id="search-input-container">
              <Search className="absolute left-3 top-2 h-3.5 w-3.5 text-slate-500" id="query-icon" />
              <input
                id="rag-search-input"
                type="text"
                placeholder="Query: 'coffee', 'bills', 'hazard'..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-4 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl focus:outline-none focus:border-pink-500 text-white placeholder-slate-500"
              />
            </div>

            <div className="flex-1 space-y-2 overflow-y-auto max-h-[140px] pr-1 glass-scrollbar" id="rag-results">
              {searchResults.map((res, index) => (
                <div
                  key={index}
                  id={`rag-res-${res.memory.id}`}
                  className="p-2.5 bg-indigo-950/20 border border-indigo-500/30 rounded-xl text-[11px] space-y-1.5"
                >
                  <div className="flex justify-between text-[10px] text-slate-400 font-mono" id={`rag-meta-${res.memory.id}`}>
                    <span className="font-bold text-pink-300 uppercase">{res.memory.layer.toUpperCase()} - {res.memory.category}</span>
                    <span>RAG SCORE: <span className="text-white font-bold">{res.score.toFixed(3)}</span></span>
                  </div>
                  <p className="text-slate-200 leading-normal font-sans font-medium">{res.memory.description}</p>
                  
                  {/* Mathematics Component Breakdown */}
                  <div className="grid grid-cols-5 gap-1 pt-1.5 border-t border-white/5 text-[8px] font-mono text-slate-400" id={`rag-math-${res.memory.id}`}>
                    <span>Sem: {res.components?.semantic.toFixed(2)}</span>
                    <span>Goal: {res.components?.goal.toFixed(2)}</span>
                    <span>Need: {res.components?.need.toFixed(2)}</span>
                    <span>Rel: {res.components?.relationship.toFixed(2)}</span>
                    <span>Emo: {res.components?.emotion.toFixed(2)}</span>
                  </div>
                </div>
              ))}
              
              {searchResults.length > 0 && (
                <div className="text-[10px] text-indigo-400 font-semibold text-center py-1 mt-1 border-t border-indigo-500/10">
                  Matches resolved using Contextual Blended weights.
                </div>
              )}

              {searchResults.length === 0 && (searchQuery.trim() || activeGoalFilter !== 'None' || activeNeedFilter !== 'None' || activeNearbyFilter !== 'None') && (
                <div className="text-center py-6 text-slate-500 text-xs italic" id="rag-no-matches">
                  No cognitive memory matches active threshold weights.
                </div>
              )}

              {searchResults.length === 0 && !searchQuery.trim() && activeGoalFilter === 'None' && activeNeedFilter === 'None' && activeNearbyFilter === 'None' && (
                <div className="text-center py-6 text-slate-400 text-[11px] italic" id="rag-idle-placeholder">
                  Trigger context variables or input queries above to retrieve cognitive associations.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* RELATIONSHIP MEMORY DOSSIER */}
        <div className="glass-panel rounded-2xl p-5 space-y-3" id="relationship-memories-card">
          <h3 className="text-sm font-bold text-white font-serif flex items-center gap-2">
            <Heart className="text-pink-500 h-4.5 w-4.5" /> Interpersonal Relationship Memories (Volume III Integration)
          </h3>
          <p className="text-xs text-slate-400 leading-normal">
            Calculates Social Vector metrics based directly on localized episodic memory history logs per specific NPC.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3" id="npc-dossier-grid">
            {relationshipDossier.map((dossier) => (
              <div key={dossier.npc} className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-2">
                <div className="flex justify-between items-center border-b border-white/10 pb-1.5">
                  <span className="text-xs font-bold text-slate-200">{dossier.npc}</span>
                  <span className="text-[9px] font-mono bg-white/5 px-1.5 py-0.5 rounded text-slate-400">{dossier.memoriesCount} Events</span>
                </div>
                
                <div className="space-y-1 text-[10px] font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Affinity:</span>
                    <span className={`font-bold ${dossier.affinity >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {dossier.affinity >= 0 ? '+' : ''}{dossier.affinity.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Trust:</span>
                    <span className={`font-bold ${dossier.trust >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {dossier.trust >= 0 ? '+' : ''}{dossier.trust.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Conflict Factor:</span>
                    <span className="text-slate-300">{dossier.conflict.toFixed(2)}</span>
                  </div>
                </div>

                <div className="border-t border-white/5 pt-1.5 text-[9px] text-slate-400">
                  <span className="block font-semibold uppercase text-slate-500 mb-0.5">Most Salient:</span>
                  <p className="line-clamp-2 leading-tight text-slate-300 italic">"{dossier.significantEpisode}"</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cognitive consolidation log queue */}
        <div className="glass-panel rounded-2xl p-4 space-y-2" id="status-notification-bar">
          <div className="flex items-center justify-between text-xs border-b border-white/10 pb-1.5">
            <span className="font-bold text-pink-400 flex items-center gap-1">
              <Sparkles className="h-4 w-4 text-pink-400 shrink-0 animate-pulse" /> Live Memory Engine Logs
            </span>
            <span className="text-[10px] text-slate-500 font-mono">SYSTEM ACTIVE</span>
          </div>
          <div className="space-y-1 max-h-[100px] overflow-y-auto pr-1 glass-scrollbar text-[10px] font-mono text-slate-300">
            {consolidationLogs.map((log, index) => (
              <div key={index} className="flex gap-2">
                <span className="text-slate-500 shrink-0">[{new Date().toLocaleTimeString()}]</span>
                <span className="leading-snug">{log}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
