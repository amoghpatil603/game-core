import { useState, useMemo } from 'react';
import { LedgerEntry } from '../types';
import { Landmark, ArrowUpRight, ArrowDownRight, RefreshCw, AlertTriangle, HelpCircle, FileText } from 'lucide-react';

export default function MicroEconomy() {
  const [cash, setCash] = useState(380);
  const [debt, setDebt] = useState(1200);
  const [rent, setRent] = useState(450);
  const [utilities, setUtilities] = useState(120);
  const [salary, setSalary] = useState(850);

  const [ledger, setLedger] = useState<LedgerEntry[]>([
    { id: '1', timestamp: 'Day 1, 00:00', description: 'Monthly Salary Paycheck', amount: 850, category: 'salary' },
    { id: '2', timestamp: 'Day 1, 00:05', description: 'Apartment Monthly Rent Bill', amount: -450, category: 'housing' },
    { id: '3', timestamp: 'Day 2, 12:00', description: 'Grocery Market Restock', amount: -65, category: 'groceries' },
    { id: '4', timestamp: 'Day 3, 08:00', description: 'Municipal Energy Utility Bill', amount: -120, category: 'utilities' },
    { id: '5', timestamp: 'Day 4, 18:30', description: 'Interest on Education Debt', amount: -45, category: 'debt' }
  ]);

  const monthlyFixed = useMemo(() => {
    return rent + utilities;
  }, [rent, utilities]);

  // Financial Stress Formula:
  // Stress_Financial = 1.0 / [1.0 + (Cash / (1.5 * Monthly_Fixed_Costs))^2]
  const financialStress = useMemo(() => {
    const denominator = 1.5 * monthlyFixed;
    if (denominator === 0) return 0;
    return 1.0 / (1.0 + Math.pow(cash / denominator, 2));
  }, [cash, monthlyFixed]);

  // Work Utility Multiplier = 1.0 + 3.5 * Stress_Financial
  const workMultiplier = useMemo(() => {
    return 1.0 + 3.5 * financialStress;
  }, [financialStress]);

  // Leisure Utility Multiplier = 1.0 - 0.9 * Stress_Financial
  const leisureMultiplier = useMemo(() => {
    return Math.max(0.05, 1.0 - 0.9 * financialStress);
  }, [financialStress]);

  const handleApplyExpense = (desc: string, amount: number, category: LedgerEntry['category']) => {
    setCash((prev) => prev - amount);
    setLedger((prev) => [
      {
        id: Math.random().toString(),
        timestamp: `Day ${prev.length + 1}, 10:00`,
        description: desc,
        amount: -amount,
        category
      },
      ...prev
    ]);
  };

  const handleReceiveIncome = (desc: string, amount: number, category: LedgerEntry['category']) => {
    setCash((prev) => prev + amount);
    setLedger((prev) => [
      {
        id: Math.random().toString(),
        timestamp: `Day ${prev.length + 1}, 08:00`,
        description: desc,
        amount,
        category
      },
      ...prev
    ]);
  };

  const handlePayDebt = (amount: number) => {
    if (cash < amount) {
      alert("Insufficient cash reserves to service this debt payment.");
      return;
    }
    setCash((prev) => prev - amount);
    setDebt((prev) => Math.max(0, prev - amount));
    setLedger((prev) => [
      {
        id: Math.random().toString(),
        timestamp: `Day ${prev.length + 1}, 15:00`,
        description: `Serviced Outstanding Debt Principal`,
        amount: -amount,
        category: 'debt'
      },
      ...prev
    ]);
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-8" id="micro-eco-root">
      {/* Left Column: Ledger Metrics, Cash, Stress levels */}
      <div className="xl:col-span-1 space-y-6" id="eco-metrics-panel">
        <div className="glass-panel rounded-2xl p-5 flex flex-col gap-4" id="assets-card">
          <h3 className="text-sm font-bold text-white font-serif flex items-center gap-2 border-b border-white/10 pb-2">
            <Landmark className="h-4 w-4 text-pink-500" /> Financial Holdings Account
          </h3>

          <div className="grid grid-cols-2 gap-4" id="assets-holdings-grid">
            <div className="bg-white/5 rounded-xl p-3.5 border border-white/10" id="cash-reserves-box">
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Liquid Cash Balance</div>
              <div className="text-xl font-mono font-bold text-cyan-400 mt-1" id="cash-value">${cash.toFixed(2)}</div>
            </div>
            <div className="bg-white/5 rounded-xl p-3.5 border border-white/10" id="outstanding-debt-box">
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Outstanding Liability</div>
              <div className="text-xl font-mono font-bold text-pink-400 mt-1" id="debt-value">${debt.toFixed(2)}</div>
            </div>
          </div>

          <div className="space-y-1.5" id="fixed-expenses-inputs">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Simulation Parameters</div>
            <div className="grid grid-cols-3 gap-2" id="inputs-grid">
              <div className="space-y-1" id="rent-input-box">
                <span className="text-[9px] text-slate-400 font-bold">Monthly Rent</span>
                <input
                  id="rent-input"
                  type="number"
                  value={rent}
                  onChange={(e) => setRent(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full glass-input rounded-xl p-1.5 font-mono text-xs text-white focus:outline-none"
                />
              </div>
              <div className="space-y-1" id="utilities-input-box">
                <span className="text-[9px] text-slate-400 font-bold">Utilities Grid</span>
                <input
                  id="utilities-input"
                  type="number"
                  value={utilities}
                  onChange={(e) => setUtilities(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full glass-input rounded-xl p-1.5 font-mono text-xs text-white focus:outline-none"
                />
              </div>
              <div className="space-y-1" id="salary-input-box">
                <span className="text-[9px] text-slate-400 font-bold">Base Salary</span>
                <input
                  id="salary-input"
                  type="number"
                  value={salary}
                  onChange={(e) => setSalary(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full glass-input rounded-xl p-1.5 font-mono text-xs text-white focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Financial Stress Card */}
        <div className="glass-panel rounded-2xl p-5 flex flex-col gap-4" id="eco-stress-card">
          <div className="flex justify-between items-center" id="stress-header">
            <h3 className="text-sm font-bold text-white font-serif">Financial Stress Impact</h3>
            <span className="text-[10px] font-mono font-bold bg-pink-500/20 text-pink-300 border border-pink-500/30 px-2.5 py-0.5 rounded-full" id="stress-ratio-label">
              Stress Coefficient: {(financialStress * 100).toFixed(0)}%
            </span>
          </div>

          <div className="h-2.5 bg-white/5 rounded-full overflow-hidden border border-white/10" id="stress-coeff-bar-bg">
            <div
              className={`h-full transition-all duration-500 bg-pink-500 shadow-[0_0_8px_rgba(236,72,153,0.4)]`}
              style={{ width: `${financialStress * 100}%` }}
              id="stress-coeff-bar-fill"
            />
          </div>

          <div className="space-y-3 pt-2" id="utility-multipliers-display">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-sans">Behavioral GOAP Multipliers</div>

            <div className="flex justify-between items-center text-xs p-2.5 bg-white/5 border border-white/10 rounded-xl" id="multiplier-work-box">
              <span className="text-slate-300 font-medium">Work Overtime Weight (1 + 3.5 × Stress)</span>
              <span className="font-mono text-cyan-400 font-extrabold">{workMultiplier.toFixed(2)}x</span>
            </div>

            <div className="flex justify-between items-center text-xs p-2.5 bg-white/5 border border-white/10 rounded-xl" id="multiplier-leisure-box">
              <span className="text-slate-300 font-medium">Leisure Weight (1 - 0.9 × Stress)</span>
              <span className="font-mono text-pink-400 font-extrabold">{leisureMultiplier.toFixed(2)}x</span>
            </div>
          </div>
        </div>
      </div>

      {/* Center Column: Manual Economic Incidents */}
      <div className="xl:col-span-1 space-y-6" id="eco-incidents-panel">
        <div className="glass-panel rounded-2xl p-5" id="eco-events-card">
          <h3 className="text-sm font-bold text-white font-serif mb-4">Execute Economic Actions</h3>

          <div className="space-y-3" id="economic-actions-list">
            <div className="space-y-1.5" id="expense-actions-group">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Trigger Liabilities</span>
              <div className="grid grid-cols-2 gap-2" id="expense-grid">
                <button
                  id="eco-buy-groceries-btn"
                  onClick={() => handleApplyExpense('Bought Weekly Groceries', 65, 'groceries')}
                  className="p-2.5 bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 rounded-xl text-left text-xs font-semibold text-slate-200 transition-all flex flex-col gap-0.5"
                >
                  <span>🛒 Buy Food</span>
                  <span className="text-[10px] font-mono text-slate-400 font-normal">Costs -$65.00</span>
                </button>
                <button
                  id="eco-pay-utilities-btn"
                  onClick={() => handleApplyExpense('Paid Monthly Utility Grid', utilities, 'utilities')}
                  className="p-2.5 bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 rounded-xl text-left text-xs font-semibold text-slate-200 transition-all flex flex-col gap-0.5"
                >
                  <span>⚡ Pay Utilities</span>
                  <span className="text-[10px] font-mono text-slate-400 font-normal">Costs -${utilities.toFixed(2)}</span>
                </button>
                <button
                  id="eco-charge-rent-btn"
                  onClick={() => handleApplyExpense('Apartment Monthly Rent', rent, 'housing')}
                  className="p-2.5 bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 rounded-xl text-left text-xs font-semibold text-slate-200 transition-all flex flex-col gap-0.5"
                >
                  <span>🏠 Pay Home Rent</span>
                  <span className="text-[10px] font-mono text-slate-400 font-normal">Costs -${rent.toFixed(2)}</span>
                </button>
                <button
                  id="eco-pay-taxes-btn"
                  onClick={() => handleApplyExpense('Taxes Remitted to Council', 140, 'tax')}
                  className="p-2.5 bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 rounded-xl text-left text-xs font-semibold text-slate-200 transition-all flex flex-col gap-0.5"
                >
                  <span>🏛️ Remit Taxes</span>
                  <span className="text-[10px] font-mono text-slate-400 font-normal">Costs -$140.00</span>
                </button>
              </div>
            </div>

            <div className="space-y-1.5 pt-2" id="income-actions-group">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Acquire Liquidity</span>
              <div className="grid grid-cols-2 gap-2" id="income-grid">
                <button
                  id="eco-payday-btn"
                  onClick={() => handleReceiveIncome('Received Monthly Base Salary', salary, 'salary')}
                  className="p-2.5 bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 rounded-xl text-left text-xs font-semibold text-slate-200 transition-all flex flex-col gap-0.5"
                >
                  <span>💼 Collect Salary</span>
                  <span className="text-[10px] font-mono text-slate-400 font-normal">Earns +${salary.toFixed(2)}</span>
                </button>
                <button
                  id="eco-overtime-btn"
                  onClick={() => handleReceiveIncome('Overtime Freelance Bonus', 180, 'salary')}
                  className="p-2.5 bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 rounded-xl text-left text-xs font-semibold text-slate-200 transition-all flex flex-col gap-0.5"
                >
                  <span>🔨 Freelance Shift</span>
                  <span className="text-[10px] font-mono text-slate-400 font-normal">Earns +$180.00</span>
                </button>
              </div>
            </div>

            <div className="space-y-1.5 pt-2" id="liability-actions-group">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Debt & Liabilities</span>
              <div className="grid grid-cols-2 gap-2" id="liability-grid">
                <button
                  id="eco-pay-debt-50-btn"
                  onClick={() => handlePayDebt(100)}
                  className="p-2.5 bg-pink-500/10 border border-pink-500/30 hover:bg-pink-500/20 rounded-xl text-left text-xs font-semibold text-pink-300 transition-all flex flex-col gap-0.5 cursor-pointer"
                >
                  <span>💳 Pay Debt Principal</span>
                  <span className="text-[10px] font-mono text-pink-400 font-normal">Settle $100.00</span>
                </button>
                <button
                  id="eco-draw-debt-btn"
                  onClick={() => {
                    setDebt((prev) => prev + 500);
                    setCash((prev) => prev + 500);
                    setLedger((prev) => [
                      {
                        id: Math.random().toString(),
                        timestamp: `Day ${prev.length + 1}, 10:00`,
                        description: 'Drew Bank Loan Liquidity',
                        amount: 500,
                        category: 'debt'
                      },
                      ...prev
                    ]);
                  }}
                  className="p-2.5 bg-white/10 text-white border border-white/20 hover:bg-white/20 rounded-xl text-left text-xs font-semibold transition-all flex flex-col gap-0.5 cursor-pointer"
                >
                  <span>💸 Borrow $500.00</span>
                  <span className="text-[10px] font-mono text-slate-300 font-normal">Spikes Liability</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: Ledger Log Entries */}
      <div className="xl:col-span-1 space-y-6" id="eco-ledger-panel">
        <div className="glass-panel rounded-2xl p-5 h-full flex flex-col" id="ledger-card">
          <h3 className="text-sm font-bold text-white font-serif flex items-center gap-2 border-b border-white/10 pb-3 mb-4 shrink-0">
            <FileText className="h-4 w-4 text-cyan-400" /> Double-Entry Ledger Transactions
          </h3>

          <div className="flex-1 overflow-y-auto space-y-2.5 max-h-[360px] pr-1 glass-scrollbar" id="ledger-entries-list">
            {ledger.map((entry) => {
              const isPositive = entry.amount > 0;
              return (
                <div key={entry.id} className="flex justify-between items-start border-b border-white/5 pb-2" id={`ledger-entry-${entry.id}`}>
                  <div className="flex items-start gap-2.5 min-w-0" id={`ledger-entry-details-${entry.id}`}>
                    <div className={`p-1.5 rounded-md border shrink-0 ${isPositive ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' : 'bg-pink-500/20 text-pink-300 border-pink-500/30'}`} id={`ledger-entry-icon-container-${entry.id}`}>
                      {isPositive ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}
                    </div>
                    <div className="min-w-0" id={`ledger-entry-text-${entry.id}`}>
                      <div className="text-xs font-bold text-slate-200 truncate" id={`ledger-entry-desc-${entry.id}`}>{entry.description}</div>
                      <div className="text-[9.5px] font-mono text-slate-400 mt-0.5" id={`ledger-entry-time-${entry.id}`}>{entry.timestamp} • {entry.category}</div>
                    </div>
                  </div>
                  <span className={`font-mono text-xs font-bold ${isPositive ? 'text-cyan-400' : 'text-pink-400'}`} id={`ledger-entry-amount-${entry.id}`}>
                    {isPositive ? '+' : ''}${entry.amount.toFixed(2)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
