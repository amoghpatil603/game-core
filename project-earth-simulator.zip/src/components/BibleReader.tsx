import { useState, useMemo } from 'react';
import { BIBLE_CHAPTERS } from '../data/bibleData';
import { Search, BookOpen, AlertCircle, FileText, CheckCircle2 } from 'lucide-react';

interface BibleReaderProps {
  signedOffChapters: string[];
  toggleSignOff: (chapterId: string) => void;
}

export default function BibleReader({ signedOffChapters, toggleSignOff }: BibleReaderProps) {
  const [selectedChapterId, setSelectedChapterId] = useState('vol-0');
  const [searchQuery, setSearchQuery] = useState('');

  const selectedChapter = useMemo(() => {
    return BIBLE_CHAPTERS.find((c) => c.id === selectedChapterId) || BIBLE_CHAPTERS[0];
  }, [selectedChapterId]);

  const filteredChapters = useMemo(() => {
    if (!searchQuery.trim()) return BIBLE_CHAPTERS;
    const query = searchQuery.toLowerCase();
    return BIBLE_CHAPTERS.filter((c) => {
      const matchTitle = c.title.toLowerCase().includes(query) || c.subTitle.toLowerCase().includes(query);
      const matchSections = c.sections.some(
        (s) => s.title.toLowerCase().includes(query) || s.content.toLowerCase().includes(query)
      );
      return matchTitle || matchSections;
    });
  }, [searchQuery]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 h-[calc(100vh-210px)]" id="bible-reader-root">
      {/* Sidebar navigation */}
      <div className="lg:col-span-1 glass-panel rounded-2xl p-4 flex flex-col gap-4 overflow-hidden" id="bible-sidebar">
        <div className="relative" id="bible-search-container">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" id="bible-search-icon" />
          <input
            id="bible-search-input"
            type="text"
            placeholder="Search Bible..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm glass-input rounded-xl focus:outline-none text-white placeholder-slate-400"
          />
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-1 glass-scrollbar" id="bible-chapters-list">
          {filteredChapters.map((chapter) => {
            const isSelected = chapter.id === selectedChapterId;
            const isSignedOff = signedOffChapters.includes(chapter.id);
            return (
              <button
                id={`chapter-btn-${chapter.id}`}
                key={chapter.id}
                onClick={() => setSelectedChapterId(chapter.id)}
                className={`w-full text-left p-3.5 rounded-xl transition-all duration-200 flex items-start gap-3 border ${
                  isSelected
                    ? 'bg-pink-500/20 text-white border-pink-500/40 shadow-[0_0_12px_rgba(236,72,153,0.1)]'
                    : 'bg-white/5 hover:bg-white/10 text-slate-300 border-white/5 hover:border-white/20'
                }`}
              >
                <div className="mt-0.5" id={`chapter-icon-container-${chapter.id}`}>
                  {isSignedOff ? (
                    <CheckCircle2 className={`h-4.5 w-4.5 ${isSelected ? 'text-pink-400' : 'text-cyan-400'}`} id={`signed-off-icon-${chapter.id}`} />
                  ) : (
                    <BookOpen className="h-4.5 w-4.5 opacity-70 text-slate-400" id={`book-icon-${chapter.id}`} />
                  )}
                </div>
                <div className="flex-1 min-w-0" id={`chapter-text-container-${chapter.id}`}>
                  <div className={`text-[10px] font-bold tracking-widest uppercase opacity-75 mb-0.5 ${isSelected ? 'text-pink-300' : 'text-slate-400'}`} id={`chapter-vol-${chapter.id}`}>
                    {chapter.volume}
                  </div>
                  <h4 className="text-xs font-semibold leading-tight truncate" id={`chapter-title-${chapter.id}`}>{chapter.title}</h4>
                </div>
              </button>
            );
          })}
          {filteredChapters.length === 0 && (
            <div className="text-center py-8 text-slate-400 text-xs" id="no-chapters-found">No matching chapters found.</div>
          )}
        </div>

        <div className="p-3 bg-pink-500/10 border border-pink-500/20 rounded-xl" id="phase-1-5-info">
          <div className="flex gap-2" id="info-flex">
            <AlertCircle className="h-4 w-4 text-pink-400 shrink-0 mt-0.5" id="info-icon" />
            <div className="text-[11px] text-slate-300 leading-normal" id="info-text">
              <span className="font-semibold">Phase 1.5 Mandate:</span> Review all specifications and equations. Sign off to declare sections approved for the final Phase 2 assembly.
            </div>
          </div>
        </div>
      </div>

      {/* Main Document Viewer */}
      <div className="lg:col-span-3 glass-panel rounded-2xl p-8 overflow-y-auto flex flex-col glass-scrollbar" id="bible-doc-viewer">
        <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/10 pb-6 mb-6 gap-4" id="doc-header">
          <div id="doc-title-container">
            <div className="text-xs font-bold text-pink-400 tracking-widest uppercase mb-1" id="doc-volume-label">
              {selectedChapter.volume} • HUMAN SIMULATION BIBLE
            </div>
            <h2 className="text-2xl font-bold text-white font-serif" id="doc-main-title">{selectedChapter.title}</h2>
            <p className="text-slate-300 text-xs mt-1 leading-relaxed max-w-2xl" id="doc-sub-title">{selectedChapter.subTitle}</p>
          </div>
          <button
            id={`sign-off-btn-${selectedChapter.id}`}
            onClick={() => toggleSignOff(selectedChapter.id)}
            className={`px-4 py-2 text-xs font-semibold rounded-xl shadow-sm transition-all flex items-center gap-2 border ${
              signedOffChapters.includes(selectedChapter.id)
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30 hover:bg-cyan-500/30'
                : 'bg-pink-500/20 text-white hover:bg-pink-500/30 border-pink-500/30'
            }`}
          >
            {signedOffChapters.includes(selectedChapter.id) ? (
              <>
                <CheckCircle2 className="h-4 w-4 text-cyan-400" id="sign-off-checked" />
                Chapter Signed Off
              </>
            ) : (
              <>
                <FileText className="h-4 w-4" id="sign-off-unchecked" />
                Sign Off Chapter
              </>
            )}
          </button>
        </div>

        {/* Document Content */}
        <div className="flex-1 space-y-8 max-w-3xl" id="doc-body">
          {selectedChapter.sections.map((section, idx) => (
            <div key={idx} className="space-y-3" id={`section-${idx}`}>
              <h3 className="text-sm font-bold text-white font-mono tracking-tight flex items-center gap-2" id={`section-title-${idx}`}>
                <span className="text-pink-500 font-bold" id={`section-num-${idx}`}>§</span> {section.title}
              </h3>
              <p className="text-slate-300 text-sm leading-relaxed" id={`section-content-${idx}`}>{section.content}</p>

              {/* Equations Render block */}
              {section.equations && section.equations.length > 0 && (
                <div className="bg-white/5 border-l-2 border-pink-500 rounded-r-xl p-4 font-mono text-xs text-slate-300 space-y-1.5 shadow-xs" id={`section-eq-container-${idx}`}>
                  <div className="text-[9px] font-bold tracking-wider text-slate-400 uppercase mb-1" id={`eq-tag-${idx}`}>Mathematical Reference</div>
                  {section.equations.map((eq, eqIdx) => (
                    <div key={eqIdx} className="pl-2 flex items-center justify-between" id={`eq-item-${idx}-${eqIdx}`}>
                      <span className="text-white font-semibold" id={`eq-text-${idx}-${eqIdx}`}>{eq}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Matrices Render block */}
              {section.matrices && section.matrices.length > 0 && (
                <div className="overflow-x-auto border border-white/10 rounded-xl my-4 bg-white/5" id={`section-matrix-container-${idx}`}>
                  <table className="w-full text-left border-collapse text-xs" id={`section-matrix-table-${idx}`}>
                    <thead>
                      <tr className="bg-white/10 border-b border-white/10" id={`matrix-header-row-${idx}`}>
                        {section.matrices[0].map((header, hIdx) => (
                          <th key={hIdx} className="p-2.5 font-bold text-slate-200 uppercase tracking-wider text-[10px]" id={`matrix-th-${idx}-${hIdx}`}>
                            {header}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5" id={`matrix-tbody-${idx}`}>
                      {section.matrices.slice(1).map((row, rIdx) => (
                        <tr key={rIdx} className="hover:bg-white/5 transition-colors" id={`matrix-tr-${idx}-${rIdx}`}>
                          {row.map((cell, cIdx) => (
                            <td key={cIdx} className={`p-2.5 text-slate-300 ${cIdx === 0 ? 'font-medium font-mono' : ''}`} id={`matrix-td-${idx}-${rIdx}-${cIdx}`}>
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="border-t border-white/10 pt-6 mt-12 flex justify-between items-center text-xs text-slate-400 font-mono" id="doc-footer">
          <span id="doc-confidential">PROJECT EARTH CONFIDENTIAL • SYSTEM DESIGN</span>
          <span id="doc-version">v2.1.0 COMPLIANT</span>
        </div>
      </div>
    </div>
  );
}
