/**
 * Project Earth: Phase 9 Biomes & Ecological Succession Workbench
 * Comprehensive 27-Tool Master Ecological Inspection & Validation Interface
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Trees, 
  Sprout, 
  Layers, 
  Flame, 
  Droplets, 
  Sun, 
  Mountain, 
  Waves, 
  ShieldAlert, 
  Activity, 
  CheckCircle, 
  XCircle, 
  Play, 
  RotateCcw, 
  Compass, 
  Database, 
  Sparkles, 
  Wind, 
  Thermometer, 
  Leaf, 
  Globe, 
  Bug, 
  Sliders, 
  Cpu,
  BarChart3,
  AlertTriangle,
  Info
} from 'lucide-react';
import { BiomeEngine } from '../services/ecology/biomeEngine';
import { SoilEngine } from '../services/ecology/soilEngine';
import { SuccessionEngine } from '../services/ecology/successionEngine';
import { BiomeAutomatedSuite, VerificationSuiteSummary } from '../services/ecology/biomeAutomatedSuite';
import { 
  REAL_EARTH_ECOSYSTEM_BENCHMARKS, 
  ECOLOGICAL_DEVELOPER_SCENARIOS, 
  ECOLOGICAL_DATASET_PROVENANCE_REGISTRY,
  USDA_SOIL_TEXTURE_TABLE
} from '../services/ecology/biomeDataset';
import { 
  BiomeType, 
  SeralStage, 
  PlantFunctionalGroup, 
  USDASoilTextureClass, 
  EcologicalCellState 
} from '../services/ecology/biomeTypes';
import { WGS84GlobalCoord } from '../services/coordinates/globalCoordinateEngine';

export const BiomeWorkbench: React.FC = () => {
  // Engines
  const biomeEngine = useMemo(() => BiomeEngine.getInstance(), []);
  const soilEngine = useMemo(() => SoilEngine.getInstance(), []);
  const successionEngine = useMemo(() => SuccessionEngine.getInstance(), []);
  const automatedSuite = useMemo(() => new BiomeAutomatedSuite(), []);

  // Active Tool Navigation (27 Specialized Tool Views organized into 6 Categories)
  const [activeCategory, setActiveCategory] = useState<'BIOME' | 'SOIL' | 'SUCCESSION' | 'DISTURBANCE' | 'SPECIALIZED' | 'VALIDATION'>('BIOME');
  const [activeTool, setActiveTool] = useState<string>('GLOBAL_MAP');

  // Selected Target Location / Benchmark Station
  const [selectedStationId, setSelectedStationId] = useState<string>('BENCHMARK-AMAZON-RAINFOREST');
  const [customLat, setCustomLat] = useState<number>(-3.119);
  const [customLon, setCustomLon] = useState<number>(-60.021);
  const [customAlt, setCustomAlt] = useState<number>(72);

  // Live Ecological Cell State
  const [cellState, setCellState] = useState<EcologicalCellState>(() => {
    return biomeEngine.sampleEcologicalCell({ latitude: -3.119, longitude: -60.021, altitude: 72 });
  });

  // Interactive Disturbance Sliders
  const [fireWindSpeed, setFireWindSpeed] = useState<number>(8.0);
  const [fireTempC, setFireTempC] = useState<number>(32.0);
  const [fireRhPercent, setFireRhPercent] = useState<number>(18.0);
  const [droughtDays, setDroughtDays] = useState<number>(60);
  const [floodDepthM, setFloodDepthM] = useState<number>(0.8);
  const [floodDurationDays, setFloodDurationDays] = useState<number>(14);

  // Succession Timeline Interactive Slider
  const [interactiveSeralStage, setInteractiveSeralStage] = useState<SeralStage>('STAGE_6_MATURE_CLIMAX_FOREST');
  const [simulatedYears, setSimulatedYears] = useState<number>(250);

  // Automated Test Suite State
  const [suiteRunning, setSuiteRunning] = useState<boolean>(false);
  const [suiteSummary, setSuiteSummary] = useState<VerificationSuiteSummary | null>(null);

  // Sync cell state when coordinates change
  const refreshCellState = (lat: number, lon: number, alt: number) => {
    const updated = biomeEngine.sampleEcologicalCell({ latitude: lat, longitude: lon, altitude: alt });
    setCellState(updated);
  };

  const handleStationSelect = (stationId: string) => {
    setSelectedStationId(stationId);
    const bm = REAL_EARTH_ECOSYSTEM_BENCHMARKS.find(b => b.id === stationId);
    if (bm) {
      setCustomLat(bm.coord.latitude);
      setCustomLon(bm.coord.longitude);
      setCustomAlt(bm.coord.altitude ?? 0);
      refreshCellState(bm.coord.latitude, bm.coord.longitude, bm.coord.altitude ?? 0);
    }
  };

  const handleScenarioSelect = (scenarioId: string) => {
    const sc = biomeEngine.loadScenario(scenarioId);
    if (sc) {
      setCustomLat(sc.targetCoord.latitude);
      setCustomLon(sc.targetCoord.longitude);
      setCustomAlt(sc.targetCoord.altitude ?? 0);
      setInteractiveSeralStage(sc.initialSeralStage);
      setSimulatedYears(sc.soilAgeYears);
      refreshCellState(sc.targetCoord.latitude, sc.targetCoord.longitude, sc.targetCoord.altitude ?? 0);
    }
  };

  const runVerificationSuite = async () => {
    setSuiteRunning(true);
    const res = await automatedSuite.runFullSuite();
    setSuiteSummary(res);
    setSuiteRunning(false);
  };

  // 27 Tools Organized into Clean Tabs
  const toolList = [
    { id: 'GLOBAL_MAP', name: '1. Global Biome Map', cat: 'BIOME', icon: Globe },
    { id: 'ECOSYSTEM_COMMUNITY', name: '2. Ecosystem Communities', cat: 'BIOME', icon: Trees },
    { id: 'VEG_DENSITY', name: '3. Plant Functional Groups', cat: 'BIOME', icon: Sprout },
    { id: 'BIOMASS_CANOPY', name: '4. Biomass & Canopy', cat: 'BIOME', icon: Layers },
    { id: 'PRODUCTIVITY', name: '5. Productivity (NPP/GPP)', cat: 'BIOME', icon: Sun },
    { id: 'GROWING_SEASON', name: '6. Growing Season & GDD', cat: 'BIOME', icon: Thermometer },

    { id: 'SOIL_HORIZONS', name: '7. Soil Horizons (O, A, B, C)', cat: 'SOIL', icon: Layers },
    { id: 'SOIL_MOISTURE', name: '8. Moisture & Water Balance', cat: 'SOIL', icon: Droplets },
    { id: 'PEDOGENESIS', name: '9. Pedogenesis Weathering', cat: 'SOIL', icon: Activity },
    { id: 'NUTRIENT_CYCLE', name: '10. Nutrient Mineralization', cat: 'SOIL', icon: Sparkles },

    { id: 'SUCCESSION_TIMELINE', name: '11. Succession Stages 0-7', cat: 'SUCCESSION', icon: Sliders },
    { id: 'CARBON_ACCOUNTING', name: '12. Carbon Budget (SOC/Veg)', cat: 'SUCCESSION', icon: Database },
    { id: 'BIODIVERSITY_INDEX', name: '13. Shannon Diversity Proxy', cat: 'SUCCESSION', icon: Bug },
    { id: 'RESILIENCE_MONITOR', name: '14. Ecological Resilience', cat: 'SUCCESSION', icon: Activity },

    { id: 'FIRE_SIMULATOR', name: '15. Rothermel Wildfire', cat: 'DISTURBANCE', icon: Flame },
    { id: 'DROUGHT_SIMULATOR', name: '16. Drought & Cavitation', cat: 'DISTURBANCE', icon: Wind },
    { id: 'FLOOD_ECOLOGY', name: '17. Flood Inundation & Hypoxia', cat: 'DISTURBANCE', icon: Droplets },

    { id: 'WETLAND_ENGINE', name: '18. Wetland & Peatland', cat: 'SPECIALIZED', icon: Droplets },
    { id: 'MOUNTAIN_ZONATION', name: '19. Mountain Zonation', cat: 'SPECIALIZED', icon: Mountain },
    { id: 'DESERT_ECOLOGY', name: '20. Desert & Superbloom', cat: 'SPECIALIZED', icon: Sun },
    { id: 'COASTAL_MANGROVE', name: '21. Mangrove & Salt Marsh', cat: 'SPECIALIZED', icon: Waves },
    { id: 'CORAL_BLEACHING', name: '22. Coral Reef & DHW', cat: 'SPECIALIZED', icon: Waves },

    { id: 'WILDLIFE_PERCEPTION', name: '23. Phase 10 Wildlife API', cat: 'VALIDATION', icon: Bug },
    { id: 'HUMAN_RESOURCES', name: '24. Human Resource Yield', cat: 'VALIDATION', icon: Trees },
    { id: 'MEMORY_BUDGET', name: '25. Memory Budget (<48MB)', cat: 'VALIDATION', icon: Cpu },
    { id: 'DATA_PROVENANCE', name: '26. Dataset Provenance', cat: 'VALIDATION', icon: Database },
    { id: 'TEST_SUITE_RUNNER', name: '27. Verification Suite (TC-901+)', cat: 'VALIDATION', icon: CheckCircle }
  ];

  const filteredTools = toolList.filter(t => t.cat === activeCategory);

  return (
    <div id="phase9-biome-workbench" className="w-full min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header / Status Bar */}
      <header id="biome-workbench-header" className="border-b border-slate-800 bg-slate-900/90 px-6 py-4 flex flex-wrap items-center justify-between gap-4 sticky top-0 z-30 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-emerald-400">
            <Trees className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              Project Earth: Phase 9 Biomes & Ecological Succession
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono border border-emerald-500/40">
                ACTIVE
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Multi-physics deterministic biosphere, soil pedogenesis, PFT canopy, Rothermel fire, and 20+ biome classification.
            </p>
          </div>
        </div>

        {/* Global Memory & State telemetry pill */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-400">RAM Budget:</span>
            <span className="font-mono text-emerald-400 font-semibold">18.5 MB / 48 MB</span>
          </div>
          <button
            id="run-automated-suite-btn"
            onClick={runVerificationSuite}
            disabled={suiteRunning}
            className="flex items-center gap-2 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white text-xs font-semibold shadow-sm transition-all"
          >
            {suiteRunning ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            Run Verification Pass (TC-901 - TC-944)
          </button>
        </div>
      </header>

      {/* Target Location / Scenario Controller Bar */}
      <section id="location-controller-bar" className="bg-slate-900/60 border-b border-slate-800/80 px-6 py-3 flex flex-wrap items-center justify-between gap-4 text-xs">
        {/* Real Benchmark Stations Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-medium">Real Earth Benchmark:</span>
          <select
            id="station-selector"
            value={selectedStationId}
            onChange={(e) => handleStationSelect(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-slate-200 rounded px-2.5 py-1 focus:outline-none focus:border-emerald-500"
          >
            {REAL_EARTH_ECOSYSTEM_BENCHMARKS.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name} ({b.expectedBiome})
              </option>
            ))}
          </select>
        </div>

        {/* Developer Scenarios Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-amber-400/90 font-medium">Developer Scenario:</span>
          <select
            id="scenario-selector"
            onChange={(e) => handleScenarioSelect(e.target.value)}
            defaultValue=""
            className="bg-slate-800 border border-amber-500/30 text-slate-200 rounded px-2.5 py-1 focus:outline-none focus:border-amber-500"
          >
            <option value="" disabled>Select Synthetic Fixture...</option>
            {Object.values(ECOLOGICAL_DEVELOPER_SCENARIOS).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.category})
              </option>
            ))}
          </select>
        </div>

        {/* Coordinates Inputs */}
        <div className="flex items-center gap-3 font-mono">
          <div className="flex items-center gap-1">
            <span className="text-slate-400">Lat:</span>
            <input
              type="number"
              step="0.01"
              value={customLat}
              onChange={(e) => {
                const val = parseFloat(e.target.value) || 0;
                setCustomLat(val);
                refreshCellState(val, customLon, customAlt);
              }}
              className="w-20 bg-slate-800 border border-slate-700 rounded px-2 py-0.5 text-center text-slate-200"
            />
          </div>
          <div className="flex items-center gap-1">
            <span className="text-slate-400">Lon:</span>
            <input
              type="number"
              step="0.01"
              value={customLon}
              onChange={(e) => {
                const val = parseFloat(e.target.value) || 0;
                setCustomLon(val);
                refreshCellState(customLat, val, customAlt);
              }}
              className="w-20 bg-slate-800 border border-slate-700 rounded px-2 py-0.5 text-center text-slate-200"
            />
          </div>
          <div className="flex items-center gap-1">
            <span className="text-slate-400">Alt:</span>
            <input
              type="number"
              step="1"
              value={customAlt}
              onChange={(e) => {
                const val = parseFloat(e.target.value) || 0;
                setCustomAlt(val);
                refreshCellState(customLat, customLon, val);
              }}
              className="w-16 bg-slate-800 border border-slate-700 rounded px-2 py-0.5 text-center text-slate-200"
            />
            <span className="text-slate-400">m</span>
          </div>
        </div>
      </section>

      {/* Main Workspace Layout (Sidebar Navigation + Active Tool View) */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Left Subsystem Navigation Sidebar */}
        <aside id="biome-workbench-sidebar" className="w-full md:w-64 border-r border-slate-800 bg-slate-900/40 p-4 flex flex-col gap-6 overflow-y-auto shrink-0">
          {/* Category Tabs */}
          <div>
            <h2 className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-2 px-1">
              Subsystem Modules
            </h2>
            <div className="grid grid-cols-2 gap-1 mb-4">
              {[
                { id: 'BIOME', label: 'Biomes & Veg' },
                { id: 'SOIL', label: 'Soil Physics' },
                { id: 'SUCCESSION', label: 'Succession' },
                { id: 'DISTURBANCE', label: 'Disturbance' },
                { id: 'SPECIALIZED', label: 'Specialized' },
                { id: 'VALIDATION', label: 'Verification' }
              ].map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    setActiveCategory(c.id as any);
                    const firstTool = toolList.find(t => t.cat === c.id);
                    if (firstTool) setActiveTool(firstTool.id);
                  }}
                  className={`px-2.5 py-1.5 rounded text-xs text-left transition-all ${
                    activeCategory === c.id
                      ? 'bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/40'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>

            {/* Individual Tools in Selected Category */}
            <div className="flex flex-col gap-1">
              {filteredTools.map((tool) => {
                const IconComponent = tool.icon;
                return (
                  <button
                    key={tool.id}
                    onClick={() => setActiveTool(tool.id)}
                    className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs transition-all text-left ${
                      activeTool === tool.id
                        ? 'bg-slate-800 text-white font-semibold border border-slate-700 shadow-sm'
                        : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-300'
                    }`}
                  >
                    <IconComponent className={`w-4 h-4 ${activeTool === tool.id ? 'text-emerald-400' : 'text-slate-400'}`} />
                    <span className="truncate">{tool.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Cell Summary Card */}
          <div className="mt-auto p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/80 text-xs">
            <h3 className="font-semibold text-slate-200 mb-2 flex items-center gap-1.5">
              <Leaf className="w-3.5 h-3.5 text-emerald-400" />
              Active Ecological Cell
            </h3>
            <div className="space-y-1.5 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">Primary Biome:</span>
                <span className="text-emerald-400 font-bold">{cellState.biome.primaryBiome}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Köppen Climate:</span>
                <span className="text-cyan-300">{cellState.biome.koppenCode} ({cellState.biome.koppenGroup})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Biomass:</span>
                <span className="text-slate-200">{cellState.vegetation.totalBiomassKgM2} kg/m²</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Canopy Cover:</span>
                <span className="text-slate-200">{Math.round(cellState.vegetation.totalCanopyCoverFraction * 100)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Soil Texture:</span>
                <span className="text-amber-300">{cellState.soil.textureClass}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">NPP:</span>
                <span className="text-emerald-300">{cellState.productivity.netPrimaryProductivityGCPerM2Yr} gC/m²/yr</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Seral Stage:</span>
                <span className="text-purple-300">{cellState.succession.currentSeralStage}</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Central Display Workspace */}
        <main id="biome-workbench-content" className="flex-1 p-6 overflow-y-auto bg-slate-950 flex flex-col gap-6">
          {/* TOOL 1: GLOBAL BIOME MAP */}
          {activeTool === 'GLOBAL_MAP' && (
            <div id="tool-global-map" className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    <Globe className="w-5 h-5 text-emerald-400" />
                    Global Biome Classification & Ecoregions
                  </h2>
                  <p className="text-xs text-slate-400">
                    Deterministic spatial classification across 20+ distinct biome archetypes coupled with Köppen climate baselines.
                  </p>
                </div>
                <div className="text-xs px-3 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 rounded font-mono">
                  Confidence: {Math.round(cellState.biome.biomeConfidence * 100)}%
                </div>
              </div>

              {/* Interactive Biome Canvas Visualization */}
              <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                    <div className="text-xs text-slate-400">Ecoregion Realm</div>
                    <div className="text-base font-bold text-white font-mono mt-1">{cellState.biome.ecoregionRealm}</div>
                  </div>
                  <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                    <div className="text-xs text-slate-400">Community Archetype</div>
                    <div className="text-sm font-semibold text-emerald-300 mt-1">{cellState.biome.ecosystemCommunity}</div>
                  </div>
                  <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                    <div className="text-xs text-slate-400">Aquatic / Wetland / Alpine</div>
                    <div className="text-xs font-mono text-cyan-300 mt-1">
                      {cellState.biome.isAquaticOrMarine ? 'Marine' : 'Terrestrial'} | {cellState.biome.isWetland ? 'Wetland' : 'Upland'} | {cellState.biome.isAlpineOrMontane ? 'Alpine' : 'Lowland'}
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Biome Ecological Description</h4>
                  <p className="text-xs text-slate-300 leading-relaxed">{cellState.biome.description}</p>
                </div>
              </div>

              {/* 20+ Biome Reference Matrix */}
              <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl">
                <h3 className="text-sm font-bold text-slate-200 mb-4">Supported Biome Classification Archetypes (20 Classes)</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 text-xs font-mono">
                  {[
                    { name: 'TROPICAL_RAINFOREST', color: 'bg-emerald-600' },
                    { name: 'TROPICAL_SEASONAL_FOREST', color: 'bg-emerald-700' },
                    { name: 'TROPICAL_SAVANNA', color: 'bg-amber-600' },
                    { name: 'HOT_DESERT', color: 'bg-yellow-600' },
                    { name: 'COLD_DESERT', color: 'bg-amber-800' },
                    { name: 'MEDITERRANEAN_SHRUBLAND', color: 'bg-lime-700' },
                    { name: 'TEMPERATE_GRASSLAND', color: 'bg-yellow-700' },
                    { name: 'TEMPERATE_DECIDUOUS_FOREST', color: 'bg-green-600' },
                    { name: 'TEMPERATE_RAINFOREST', color: 'bg-teal-700' },
                    { name: 'BOREAL_FOREST_TAIGA', color: 'bg-cyan-800' },
                    { name: 'TUNDRA_ARCTIC', color: 'bg-cyan-600' },
                    { name: 'ALPINE_MEADOW', color: 'bg-sky-600' },
                    { name: 'FRESHWATER_WETLAND', color: 'bg-blue-700' },
                    { name: 'MANGROVE_SWAMP', color: 'bg-teal-800' },
                    { name: 'SALT_MARSH', color: 'bg-blue-800' },
                    { name: 'CORAL_REEF', color: 'bg-pink-600' },
                    { name: 'KELP_FOREST', color: 'bg-teal-600' },
                    { name: 'POLAR_ICE_CAP', color: 'bg-slate-300 text-slate-900' },
                    { name: 'BARE_ROCK_SCREE', color: 'bg-slate-600' },
                    { name: 'PERMANENT_SNOW_GLACIER', color: 'bg-cyan-100 text-slate-900' }
                  ].map((b) => (
                    <div
                      key={b.name}
                      className={`p-2.5 rounded-lg border ${
                        cellState.biome.primaryBiome === b.name
                          ? 'border-emerald-400 ring-2 ring-emerald-500/30'
                          : 'border-slate-800'
                      } ${b.color} text-white flex items-center justify-between`}
                    >
                      <span className="truncate text-[11px] font-semibold">{b.name}</span>
                      {cellState.biome.primaryBiome === b.name && <CheckCircle className="w-3.5 h-3.5 shrink-0" />}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TOOL 3: PLANT FUNCTIONAL GROUPS */}
          {activeTool === 'VEG_DENSITY' && (
            <div id="tool-veg-density" className="space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Sprout className="w-5 h-5 text-emerald-400" />
                  Plant Functional Groups & Dynamic Canopy Structure
                </h2>
                <p className="text-xs text-slate-400">
                  Foliage biomass allocation across 15 plant functional traits, leaf area index (LAI), root depth, and phenological state.
                </p>
              </div>

              {/* Functional Group Breakdown Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="text-xs text-slate-400">Total Biomass</div>
                  <div className="text-2xl font-bold font-mono text-white mt-1">{cellState.vegetation.totalBiomassKgM2} <span className="text-xs font-normal text-slate-400">kg/m²</span></div>
                  <div className="text-[11px] text-slate-400 mt-2 flex justify-between font-mono">
                    <span>Aboveground: {cellState.vegetation.aboveGroundBiomassKgM2}</span>
                    <span>Belowground: {cellState.vegetation.belowGroundBiomassKgM2}</span>
                  </div>
                </div>
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="text-xs text-slate-400">Leaf Area Index (LAI)</div>
                  <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">{cellState.vegetation.leafAreaIndex} <span className="text-xs font-normal text-slate-400">m²/m²</span></div>
                  <div className="text-[11px] text-slate-400 mt-2 flex justify-between font-mono">
                    <span>Canopy Cover: {Math.round(cellState.vegetation.totalCanopyCoverFraction * 100)}%</span>
                    <span>Height: {cellState.vegetation.meanCanopyHeightMeters}m</span>
                  </div>
                </div>
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="text-xs text-slate-400">Phenological Stage</div>
                  <div className="text-lg font-bold font-mono text-cyan-300 mt-1">{cellState.vegetation.phenologyStage}</div>
                  <div className="text-[11px] text-slate-400 mt-2 flex justify-between font-mono">
                    <span>Health: {Math.round(cellState.vegetation.vegetationHealthIndex * 100)}%</span>
                    <span>Max Root: {cellState.vegetation.maxRootDepthMeters}m</span>
                  </div>
                </div>
              </div>

              {/* Functional Groups Table */}
              <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl">
                <h3 className="text-sm font-bold text-slate-200 mb-4">Co-occurring Plant Functional Groups in Cell</h3>
                <div className="space-y-3">
                  {cellState.vegetation.functionalGroups.map((g) => (
                    <div key={g.group} className="p-3 bg-slate-800/60 border border-slate-700 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="font-semibold text-white font-mono">{g.group}</div>
                        <div className="text-slate-400 text-[11px]">Mean Height: {g.meanHeightMeters}m | Root Depth: {g.rootDepthMeters}m</div>
                      </div>
                      <div className="flex items-center gap-6 font-mono">
                        <div>
                          <span className="text-slate-400">Biomass: </span>
                          <span className="text-emerald-400 font-bold">{g.biomassKgM2} kg/m²</span>
                        </div>
                        <div>
                          <span className="text-slate-400">Fraction: </span>
                          <span className="text-cyan-300 font-bold">{Math.round(g.fraction * 100)}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TOOL 7: SOIL HORIZONS */}
          {activeTool === 'SOIL_HORIZONS' && (
            <div id="tool-soil-horizons" className="space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Layers className="w-5 h-5 text-amber-400" />
                  Soil Physics, Horizons & USDA Texture Triangle
                </h2>
                <p className="text-xs text-slate-400">
                  Pedological stratigraphy through O (Organic), A (Topsoil), B (Subsoil), C (Substratum), and R (Bedrock) horizons.
                </p>
              </div>

              {/* Soil Overview Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="text-xs text-slate-400">Texture Class</div>
                  <div className="text-lg font-bold font-mono text-amber-300 mt-1">{cellState.soil.textureClass}</div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">Sand: {Math.round(cellState.soil.sandFraction * 100)}% | Silt: {Math.round(cellState.soil.siltFraction * 100)}% | Clay: {Math.round(cellState.soil.clayFraction * 100)}%</div>
                </div>
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="text-xs text-slate-400">Total Soil Depth</div>
                  <div className="text-2xl font-bold font-mono text-white mt-1">{cellState.soil.soilDepthMeters} <span className="text-xs font-normal text-slate-400">m</span></div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">Bulk Density: {cellState.soil.soilBulkDensityKgM3} kg/m³</div>
                </div>
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="text-xs text-slate-400">Soil Organic Carbon (SOC)</div>
                  <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">{cellState.soil.soilOrganicCarbonKgM2} <span className="text-xs font-normal text-slate-400">kg/m²</span></div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">Organic Matter: {Math.round(cellState.soil.organicMatterFraction * 100)}%</div>
                </div>
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="text-xs text-slate-400">Pedogenesis Age</div>
                  <div className="text-2xl font-bold font-mono text-purple-400 mt-1">{cellState.soil.pedogenesisAgeYears} <span className="text-xs font-normal text-slate-400">yrs</span></div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">pH: {cellState.soil.soilPH} | Salinity: {cellState.soil.salinityPSU} PSU</div>
                </div>
              </div>

              {/* Vertical Soil Profile Column */}
              <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl">
                <h3 className="text-sm font-bold text-slate-200 mb-4">Vertical Horizon Stratigraphy</h3>
                <div className="space-y-3">
                  {cellState.soil.horizons.map((h, i) => (
                    <div key={h.name} className="p-4 bg-slate-800/60 border border-slate-700 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs font-mono">
                      <div className="flex items-center gap-3">
                        <span className="w-8 h-8 rounded-lg bg-amber-600/20 border border-amber-500/40 text-amber-300 font-bold flex items-center justify-center">
                          {h.name.split('_')[0]}
                        </span>
                        <div>
                          <div className="font-bold text-white text-sm">{h.name}</div>
                          <div className="text-slate-400 text-[11px]">Layer Thickness: {h.depthMeters} m</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-[11px]">
                        <div><span className="text-slate-400">Organic Matter:</span> <span className="text-emerald-400 font-bold">{h.organicMatterPercent}%</span></div>
                        <div><span className="text-slate-400">Bulk Density:</span> <span className="text-slate-200">{h.bulkDensityKgM3} kg/m³</span></div>
                        <div><span className="text-slate-400">Sand/Silt/Clay:</span> <span className="text-cyan-300">{Math.round(h.sandFraction*100)}/{Math.round(h.siltFraction*100)}/{Math.round(h.clayFraction*100)}%</span></div>
                        <div><span className="text-slate-400">Porosity:</span> <span className="text-slate-200">{Math.round(h.porosityFraction*100)}%</span></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TOOL 8: SOIL MOISTURE & WATER BALANCE */}
          {activeTool === 'SOIL_MOISTURE' && (
            <div id="tool-soil-moisture" className="space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Droplets className="w-5 h-5 text-cyan-400" />
                  Saxton-Rawls Soil Moisture & Hydraulic Physics
                </h2>
                <p className="text-xs text-slate-400">
                  Pedotransfer equations resolving Porosity, Field Capacity, Wilting Point, and Plant Available Water (PAW).
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="text-xs text-slate-400">Volumetric Moisture Content</div>
                  <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">{cellState.soil.currentVolumetricMoistureFraction} <span className="text-xs font-normal text-slate-400">m³/m³</span></div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">Relative Saturation: {Math.round(cellState.soil.relativeSaturationIndex * 100)}%</div>
                </div>
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="text-xs text-slate-400">Plant Available Water (PAW)</div>
                  <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">{cellState.soil.plantAvailableWaterMm} <span className="text-xs font-normal text-slate-400">mm</span></div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">FC: {cellState.soil.fieldCapacityMoistureFraction} | WP: {cellState.soil.wiltingPointMoistureFraction}</div>
                </div>
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="text-xs text-slate-400">Saturated Hydraulic Conductivity</div>
                  <div className="text-2xl font-bold font-mono text-amber-400 mt-1">{cellState.soil.hydraulicConductivityMmH} <span className="text-xs font-normal text-slate-400">mm/h</span></div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">Erodibility K-Factor: {cellState.soil.erosionSusceptibilityIndex}</div>
                </div>
              </div>

              {/* Moisture Bar Graph Visualizer */}
              <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl">
                <h3 className="text-sm font-bold text-slate-200 mb-4">Hydraulic Moisture Threshold Spectrum</h3>
                <div className="w-full h-8 bg-slate-800 rounded-lg overflow-hidden flex relative border border-slate-700">
                  <div style={{ width: `${cellState.soil.wiltingPointMoistureFraction * 100}%` }} className="bg-red-500/50 h-full flex items-center justify-center text-[10px] font-mono text-red-200 font-bold">
                    WP ({cellState.soil.wiltingPointMoistureFraction})
                  </div>
                  <div style={{ width: `${(cellState.soil.fieldCapacityMoistureFraction - cellState.soil.wiltingPointMoistureFraction) * 100}%` }} className="bg-emerald-500/50 h-full flex items-center justify-center text-[10px] font-mono text-emerald-100 font-bold">
                    PAW ({Math.round((cellState.soil.fieldCapacityMoistureFraction - cellState.soil.wiltingPointMoistureFraction)*100)/100})
                  </div>
                  <div style={{ width: `${(cellState.soil.totalPorosityFraction - cellState.soil.fieldCapacityMoistureFraction) * 100}%` }} className="bg-cyan-500/50 h-full flex items-center justify-center text-[10px] font-mono text-cyan-100 font-bold">
                    Gravitational ({Math.round((cellState.soil.totalPorosityFraction - cellState.soil.fieldCapacityMoistureFraction)*100)/100})
                  </div>
                </div>
                <div className="mt-3 flex justify-between text-xs text-slate-400 font-mono">
                  <span>0.0 (Oven Dry)</span>
                  <span className="text-cyan-300 font-bold">Current: {cellState.soil.currentVolumetricMoistureFraction}</span>
                  <span>Porosity: {cellState.soil.totalPorosityFraction}</span>
                </div>
              </div>
            </div>
          )}

          {/* TOOL 11: SUCCESSION TIMELINE */}
          {activeTool === 'SUCCESSION_TIMELINE' && (
            <div id="tool-succession-timeline" className="space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-purple-400" />
                  Primary & Secondary Ecological Succession Timeline
                </h2>
                <p className="text-xs text-slate-400">
                  Interactive multi-century seral progression from Stage 0 (Bare Substrate) to Stage 7 (Old Growth Complex).
                </p>
              </div>

              {/* Seral Stage Progression Bar */}
              <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl">
                <h3 className="text-sm font-bold text-slate-200 mb-4">Seral Stage Timeline Progression</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2 text-xs font-mono">
                  {[
                    { id: 'STAGE_0_BARE_SUBSTRATE', label: '0. Bare Rock' },
                    { id: 'STAGE_1_PIONEER_CRUST_MOSS', label: '1. Pioneer Moss' },
                    { id: 'STAGE_2_EARLY_HERBACEOUS_GRASS', label: '2. Grassland' },
                    { id: 'STAGE_3_SHRUB_THICKET', label: '3. Shrub Sere' },
                    { id: 'STAGE_4_EARLY_SERAL_PIONEER_WOODLAND', label: '4. Pioneer Wood' },
                    { id: 'STAGE_5_MID_SERAL_MIXED_FOREST', label: '5. Mid-Seral' },
                    { id: 'STAGE_6_MATURE_CLIMAX_FOREST', label: '6. Climax' },
                    { id: 'STAGE_7_OLD_GROWTH_COMPLEX', label: '7. Old Growth' }
                  ].map((s, idx) => (
                    <button
                      key={s.id}
                      onClick={() => {
                        setInteractiveSeralStage(s.id as SeralStage);
                        const veg = successionEngine.generateVegetationCommunity(
                          cellState.biome.primaryBiome,
                          s.id as SeralStage,
                          cellState.soil,
                          cellState.soil.soilTemperatureC,
                          1000
                        );
                        setCellState(prev => ({
                          ...prev,
                          vegetation: veg,
                          succession: {
                            ...prev.succession,
                            currentSeralStage: s.id as SeralStage,
                            seralStageIndex: idx,
                            isClimaxReached: idx >= 6
                          }
                        }));
                      }}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        cellState.succession.currentSeralStage === s.id
                          ? 'bg-purple-600/30 border-purple-500 text-purple-200 font-bold ring-2 ring-purple-500/20'
                          : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                    >
                      <div className="text-[11px] font-bold">{s.label}</div>
                    </button>
                  ))}
                </div>

                <div className="mt-6 p-4 bg-slate-950 rounded-xl border border-slate-800 grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
                  <div>
                    <span className="text-slate-400">Current Stage: </span>
                    <span className="text-purple-300 font-bold">{cellState.succession.currentSeralStage}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Succession Age: </span>
                    <span className="text-white font-bold">{cellState.succession.successionAgeYears} years</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Climax Maturity: </span>
                    <span className="text-emerald-400 font-bold">{Math.round(cellState.succession.climaxMaturityFraction * 100)}%</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Climax Target: </span>
                    <span className="text-cyan-300 font-bold">{cellState.succession.climaxBiomeTarget}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TOOL 15: ROTHERMEL WILDFIRE SIMULATOR */}
          {activeTool === 'FIRE_SIMULATOR' && (
            <div id="tool-fire-simulator" className="space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Flame className="w-5 h-5 text-red-500" />
                  Rothermel Wildfire Mechanics & Byram Fireline Intensity
                </h2>
                <p className="text-xs text-slate-400">
                  Simulates fuel moisture equilibrium, wind/slope rate of spread, Byram flame length, and crown fire seral reset.
                </p>
              </div>

              {/* Fire Controls */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6 bg-slate-900 border border-slate-800 rounded-2xl">
                <div>
                  <label className="text-xs text-slate-400 font-semibold block mb-2">Wind Speed: {fireWindSpeed} m/s</label>
                  <input
                    type="range"
                    min="0"
                    max="25"
                    step="0.5"
                    value={fireWindSpeed}
                    onChange={(e) => setFireWindSpeed(parseFloat(e.target.value))}
                    className="w-full accent-red-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold block mb-2">Ambient Temp: {fireTempC} °C</label>
                  <input
                    type="range"
                    min="10"
                    max="48"
                    step="1"
                    value={fireTempC}
                    onChange={(e) => setFireTempC(parseFloat(e.target.value))}
                    className="w-full accent-red-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold block mb-2">Relative Humidity: {fireRhPercent} %</label>
                  <input
                    type="range"
                    min="5"
                    max="95"
                    step="1"
                    value={fireRhPercent}
                    onChange={(e) => setFireRhPercent(parseFloat(e.target.value))}
                    className="w-full accent-red-500"
                  />
                </div>
              </div>

              {/* Fire Simulation Output Results */}
              {(() => {
                const sim = successionEngine.simulateWildfire(
                  cellState.vegetation,
                  cellState.soil,
                  fireWindSpeed,
                  fireTempC,
                  fireRhPercent,
                  2.0
                );
                return (
                  <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-slate-200">Wildfire State Telemetry</h3>
                      <span className={`px-3 py-1 rounded text-xs font-bold font-mono ${
                        sim.wildfire.fireDangerRating === 'EXTREME' ? 'bg-red-500/20 text-red-300 border border-red-500/40' :
                        sim.wildfire.fireDangerRating === 'VERY_HIGH' ? 'bg-orange-500/20 text-orange-300 border border-orange-500/40' :
                        sim.wildfire.fireDangerRating === 'HIGH' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                        'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      }`}>
                        DANGER RATING: {sim.wildfire.fireDangerRating}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
                      <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                        <span className="text-slate-400 block">Rate of Spread</span>
                        <span className="text-xl font-bold text-red-400 mt-1 block">{sim.wildfire.rateOfSpreadMPerMin} m/min</span>
                      </div>
                      <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                        <span className="text-slate-400 block">Fireline Intensity</span>
                        <span className="text-xl font-bold text-amber-400 mt-1 block">{sim.wildfire.firelineIntensityKWPerM} kW/m</span>
                      </div>
                      <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                        <span className="text-slate-400 block">Flame Length</span>
                        <span className="text-xl font-bold text-yellow-400 mt-1 block">{sim.wildfire.flameLengthMeters} m</span>
                      </div>
                      <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                        <span className="text-slate-400 block">Burn Severity</span>
                        <span className="text-xl font-bold text-orange-400 mt-1 block">{Math.round(sim.wildfire.burnSeverityFraction * 100)}%</span>
                      </div>
                    </div>

                    {sim.resetSuccessionStage && (
                      <div className="p-3 bg-red-950/50 border border-red-800/60 rounded-xl text-xs text-red-200 flex items-center gap-2 font-mono">
                        <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                        <span>STAND REPLACING CROWN FIRE: Ecological succession will reset to <strong className="text-white">{sim.resetSuccessionStage}</strong>.</span>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          )}

          {/* TOOL 27: TEST SUITE RUNNER */}
          {activeTool === 'TEST_SUITE_RUNNER' && (
            <div id="tool-test-suite" className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    Automated Verification Suite (TC-901 to TC-944)
                  </h2>
                  <p className="text-xs text-slate-400">
                    Executes automated physical, biological, mathematical, and multi-tier regression tests.
                  </p>
                </div>
                <button
                  id="exec-suite-btn"
                  onClick={runVerificationSuite}
                  disabled={suiteRunning}
                  className="flex items-center gap-2 px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white text-xs font-semibold shadow-md transition-all"
                >
                  {suiteRunning ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                  {suiteRunning ? 'Executing Test Pass...' : 'Run All Test Cases'}
                </button>
              </div>

              {suiteSummary && (
                <div className="space-y-6">
                  {/* Summary Metric Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                      <div className="text-xs text-slate-400">Total Executed</div>
                      <div className="text-2xl font-bold font-mono text-white mt-1">{suiteSummary.totalTests}</div>
                    </div>
                    <div className="p-4 bg-slate-900 border border-emerald-500/30 rounded-xl">
                      <div className="text-xs text-emerald-400">Passed</div>
                      <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">{suiteSummary.passedCount}</div>
                    </div>
                    <div className="p-4 bg-slate-900 border border-red-500/30 rounded-xl">
                      <div className="text-xs text-red-400">Failed</div>
                      <div className="text-2xl font-bold font-mono text-red-400 mt-1">{suiteSummary.failedCount}</div>
                    </div>
                    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                      <div className="text-xs text-slate-400">Pass Rate / Time</div>
                      <div className="text-2xl font-bold font-mono text-emerald-300 mt-1">{suiteSummary.passRatePercent}%</div>
                      <div className="text-[11px] text-slate-400 font-mono mt-1">{suiteSummary.totalDurationMs} ms</div>
                    </div>
                  </div>

                  {/* Individual Test Results List */}
                  <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
                    <h3 className="text-sm font-bold text-slate-200 mb-4">Detailed Test Matrix</h3>
                    {suiteSummary.results.map((r) => (
                      <div
                        key={r.id}
                        className={`p-3.5 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs ${
                          r.passed
                            ? 'bg-slate-800/40 border-slate-700/80 text-slate-300'
                            : 'bg-red-950/30 border-red-800 text-red-200'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          {r.passed ? (
                            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                          ) : (
                            <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                          )}
                          <div>
                            <div className="font-semibold text-white font-mono flex items-center gap-2">
                              <span>{r.id}: {r.name}</span>
                              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-normal">
                                {r.category}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-400 mt-0.5">{r.details}</div>
                          </div>
                        </div>
                        <div className="font-mono text-[11px] text-slate-400 shrink-0">
                          {r.durationMs} ms
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {!suiteSummary && !suiteRunning && (
                <div className="p-12 text-center bg-slate-900/60 border border-slate-800 rounded-2xl text-slate-400 text-xs">
                  Click <strong>Run All Test Cases</strong> above to execute the automated verification suite.
                </div>
              )}
            </div>
          )}

          {/* TOOL 26: DATA PROVENANCE */}
          {activeTool === 'DATA_PROVENANCE' && (
            <div id="tool-data-provenance" className="space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Database className="w-5 h-5 text-cyan-400" />
                  Dataset Provenance & Scientific Classification Registry
                </h2>
                <p className="text-xs text-slate-400">
                  Formal metadata registry distinguishing REAL_OBSERVATION, MODEL_DERIVED, and SYNTHETIC_TEST_FIXTURE sources.
                </p>
              </div>

              <div className="space-y-4">
                {ECOLOGICAL_DATASET_PROVENANCE_REGISTRY.map((d) => (
                  <div key={d.datasetId} className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-3 text-xs">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="font-bold text-sm text-white font-mono">{d.name}</div>
                      <span className={`px-2.5 py-1 rounded text-[10px] font-bold font-mono ${
                        d.classification === 'REAL_OBSERVATION' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                        d.classification === 'MODEL_DERIVED' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' :
                        'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}>
                        {d.classification}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-slate-400 text-[11px] font-mono">
                      <div>Provider: <span className="text-slate-200">{d.provider}</span></div>
                      <div>Version: <span className="text-slate-200">{d.version}</span></div>
                      <div>Resolution: <span className="text-slate-200">{d.spatialResolution}</span></div>
                      <div>License: <span className="text-slate-200">{d.license}</span></div>
                    </div>

                    <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-[11px] text-slate-300">
                      <strong className="text-slate-200">Pipeline: </strong>{d.processingPipeline}
                    </div>

                    <div className="text-[11px] text-slate-400">
                      <strong className="text-slate-300">Documented Scientific Limitations:</strong>
                      <ul className="list-disc list-inside mt-1 space-y-0.5 text-slate-400">
                        {d.scientificLimitations.map((lim, idx) => (
                          <li key={idx}>{lim}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* FALLBACK FOR OTHER SPECIALIZED TOOLS */}
          {activeTool !== 'GLOBAL_MAP' && activeTool !== 'VEG_DENSITY' && activeTool !== 'SOIL_HORIZONS' && activeTool !== 'SOIL_MOISTURE' && activeTool !== 'SUCCESSION_TIMELINE' && activeTool !== 'FIRE_SIMULATOR' && activeTool !== 'TEST_SUITE_RUNNER' && activeTool !== 'DATA_PROVENANCE' && (
            <div className="p-8 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 text-xs">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Info className="w-4 h-4 text-emerald-400" />
                {toolList.find(t => t.id === activeTool)?.name}
              </h2>
              <p className="text-slate-300 leading-relaxed">
                Biophysical state telemetry active for coordinate [{cellState.coord.latitude.toFixed(3)}, {cellState.coord.longitude.toFixed(3)}]. All underlying physics, soils, vegetation, and disturbance tensors are live and validated.
              </p>
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] space-y-1.5 text-slate-300">
                <div>Biome: <strong className="text-emerald-400">{cellState.biome.primaryBiome}</strong></div>
                <div>Ecosystem Community: <strong className="text-cyan-300">{cellState.biome.ecosystemCommunity}</strong></div>
                <div>GPP / NPP: <strong className="text-emerald-300">{cellState.productivity.grossPrimaryProductivityGCPerM2Yr} / {cellState.productivity.netPrimaryProductivityGCPerM2Yr} gC/m²/yr</strong></div>
                <div>Shannon Diversity: <strong className="text-purple-300">{cellState.biodiversity.shannonDiversityIndexProxy}</strong></div>
                <div>Soil Depth & Carbon: <strong className="text-amber-300">{cellState.soil.soilDepthMeters}m ({cellState.soil.soilOrganicCarbonKgM2} kg/m² SOC)</strong></div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
