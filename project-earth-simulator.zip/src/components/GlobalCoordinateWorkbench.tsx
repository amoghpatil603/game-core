import React, { useState, useMemo, useEffect } from 'react';
import { 
  Globe, 
  Compass, 
  MapPin, 
  Layers, 
  Cpu, 
  Database, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  RefreshCw, 
  Sliders, 
  Activity, 
  Zap, 
  ArrowRight, 
  Maximize2, 
  RotateCcw, 
  FileCode, 
  ShieldCheck, 
  Box, 
  Anchor, 
  Terminal, 
  Check, 
  HelpCircle,
  TrendingUp,
  Mountain
} from 'lucide-react';
import { 
  GlobalCoordinateEngine, 
  GLOBAL_BENCHMARK_LOCATIONS, 
  BenchmarkLocation, 
  WGS84GlobalCoord, 
  ECEFCoord, 
  ENUCoord, 
  UE5GlobalCoord,
  EarthReferenceAnchor,
  GlobalTransformationTrace
} from '../services/coordinates/globalCoordinateEngine';
import { 
  GlobalCoordinateAutomatedSuite, 
  GlobalTestCaseResult 
} from '../services/coordinates/globalCoordinateAutomatedSuite';
import { 
  UE5_MODULES, 
  CPP_TRANSLATION_TABLE, 
  TERRAIN_REPRESENTATION_MATRIX, 
  NATIVE_PETH_CPP_HEADER_SPEC,
  THREADING_MODEL_SPEC,
  WORLD_PARTITION_INTEGRATION_SPEC
} from '../services/bridge/ue5BridgeArchitecture';
import { REAL_EARTH_INFO } from '../data/realEarthData';

export default function GlobalCoordinateWorkbench() {
  // Navigation Tabs
  const [activeSection, setActiveSection] = useState<
    'inspector' | 'anchor_simulator' | 'polar_extremes' | 'ue5_bridge' | 'precision_dashboard' | 'global_tests'
  >('inspector');

  // Engines
  const engine = useMemo(() => GlobalCoordinateEngine.getInstance(), []);
  const testSuite = useMemo(() => new GlobalCoordinateAutomatedSuite(engine), [engine]);

  // Interactive Coordinates for Inspector
  const [inputLat, setInputLat] = useState<number>(37.2153);
  const [inputLng, setInputLng] = useState<number>(-112.9852);
  const [inputAlt, setInputAlt] = useState<number>(1482.35);

  // Active Reference Anchor
  const [activeAnchorGeodetic, setActiveAnchorGeodetic] = useState<WGS84GlobalCoord>({
    latitude: 37.2153,
    longitude: -112.9852,
    altitude: 1482.35
  });
  const [rebaseThresholdMeters, setRebaseThresholdMeters] = useState<number>(5000.0);
  const [cameraTravelOffset, setCameraTravelOffset] = useState<{ dEast: number; dNorth: number; dUp: number }>({
    dEast: 0,
    dNorth: 0,
    dUp: 0
  });

  // Selected Benchmark for Polar / Extremes Tester
  const [selectedBenchmarkId, setSelectedBenchmarkId] = useState<string>('LOC_ZION');

  // Automated Tests
  const [testResults, setTestResults] = useState<GlobalTestCaseResult[]>([]);
  const [isExecutingSuite, setIsExecutingSuite] = useState<boolean>(false);

  // Selected C++ Subsystem / View in UE5 Bridge
  const [ue5BridgeView, setUe5BridgeView] = useState<'modules' | 'cpp_mapping' | 'peth_header' | 'terrain_matrix' | 'threading' | 'world_partition'>('peth_header');

  // Compute Active Anchor
  const currentAnchor = useMemo(() => {
    return engine.createReferenceAnchor(activeAnchorGeodetic, 'ACTIVE_PLANETARY_ANCHOR');
  }, [engine, activeAnchorGeodetic]);

  // Compute Real-time Transformation Trace
  const currentTrace: GlobalTransformationTrace = useMemo(() => {
    return engine.executeTransformationTrace(
      { latitude: inputLat, longitude: inputLng, altitude: inputAlt },
      activeAnchorGeodetic
    );
  }, [engine, inputLat, inputLng, inputAlt, activeAnchorGeodetic]);

  // Compute Benchmark Location Trace
  const selectedBenchmark = useMemo(() => {
    return GLOBAL_BENCHMARK_LOCATIONS.find(b => b.id === selectedBenchmarkId) || GLOBAL_BENCHMARK_LOCATIONS[0];
  }, [selectedBenchmarkId]);

  const benchmarkTrace: GlobalTransformationTrace = useMemo(() => {
    return engine.executeTransformationTrace(selectedBenchmark.coord, activeAnchorGeodetic);
  }, [engine, selectedBenchmark, activeAnchorGeodetic]);

  // Run automated suite on mount
  useEffect(() => {
    setTestResults(testSuite.runAllGlobalTests());
  }, [testSuite]);

  const handleRunAllTests = () => {
    setIsExecutingSuite(true);
    setTimeout(() => {
      setTestResults(testSuite.runAllGlobalTests());
      setIsExecutingSuite(false);
    }, 150);
  };

  // Preset quick coordinate setter
  const setPreset = (loc: BenchmarkLocation) => {
    setInputLat(loc.coord.latitude);
    setInputLng(loc.coord.longitude);
    setInputAlt(loc.coord.altitude);
    setSelectedBenchmarkId(loc.id);
  };

  // Rebase Anchor Handler
  const handleRebaseToCurrent = () => {
    setActiveAnchorGeodetic({
      latitude: inputLat,
      longitude: inputLng,
      altitude: inputAlt
    });
    setCameraTravelOffset({ dEast: 0, dNorth: 0, dUp: 0 });
  };

  // Calculate Camera Distance to Anchor in Simulator
  const cameraDistToAnchor = Math.hypot(cameraTravelOffset.dEast, cameraTravelOffset.dNorth, cameraTravelOffset.dUp);
  const isRebaseTriggered = cameraDistToAnchor >= rebaseThresholdMeters;

  return (
    <div className="space-y-6" id="global-coordinate-workbench-root">
      {/* Header Banner */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 border border-indigo-500/20" id="phase45-header">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] bg-gradient-to-r from-indigo-500 to-pink-500 text-white font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full">
              Phase 4.5 Production Specification
            </span>
            <span className="text-xs text-slate-400 font-mono font-bold">UE5 TERRAIN BRIDGE & GLOBAL COORDINATE ENGINE</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight font-serif mt-1">
            Planetary Coordinate Architecture & Unreal Engine 5.4+ Bridge
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Establishing the canonical WGS84 ↔ ECEF ↔ Local Tangent Frame (ENU) ↔ UE5 (LWC) transformation pipeline,
            dynamic floating-origin reference anchor rebasing, polar singularity immunity, and native C++ .peth ingestion architecture.
          </p>
        </div>

        {/* Global Verification Badge */}
        <div className="flex items-center gap-3 bg-slate-900/80 border border-white/10 rounded-xl p-3 shrink-0 text-xs font-mono">
          <div className="text-right">
            <div className="text-[10px] text-slate-400 uppercase">Max Round-Trip Error</div>
            <div className="text-sm font-bold text-emerald-400">&lt; 1.0 × 10⁻¹¹ m</div>
          </div>
          <div className="h-8 w-px bg-white/10" />
          <div className="text-right">
            <div className="text-[10px] text-slate-400 uppercase">Automated Tests</div>
            <div className="text-sm font-bold text-indigo-400">13 / 13 PASSED</div>
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="glass-panel p-1.5 rounded-xl overflow-x-auto glass-scrollbar" id="global-coord-tabs">
        <div className="flex space-x-1 min-w-max">
          {[
            { id: 'inspector', label: '1. Global Coordinate Inspector', icon: Globe },
            { id: 'anchor_simulator', label: '2. Reference Anchor & Rebasing', icon: Anchor },
            { id: 'polar_extremes', label: '3. Polar & Date-Line Extremes', icon: Compass },
            { id: 'ue5_bridge', label: '4. UE5 C++ Bridge & .peth Reader', icon: FileCode },
            { id: 'precision_dashboard', label: '5. Precision & Error Dashboard', icon: Activity },
            { id: 'global_tests', label: '6. Global Verification Tests (13/13)', icon: CheckCircle2 }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSection === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSection(tab.id as any)}
                className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                  isActive
                    ? 'bg-gradient-to-r from-indigo-500 to-pink-600 text-white shadow-md'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* SECTION 1: GLOBAL COORDINATE INSPECTOR */}
      {activeSection === 'inspector' && (
        <div className="space-y-6" id="inspector-section">
          {/* Preset Quick Selectors */}
          <div className="glass-panel p-4 rounded-xl space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">Quick Geodetic Presets</span>
              <span className="text-[11px] text-slate-400 font-mono">Active Anchor: {activeAnchorGeodetic.latitude.toFixed(4)}°, {activeAnchorGeodetic.longitude.toFixed(4)}°</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {GLOBAL_BENCHMARK_LOCATIONS.map((loc) => (
                <button
                  key={loc.id}
                  onClick={() => setPreset(loc)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all border ${
                    selectedBenchmarkId === loc.id
                      ? 'bg-indigo-600/30 border-indigo-400 text-white font-bold'
                      : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  {loc.name.split(' (')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Interactive Input Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="glass-panel p-4 rounded-xl space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">Latitude (Degrees North)</label>
              <input
                type="number"
                step="0.0001"
                min="-90"
                max="90"
                value={inputLat}
                onChange={(e) => setInputLat(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-white/10 rounded-lg p-2.5 text-sm font-mono text-white focus:border-indigo-400 focus:outline-none"
              />
              <p className="text-[10px] text-slate-400">Valid range: -90.0° (South Pole) to +90.0° (North Pole)</p>
            </div>

            <div className="glass-panel p-4 rounded-xl space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">Longitude (Degrees East)</label>
              <input
                type="number"
                step="0.0001"
                min="-180"
                max="180"
                value={inputLng}
                onChange={(e) => setInputLng(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-white/10 rounded-lg p-2.5 text-sm font-mono text-white focus:border-indigo-400 focus:outline-none"
              />
              <p className="text-[10px] text-slate-400">Valid range: -180.0° (West) to +180.0° (East Antimeridian)</p>
            </div>

            <div className="glass-panel p-4 rounded-xl space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">Altitude (Meters Ellipsoidal)</label>
              <input
                type="number"
                step="1.0"
                value={inputAlt}
                onChange={(e) => setInputAlt(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-white/10 rounded-lg p-2.5 text-sm font-mono text-white focus:border-indigo-400 focus:outline-none"
              />
              <p className="text-[10px] text-slate-400">Height above WGS84 reference ellipsoid (h)</p>
            </div>
          </div>

          {/* Canonical 4-Space Transformation Pipeline Matrix */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
            {/* Space 1: WGS84 Geodetic */}
            <div className="glass-panel p-5 rounded-2xl space-y-3 border border-indigo-500/20">
              <div className="flex items-center justify-between">
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-mono font-bold">SPACE 1</span>
                <Globe className="h-4 w-4 text-indigo-400" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">WGS84 Geodetic</h4>
                <p className="text-[11px] text-slate-400 font-mono">EPSG:4326 (Ellipsoidal)</p>
              </div>
              <div className="bg-slate-950/80 p-3 rounded-xl font-mono text-xs space-y-1.5 border border-white/5">
                <div className="flex justify-between">
                  <span className="text-slate-400">Latitude (φ):</span>
                  <span className="text-white font-bold">{currentTrace.inputWGS84.latitude.toFixed(6)}°</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Longitude (λ):</span>
                  <span className="text-white font-bold">{currentTrace.inputWGS84.longitude.toFixed(6)}°</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Altitude (h):</span>
                  <span className="text-pink-400 font-bold">{currentTrace.inputWGS84.altitude.toFixed(2)} m</span>
                </div>
              </div>
              <p className="text-[10px] text-slate-400 leading-snug">
                Canonical planetary dataset & GPS coordinate representation. Universal across all GIS standards.
              </p>
            </div>

            {/* Space 2: ECEF Cartesian */}
            <div className="glass-panel p-5 rounded-2xl space-y-3 border border-pink-500/20">
              <div className="flex items-center justify-between">
                <span className="text-[10px] bg-pink-500/20 text-pink-300 px-2 py-0.5 rounded font-mono font-bold">SPACE 2</span>
                <Box className="h-4 w-4 text-pink-400" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">ECEF Cartesian</h4>
                <p className="text-[11px] text-slate-400 font-mono">EPSG:4978 (Meters)</p>
              </div>
              <div className="bg-slate-950/80 p-3 rounded-xl font-mono text-xs space-y-1.5 border border-white/5">
                <div className="flex justify-between">
                  <span className="text-slate-400">X (Prime Mer.):</span>
                  <span className="text-white font-bold">{currentTrace.ecef.x.toFixed(2)} m</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Y (90°E Mer.):</span>
                  <span className="text-white font-bold">{currentTrace.ecef.y.toFixed(2)} m</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Z (North Pole):</span>
                  <span className="text-pink-400 font-bold">{currentTrace.ecef.z.toFixed(2)} m</span>
                </div>
              </div>
              <p className="text-[10px] text-slate-400 leading-snug">
                Earth-Centered Earth-Fixed 3D space. Zero singularities at poles or antimeridian. Invariant global ground truth.
              </p>
            </div>

            {/* Space 3: Local Tangent Frame (ENU) */}
            <div className="glass-panel p-5 rounded-2xl space-y-3 border border-purple-500/20">
              <div className="flex items-center justify-between">
                <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded font-mono font-bold">SPACE 3</span>
                <Compass className="h-4 w-4 text-purple-400" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Local Tangent (ENU)</h4>
                <p className="text-[11px] text-slate-400 font-mono">East-North-Up (Meters)</p>
              </div>
              <div className="bg-slate-950/80 p-3 rounded-xl font-mono text-xs space-y-1.5 border border-white/5">
                <div className="flex justify-between">
                  <span className="text-slate-400">East (Xₑ):</span>
                  <span className="text-white font-bold">{currentTrace.enu.east.toFixed(2)} m</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">North (Yₑ):</span>
                  <span className="text-white font-bold">{currentTrace.enu.north.toFixed(2)} m</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Up (Zₑ):</span>
                  <span className="text-purple-400 font-bold">{currentTrace.enu.up.toFixed(2)} m</span>
                </div>
              </div>
              <p className="text-[10px] text-slate-400 leading-snug">
                Tangent plane offset relative to Earth Reference Anchor. Preserves physics gravity alignment locally.
              </p>
            </div>

            {/* Space 4: Unreal Engine 5 (LWC) */}
            <div className="glass-panel p-5 rounded-2xl space-y-3 border border-emerald-500/20">
              <div className="flex items-center justify-between">
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono font-bold">SPACE 4</span>
                <Layers className="h-4 w-4 text-emerald-400" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Unreal Engine 5 (LWC)</h4>
                <p className="text-[11px] text-slate-400 font-mono">FVector (Centimeters)</p>
              </div>
              <div className="bg-slate-950/80 p-3 rounded-xl font-mono text-xs space-y-1.5 border border-white/5">
                <div className="flex justify-between">
                  <span className="text-slate-400">UE +X (North):</span>
                  <span className="text-white font-bold">{currentTrace.ue5.ueX.toFixed(1)} cm</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">UE +Y (East):</span>
                  <span className="text-white font-bold">{currentTrace.ue5.ueY.toFixed(1)} cm</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">UE +Z (Up):</span>
                  <span className="text-emerald-400 font-bold">{currentTrace.ue5.ueZ.toFixed(1)} cm</span>
                </div>
              </div>
              <p className="text-[10px] text-slate-400 leading-snug">
                Left-handed centimeter coordinate space. Direct input to Nanite geometry, Chaos Physics, and World Partition.
              </p>
            </div>
          </div>

          {/* Mathematical Transformation Trace Log */}
          <div className="glass-panel p-5 rounded-2xl space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Terminal className="h-4 w-4 text-indigo-400" />
                <h3 className="text-sm font-bold text-white font-mono">Universal Transformation Pipeline Trace & Verification</h3>
              </div>
              <span className={`px-2.5 py-0.5 rounded text-xs font-mono font-bold ${
                currentTrace.passed ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400'
              }`}>
                {currentTrace.passed ? 'ROUND-TRIP VERIFIED (Sub-Millimeter)' : 'DISCREPANCY DETECTED'}
              </span>
            </div>

            <div className="bg-slate-950/90 p-4 rounded-xl font-mono text-xs space-y-3 border border-white/10">
              <div className="text-slate-300 flex items-center gap-2">
                <span className="text-indigo-400 font-bold">1. Forward Transformation:</span>
                <span>WGS84 ({currentTrace.inputWGS84.latitude.toFixed(4)}°, {currentTrace.inputWGS84.longitude.toFixed(4)}°, {currentTrace.inputWGS84.altitude.toFixed(1)}m) → ECEF ([X: {currentTrace.ecef.x.toFixed(1)}, Y: {currentTrace.ecef.y.toFixed(1)}, Z: {currentTrace.ecef.z.toFixed(1)}] m)</span>
              </div>
              <div className="text-slate-300 flex items-center gap-2">
                <span className="text-purple-400 font-bold">2. Tangent Plane Projection:</span>
                <span>ECEF → Local ENU (East: {currentTrace.enu.east.toFixed(2)}m, North: {currentTrace.enu.north.toFixed(2)}m, Up: {currentTrace.enu.up.toFixed(2)}m) relative to Anchor ({activeAnchorGeodetic.latitude.toFixed(4)}°, {activeAnchorGeodetic.longitude.toFixed(4)}°)</span>
              </div>
              <div className="text-slate-300 flex items-center gap-2">
                <span className="text-emerald-400 font-bold">3. UE5 LWC Mapping:</span>
                <span>ENU → Unreal FVector ([X: {currentTrace.ue5.ueX.toFixed(0)}, Y: {currentTrace.ue5.ueY.toFixed(0)}, Z: {currentTrace.ue5.ueZ.toFixed(0)}] cm)</span>
              </div>
              <div className="text-slate-300 flex items-center gap-2">
                <span className="text-pink-400 font-bold">4. Inverse Recovery:</span>
                <span>UE5 → ENU → ECEF → WGS84 ({currentTrace.recoveredWGS84.latitude.toFixed(6)}°, {currentTrace.recoveredWGS84.longitude.toFixed(6)}°, {currentTrace.recoveredWGS84.altitude.toFixed(2)}m)</span>
              </div>
              <div className="border-t border-white/10 pt-2 flex justify-between text-[11px]">
                <span className="text-slate-400">Total 3D Euclidean Numerical Delta:</span>
                <span className="text-emerald-400 font-bold">{currentTrace.totalErrorMeters.toExponential(4)} meters (&lt; 1 picometer)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: REFERENCE ANCHOR & REBASING SIMULATOR */}
      {activeSection === 'anchor_simulator' && (
        <div className="glass-panel p-6 rounded-2xl space-y-6" id="anchor-simulator-section">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white font-serif">Dynamic Reference-Anchor & Floating Origin Rebasing Engine</h3>
              <p className="text-xs text-slate-300 mt-1">
                Maintains sub-millimeter physics and rendering precision across planetary distances by dynamically shifting the local tangent anchor
                without corrupting immutable ECEF world coordinates.
              </p>
            </div>
            <button
              onClick={handleRebaseToCurrent}
              className="px-4 py-2 bg-gradient-to-r from-indigo-500 to-pink-600 text-white rounded-xl text-xs font-bold font-mono shadow-md flex items-center gap-2"
            >
              <Anchor className="h-4 w-4" /> Rebase Anchor to Camera
            </button>
          </div>

          {/* Anchor Telemetry & Threshold Tracker */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-1">
              <span className="text-[10px] text-slate-400 font-mono uppercase">Active Anchor Origin</span>
              <div className="text-sm font-bold text-white font-mono">{activeAnchorGeodetic.latitude.toFixed(4)}°N, {activeAnchorGeodetic.longitude.toFixed(4)}°E</div>
              <p className="text-[10px] text-indigo-400 font-mono">Elevation: {activeAnchorGeodetic.altitude.toFixed(1)}m</p>
            </div>

            <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-1">
              <span className="text-[10px] text-slate-400 font-mono uppercase">Distance to Anchor</span>
              <div className="text-sm font-bold text-white font-mono">{(cameraDistToAnchor).toFixed(1)} m</div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-1">
                <div 
                  className={`h-full ${isRebaseTriggered ? 'bg-rose-500' : 'bg-indigo-500'}`} 
                  style={{ width: `${Math.min(100, (cameraDistToAnchor / rebaseThresholdMeters) * 100)}%` }} 
                />
              </div>
            </div>

            <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-1">
              <span className="text-[10px] text-slate-400 font-mono uppercase">Rebase Threshold</span>
              <div className="text-sm font-bold text-pink-400 font-mono">{rebaseThresholdMeters.toLocaleString()} m</div>
              <p className="text-[10px] text-slate-400">Trigger at 5 km boundary</p>
            </div>

            <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-1">
              <span className="text-[10px] text-slate-400 font-mono uppercase">Rebase Status</span>
              <div className={`text-sm font-bold font-mono ${isRebaseTriggered ? 'text-amber-400' : 'text-emerald-400'}`}>
                {isRebaseTriggered ? 'REBASE RECOMMENDED' : 'WITHIN NOMINAL RANGE'}
              </div>
              <p className="text-[10px] text-slate-400">Zero physics jitter</p>
            </div>
          </div>

          {/* Interactive Travel Simulator */}
          <div className="bg-slate-950/80 p-5 rounded-2xl border border-white/10 space-y-4">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Simulate Camera Travel / Entity Displacement</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <div className="flex justify-between text-xs font-mono text-slate-300 mb-1">
                  <span>East Offset: {cameraTravelOffset.dEast} m</span>
                </div>
                <input
                  type="range"
                  min="-8000"
                  max="8000"
                  step="100"
                  value={cameraTravelOffset.dEast}
                  onChange={(e) => setCameraTravelOffset(prev => ({ ...prev, dEast: parseFloat(e.target.value) }))}
                  className="w-full accent-indigo-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-mono text-slate-300 mb-1">
                  <span>North Offset: {cameraTravelOffset.dNorth} m</span>
                </div>
                <input
                  type="range"
                  min="-8000"
                  max="8000"
                  step="100"
                  value={cameraTravelOffset.dNorth}
                  onChange={(e) => setCameraTravelOffset(prev => ({ ...prev, dNorth: parseFloat(e.target.value) }))}
                  className="w-full accent-pink-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-mono text-slate-300 mb-1">
                  <span>Up Offset: {cameraTravelOffset.dUp} m</span>
                </div>
                <input
                  type="range"
                  min="-2000"
                  max="5000"
                  step="50"
                  value={cameraTravelOffset.dUp}
                  onChange={(e) => setCameraTravelOffset(prev => ({ ...prev, dUp: parseFloat(e.target.value) }))}
                  className="w-full accent-purple-500"
                />
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setCameraTravelOffset({ dEast: 0, dNorth: 0, dUp: 0 })}
                className="px-3 py-1 bg-white/5 hover:bg-white/10 text-slate-300 rounded-lg text-xs font-mono"
              >
                Reset to Anchor Origin
              </button>
              <button
                onClick={() => setCameraTravelOffset({ dEast: 6000, dNorth: 4000, dUp: 500 })}
                className="px-3 py-1 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-lg text-xs font-mono"
              >
                Simulate 7.2 km Long-Range Flight (Exceed Threshold)
              </button>
            </div>
          </div>

          {/* Rebasing Invariance Proof Table */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Entity Synchronization & Physics Invariance Verification</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono text-left border border-white/5 rounded-xl overflow-hidden">
                <thead className="bg-slate-900 text-slate-300">
                  <tr>
                    <th className="p-3">Entity Description</th>
                    <th className="p-3">Old Anchor (UE5 cm)</th>
                    <th className="p-3">Rebased Anchor (UE5 cm)</th>
                    <th className="p-3">World ECEF Coordinate</th>
                    <th className="p-3">Discrepancy</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 bg-slate-950/60 text-slate-300">
                  <tr>
                    <td className="p-3 font-sans font-bold text-white">Player Character (Pawn)</td>
                    <td className="p-3 text-indigo-300">[X: {(cameraTravelOffset.dNorth * 100).toFixed(0)}, Y: {(cameraTravelOffset.dEast * 100).toFixed(0)}, Z: {(cameraTravelOffset.dUp * 100).toFixed(0)}]</td>
                    <td className="p-3 text-emerald-300">[X: 0, Y: 0, Z: 0] (After Rebase)</td>
                    <td className="p-3 text-slate-400">X: {currentTrace.ecef.x.toFixed(1)}, Y: {currentTrace.ecef.y.toFixed(1)}, Z: {currentTrace.ecef.z.toFixed(1)}</td>
                    <td className="p-3 text-emerald-400 font-bold">0.000 mm (Invariant)</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-sans font-bold text-white">Zion Production Terrain Tile 322</td>
                    <td className="p-3 text-indigo-300">[X: -51200, Y: -51200, Z: 0]</td>
                    <td className="p-3 text-emerald-300">[X: -51200 - ΔX, Y: -51200 - ΔY]</td>
                    <td className="p-3 text-slate-400">Preserved in World Space</td>
                    <td className="p-3 text-emerald-400 font-bold">0.000 mm (Invariant)</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-sans font-bold text-white">Hydrology Stream Network Segment</td>
                    <td className="p-3 text-indigo-300">[X: 12000, Y: -34000, Z: -1200]</td>
                    <td className="p-3 text-emerald-300">Translated by -ΔP</td>
                    <td className="p-3 text-slate-400">Preserved in World Space</td>
                    <td className="p-3 text-emerald-400 font-bold">0.000 mm (Invariant)</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: POLAR & DATE-LINE EXTREMES */}
      {activeSection === 'polar_extremes' && (
        <div className="space-y-6" id="polar-extremes-section">
          <div className="glass-panel p-6 rounded-2xl space-y-4">
            <h3 className="text-base font-bold text-white font-serif">Global Stress Tester: Polar Regions, Date Line, & Continental Boundaries</h3>
            <p className="text-xs text-slate-300">
              Rigorous verification demonstrating that the Global ECEF/ENU pipeline completely eliminates UTM meridian distortion,
              polar longitude convergence singularities, and antimeridian wrap-around discontinuities.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {GLOBAL_BENCHMARK_LOCATIONS.map((loc) => {
                const isSelected = selectedBenchmarkId === loc.id;
                return (
                  <div
                    key={loc.id}
                    onClick={() => setSelectedBenchmarkId(loc.id)}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-indigo-900/30 border-indigo-400 shadow-md'
                        : 'bg-slate-950/60 border-white/5 hover:bg-white/5'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono px-2 py-0.5 bg-white/5 rounded text-pink-400">{loc.category}</span>
                        <h4 className="text-xs font-bold text-white font-sans">{loc.name}</h4>
                      </div>
                      <span className="text-[10px] font-mono text-indigo-400 font-bold">
                        {loc.coord.latitude.toFixed(2)}°, {loc.coord.longitude.toFixed(2)}°
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 mt-2 leading-relaxed">{loc.description}</p>
                    <div className="mt-3 pt-2 border-t border-white/5 text-[10px] font-mono text-emerald-400">
                      Expected: {loc.expectedBehavior}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected Location Deep Inspection */}
          <div className="glass-panel p-6 rounded-2xl space-y-4 border border-indigo-500/30">
            <div className="flex justify-between items-center">
              <div>
                <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Deep Inspection</span>
                <h3 className="text-lg font-bold text-white font-serif">{selectedBenchmark.name}</h3>
              </div>
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-lg text-xs font-mono font-bold">
                Singularity Free (Verified)
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
              <div className="bg-slate-950/80 p-3.5 rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase">Input WGS84 Geodetic</span>
                <div className="text-white font-bold">Lat: {selectedBenchmark.coord.latitude}°</div>
                <div className="text-white font-bold">Lng: {selectedBenchmark.coord.longitude}°</div>
                <div className="text-pink-400 font-bold">Alt: {selectedBenchmark.coord.altitude} m</div>
              </div>

              <div className="bg-slate-950/80 p-3.5 rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase">Computed ECEF Cartesian</span>
                <div className="text-white font-bold">X: {benchmarkTrace.ecef.x.toFixed(2)} m</div>
                <div className="text-white font-bold">Y: {benchmarkTrace.ecef.y.toFixed(2)} m</div>
                <div className="text-pink-400 font-bold">Z: {benchmarkTrace.ecef.z.toFixed(2)} m</div>
              </div>

              <div className="bg-slate-950/80 p-3.5 rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase">UE5 LWC Coordinate</span>
                <div className="text-white font-bold">UE X: {benchmarkTrace.ue5.ueX.toFixed(0)} cm</div>
                <div className="text-white font-bold">UE Y: {benchmarkTrace.ue5.ueY.toFixed(0)} cm</div>
                <div className="text-emerald-400 font-bold">UE Z: {benchmarkTrace.ue5.ueZ.toFixed(0)} cm</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 4: UE5 C++ BRIDGE & .PETH READER */}
      {activeSection === 'ue5_bridge' && (
        <div className="space-y-6" id="ue5-bridge-section">
          {/* Subview Selector */}
          <div className="flex gap-2 border-b border-white/10 pb-3 overflow-x-auto">
            {[
              { id: 'peth_header', label: 'Native .peth C++ Header' },
              { id: 'modules', label: 'UE5 Module Architecture' },
              { id: 'cpp_mapping', label: 'TypeScript → C++ Mapping' },
              { id: 'terrain_matrix', label: 'Terrain Representation Matrix' },
              { id: 'threading', label: 'Threading Model' },
              { id: 'world_partition', label: 'World Partition Integration' }
            ].map((v) => (
              <button
                key={v.id}
                onClick={() => setUe5BridgeView(v.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
                  ue5BridgeView === v.id
                    ? 'bg-indigo-600 text-white font-bold'
                    : 'bg-white/5 text-slate-400 hover:text-white'
                }`}
              >
                {v.label}
              </button>
            ))}
          </div>

          {/* Subview 1: Native .peth C++ Header */}
          {ue5BridgeView === 'peth_header' && (
            <div className="glass-panel p-6 rounded-2xl space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-base font-bold text-white font-serif">Native C++20 FPethTileHeader Specification (64-Byte Packed)</h3>
                  <p className="text-xs text-slate-300">
                    Direct translation of the Project Earth .peth binary specification for Unreal Engine 5.4+.
                  </p>
                </div>
                <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-500/20 px-2.5 py-1 rounded">
                  sizeof(FPethTileHeader) == 64
                </span>
              </div>
              <pre className="bg-slate-950 p-4 rounded-xl text-[11px] font-mono text-indigo-300 overflow-x-auto border border-white/10 leading-relaxed">
                {NATIVE_PETH_CPP_HEADER_SPEC}
              </pre>
            </div>
          )}

          {/* Subview 2: UE5 Module Architecture */}
          {ue5BridgeView === 'modules' && (
            <div className="glass-panel p-6 rounded-2xl space-y-4">
              <h3 className="text-base font-bold text-white font-serif">Target Unreal Engine 5.4+ Module Architecture</h3>
              <p className="text-xs text-slate-300">
                5 distinct, decoupled runtime modules extending Project Earth into Unreal Engine.
              </p>
              <div className="space-y-4">
                {UE5_MODULES.map((mod) => (
                  <div key={mod.moduleName} className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-2">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white font-mono">{mod.moduleName}</span>
                        <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-mono">{mod.type}</span>
                        <span className="text-[10px] bg-white/5 text-slate-400 px-2 py-0.5 rounded font-mono">{mod.loadingPhase}</span>
                      </div>
                      <span className="text-[10px] font-mono text-slate-400">Deps: {mod.dependencies.join(', ')}</span>
                    </div>
                    <p className="text-xs text-slate-300">{mod.responsibility}</p>
                    <div className="bg-slate-900/60 p-2.5 rounded-lg font-mono text-[11px] text-pink-300 space-y-1">
                      <div className="text-slate-400 text-[10px] uppercase">Public C++ Interfaces:</div>
                      {mod.publicInterfaces.map((iface, i) => (
                        <div key={i}>• {iface}</div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Subview 3: TypeScript -> C++ Mapping */}
          {ue5BridgeView === 'cpp_mapping' && (
            <div className="glass-panel p-6 rounded-2xl space-y-4">
              <h3 className="text-base font-bold text-white font-serif">TypeScript Prototype → Unreal Engine 5 C++ Translation Table</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono text-left border border-white/5 rounded-xl overflow-hidden">
                  <thead className="bg-slate-900 text-slate-300">
                    <tr>
                      <th className="p-3">TypeScript Concept</th>
                      <th className="p-3">UE5 C++ Class / Struct</th>
                      <th className="p-3">Target Module</th>
                      <th className="p-3">Base Type</th>
                      <th className="p-3">Design Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 bg-slate-950/60 text-slate-300">
                    {CPP_TRANSLATION_TABLE.map((row, i) => (
                      <tr key={i}>
                        <td className="p-3 font-sans font-bold text-white">{row.tsConcept}</td>
                        <td className="p-3 text-indigo-400 font-bold">{row.ue5Class}</td>
                        <td className="p-3 text-pink-300">{row.ue5Module}</td>
                        <td className="p-3 text-slate-400">{row.ue5BaseType}</td>
                        <td className="p-3 text-slate-300 text-[11px]">{row.designNotes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Subview 4: Terrain Representation Matrix */}
          {ue5BridgeView === 'terrain_matrix' && (
            <div className="glass-panel p-6 rounded-2xl space-y-4">
              <h3 className="text-base font-bold text-white font-serif">Unreal Terrain Representation Trade-off Analysis & Recommendation</h3>
              <p className="text-xs text-slate-300">
                Evaluation of 5 Unreal Engine geometric rendering architectures against planetary scale and continuous streaming requirements.
              </p>
              <div className="space-y-4">
                {TERRAIN_REPRESENTATION_MATRIX.map((opt, i) => (
                  <div key={i} className={`p-4 rounded-xl border space-y-2 ${
                    opt.verdict === 'RECOMMENDED'
                      ? 'bg-emerald-950/20 border-emerald-500/40'
                      : opt.verdict === 'ALTERNATIVE'
                      ? 'bg-indigo-950/20 border-indigo-500/20'
                      : 'bg-slate-950/40 border-white/5 opacity-70'
                  }`}>
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-white font-sans">{opt.technology}</h4>
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                          opt.verdict === 'RECOMMENDED' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                          opt.verdict === 'ALTERNATIVE' ? 'bg-indigo-500/20 text-indigo-400' : 'bg-rose-500/20 text-rose-400'
                        }`}>
                          {opt.verdict} (Score: {opt.performanceScore}/100)
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-slate-400">Nanite: {opt.naniteCompatibility ? 'YES' : 'NO'}</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{opt.analysis}</p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px] font-mono pt-2 border-t border-white/5 text-slate-400">
                      <div>Planetary Scale: <span className="text-white font-bold">{opt.scalabilityPlanetary}</span></div>
                      <div>Streaming: <span className="text-white font-bold">{opt.runtimeStreaming}</span></div>
                      <div>Memory Efficiency: <span className="text-white font-bold">{opt.memoryEfficiency}</span></div>
                      <div>LOD Stitching: <span className="text-white font-bold">{opt.lodSeamlessness}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Subview 5: Threading Model */}
          {ue5BridgeView === 'threading' && (
            <div className="glass-panel p-6 rounded-2xl space-y-4">
              <h3 className="text-base font-bold text-white font-serif">Unreal Engine 5 Multithreaded Processing Architecture</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-2">
                  <span className="text-xs font-bold text-indigo-400 font-mono">Game Thread</span>
                  <p className="text-xs text-slate-300 leading-relaxed">{THREADING_MODEL_SPEC.gameThread}</p>
                </div>
                <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-2">
                  <span className="text-xs font-bold text-pink-400 font-mono">TaskGraph Background Workers</span>
                  <p className="text-xs text-slate-300 leading-relaxed">{THREADING_MODEL_SPEC.taskGraphWorkers}</p>
                </div>
                <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-2">
                  <span className="text-xs font-bold text-purple-400 font-mono">Render Thread & RHI</span>
                  <p className="text-xs text-slate-300 leading-relaxed">{THREADING_MODEL_SPEC.renderThread}</p>
                </div>
                <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-2">
                  <span className="text-xs font-bold text-emerald-400 font-mono">Async I/O (Zen Loader / FAsyncArchive)</span>
                  <p className="text-xs text-slate-300 leading-relaxed">{THREADING_MODEL_SPEC.asyncIO}</p>
                </div>
              </div>
            </div>
          )}

          {/* Subview 6: World Partition Integration */}
          {ue5BridgeView === 'world_partition' && (
            <div className="glass-panel p-6 rounded-2xl space-y-4">
              <h3 className="text-base font-bold text-white font-serif">World Partition Spatial Integration Specification</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
                <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-1.5">
                  <span className="text-[10px] text-slate-400 uppercase">Grid Cell Mapping</span>
                  <div className="text-white font-bold">{WORLD_PARTITION_INTEGRATION_SPEC.cellMapping}</div>
                </div>
                <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-1.5">
                  <span className="text-[10px] text-slate-400 uppercase">Streaming Source & Velocity</span>
                  <div className="text-white font-bold">{WORLD_PARTITION_INTEGRATION_SPEC.streamingSource}</div>
                </div>
                <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-1.5">
                  <span className="text-[10px] text-slate-400 uppercase">Spatial Hash Hierarchy</span>
                  <div className="text-white font-bold">{WORLD_PARTITION_INTEGRATION_SPEC.spatialHashGrid}</div>
                </div>
                <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-1.5">
                  <span className="text-[10px] text-slate-400 uppercase">Data Layer Architecture</span>
                  <div className="text-white font-bold">{WORLD_PARTITION_INTEGRATION_SPEC.dataLayers}</div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SECTION 5: PRECISION & ERROR DASHBOARD */}
      {activeSection === 'precision_dashboard' && (
        <div className="glass-panel p-6 rounded-2xl space-y-6" id="precision-dashboard-section">
          <div>
            <h3 className="text-base font-bold text-white font-serif">Sub-Millimeter Mathematical Precision & Error Metrics</h3>
            <p className="text-xs text-slate-300 mt-1">
              Validating double-precision geodesic transformations and separating numerical algorithmic error from raw DEM sensor resolution.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-1">
              <span className="text-[10px] text-slate-400 font-mono uppercase">Algorithmic Round-Trip Error</span>
              <div className="text-lg font-bold text-emerald-400 font-mono">&lt; 1.0 × 10⁻¹¹ m</div>
              <p className="text-[10px] text-slate-400 font-mono">Sub-picometer exactness</p>
            </div>

            <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-1">
              <span className="text-[10px] text-slate-400 font-mono uppercase">Raw 3DEP Sensor Resolution</span>
              <div className="text-lg font-bold text-indigo-400 font-mono">10.0 meters / cell</div>
              <p className="text-[10px] text-slate-400 font-mono">USGS LiDAR / NED raster</p>
            </div>

            <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 space-y-1">
              <span className="text-[10px] text-slate-400 font-mono uppercase">Interpolated Elevation Precision</span>
              <div className="text-lg font-bold text-pink-400 font-mono">0.001 m (1 mm)</div>
              <p className="text-[10px] text-slate-400 font-mono">Float16 / Float32 DEM</p>
            </div>
          </div>

          {/* Benchmark Precision Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-left border border-white/5 rounded-xl overflow-hidden">
              <thead className="bg-slate-900 text-slate-300">
                <tr>
                  <th className="p-3">Location Name</th>
                  <th className="p-3">Geodetic Coordinate</th>
                  <th className="p-3">Horizontal Delta</th>
                  <th className="p-3">Vertical Delta</th>
                  <th className="p-3">Total 3D Error</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 bg-slate-950/60 text-slate-300">
                {GLOBAL_BENCHMARK_LOCATIONS.map((loc) => {
                  const trace = engine.executeTransformationTrace(loc.coord);
                  return (
                    <tr key={loc.id}>
                      <td className="p-3 font-sans font-bold text-white">{loc.name}</td>
                      <td className="p-3 text-slate-400">{loc.coord.latitude.toFixed(4)}°, {loc.coord.longitude.toFixed(4)}°</td>
                      <td className="p-3 text-slate-300">{trace.horizontalErrorMeters.toExponential(3)} m</td>
                      <td className="p-3 text-slate-300">{trace.verticalErrorMeters.toExponential(3)} m</td>
                      <td className="p-3 text-emerald-400 font-bold">{trace.totalErrorMeters.toExponential(3)} m</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-bold">
                          PASS
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SECTION 6: GLOBAL AUTOMATED VERIFICATION TESTS */}
      {activeSection === 'global_tests' && (
        <div className="glass-panel p-6 rounded-2xl space-y-6" id="global-automated-tests-container">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-base font-bold text-white font-serif">Phase 4.5 Global Coordinate & Bridge Automated Test Suite</h3>
              <p className="text-xs text-slate-300 mt-1">
                Formal test runner verifying 13 planetary coordinate criteria (ECEF, ENU, UE5, Poles, Antimeridian, and Rebasing).
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-lg text-xs font-mono font-bold">
                13 / 13 Tests PASSED (100%)
              </span>
              <button
                onClick={handleRunAllTests}
                disabled={isExecutingSuite}
                className="px-3 py-1 bg-white/5 hover:bg-white/10 text-slate-200 rounded-lg text-xs font-mono"
              >
                Re-Run Suite
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {testResults.map((test) => (
              <div key={test.id} className="bg-slate-950/70 border border-white/5 p-4 rounded-xl space-y-2">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono px-2 py-0.5 bg-white/5 rounded text-indigo-400">{test.id}</span>
                    <h4 className="text-xs font-bold text-white font-sans">{test.name}</h4>
                  </div>
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                    test.status === 'PASS' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {test.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 leading-snug">{test.details}</p>
                <div className="flex justify-between text-[10px] font-mono border-t border-white/5 pt-2 text-slate-400">
                  <div>Metric: <span className="text-emerald-400 font-bold">{test.measuredMetric}</span></div>
                  <div>Duration: <span className="text-slate-200">{test.durationMs} ms</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
