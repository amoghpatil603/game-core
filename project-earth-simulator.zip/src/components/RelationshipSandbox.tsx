import { useState } from 'react';
import { NPC, Relationship } from '../types';
import { Users, Heart, ShieldAlert, Award, UserCheck, ArrowRight, CornerDownRight } from 'lucide-react';

const CHARACTERS = [
  { id: 'a', name: 'Dr. Arthur Sterling', traitStr: 'Conscientious / High Ego', ocean: { openness: 0.8, conscientiousness: 0.95, extraversion: 0.4, agreeableness: 0.3, neuroticism: 0.5 } },
  { id: 'b', name: 'Lyra Mercer', traitStr: 'Empathetic / Vulnerable', ocean: { openness: 0.9, conscientiousness: 0.5, extraversion: 0.7, agreeableness: 0.9, neuroticism: 0.75 } },
  { id: 'c', name: 'Marcus Vance', traitStr: 'Competitive / Cynical', ocean: { openness: 0.5, conscientiousness: 0.7, extraversion: 0.6, agreeableness: 0.2, neuroticism: 0.8 } }
];

interface SocialInteraction {
  id: string;
  name: string;
  description: string;
  primaryMetric: keyof Relationship;
  baseChange: number;
  fearCost?: number;
  requiresTrust?: number;
}

const SOCIAL_INTERACTIONS: SocialInteraction[] = [
  { id: 'compliment', name: 'Offer Professional Praise', description: 'Agent A commends Agent B’s expertise. Increases Respect, slightly increases Love.', primaryMetric: 'respect', baseChange: 0.15 },
  { id: 'gift', name: 'Deliver Thoughtful Gift', description: 'Agent A spends capital for Agent B. Greatly increases Love, decreases Jealousy.', primaryMetric: 'love', baseChange: 0.25 },
  { id: 'betray', name: 'Secret Betrayal Exposed', description: 'Agent A acts behind Agent B’s back. Drastically collapses Trust and Loyalty, spikes Conflict.', primaryMetric: 'trust', baseChange: -0.6 },
  { id: 'apology', name: 'Offer Sincere Apology', description: 'Agent A attempts to mend fences. Decreases Conflict based on Agent B’s Forgiveness score.', primaryMetric: 'conflict', baseChange: -0.2 },
  { id: 'coerce', name: 'Exert Coercive Threat', description: 'Agent A bullies or commands Agent B. Spikes Fear, drastically degrades Love & Respect.', primaryMetric: 'fear', baseChange: 0.4 },
  { id: 'confide', name: 'Share Deep Secret vulnerability', description: 'Agent A confides personal information. Increases Trust and Dependency.', primaryMetric: 'trust', baseChange: 0.2, requiresTrust: 0.25 }
];

export default function RelationshipSandbox() {
  const [agentAIndex, setAgentAIndex] = useState(0);
  const [agentBIndex, setAgentBIndex] = useState(1);

  // Directional relationship state from A -> B
  const [relAB, setRelAB] = useState<Relationship>({
    fromId: 'a',
    toId: 'b',
    love: 0.3,
    trust: 0.4,
    respect: 0.5,
    fear: 0.0,
    jealousy: 0.1,
    loyalty: 0.45,
    dependency: 0.2,
    forgiveness: 0.6,
    conflict: 0.15
  });

  // Directional relationship state from B -> A
  const [relBA, setRelBA] = useState<Relationship>({
    fromId: 'b',
    toId: 'a',
    love: 0.1,
    trust: 0.25,
    respect: 0.7,
    fear: 0.2,
    jealousy: 0.3,
    loyalty: 0.5,
    dependency: 0.4,
    forgiveness: 0.8,
    conflict: 0.2
  });

  const [interactionHistory, setInteractionHistory] = useState<string[]>(["Sandbox initialized."]);

  const npcA = CHARACTERS[agentAIndex];
  const npcB = CHARACTERS[agentBIndex];

  const handleMetricChange = (dir: 'AB' | 'BA', key: keyof Relationship, val: number) => {
    if (dir === 'AB') {
      setRelAB((prev) => ({ ...prev, [key]: val }));
    } else {
      setRelBA((prev) => ({ ...prev, [key]: val }));
    }
  };

  const executeInteraction = (action: SocialInteraction) => {
    if (agentAIndex === agentBIndex) {
      alert("An agent cannot engage in bilateral relations with themselves.");
      return;
    }

    // Check conditions
    if (action.requiresTrust && relAB.trust < action.requiresTrust) {
      setInteractionHistory((prev) => [
        `[Blocked] ${npcA.name} attempted to confide, but current Trust (${relAB.trust.toFixed(2)}) is below the required ${action.requiresTrust}.`,
        ...prev
      ]);
      return;
    }

    // Calculate delta changes based on the interactive resolver formula:
    // ΔR_AB = f(Interaction, Context, P_A, P_B, R_AB)
    setRelBA((prevBA) => {
      // Agent B's perspective updates based on Agent A's action
      const newBA = { ...prevBA };

      // Base interaction modifiers
      const agreeablenessFactor = npcA.ocean.agreeableness * 1.2;
      const neuroticismFactor = npcB.ocean.neuroticism * 1.1;

      if (action.id === 'compliment') {
        newBA.respect = Math.max(-1.0, Math.min(1.0, prevBA.respect + action.baseChange * agreeablenessFactor));
        newBA.love = Math.max(-1.0, Math.min(1.0, prevBA.love + 0.05 * agreeablenessFactor));
        newBA.conflict = Math.max(0.0, Math.min(1.0, prevBA.conflict - 0.05));
      } else if (action.id === 'gift') {
        newBA.love = Math.max(-1.0, Math.min(1.0, prevBA.love + action.baseChange * agreeablenessFactor));
        newBA.jealousy = Math.max(0.0, Math.min(1.0, prevBA.jealousy - 0.15));
        newBA.trust = Math.max(-1.0, Math.min(1.0, prevBA.trust + 0.1));
      } else if (action.id === 'betray') {
        newBA.trust = Math.max(-1.0, Math.min(1.0, prevBA.trust + action.baseChange * (1.5 - prevBA.forgiveness)));
        newBA.loyalty = Math.max(0.0, Math.min(1.0, prevBA.loyalty - 0.5));
        newBA.love = Math.max(-1.0, Math.min(1.0, prevBA.love - 0.4));
        newBA.conflict = Math.max(0.0, Math.min(1.0, prevBA.conflict + 0.5));
      } else if (action.id === 'apology') {
        // Reduced conflict heavily dependent on Agent B's forgiveness and A's agreeableness
        const decayAmt = action.baseChange * prevBA.forgiveness * agreeablenessFactor;
        newBA.conflict = Math.max(0.0, Math.min(1.0, prevBA.conflict + decayAmt)); // decayAmt is negative, so adding reduces conflict
        newBA.love = Math.max(-1.0, Math.min(1.0, prevBA.love + 0.08));
        newBA.trust = Math.max(-1.0, Math.min(1.0, prevBA.trust + 0.05));
      } else if (action.id === 'coerce') {
        newBA.fear = Math.max(0.0, Math.min(1.0, prevBA.fear + action.baseChange * (1.0 + neuroticismFactor)));
        newBA.love = Math.max(-1.0, Math.min(1.0, prevBA.love - 0.35));
        newBA.respect = Math.max(-1.0, Math.min(1.0, prevBA.respect - 0.25));
        newBA.conflict = Math.max(0.0, Math.min(1.0, prevBA.conflict + 0.25));
      } else if (action.id === 'confide') {
        newBA.trust = Math.max(-1.0, Math.min(1.0, prevBA.trust + action.baseChange));
        newBA.dependency = Math.max(0.0, Math.min(1.0, prevBA.dependency + 0.15));
        newBA.love = Math.max(-1.0, Math.min(1.0, prevBA.love + 0.1));
      }

      return newBA;
    });

    setRelAB((prevAB) => {
      // Agent A's own feelings might adjust as feedback
      const newAB = { ...prevAB };
      if (action.id === 'betray') {
        newAB.conflict = Math.max(0.0, Math.min(1.0, prevAB.conflict + 0.4));
        newAB.loyalty = Math.max(0.0, Math.min(1.0, prevAB.loyalty * 0.5));
      } else if (action.id === 'confide') {
        newAB.dependency = Math.max(0.0, Math.min(1.0, prevAB.dependency + 0.1));
      } else if (action.id === 'coerce') {
        newAB.conflict = Math.max(0.0, Math.min(1.0, prevAB.conflict + 0.15));
      }
      return newAB;
    });

    setInteractionHistory((prev) => [
      `[Applied] ${npcA.name} performed "${action.name}" on ${npcB.name}. Bilateral vectors updated according to OCEAN coefficients.`,
      ...prev
    ]);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="rel-sandbox-root">
      {/* Left panel: Character Selector */}
      <div className="lg:col-span-3 space-y-6" id="rel-selector-panel">
        <div className="glass-panel rounded-2xl p-5" id="agents-selection-card">
          <h3 className="text-sm font-bold text-white font-serif flex items-center gap-2 mb-4">
            <Users className="h-4 w-4 text-pink-500" id="users-icon" /> Select Interacting Agents
          </h3>

          <div className="space-y-4" id="select-a-b">
            <div className="space-y-1.5" id="agent-a-select">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider" id="label-a">Agent A (Initiator)</label>
              <select
                id="select-agent-a"
                value={agentAIndex}
                onChange={(e) => {
                  const val = parseInt(e.target.value);
                  setAgentAIndex(val);
                  if (val === agentBIndex) {
                    setAgentBIndex((val + 1) % CHARACTERS.length);
                  }
                }}
                className="w-full glass-input rounded-xl p-2 text-xs font-medium focus:outline-none"
              >
                {CHARACTERS.map((char, idx) => (
                  <option key={char.id} value={idx} className="bg-slate-900 text-white">{char.name} ({char.traitStr})</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5" id="agent-b-select">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider" id="label-b">Agent B (Target)</label>
              <select
                id="select-agent-b"
                value={agentBIndex}
                onChange={(e) => {
                  const val = parseInt(e.target.value);
                  setAgentBIndex(val);
                  if (val === agentAIndex) {
                    setAgentAIndex((val + 1) % CHARACTERS.length);
                  }
                }}
                className="w-full glass-input rounded-xl p-2 text-xs font-medium focus:outline-none"
              >
                {CHARACTERS.map((char, idx) => (
                  <option key={char.id} value={idx} className="bg-slate-900 text-white">{char.name} ({char.traitStr})</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Action Injectors */}
        <div className="glass-panel rounded-2xl p-5" id="actions-injection-card">
          <h3 className="text-sm font-bold text-white font-mono tracking-tight mb-4">Trigger Social Incident</h3>
          <div className="space-y-2.5" id="interaction-buttons">
            {SOCIAL_INTERACTIONS.map((action) => (
              <button
                id={`inc-btn-${action.id}`}
                key={action.id}
                onClick={() => executeInteraction(action)}
                className="w-full text-left p-2.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 hover:border-white/20 transition-all group flex flex-col gap-1"
              >
                <div className="flex justify-between items-center w-full" id={`inc-title-container-${action.id}`}>
                  <span className="text-xs font-bold text-slate-200 group-hover:text-pink-400 transition-colors" id={`inc-name-${action.id}`}>{action.name}</span>
                  <ArrowRight className="h-3 w-3 text-slate-400 group-hover:text-pink-400 group-hover:translate-x-0.5 transition-all" id={`inc-arrow-${action.id}`} />
                </div>
                <p className="text-[10px] text-slate-400 leading-normal" id={`inc-desc-${action.id}`}>{action.description}</p>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Center panel: Interaction Resolver Vectors and visual flow */}
      <div className="lg:col-span-6 space-y-6" id="rel-vectors-panel">
        <div className="glass-panel rounded-2xl p-6 flex flex-col gap-6" id="vectors-card">
          <div className="flex justify-between items-center border-b border-white/10 pb-4" id="vectors-header">
            <h3 className="text-sm font-bold text-white font-serif">Dual Directional Social Vectors</h3>
            <span className="text-[10px] font-mono bg-white/5 text-slate-300 px-2.5 py-0.5 rounded-full border border-white/10">Mathematical Graph</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="vectors-grid">
            {/* Vector A -> B */}
            <div className="bg-white/5 rounded-2xl p-4 border border-white/10 space-y-4" id="vector-ab-box">
              <div className="flex items-center justify-between border-b border-white/10 pb-2" id="ab-header">
                <span className="text-xs font-bold text-white font-sans truncate">{npcA.name}</span>
                <span className="text-[10px] bg-pink-500/20 text-pink-300 border border-pink-500/30 font-semibold px-2 py-0.5 rounded-md">towards B</span>
              </div>

              <div className="space-y-3" id="ab-sliders">
                {Object.entries(relAB).map(([metric, val]) => {
                  if (metric === 'fromId' || metric === 'toId') return null;
                  const numVal = val as number;
                  const isSigned = metric === 'love' || metric === 'trust' || metric === 'respect';
                  return (
                    <div key={metric} className="space-y-1" id={`ab-slider-wrapper-${metric}`}>
                      <div className="flex justify-between text-[11px]" id={`ab-slider-info-${metric}`}>
                        <span className="capitalize text-slate-400 font-medium" id={`ab-slider-label-${metric}`}>{metric}</span>
                        <span className="font-mono text-pink-400 font-bold" id={`ab-slider-val-${metric}`}>{numVal.toFixed(2)}</span>
                      </div>
                      <input
                        id={`ab-slider-input-${metric}`}
                        type="range"
                        min={isSigned ? "-1" : "0"}
                        max="1"
                        step="0.05"
                        value={numVal}
                        onChange={(e) => handleMetricChange('AB', metric as keyof Relationship, parseFloat(e.target.value))}
                        className="w-full accent-pink-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Vector B -> A */}
            <div className="bg-white/5 rounded-2xl p-4 border border-white/10 space-y-4" id="vector-ba-box">
              <div className="flex items-center justify-between border-b border-white/10 pb-2" id="ba-header">
                <span className="text-xs font-bold text-white font-sans truncate">{npcB.name}</span>
                <span className="text-[10px] bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold px-2 py-0.5 rounded-md">towards A</span>
              </div>

              <div className="space-y-3" id="ba-sliders">
                {Object.entries(relBA).map(([metric, val]) => {
                  if (metric === 'fromId' || metric === 'toId') return null;
                  const numVal = val as number;
                  const isSigned = metric === 'love' || metric === 'trust' || metric === 'respect';
                  return (
                    <div key={metric} className="space-y-1" id={`ba-slider-wrapper-${metric}`}>
                      <div className="flex justify-between text-[11px]" id={`ba-slider-info-${metric}`}>
                        <span className="capitalize text-slate-400 font-medium" id={`ba-slider-label-${metric}`}>{metric}</span>
                        <span className="font-mono text-cyan-400 font-bold" id={`ba-slider-val-${metric}`}>{numVal.toFixed(2)}</span>
                      </div>
                      <input
                        id={`ba-slider-input-${metric}`}
                        type="range"
                        min={isSigned ? "-1" : "0"}
                        max="1"
                        step="0.05"
                        value={numVal}
                        onChange={(e) => handleMetricChange('BA', metric as keyof Relationship, parseFloat(e.target.value))}
                        className="w-full accent-cyan-400 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right panel: Live Math Log and Narrative Transcript */}
      <div className="lg:col-span-3 space-y-6" id="rel-log-panel">
        <div className="glass-panel rounded-2xl p-5 flex flex-col gap-4" id="rel-math-card">
          <h3 className="text-xs font-bold text-pink-400 font-mono uppercase tracking-wider">Dynamic Interaction Resolver Math</h3>
          <div className="text-[11px] font-mono text-slate-300 space-y-2.5 leading-relaxed bg-white/5 p-3.5 border border-white/10 rounded-xl" id="resolver-equation-box">
            <div className="text-white font-semibold border-b border-white/5 pb-1" id="eq-formula-label">The Resolver Model:</div>
            <p id="eq-math-statement">ΔR_BA = Base × Personality_Modifier × Memory_Filter</p>
            <div className="text-white font-semibold border-b border-white/5 pt-2 pb-1" id="eq-live-scalars">Live Interaction Coefficients:</div>
            <div id="eq-scalars-list">
              <div className="flex justify-between text-slate-400" id="coef-agree-a">
                <span>Agreeableness (A)</span>
                <span className="text-pink-400 font-bold">{(npcA.ocean.agreeableness).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400" id="coef-forgive-b">
                <span>Forgiveness (B)</span>
                <span className="text-pink-400 font-bold">{(relBA.forgiveness).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400" id="coef-conflict-ba">
                <span>Jealousy (B)</span>
                <span className="text-pink-400 font-bold">{(relBA.jealousy).toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Interactive Log */}
        <div className="glass-panel rounded-2xl p-5" id="incident-log-card">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Interaction Feed Logs</h3>
          <div className="space-y-3 h-[250px] overflow-y-auto font-mono text-[10.5px] text-slate-300 leading-normal pr-1 glass-scrollbar" id="incident-history-logs">
            {interactionHistory.map((log, idx) => (
              <div key={idx} className="border-b border-white/5 pb-2.5 flex items-start gap-1.5" id={`inc-log-${idx}`}>
                <CornerDownRight className="h-3 w-3 text-pink-500 shrink-0 mt-0.5" />
                <span id={`inc-log-text-${idx}`}>{log}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
