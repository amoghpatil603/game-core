import { useState, useMemo } from 'react';
import { 
  Globe, 
  Sun, 
  Moon, 
  Compass, 
  Waves, 
  CloudRain, 
  Thermometer, 
  Wind, 
  Layers, 
  Cpu, 
  Database, 
  TrendingUp, 
  Navigation, 
  AlertTriangle,
  RefreshCcw,
  Clock,
  Activity,
  Sparkles,
  Map,
  MapPin,
  Settings,
  Flame,
  Info
} from 'lucide-react';

interface PresetCoordinate {
  name: string;
  lat: number;
  lng: number;
  alt: number; // in meters
  desc: string;
  region: string;
}

const PRESET_COORDINATES: PresetCoordinate[] = [
  {
    name: "Mt. Everest Peak",
    lat: 27.9881,
    lng: 86.9250,
    alt: 8848,
    region: "Himalayas, Nepal/China",
    desc: "Extreme high altitude, sub-zero temperatures, Alpine/Tundra biome with glacier ice geomorphology."
  },
  {
    name: "Amazon River Delta",
    lat: -0.1500,
    lng: -49.3000,
    alt: 2,
    region: "Pará, Brazil",
    desc: "Equatorial warmth, massive freshwater flow rate, high precipitation and humidity, Tropical Rainforest biome."
  },
  {
    name: "Sahara Desert (Dunes)",
    lat: 23.8000,
    lng: 11.3000,
    alt: 320,
    region: "Murzuq, Libya",
    desc: "Hyper-arid, massive solar irradiation, high daytime temperatures, sparse land cover, Arid Desert biome."
  },
  {
    name: "Tokyo Metropolitan Center",
    lat: 35.6762,
    lng: 139.6503,
    alt: 40,
    region: "Kanto, Japan",
    desc: "Temperate maritime urban area, dense population footprint, asphalt-surface thermal retention, Temperate Forest zone."
  },
  {
    name: "Riyadh District",
    lat: 24.7136,
    lng: 46.6753,
    alt: 612,
    region: "Najd, Saudi Arabia",
    desc: "Sub-tropical continental desert, extreme dry wind, high structural building footprint count, Arid Desert biome."
  },
  {
    name: "Mariana Trench",
    lat: 11.3493,
    lng: 142.1996,
    alt: -10994,
    region: "Pacific Ocean Floor",
    desc: "Deepest bathymetric abyss on Earth. Zero solar irradiance, extreme ocean pressure, high salinity, Oceanic Open biome."
  }
];

export default function EarthEnvironmentSandbox() {
  const [activeTab, setActiveTab] = useState<'celestial' | 'gis' | 'climate' | 'hydrology' | 'streaming'>('celestial');
  const [selectedPreset, setSelectedPreset] = useState<number>(0);
  
  // Geodetic parameters
  const [lat, setLat] = useState<number>(27.9881);
  const [lng, setLng] = useState<number>(86.9250);
  const [alt, setAlt] = useState<number>(8848);
  const [dayOfYear, setDayOfYear] = useState<number>(80); // Vernal Equinox (~March 21)
  const [localTime, setLocalTime] = useState<number>(12.0); // Noon
  const [lunarPhase, setLunarPhase] = useState<number>(0.5); // Full Moon

  // Simulated live events / locks
  const [stormActive, setStormActive] = useState<boolean>(false);
  const [highTideTrigger, setHighTideTrigger] = useState<boolean>(false);
  const [lastBakeLog, setLastBakeLog] = useState<string>("GIS pipeline: Ready.");
  const [bakingInProgress, setBakingInProgress] = useState<boolean>(false);

  const applyPreset = (index: number) => {
    setSelectedPreset(index);
    const p = PRESET_COORDINATES[index];
    setLat(p.lat);
    setLng(p.lng);
    setAlt(p.alt);
    setLastBakeLog(`Coordinates re-centered: Ingesting UTM zone for ${p.name}.`);
  };

  // 1. CELESTIAL CALCULATIONS (Section 2 equations)
  const celestialState = useMemo(() => {
    // Solar Declination: delta = 23.44 * sin(360 / 365 * (N + 10))
    const deltaDeg = 23.44 * Math.sin((2 * Math.PI / 365) * (dayOfYear + 10));
    const deltaRad = (deltaDeg * Math.PI) / 180;
    
    // Hour Angle: H = 15 * (T - 12)
    const hDeg = 15 * (localTime - 12);
    const hRad = (hDeg * Math.PI) / 180;
    
    const latRad = (lat * Math.PI) / 180;

    // Solar Elevation: sin(alpha) = sin(lat)*sin(delta) + cos(lat)*cos(delta)*cos(H)
    const sinAlpha = Math.sin(latRad) * Math.sin(deltaRad) + Math.cos(latRad) * Math.cos(deltaRad) * Math.cos(hRad);
    const alphaRad = Math.asin(Math.max(-1.0, Math.min(1.0, sinAlpha)));
    const alphaDeg = (alphaRad * 180) / Math.PI;

    // Azimuth calculation
    const cosAzimuth = (Math.sin(deltaRad) - Math.sin(latRad) * Math.sin(alphaRad)) / (Math.cos(latRad) * Math.cos(alphaRad));
    let azimuthDeg = Math.acos(Math.max(-1.0, Math.min(1.0, cosAzimuth))) * (180 / Math.PI);
    if (localTime > 12) {
      azimuthDeg = 360 - azimuthDeg;
    }

    // Tidal Force Vector calculations (syzygy bonus when sun and moon align: full moon or new moon)
    const isSyzygy = Math.abs(lunarPhase - 0.5) < 0.1 || lunarPhase < 0.1 || lunarPhase > 0.9;
    const baseTide = 0.52 * Math.cos(latRad); // peak tide at equator
    const tideGravityMult = isSyzygy ? 1.45 : 0.85; // Spring vs Neap tides
    const currentTidalOffset = baseTide * tideGravityMult * (1.0 + Math.sin(localTime * Math.PI / 6.0) * 0.3);

    return {
      solarDeclination: deltaDeg,
      hourAngle: hDeg,
      solarElevation: alt < 0 ? -90 : alphaDeg, // complete darkness underwater
      solarAzimuth: isNaN(azimuthDeg) ? 180 : azimuthDeg,
      tidalAcceleration: alt < -100 ? 0 : Math.max(0, currentTidalOffset),
      tideType: isSyzygy ? "Spring Tide (Syzygy - Sun & Moon Aligned)" : "Neap Tide (Quadrature - Perpendicular Forces)"
    };
  }, [lat, dayOfYear, localTime, lunarPhase, alt]);

  // 2. GEOMORPHOLOGY & BIOME CLASSIFICATION (Section 4 & 7.6 Köppen-Geiger)
  const terrainAndBiome = useMemo(() => {
    // Geomorphology type
    let geom = "Plains";
    if (alt < -100) {
      geom = "OceanFloor";
    } else if (alt < 5) {
      geom = "Beach";
    } else if (alt > 4000) {
      geom = "GlacierIce";
    } else if (alt > 1500) {
      geom = "Mountain";
    } else if (alt > 500) {
      geom = "Hills";
    }

    // Biome classification based on latitude, altitude, temperature estimate
    let biome = "Temperate Grassland";
    let rule = "Default maritime landmass ruleset";
    
    const absLat = Math.abs(lat);
    
    if (alt < -100) {
      biome = "Oceanic Open";
      rule = "Depth exceeds photic limits (>100m). Extremophile barophilic mechanics active.";
    } else if (absLat < 10) {
      biome = "Tropical Rainforest";
      rule = "Latitude < 10°. Continuous high humidity (precipitation > 150mm/mo), high heat.";
    } else if (absLat >= 10 && absLat < 25) {
      if (lng > 20 && lng < 60) {
        biome = "Arid Desert";
        rule = "Subtropical high-pressure belt with minimal annual moisture budget (<100mm).";
      } else {
        biome = "Tropical Savanna";
        rule = "Marked seasonal wet/dry cycles with high grasslands fraction.";
      }
    } else if (absLat >= 25 && absLat < 45) {
      if (lng > 40 && lng < 80) {
        biome = "Arid Desert";
        rule = "Continental dry landmass shielding, extremely sparse vegetation cover.";
      } else {
        biome = "Temperate Forest";
        rule = "Moderate rainfall distribution, seasonal deciduous and evergreen mix.";
      }
    } else if (absLat >= 45 && absLat < 65) {
      biome = "Boreal Taiga";
      rule = "High-latitude microthermal climate. Extensive coniferous forests, shallow organic soils.";
    } else if (absLat >= 65) {
      biome = "Tundra";
      rule = "Average warmest month temperature < 10°C. Permafrost boundaries active.";
    }

    // Altitude Override for Alpine biome
    if (alt > 3000 && alt < 5000) {
      biome = "Alpine";
      rule = "Elevational lapse-rate cooling replaces latitudinal zoning. Deciduous timberline cutoff exceeded.";
    }

    return { geomorphology: geom, biome, rule };
  }, [lat, lng, alt]);

  // 3. CLIMATE CALCULATIONS (Section 7.3 equations with Lapse Rate)
  const climateSample = useMemo(() => {
    // Environmental lapse rate is -6.5C per 1000m elevation.
    // Base temperature at sea level varies by latitude.
    const baseTempAtLatitude = 28.0 - (Math.abs(lat) * 0.45); // Warm at equator, freezing at poles
    const altitudeLapseC = (Math.max(0, alt) / 1000) * 6.5;
    
    // Time of day fluctuation: peak at 14:00, coldest at 05:00
    const timeFactor = Math.sin(((localTime - 8) / 24) * 2 * Math.PI);
    const dailyFluctuation = 5.0 * timeFactor;

    let temperature = baseTempAtLatitude - altitudeLapseC + dailyFluctuation;
    if (alt < -100) {
      temperature = 2.0; // Deep ocean temperature holds steady around 2-4C
    }

    // Storm modifiers
    const humidityBase = 90.0 - (Math.abs(lat) * 0.8) - (alt / 300.0);
    let humidity = Math.max(5, Math.min(100, humidityBase + (stormActive ? 20 : 0)));
    if (alt < -100) humidity = 100;

    const pressureBase = 1013.25 - (alt / 8.3); // exponential barometric drop simulated
    let pressure = Math.max(200, pressureBase);
    
    let windSpeed = 3.2 + (alt / 1200.0) + (stormActive ? 18.0 : 0);
    if (alt < -100) windSpeed = 0.1; // tiny underwater currents

    let precipitation = 0.0;
    let snowfall = 0.0;
    if (stormActive && alt >= -100) {
      if (temperature <= 0) {
        snowfall = 4.2;
      } else {
        precipitation = 8.5;
      }
    }

    const cloudFraction = stormActive ? 1.0 : Math.max(0.0, Math.min(1.0, 0.2 + (humidity / 150)));

    return {
      temperature: temperature,
      humidity: alt < -100 ? 100 : humidity,
      pressure: alt < -100 ? 1013.25 + (Math.abs(alt) * 0.1) : pressure, // underwater pressure spikes massively
      windSpeed: windSpeed,
      windDirection: 45 + (lat * 2.0) + (dayOfYear * 0.5), // degree vector
      precipitation: precipitation,
      snowfall: snowfall,
      cloudCover: alt < -100 ? 0.0 : cloudFraction
    };
  }, [lat, alt, localTime, dayOfYear, stormActive]);

  // 4. HYDROLOGY & OCEAN ANALYSIS (Section 7.4 & 7.5)
  const hydroOceanState = useMemo(() => {
    const isWaterPreset = alt < 10;
    const searchRadius = 1500; // Search radius in meters
    
    // Hydrology Segment Simulation
    const flowMultiplier = stormActive ? 3.4 : 1.0;
    const baseFlowRate = Math.max(0.1, 520 - (Math.abs(lat) * 5) - (alt / 10));
    const flowRate = isWaterPreset ? baseFlowRate * flowMultiplier : 1.2 * flowMultiplier;
    const channelWidth = Math.sqrt(flowRate) * 1.8;

    // Ocean simulation
    const tideAmplitude = celestialState.tidalAcceleration * (highTideTrigger ? 1.5 : 1.0);
    const salinity = alt < 0 ? 34.8 : (alt < 10 ? 32.1 : 0.0); // parts per thousand
    const isCoralReef = Math.abs(lat) < 20 && alt < 20 && alt > -50 && salinity > 30;

    return {
      segmentId: Math.floor(98273641 + Math.abs(lat * 100)),
      flowRate,
      channelWidth,
      searchRadius,
      tideAmplitude,
      salinity,
      isCoralReef,
      oceanDepth: alt < 0 ? Math.abs(alt) : 0
    };
  }, [lat, alt, stormActive, celestialState, highTideTrigger]);

  // 5. STREAMING & MEMORY CONSUMPTION (Section 8 budgets)
  const streamingMetrics = useMemo(() => {
    // Dynamic tracking depending on coordinate complexity (NYC / Tokyo center has more nodes)
    const isUrban = PRESET_COORDINATES[selectedPreset]?.name.includes("Tokyo");
    const isMountain = PRESET_COORDINATES[selectedPreset]?.name.includes("Everest");

    // RAM allocation counts based on loaded cells (represented in megabytes)
    const heightmapRam = 1250 + (isMountain ? 650 : 0) + (lat > 50 ? 200 : 0);
    const climateRam = 520 + (dayOfYear > 180 ? 80 : 0);
    const hydroRam = 210 + (isWaterPreset() ? 150 : 0);
    
    // VRAM allocations
    const naniteVram = 1580 + (isMountain ? 820 : 0) + (isUrban ? 400 : 0);
    const virtualTextureVram = 1280 + (isUrban ? 650 : 120);

    function isWaterPreset() {
      return alt < 10;
    }

    return {
      heightmapRam,
      climateRam,
      hydroRam,
      naniteVram,
      virtualTextureVram,
      totalRam: (heightmapRam + climateRam + hydroRam) / 1024,
      totalVram: (naniteVram + virtualTextureVram) / 1024,
      tier0Count: 16 + (isUrban ? 24 : 0),
      tier1Count: 128,
      tier2Count: 512,
      threadLoads: {
        gameThread: 18 + (isUrban ? 14 : 0),
        asyncIo: 42 + (isMountain ? 25 : 0),
        climatePool: 30 + (stormActive ? 25 : 0),
        hydroWorker: 12 + (stormActive ? 32 : 0)
      }
    };
  }, [selectedPreset, lat, dayOfYear, alt, stormActive]);

  // Handle baking process animation
  const handleBakePipeline = () => {
    setBakingInProgress(true);
    setLastBakeLog("PROJ: Reprojecting WGS84 coordinates to active UTM projection bounds...");
    
    setTimeout(() => {
      setLastBakeLog("GDAL: Ingesting Digital Elevation Model heightmap blocks...");
      
      setTimeout(() => {
        setLastBakeLog("GDAL: Masking ESA WorldCover land classification rasters...");
        
        setTimeout(() => {
          setLastBakeLog("BAKER: Quantizing height assets into normalized 16-bit streamable binary (.peth).");
          setBakingInProgress(false);
          addBakeCompleteLog();
        }, 1200);
      }, 1000);
    }, 800);
  };

  const addBakeCompleteLog = () => {
    const presetName = PRESET_COORDINATES[selectedPreset].name;
    setLastBakeLog(`Success: Active GIS packages for [${presetName}] re-projected and fully optimized!`);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="earth-environment-root">
      {/* LEFT COLUMN: Globe Coordinates & Presets Control Panel (4 Cols) */}
      <div className="lg:col-span-4 space-y-6" id="globe-control-column">
        {/* Geographic Presets Select */}
        <div className="glass-panel rounded-2xl p-5 border border-pink-500/10" id="preset-selector-card">
          <h3 className="text-sm font-bold text-white font-serif flex items-center gap-2 mb-3">
            <Globe className="text-pink-400 h-4.5 w-4.5" /> Planetary Target Ingestion
          </h3>
          <p className="text-xs text-slate-300 leading-normal mb-4">
            Select an official terrestrial benchmark target to auto-project GIS raster grids, elevation nodes, and local climate rules.
          </p>

          <div className="space-y-2 max-h-64 overflow-y-auto pr-1 glass-scrollbar" id="presets-list">
            {PRESET_COORDINATES.map((preset, index) => (
              <button
                id={`preset-btn-${index}`}
                key={index}
                onClick={() => applyPreset(index)}
                className={`w-full p-3 text-left rounded-xl border transition-all flex flex-col gap-1 ${
                  selectedPreset === index 
                    ? 'bg-pink-500/10 border-pink-500/30 text-white shadow-[0_0_12px_rgba(236,72,153,0.1)]' 
                    : 'bg-white/5 border-white/5 text-slate-300 hover:bg-white/10'
                }`}
              >
                <div className="flex justify-between items-center w-full">
                  <span className="text-xs font-bold font-serif">{preset.name}</span>
                  <span className="text-[9px] font-mono bg-white/5 px-1.5 py-0.5 rounded text-slate-400">{preset.region}</span>
                </div>
                <p className="text-[10px] text-slate-400 leading-snug line-clamp-2">{preset.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Manual Geodetic Parameters */}
        <div className="glass-panel rounded-2xl p-5 space-y-5" id="geodetic-meters-card">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
            <span>Manual Spatial Coordinates</span>
            <span className="text-[9px] bg-pink-500/20 text-pink-400 px-1.5 py-0.5 rounded font-mono">WGS84 Ellipsoid</span>
          </h3>

          {/* Latitude Slider */}
          <div className="space-y-1.5" id="lat-slider-wrapper">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">Geodetic Latitude (φ)</span>
              <span className="font-mono font-bold text-pink-400">{lat.toFixed(4)}° {lat >= 0 ? 'N' : 'S'}</span>
            </div>
            <input
              id="lat-slider"
              type="range"
              min="-90"
              max="90"
              step="0.0001"
              value={lat}
              onChange={(e) => {
                setLat(parseFloat(e.target.value));
                setSelectedPreset(-1); // Break preset lock
              }}
              className="w-full accent-pink-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-slate-500 font-mono">
              <span>-90° (South Pole)</span>
              <span>0° (Equator)</span>
              <span>+90° (North Pole)</span>
            </div>
          </div>

          {/* Longitude Slider */}
          <div className="space-y-1.5" id="lng-slider-wrapper">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">Geodetic Longitude (λ)</span>
              <span className="font-mono font-bold text-pink-400">{lng.toFixed(4)}° {lng >= 0 ? 'E' : 'W'}</span>
            </div>
            <input
              id="lng-slider"
              type="range"
              min="-180"
              max="180"
              step="0.0001"
              value={lng}
              onChange={(e) => {
                setLng(parseFloat(e.target.value));
                setSelectedPreset(-1);
              }}
              className="w-full accent-pink-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-slate-500 font-mono">
              <span>-180° W</span>
              <span>Prime Meridian (0°)</span>
              <span>+180° E</span>
            </div>
          </div>

          {/* Altitude Slider */}
          <div className="space-y-1.5" id="alt-slider-wrapper">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">Elevation / Altitude</span>
              <span className="font-mono font-bold text-pink-400">{alt.toLocaleString()} m</span>
            </div>
            <input
              id="alt-slider"
              type="range"
              min="-11000"
              max="9000"
              step="1"
              value={alt}
              onChange={(e) => {
                setAlt(parseInt(e.target.value));
                setSelectedPreset(-1);
              }}
              className="w-full accent-pink-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-slate-500 font-mono">
              <span>-11,000m (Challenger Deep)</span>
              <span>Sea Level (0m)</span>
              <span>+9,000m (Everest Peak)</span>
            </div>
          </div>
        </div>

        {/* Ephemeris / Chrono Variables */}
        <div className="glass-panel rounded-2xl p-5 space-y-4" id="ephemeris-card">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-pink-500" /> Ephemeris Orbit Calibration
          </h3>

          {/* Local Time of Day */}
          <div className="space-y-1.5" id="time-slider-wrapper">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">Local Solar Time</span>
              <span className="font-mono font-bold text-orange-400">
                {Math.floor(localTime).toString().padStart(2, '0')}:
                {Math.floor((localTime % 1) * 60).toString().padStart(2, '0')}
              </span>
            </div>
            <input
              id="time-slider"
              type="range"
              min="0"
              max="23.99"
              step="0.01"
              value={localTime}
              onChange={(e) => setLocalTime(parseFloat(e.target.value))}
              className="w-full accent-orange-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
            />
          </div>

          {/* Calendar Day of Year */}
          <div className="space-y-1.5" id="day-slider-wrapper">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">Calendar Julian Day</span>
              <span className="font-mono font-bold text-orange-400">Day {dayOfYear}</span>
            </div>
            <input
              id="day-slider"
              type="range"
              min="1"
              max="365"
              step="1"
              value={dayOfYear}
              onChange={(e) => setDayOfYear(parseInt(e.target.value))}
              className="w-full accent-orange-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: Engine Sub-Module Workspaces (8 Cols) */}
      <div className="lg:col-span-8 space-y-6" id="engine-subsystem-column">
        {/* Navigation Tabs for Subsystems */}
        <div className="glass-panel rounded-xl p-2 flex space-x-1 overflow-x-auto glass-scrollbar shrink-0" id="subsystem-tabs">
          <button
            id="subsystem-tab-celestial"
            onClick={() => setActiveTab('celestial')}
            className={`flex-1 min-w-[90px] py-2 px-3 rounded-lg text-[10px] uppercase tracking-wider font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap ${
              activeTab === 'celestial' 
                ? 'bg-white text-slate-950 shadow-md' 
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Sun className="h-3.5 w-3.5" /> Celestial
          </button>
          <button
            id="subsystem-tab-gis"
            onClick={() => setActiveTab('gis')}
            className={`flex-1 min-w-[90px] py-2 px-3 rounded-lg text-[10px] uppercase tracking-wider font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap ${
              activeTab === 'gis' 
                ? 'bg-white text-slate-950 shadow-md' 
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Map className="h-3.5 w-3.5" /> GIS Pipeline
          </button>
          <button
            id="subsystem-tab-climate"
            onClick={() => setActiveTab('climate')}
            className={`flex-1 min-w-[90px] py-2 px-3 rounded-lg text-[10px] uppercase tracking-wider font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap ${
              activeTab === 'climate' 
                ? 'bg-white text-slate-950 shadow-md' 
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Thermometer className="h-3.5 w-3.5" /> Climate
          </button>
          <button
            id="subsystem-tab-hydrology"
            onClick={() => setActiveTab('hydrology')}
            className={`flex-1 min-w-[90px] py-2 px-3 rounded-lg text-[10px] uppercase tracking-wider font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap ${
              activeTab === 'hydrology' 
                ? 'bg-white text-slate-950 shadow-md' 
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Waves className="h-3.5 w-3.5" /> Hydrology
          </button>
          <button
            id="subsystem-tab-streaming"
            onClick={() => setActiveTab('streaming')}
            className={`flex-1 min-w-[90px] py-2 px-3 rounded-lg text-[10px] uppercase tracking-wider font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap ${
              activeTab === 'streaming' 
                ? 'bg-white text-slate-950 shadow-md' 
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Layers className="h-3.5 w-3.5" /> Streaming
          </button>
        </div>

        {/* Tab 1: Celestial & Geodetic Subsystem */}
        {activeTab === 'celestial' && (
          <div className="glass-panel rounded-2xl p-6 space-y-6" id="celestial-workspace">
            <div className="flex justify-between items-start" id="celestial-title-container">
              <div>
                <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 font-mono">EarthCelestial Plugin</h4>
                <h2 className="text-lg font-bold font-serif text-white mt-1">Solar / Lunar Geodetic Ephemeris</h2>
              </div>
              <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/25 px-2.5 py-1 rounded font-mono">
                Axial Tilt: 23.439°
              </span>
            </div>

            {/* Scientific Formulas Card */}
            <div className="bg-slate-950/60 border border-white/5 p-4 rounded-xl font-mono text-xs text-slate-300 space-y-2" id="celestial-formulas">
              <div className="text-[10px] uppercase text-pink-500 font-bold">WGS84 Mathematical Solar Alignment</div>
              <div>Solar Declination (δ): <span className="text-emerald-400">23.44° × sin(360°/365 × (Day + 10))</span> = <span className="text-white font-bold">{celestialState.solarDeclination.toFixed(2)}°</span></div>
              <div>Hour Angle (H): <span className="text-emerald-400">15° × (Hour - 12)</span> = <span className="text-white font-bold">{celestialState.hourAngle.toFixed(2)}°</span></div>
              <div>Solar Elevation (α): <span className="text-emerald-400">asin(sin(φ)sin(δ) + cos(φ)cos(δ)cos(H))</span> = <span className="text-white font-bold">{celestialState.solarElevation.toFixed(2)}°</span></div>
            </div>

            {/* Dials Layout */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="celestial-dials">
              {/* Solar Vector SVG Dial */}
              <div className="bg-white/2 border border-white/5 rounded-2xl p-5 flex flex-col items-center justify-center text-center" id="solar-dial-card">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-1">
                  <Sun className="h-4 w-4 text-orange-400" /> Heliocentric Position Vector
                </span>

                <div className="relative w-44 h-44 flex items-center justify-center" id="solar-gauge-svg">
                  {/* Sky dome background arc */}
                  <svg className="w-full h-full transform -rotate-90">
                    <circle
                      cx="88"
                      cy="88"
                      r="70"
                      className="stroke-white/5 fill-transparent"
                      strokeWidth="6"
                    />
                    {/* Active daytime arc */}
                    <path
                      d="M 18,88 A 70,70 0 0,1 158,88"
                      className="stroke-orange-500/20 fill-transparent"
                      strokeWidth="6"
                      strokeLinecap="round"
                    />
                  </svg>
                  {/* Rotating pointer based on Solar Elevation */}
                  <div 
                    className="absolute inset-0 flex items-center justify-center transition-transform duration-300"
                    style={{ transform: `rotate(${celestialState.solarElevation}deg)` }}
                    id="solar-pointer"
                  >
                    <div className="w-20 h-0.5 bg-gradient-to-r from-transparent to-orange-400 relative">
                      <div className="absolute -right-2 -top-2 w-4.5 h-4.5 bg-orange-500 rounded-full shadow-[0_0_12px_#f97316]" />
                    </div>
                  </div>
                  {/* Internal state readout */}
                  <div className="absolute flex flex-col items-center justify-center" id="solar-readout">
                    <span className="text-2xl font-bold font-mono text-white">
                      {celestialState.solarElevation.toFixed(0)}°
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium uppercase mt-0.5">
                      {celestialState.solarElevation > 0 ? "Above Horizon" : "Complete Dark"}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 w-full border-t border-white/5 pt-4 mt-2 text-xs" id="solar-dossier">
                  <div className="text-left">
                    <span className="text-slate-400 block">Solar Azimuth:</span>
                    <span className="font-mono font-bold text-white">{celestialState.solarAzimuth.toFixed(1)}° (North)</span>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-400 block">Solar Flux Irradiance:</span>
                    <span className="font-mono font-bold text-emerald-400">
                      {celestialState.solarElevation > 0 ? (Math.sin(celestialState.solarElevation * Math.PI / 180) * 1361).toFixed(0) : 0} W/m²
                    </span>
                  </div>
                </div>
              </div>

              {/* Lunar/Tidal gravitational forces */}
              <div className="bg-white/2 border border-white/5 rounded-2xl p-5 flex flex-col justify-between" id="lunar-tide-card">
                <div className="space-y-4" id="lunar-tide-top">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Moon className="h-4 w-4 text-cyan-400" /> Gravitational Tides & Moon Phases
                  </span>

                  {/* Lunar Phase config slider */}
                  <div className="space-y-1.5" id="lunar-phase-slider-wrapper">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-300">Lunar Phase Fraction</span>
                      <span className="font-mono font-bold text-cyan-400">{(lunarPhase * 100).toFixed(0)}% (Full)</span>
                    </div>
                    <input
                      id="lunar-phase-slider"
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={lunarPhase}
                      onChange={(e) => setLunarPhase(parseFloat(e.target.value))}
                      className="w-full accent-cyan-400 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-[9px] text-slate-500 font-mono">
                      <span>New Moon (0.0)</span>
                      <span>Quarter (0.25)</span>
                      <span>Full Moon (0.5)</span>
                      <span>New Moon (1.0)</span>
                    </div>
                  </div>
                </div>

                {/* Tide Readout indicators */}
                <div className="border-t border-white/5 pt-4 mt-4 space-y-3" id="tide-indicators">
                  <div className="flex items-center justify-between" id="tidal-force-metric">
                    <div className="flex items-center gap-1 text-xs">
                      <Waves className="h-4 w-4 text-pink-400" />
                      <span className="text-slate-300">Tidal Gravitational Pull:</span>
                    </div>
                    <span className="font-mono font-bold text-pink-400 text-sm">
                      {celestialState.tidalAcceleration.toFixed(3)} m/s²
                    </span>
                  </div>

                  <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-[11px] leading-relaxed text-slate-300" id="tidal-state-explanation">
                    <span className="font-bold text-white block mb-0.5">{celestialState.tideType}</span>
                    Gravitational vectors from Sun & Moon compound linearly during syzygy. This amplifies oceanic high/low tide deltas by up to 45%.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: GIS Ingestion Pipeline Subsystem */}
        {activeTab === 'gis' && (
          <div className="glass-panel rounded-2xl p-6 space-y-6" id="gis-workspace">
            <div className="flex justify-between items-start" id="gis-title-container">
              <div>
                <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 font-mono">EarthTerrain & EarthGIS Plugins</h4>
                <h2 className="text-lg font-bold font-serif text-white mt-1">Multi-Layer GIS Data Ingestion</h2>
              </div>
              <button
                id="bake-pipeline-btn"
                onClick={handleBakePipeline}
                disabled={bakingInProgress}
                className="py-2 px-4 bg-pink-500 hover:bg-pink-600 disabled:bg-slate-800 text-white font-bold rounded-xl text-xs transition-colors flex items-center gap-2"
              >
                <RefreshCcw className={`h-3.5 w-3.5 ${bakingInProgress ? 'animate-spin' : ''}`} /> 
                {bakingInProgress ? 'Baking Chunks...' : 'Bake Local Tiles'}
              </button>
            </div>

            {/* Ingestion layer cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="gis-layers-grid">
              {/* Layer 1: DEM Heightmap */}
              <div className="bg-white/2 border border-white/5 p-4 rounded-xl space-y-2" id="gis-layer-dem">
                <span className="text-[10px] font-mono text-pink-500 font-bold uppercase">Layer 01: DEM Heightmap</span>
                <h5 className="text-xs font-bold text-slate-200">Digital Elevation Model</h5>
                <p className="text-[10px] text-slate-400 leading-relaxed">
                  Imports elevation contours at WGS84 benchmarks, mapped into high-resolution streamable vertex height arrays.
                </p>
                <div className="text-xs font-mono border-t border-white/5 pt-2 mt-2 flex justify-between">
                  <span className="text-slate-400">Resolution:</span>
                  <span className="text-white font-bold">16-bit, 30m Grid</span>
                </div>
              </div>

              {/* Layer 2: OSM Roads & Hydrology */}
              <div className="bg-white/2 border border-white/5 p-4 rounded-xl space-y-2" id="gis-layer-osm">
                <span className="text-[10px] font-mono text-pink-500 font-bold uppercase">Layer 02: OSM Vector Infrastructure</span>
                <h5 className="text-xs font-bold text-slate-200">OpenStreetMap Graph Nodes</h5>
                <p className="text-[10px] text-slate-400 leading-relaxed">
                  Extracts road topology segments, administrative borders, and structural building footprints for agent GOAP routines.
                </p>
                <div className="text-xs font-mono border-t border-white/5 pt-2 mt-2 flex justify-between">
                  <span className="text-slate-400">Vertices paged:</span>
                  <span className="text-white font-bold">142,831 nodes</span>
                </div>
              </div>

              {/* Layer 3: ESA WorldCover */}
              <div className="bg-white/2 border border-white/5 p-4 rounded-xl space-y-2" id="gis-layer-worldcover">
                <span className="text-[10px] font-mono text-pink-500 font-bold uppercase">Layer 03: Land Cover Classification</span>
                <h5 className="text-xs font-bold text-slate-200">ESA WorldCover 10m Matrix</h5>
                <p className="text-[10px] text-slate-400 leading-relaxed">
                  Classifies foliage type, urban asphalt surfaces, and water boundaries to dynamically determine biome-restricted movement costs.
                </p>
                <div className="text-xs font-mono border-t border-white/5 pt-2 mt-2 flex justify-between">
                  <span className="text-slate-400">Resolution limit:</span>
                  <span className="text-white font-bold">10-meter Raster</span>
                </div>
              </div>
            </div>

            {/* Simulated Live Bake Logger */}
            <div className="glass-panel border border-pink-500/20 bg-slate-950 p-4 rounded-xl font-mono text-xs text-slate-300 space-y-2" id="gis-bake-logs">
              <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider text-pink-400">
                <span>Active GIS Ingestion Log</span>
                <span className="h-2 w-2 bg-pink-500 rounded-full animate-ping" />
              </div>
              <div className="border-t border-white/5 pt-2 font-mono text-[11px] text-slate-300 leading-relaxed">
                {lastBakeLog}
              </div>
            </div>

            {/* Geomorphology details based on coordinates */}
            <div className="bg-white/2 border border-white/5 p-5 rounded-2xl flex flex-col md:flex-row justify-between gap-6" id="geomorphology-readout">
              <div className="space-y-1">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Geomorphology Classification</span>
                <h4 className="text-lg font-bold font-serif text-white">{terrainAndBiome.geomorphology}</h4>
                <p className="text-xs text-slate-400 max-w-md">
                  Active geographic structural contours classified under geomorphic rules to govern mass physics, erosion, and soil quality formulas.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs font-mono text-slate-300" id="geom-metrics">
                <div>
                  <span className="text-slate-400 block">Ingested Peak Elevation:</span>
                  <span className="text-white font-bold">{Math.max(0, alt)}m</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Saddle Min Elevation:</span>
                  <span className="text-white font-bold">{Math.floor(alt * 0.72)}m</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Surface Slope Delta:</span>
                  <span className="text-white font-bold">{(alt / 400.0).toFixed(1)}°</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Soil Permeability:</span>
                  <span className="text-white font-bold">{alt > 1000 ? "Shallow rock" : "Sandy loam"}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Multi-Layer Climate Grid Subsystem */}
        {activeTab === 'climate' && (
          <div className="glass-panel rounded-2xl p-6 space-y-6" id="climate-workspace">
            <div className="flex justify-between items-start" id="climate-title-container">
              <div>
                <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 font-mono">EarthClimateGrid & EarthBiome Plugins</h4>
                <h2 className="text-lg font-bold font-serif text-white mt-1">Multi-Layer Atmospheric Climate Grid</h2>
              </div>
              <button
                id="toggle-storm-btn"
                onClick={() => setStormActive(!stormActive)}
                className={`py-2 px-4 rounded-xl text-xs font-bold transition-all border ${
                  stormActive 
                    ? 'bg-amber-500/15 border-amber-500/30 text-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.15)]' 
                    : 'bg-white/5 border-white/10 text-slate-300'
                }`}
              >
                {stormActive ? '🌩️ Storm Event Active' : '☀️ Trigger Micro Storm'}
              </button>
            </div>

            {/* Climate Grid variables panel */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="climate-metrics-grid">
              {/* Temperature */}
              <div className="bg-white/2 border border-white/5 p-4 rounded-xl flex items-center gap-3" id="climate-metric-temp">
                <Thermometer className="h-8 w-8 text-pink-500 shrink-0" />
                <div>
                  <span className="text-[9px] uppercase font-mono text-slate-400 block">Temperature</span>
                  <span className="text-lg font-bold font-mono text-white">{climateSample.temperature.toFixed(1)}°C</span>
                </div>
              </div>

              {/* Relative Humidity */}
              <div className="bg-white/2 border border-white/5 p-4 rounded-xl flex items-center gap-3" id="climate-metric-humidity">
                <CloudRain className="h-8 w-8 text-cyan-400 shrink-0" />
                <div>
                  <span className="text-[9px] uppercase font-mono text-slate-400 block">Humidity</span>
                  <span className="text-lg font-bold font-mono text-white">{climateSample.humidity.toFixed(0)}%</span>
                </div>
              </div>

              {/* Wind Speed & Direction */}
              <div className="bg-white/2 border border-white/5 p-4 rounded-xl flex items-center gap-3" id="climate-metric-wind">
                <Wind className="h-8 w-8 text-orange-400 shrink-0" />
                <div>
                  <span className="text-[9px] uppercase font-mono text-slate-400 block">Wind Velocity</span>
                  <span className="text-base font-bold font-mono text-white leading-tight block">{climateSample.windSpeed.toFixed(1)} m/s</span>
                  <span className="text-[9px] font-mono text-slate-400 block">Hdg: {climateSample.windDirection.toFixed(0)}°</span>
                </div>
              </div>

              {/* Atmospheric Pressure */}
              <div className="bg-white/2 border border-white/5 p-4 rounded-xl flex items-center gap-3" id="climate-metric-pressure">
                <Compass className="h-8 w-8 text-emerald-400 shrink-0" />
                <div>
                  <span className="text-[9px] uppercase font-mono text-slate-400 block">Air Pressure</span>
                  <span className="text-base font-bold font-mono text-white leading-tight block">{climateSample.pressure.toFixed(1)} hPa</span>
                </div>
              </div>
            </div>

            {/* Köppen-Geiger Biome Classification */}
            <div className="bg-gradient-to-r from-pink-500/5 to-indigo-500/5 border border-white/10 rounded-2xl p-5" id="biome-matrix-card">
              <div className="flex justify-between items-start mb-2" id="biome-header">
                <div>
                  <span className="text-[10px] font-mono font-bold text-pink-500 uppercase tracking-wider">Köppen-Geiger Ecological Matrix</span>
                  <h4 className="text-base font-bold font-serif text-white mt-0.5">{terrainAndBiome.biome} Classification</h4>
                </div>
                <span className="text-[10px] bg-white/5 text-slate-300 px-2 py-0.5 rounded font-mono border border-white/10">
                  Lapse Rate: -6.5°C/1000m
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed mb-4">{terrainAndBiome.rule}</p>

              {/* Biome classification parameters list */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 border-t border-white/5 pt-4 text-[11px]" id="biome-parameters">
                <div className="flex justify-between">
                  <span className="text-slate-400">Warmest Month Limit:</span>
                  <span className="font-mono text-white font-bold">{alt > 3000 ? "<10°C" : ">22°C"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Precipitation Threshold:</span>
                  <span className="font-mono text-white font-bold">{stormActive ? "Saturated" : "Semi-arid"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Vegetation Density:</span>
                  <span className="font-mono text-white font-bold">
                    {terrainAndBiome.biome.includes("Desert") ? "0.02 (Dry Shrub)" : "0.85 (Coniferous)"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Hydrology & Ocean Model Subsystem */}
        {activeTab === 'hydrology' && (
          <div className="glass-panel rounded-2xl p-6 space-y-6" id="hydrology-workspace">
            <div className="flex justify-between items-start" id="hydrology-title-container">
              <div>
                <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 font-mono">EarthHydrology & EarthOcean Plugins</h4>
                <h2 className="text-lg font-bold font-serif text-white mt-1">Watershed Networks & Ocean Currents</h2>
              </div>
              <button
                id="toggle-tide-btn"
                onClick={() => setHighTideTrigger(!highTideTrigger)}
                className={`py-2 px-4 rounded-xl text-xs font-bold transition-all border ${
                  highTideTrigger 
                    ? 'bg-pink-500/15 border-pink-500/30 text-pink-400 shadow-[0_0_12px_rgba(236,72,153,0.15)]' 
                    : 'bg-white/5 border-white/10 text-slate-300'
                }`}
              >
                {highTideTrigger ? '🌊 Lunar Tidal Surge Active' : '🌊 Trigger Tidal Surge'}
              </button>
            </div>

            {/* Hydrology Segment detail card */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="hydro-ocean-grid">
              {/* Hydrology */}
              <div className="bg-white/2 border border-white/5 p-5 rounded-xl space-y-4" id="hydro-river-card">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">River Network Integration</span>
                
                <div className="flex justify-between items-center bg-slate-950 p-3 rounded-xl border border-white/5 text-xs font-mono" id="river-segment-info">
                  <span className="text-slate-400">Segment ID:</span>
                  <span className="text-white font-bold">#{hydroOceanState.segmentId}</span>
                </div>

                <div className="space-y-2 text-xs" id="river-metrics">
                  <div className="flex justify-between border-b border-white/5 pb-1.5">
                    <span className="text-slate-400">Discharge Flow Rate:</span>
                    <span className="font-mono text-white font-bold">{hydroOceanState.flowRate.toLocaleString(undefined, {maximumFractionDigits: 1})} m³/s</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1.5">
                    <span className="text-slate-400">Channel Width:</span>
                    <span className="font-mono text-white font-bold">{hydroOceanState.channelWidth.toFixed(1)} meters</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1.5">
                    <span className="text-slate-400">Downstream Connection ID:</span>
                    <span className="font-mono text-white">#{(hydroOceanState.segmentId + 124)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Watershed Buffer Area:</span>
                    <span className="font-mono text-white">{(Math.abs(lat) * 12.2).toFixed(0)} km²</span>
                  </div>
                </div>

                <div className="p-3 bg-white/5 rounded-xl text-[11px] leading-relaxed text-slate-400" id="river-note">
                  River segment vectors are extracted directly from hydrography rasters. Water levels fluctuate in response to regional daily precipitation grids.
                </div>
              </div>

              {/* Oceans */}
              <div className="bg-white/2 border border-white/5 p-5 rounded-xl space-y-4" id="ocean-bathymetry-card">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Ocean Bathymetry & Salinity</span>

                <div className="flex justify-between items-center bg-slate-950 p-3 rounded-xl border border-white/5 text-xs font-mono" id="ocean-depth-info">
                  <span className="text-slate-400">Bathymetric Depth:</span>
                  <span className="text-pink-400 font-bold">{hydroOceanState.oceanDepth.toLocaleString()} meters</span>
                </div>

                <div className="space-y-2 text-xs" id="ocean-metrics">
                  <div className="flex justify-between border-b border-white/5 pb-1.5">
                    <span className="text-slate-400">Average Salinity:</span>
                    <span className="font-mono text-white font-bold">{hydroOceanState.salinity.toFixed(1)} ppt (PPT)</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1.5">
                    <span className="text-slate-400">Lunar Tidal Offset:</span>
                    <span className="font-mono text-cyan-400 font-bold">+{hydroOceanState.tideAmplitude.toFixed(2)} m</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1.5">
                    <span className="text-slate-400">Surface Current Speed:</span>
                    <span className="font-mono text-white">0.45 m/s (East)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Coral Reef Zone:</span>
                    <span className={`font-mono font-bold ${hydroOceanState.isCoralReef ? 'text-pink-400' : 'text-slate-500'}`}>
                      {hydroOceanState.isCoralReef ? 'True (Photic Limits Ok)' : 'False (Outside Range)'}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-white/5 rounded-xl text-[11px] leading-relaxed text-slate-400" id="ocean-note">
                  Depth coordinates simulate bathymetric zones based on NOAA grids. Deep zones invoke custom thermal parameters and exclude solar illumination.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: Streaming Controller & Memory Budget */}
        {activeTab === 'streaming' && (
          <div className="glass-panel rounded-2xl p-6 space-y-6" id="streaming-workspace">
            <div className="flex justify-between items-start" id="streaming-title-container">
              <div>
                <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 font-mono">Streaming & Async Thread Allocator</h4>
                <h2 className="text-lg font-bold font-serif text-white mt-1">Continuous Memory Allocation Budget</h2>
              </div>
              <span className="text-[10px] bg-pink-500/10 text-pink-400 border border-pink-500/25 px-2.5 py-1 rounded font-mono">
                Thread-Safe Lock-Free Caches
              </span>
            </div>

            {/* RAM/VRAM Progress bars */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-b border-white/5 pb-6" id="memory-bars-container">
              {/* System RAM Allocations */}
              <div className="space-y-3" id="system-ram-budget">
                <div className="flex justify-between text-xs font-mono" id="ram-budget-labels">
                  <span className="text-slate-300 font-bold uppercase tracking-wider flex items-center gap-1"><Database className="h-4 w-4 text-pink-500" /> Active System RAM</span>
                  <span className="text-slate-400">Budget: 4.0 GB</span>
                </div>
                
                <div className="h-4.5 bg-white/5 rounded-full overflow-hidden p-0.5 border border-white/10" id="ram-progress-bg">
                  <div 
                    className="h-full bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-500 rounded-full flex items-center justify-end pr-2 text-[9px] font-mono font-bold text-white transition-all duration-500"
                    style={{ width: `${(streamingMetrics.totalRam / 4.0) * 100}%` }}
                    id="ram-progress-bar"
                  >
                    {streamingMetrics.totalRam.toFixed(2)} GB
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-[10px] font-mono text-slate-400 text-center" id="ram-allocations-breakdown">
                  <div className="bg-white/2 p-1.5 rounded border border-white/5">
                    <span className="block text-[8px] uppercase">Terrain Height:</span>
                    <span className="text-white font-bold">{streamingMetrics.heightmapRam} MB</span>
                  </div>
                  <div className="bg-white/2 p-1.5 rounded border border-white/5">
                    <span className="block text-[8px] uppercase">Climate Grid:</span>
                    <span className="text-white font-bold">{streamingMetrics.climateRam} MB</span>
                  </div>
                  <div className="bg-white/2 p-1.5 rounded border border-white/5">
                    <span className="block text-[8px] uppercase">Hydro Graph:</span>
                    <span className="text-white font-bold">{streamingMetrics.hydroRam} MB</span>
                  </div>
                </div>
              </div>

              {/* GPU VRAM Allocations */}
              <div className="space-y-3" id="gpu-vram-budget">
                <div className="flex justify-between text-xs font-mono" id="vram-budget-labels">
                  <span className="text-slate-300 font-bold uppercase tracking-wider flex items-center gap-1"><Cpu className="h-4 w-4 text-cyan-400" /> Active GPU VRAM</span>
                  <span className="text-slate-400">Budget: 5.5 GB</span>
                </div>

                <div className="h-4.5 bg-white/5 rounded-full overflow-hidden p-0.5 border border-white/10" id="vram-progress-bg">
                  <div 
                    className="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 rounded-full flex items-center justify-end pr-2 text-[9px] font-mono font-bold text-white transition-all duration-500"
                    style={{ width: `${(streamingMetrics.totalVram / 5.5) * 100}%` }}
                    id="vram-progress-bar"
                  >
                    {streamingMetrics.totalVram.toFixed(2)} GB
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-400 text-center" id="vram-allocations-breakdown">
                  <div className="bg-white/2 p-1.5 rounded border border-white/5">
                    <span className="block text-[8px] uppercase">Nanite Tessellation:</span>
                    <span className="text-white font-bold">{streamingMetrics.naniteVram} MB</span>
                  </div>
                  <div className="bg-white/2 p-1.5 rounded border border-white/5">
                    <span className="block text-[8px] uppercase">Virtual Textures:</span>
                    <span className="text-white font-bold">{streamingMetrics.virtualTextureVram} MB</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Three-tier streaming grids loaded counts */}
            <div className="space-y-3" id="three-tier-grids-section">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Three-Tier Spatial Partition Grid</span>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs" id="grids-breakdown">
                {/* Tier 0 */}
                <div className="bg-white/2 border border-white/5 p-4 rounded-xl space-y-1.5" id="grid-tier-0">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">Tier 0 (Local Cells)</span>
                    <span className="text-[9px] bg-pink-500/20 text-pink-400 px-1 rounded font-mono">64m Size</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Nanite mesh density, active structures, immediate physics collision assets.</p>
                  <div className="font-mono text-[10px] flex justify-between text-slate-300 pt-1 border-t border-white/5">
                    <span>Loaded Cells:</span>
                    <span className="text-white font-bold">{streamingMetrics.tier0Count} blocks</span>
                  </div>
                </div>

                {/* Tier 1 */}
                <div className="bg-white/2 border border-white/5 p-4 rounded-xl space-y-1.5" id="grid-tier-1">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">Tier 1 (Regional Cells)</span>
                    <span className="text-[9px] bg-orange-500/20 text-orange-400 px-1 rounded font-mono">512m Size</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Medium DEM meshes, river vectors, and secondary transit nodes.</p>
                  <div className="font-mono text-[10px] flex justify-between text-slate-300 pt-1 border-t border-white/5">
                    <span>Loaded Cells:</span>
                    <span className="text-white font-bold">{streamingMetrics.tier1Count} blocks</span>
                  </div>
                </div>

                {/* Tier 2 */}
                <div className="bg-white/2 border border-white/5 p-4 rounded-xl space-y-1.5" id="grid-tier-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">Tier 2 (Macro Cells)</span>
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1 rounded font-mono">4096m Size</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Global climate grids, wind maps, and biome matrix definitions.</p>
                  <div className="font-mono text-[10px] flex justify-between text-slate-300 pt-1 border-t border-white/5">
                    <span>Loaded Cells:</span>
                    <span className="text-white font-bold">{streamingMetrics.tier2Count} blocks</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Async Threads Load Workload Monitor */}
            <div className="space-y-3" id="async-threads-section">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Async Job Thread-Pool Allocator</span>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="thread-activities">
                {/* Game Thread */}
                <div className="bg-white/2 p-3 rounded-xl border border-white/5 space-y-1.5" id="thread-game">
                  <span className="text-[9px] font-mono text-slate-400 block uppercase">Game Thread (Main)</span>
                  <div className="h-1 bg-white/10 rounded overflow-hidden">
                    <div className="h-full bg-pink-500 rounded" style={{ width: `${streamingMetrics.threadLoads.gameThread}%` }} />
                  </div>
                  <span className="text-[10px] font-mono text-white font-semibold flex justify-between">
                    <span>Load:</span>
                    <span>{streamingMetrics.threadLoads.gameThread}%</span>
                  </span>
                </div>

                {/* GIS I/O Thread */}
                <div className="bg-white/2 p-3 rounded-xl border border-white/5 space-y-1.5" id="thread-io">
                  <span className="text-[9px] font-mono text-slate-400 block uppercase">GIS Async I/O</span>
                  <div className="h-1 bg-white/10 rounded overflow-hidden">
                    <div className="h-full bg-cyan-400 rounded" style={{ width: `${streamingMetrics.threadLoads.asyncIo}%` }} />
                  </div>
                  <span className="text-[10px] font-mono text-white font-semibold flex justify-between">
                    <span>Load:</span>
                    <span>{streamingMetrics.threadLoads.asyncIo}%</span>
                  </span>
                </div>

                {/* Climate Thread */}
                <div className="bg-white/2 p-3 rounded-xl border border-white/5 space-y-1.5" id="thread-climate">
                  <span className="text-[9px] font-mono text-slate-400 block uppercase">Climate Job Pool</span>
                  <div className="h-1 bg-white/10 rounded overflow-hidden">
                    <div className="h-full bg-orange-400 rounded" style={{ width: `${streamingMetrics.threadLoads.climatePool}%` }} />
                  </div>
                  <span className="text-[10px] font-mono text-white font-semibold flex justify-between">
                    <span>Load:</span>
                    <span>{streamingMetrics.threadLoads.climatePool}%</span>
                  </span>
                </div>

                {/* Hydrology Thread */}
                <div className="bg-white/2 p-3 rounded-xl border border-white/5 space-y-1.5" id="thread-hydro">
                  <span className="text-[9px] font-mono text-slate-400 block uppercase">Hydro Graph Worker</span>
                  <div className="h-1 bg-white/10 rounded overflow-hidden">
                    <div className="h-full bg-emerald-400 rounded" style={{ width: `${streamingMetrics.threadLoads.hydroWorker}%` }} />
                  </div>
                  <span className="text-[10px] font-mono text-white font-semibold flex justify-between">
                    <span>Load:</span>
                    <span>{streamingMetrics.threadLoads.hydroWorker}%</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
