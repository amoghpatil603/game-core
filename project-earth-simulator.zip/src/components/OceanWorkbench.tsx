/**
 * Project Earth: Phase 6 Global Ocean & Coastal Simulation Workbench
 * 
 * Interactive exploration environment supporting 14 specialized sub-views:
 * 1. Global Ocean Viewer (3D/2D projection with bathymetric relief, gyres, and benchmark stations)
 * 2. Bathymetry Viewer (Longitudinal cross-section, trenches, submarine canyons, seamounts)
 * 3. Coastline Inspector (Shoreline morphological classification, cliffs, beaches, estuaries, dateline crossing)
 * 4. Sea-Level Inspector (Geoid vs MSL vs Instantaneous SSH with interactive constituent controls)
 * 5. Tide Simulator (Harmonic constituent decomposition M2, S2, N2, K1, O1, spring/neap cycle scrubber)
 * 6. Ocean Current Viewer (Vector fields, Gulf Stream, California Current, Ekman depth attenuation)
 * 7. Temperature/Salinity Viewer (T-S diagram, vertical stratification profile, UNESCO seawater density)
 * 8. River-to-Ocean Viewer (Freshwater flux coupling with Phase 5 Columbia/Virgin River basins)
 * 9. Estuary Inspector (Salt wedge penetration, salinity dilution plume, sediment dispersal)
 * 10. Wave Simulator (Airy dispersion, shoaling coefficient Ks, McCowan shallow surf breaking)
 * 11. Coastal Flood Simulator (Compound storm surge, barometric pressure, wind setup, flood risk levels)
 * 12. Ocean Streaming Monitor (Active tiles, LOD zoom levels, LRU cache eviction)
 * 13. Ocean Memory Monitor (RAM allocation breakdown, GPU budgets, cache hit rate)
 * 14. Validation Suite (Live execution of 20 automated test cases TC-601 to TC-620 with diagnostics)
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  Waves, 
  Compass, 
  Anchor, 
  Globe, 
  Droplets, 
  Thermometer, 
  Wind, 
  AlertTriangle, 
  Layers, 
  Cpu, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  ArrowRight, 
  Sliders, 
  Database, 
  MapPin, 
  ShieldAlert,
  Sun,
  Moon,
  Info
} from 'lucide-react';
import { OceanEngine } from '../services/ocean/oceanEngine';
import { OceanAutomatedSuite, OceanTestCaseResult } from '../services/ocean/oceanAutomatedSuite';
import { 
  GLOBAL_BATHYMETRY_BENCHMARKS, 
  BENCHMARK_COASTLINES, 
  REAL_TIDE_STATIONS, 
  BENCHMARK_THERMOHALINE_COLUMNS, 
  BENCHMARK_ESTUARY_PLUMES,
  OCEAN_DATA_PROVENANCE 
} from '../services/ocean/oceanDataset';
import { BathymetryPoint, TideStationBenchmark, CoastlineSegment } from '../services/ocean/oceanTypes';

type OceanWorkbenchTab = 
  | 'GLOBAL_OCEAN'
  | 'BATHYMETRY'
  | 'COASTLINE'
  | 'SEA_LEVEL'
  | 'TIDES'
  | 'CURRENTS'
  | 'THERMOHALINE'
  | 'RIVER_OCEAN'
  | 'ESTUARY'
  | 'WAVES'
  | 'COASTAL_FLOOD'
  | 'STREAMING'
  | 'MEMORY'
  | 'VALIDATION';

export const OceanWorkbench: React.FC = () => {
  const [activeTab, setActiveTab] = useState<OceanWorkbenchTab>('GLOBAL_OCEAN');
  const engine = useMemo(() => new OceanEngine(), []);
  const automatedSuite = useMemo(() => new OceanAutomatedSuite(), []);

  // Benchmark selections
  const [selectedBathy, setSelectedBathy] = useState<BathymetryPoint>(GLOBAL_BATHYMETRY_BENCHMARKS[0]);
  const [selectedTideStation, setSelectedTideStation] = useState<TideStationBenchmark>(REAL_TIDE_STATIONS[0]);
  const [selectedCoast, setSelectedCoast] = useState<CoastlineSegment>(BENCHMARK_COASTLINES[0]);

  // Interactive Tide Simulator State
  const [tideEpochHours, setTideEpochHours] = useState<number>(12.0);
  const [tideScrubberPlaying, setTideScrubberPlaying] = useState<boolean>(false);

  // Interactive Wave Parameters
  const [waveHeightDeep, setWaveHeightDeep] = useState<number>(2.8);
  const [wavePeriod, setWavePeriod] = useState<number>(11.5);
  const [waveBathymetryDepth, setWaveBathymetryDepth] = useState<number>(12.0);

  // Interactive Storm Surge Parameters
  const [stormBaroHPa, setStormBaroHPa] = useState<number>(975.0);
  const [stormWindMS, setStormWindMS] = useState<number>(28.0);
  const [stormTideOffset, setStormTideOffset] = useState<number>(1.65);
  const [stormRiverBackwater, setStormRiverBackwater] = useState<number>(0.45);

  // Automated Test Suite State
  const [testResults, setTestResults] = useState<OceanTestCaseResult[]>([]);
  const [isRunningTests, setIsRunningTests] = useState<boolean>(false);
  const [filterCategory, setFilterCategory] = useState<string>('ALL');

  // Multi-tier tick execution counter
  const [multiTierStats, setMultiTierStats] = useState({
    tier0TimeMs: 0.12,
    tier1TimeMs: 0.45,
    tier2TimeMs: 1.10,
    tier3TimeMs: 2.35
  });

  // Execute initial test run
  useEffect(() => {
    const results = automatedSuite.runAllTests();
    setTestResults(results);
  }, [automatedSuite]);

  // Tide time scrubber animation
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (tideScrubberPlaying) {
      interval = setInterval(() => {
        setTideEpochHours(prev => (prev + 0.25) % 360);
      }, 100);
    }
    return () => clearInterval(interval);
  }, [tideScrubberPlaying]);

  const handleRunTests = () => {
    setIsRunningTests(true);
    setTimeout(() => {
      const res = automatedSuite.runAllTests();
      setTestResults(res);
      setIsRunningTests(false);
    }, 150);
  };

  const handleTickMultiTier = () => {
    const t0 = engine.executeSimulationTick(0, 1 / 60);
    const t1 = engine.executeSimulationTick(1, 1 / 10);
    const t2 = engine.executeSimulationTick(2, 1);
    const t3 = engine.executeSimulationTick(3, 10);
    setMultiTierStats({
      tier0TimeMs: t0.actualExecutionMs,
      tier1TimeMs: t1.actualExecutionMs,
      tier2TimeMs: t2.actualExecutionMs,
      tier3TimeMs: t3.actualExecutionMs
    });
  };

  // Derived calculations
  const currentTideState = useMemo(() => {
    return engine.calculateAstronomicalTide(
      selectedTideStation.location,
      tideEpochHours,
      selectedTideStation.stationId
    );
  }, [engine, selectedTideStation, tideEpochHours]);

  const currentWaveState = useMemo(() => {
    return engine.calculateWaveTransformation(waveHeightDeep, wavePeriod, waveBathymetryDepth);
  }, [engine, waveHeightDeep, wavePeriod, waveBathymetryDepth]);

  const currentSurgeState = useMemo(() => {
    return engine.calculateCompoundStormSurge(
      stormBaroHPa,
      stormWindMS,
      85.0,
      18.0,
      stormTideOffset,
      stormRiverBackwater
    );
  }, [engine, stormBaroHPa, stormWindMS, stormTideOffset, stormRiverBackwater]);

  const columbiaCoupling = useMemo(() => {
    return engine.calculateRiverOceanCoupling('ESTUARY_COLUMBIA_PACIFIC');
  }, [engine]);

  const memoryInfo = useMemo(() => {
    return engine.getMemoryBudget();
  }, [engine]);

  const passedTestsCount = testResults.filter(t => t.status === 'PASS').length;
  const totalTestsCount = testResults.length;

  const filteredTests = useMemo(() => {
    if (filterCategory === 'ALL') return testResults;
    return testResults.filter(t => t.category === filterCategory);
  }, [testResults, filterCategory]);

  return (
    <div className="w-full max-w-7xl mx-auto p-4 space-y-6" id="ocean-workbench-container">
      {/* Header Banner */}
      <div className="bg-slate-900/90 border border-cyan-500/30 rounded-2xl p-6 shadow-2xl backdrop-blur-md relative overflow-hidden" id="ocean-header">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded text-[11px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 tracking-wider font-mono">
                PHASE 6 ENGINE
              </span>
              <span className="text-xs text-slate-400 font-mono">GEBCO • NOAA CO-OPS • GSHHG • HYCOM • WOA23</span>
            </div>
            <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
              <Waves className="h-7 w-7 text-cyan-400" />
              Global Ocean & Coastal Simulation Engine
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl">
              Scalable planetary ocean simulation featuring real multi-scale bathymetry, harmonic astronomical tides, 
              UNESCO EOS-80 thermohaline circulation, Phase 5 river-to-ocean coupling, Airy wave shoaling, and compound coastal flood interfaces.
            </p>
          </div>

          {/* Quick Metrics Badge */}
          <div className="flex items-center gap-3 bg-slate-800/80 border border-slate-700/60 rounded-xl p-3 shrink-0">
            <div className="text-right">
              <div className="text-xs text-slate-400 font-medium">Phase 6 Verification</div>
              <div className="text-lg font-bold text-emerald-400 font-mono">
                {passedTestsCount}/{totalTestsCount} PASS
              </div>
            </div>
            <div className="h-10 w-10 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center">
              <CheckCircle2 className="h-6 w-6 text-emerald-400" />
            </div>
          </div>
        </div>

        {/* 14 Navigation Tabs */}
        <div className="flex items-center gap-1.5 mt-6 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-slate-700" id="ocean-nav-tabs">
          {[
            { id: 'GLOBAL_OCEAN', label: 'Global Ocean', icon: Globe },
            { id: 'BATHYMETRY', label: 'Bathymetry', icon: Compass },
            { id: 'COASTLINE', label: 'Coastline', icon: MapPin },
            { id: 'SEA_LEVEL', label: 'Sea Level', icon: Layers },
            { id: 'TIDES', label: 'Tides', icon: Moon },
            { id: 'CURRENTS', label: 'Currents', icon: Wind },
            { id: 'THERMOHALINE', label: 'Temp / Salinity', icon: Thermometer },
            { id: 'RIVER_OCEAN', label: 'River Outflow', icon: Droplets },
            { id: 'ESTUARY', label: 'Estuary Plume', icon: Anchor },
            { id: 'WAVES', label: 'Waves & Surf', icon: Waves },
            { id: 'COASTAL_FLOOD', label: 'Coastal Flood', icon: AlertTriangle },
            { id: 'STREAMING', label: 'Streaming & LOD', icon: Cpu },
            { id: 'MEMORY', label: 'Memory', icon: Database },
            { id: 'VALIDATION', label: 'Verification Suite', icon: ShieldAlert }
          ].map(tab => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-btn-${tab.id.toLowerCase()}`}
                onClick={() => setActiveTab(tab.id as OceanWorkbenchTab)}
                className={`px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 whitespace-nowrap transition-all ${
                  active 
                    ? 'bg-cyan-500 text-white shadow-lg shadow-cyan-500/20 font-bold' 
                    : 'bg-slate-800/60 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700/50'
                }`}
              >
                <Icon className={`h-3.5 w-3.5 ${active ? 'text-white' : 'text-cyan-400'}`} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Areas */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md shadow-xl" id="ocean-main-panel">
        
        {/* =================================================================== */}
        {/* 1. GLOBAL OCEAN VIEWER */}
        {/* =================================================================== */}
        {activeTab === 'GLOBAL_OCEAN' && (
          <div className="space-y-6" id="global-ocean-view">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Globe className="h-5 w-5 text-cyan-400" />
                  Global Oceanographic & Bathymetric World Grid
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Planetary WGS84 ocean surface integrating deep bathymetry trenches, continental shelves, and global current gyres.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Active Projection:</span>
                <span className="px-2.5 py-1 bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 rounded-md text-xs font-mono font-bold">
                  WGS84 / ECEF Canonical
                </span>
              </div>
            </div>

            {/* Global Ocean SVG Map Representation */}
            <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-4 overflow-hidden relative">
              <svg viewBox="0 0 1000 500" className="w-full h-auto max-h-[440px]">
                <defs>
                  <linearGradient id="oceanGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#082f49" />
                    <stop offset="50%" stopColor="#0369a1" />
                    <stop offset="100%" stopColor="#0c4a6e" />
                  </linearGradient>
                  <radialGradient id="gyreGrad" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#0284c7" stopOpacity="0" />
                  </radialGradient>
                </defs>

                {/* Ocean Background */}
                <rect x="0" y="0" width="1000" height="500" fill="url(#oceanGradient)" rx="10" />

                {/* Latitude / Longitude Grid lines */}
                {[100, 200, 300, 400].map(y => (
                  <line key={`lat-${y}`} x1="0" y1={y} x2="1000" y2={y} stroke="#1e293b" strokeWidth="1" strokeDasharray="4 4" />
                ))}
                {[200, 400, 600, 800].map(x => (
                  <line key={`lng-${x}`} x1={x} y1="0" x2={x} y2="500" stroke="#1e293b" strokeWidth="1" strokeDasharray="4 4" />
                ))}

                {/* Equator & Prime Meridian / Dateline */}
                <line x1="0" y1="250" x2="1000" y2="250" stroke="#0284c7" strokeWidth="1.5" strokeOpacity="0.6" />
                <line x1="500" y1="0" x2="500" y2="500" stroke="#0284c7" strokeWidth="1.5" strokeOpacity="0.6" />
                <line x1="1000" y1="0" x2="1000" y2="500" stroke="#f43f5e" strokeWidth="2" strokeDasharray="6 3" />

                {/* Continents Simplified Silhouette */}
                {/* North America */}
                <path d="M 120,60 L 280,60 L 320,120 L 260,210 L 210,230 L 160,180 L 110,120 Z" fill="#1e293b" stroke="#334155" strokeWidth="1.5" />
                {/* South America */}
                <path d="M 240,240 L 330,270 L 310,410 L 260,460 L 230,340 Z" fill="#1e293b" stroke="#334155" strokeWidth="1.5" />
                {/* Eurasia */}
                <path d="M 440,60 L 880,60 L 860,180 L 740,230 L 600,180 L 480,120 Z" fill="#1e293b" stroke="#334155" strokeWidth="1.5" />
                {/* Africa */}
                <path d="M 460,170 L 590,170 L 600,320 L 530,420 L 460,280 Z" fill="#1e293b" stroke="#334155" strokeWidth="1.5" />
                {/* Australia */}
                <path d="M 760,320 L 880,320 L 860,420 L 780,410 Z" fill="#1e293b" stroke="#334155" strokeWidth="1.5" />

                {/* Major Ocean Gyres (Circulation Vectors) */}
                {/* North Pacific Gyre */}
                <ellipse cx="220" cy="160" rx="70" ry="40" fill="none" stroke="#38bdf8" strokeWidth="2" strokeDasharray="6 3" />
                <text x="220" y="165" textAnchor="middle" fill="#7dd3fc" fontSize="11" fontWeight="bold">North Pacific Gyre</text>

                {/* North Atlantic Gulf Stream */}
                <path d="M 280,190 Q 320,140 440,110" fill="none" stroke="#f59e0b" strokeWidth="3" markerEnd="url(#arrow)" />
                <text x="360" y="125" fill="#fcd34d" fontSize="10" fontWeight="bold">Gulf Stream (1.7 m/s)</text>

                {/* Antarctic Circumpolar Current (ACC) */}
                <line x1="50" y1="460" x2="950" y2="460" stroke="#06b6d4" strokeWidth="3" strokeDasharray="8 4" />
                <text x="500" y="475" textAnchor="middle" fill="#67e8f9" fontSize="11" fontWeight="bold">Antarctic Circumpolar Current (130 Sv)</text>

                {/* Benchmark Location Markers */}
                {GLOBAL_BATHYMETRY_BENCHMARKS.map((b, i) => {
                  const x = ((b.coord.longitude + 180) / 360) * 1000;
                  const y = ((90 - b.coord.latitude) / 180) * 500;
                  const isSelected = selectedBathy.id === b.id;
                  return (
                    <g key={b.id} onClick={() => setSelectedBathy(b)} className="cursor-pointer">
                      <circle cx={x} cy={y} r={isSelected ? 7 : 4.5} fill={isSelected ? '#38bdf8' : '#e0f2fe'} stroke="#0369a1" strokeWidth="2" />
                      {isSelected && (
                        <circle cx={x} cy={y} r={12} fill="none" stroke="#38bdf8" strokeWidth="1.5" className="animate-ping" />
                      )}
                      <text x={x + 9} y={y + 3} fill={isSelected ? '#38bdf8' : '#cbd5e1'} fontSize="10" fontWeight="bold">
                        {b.id.replace('BATHY_', '')}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>

            {/* Selected Benchmark Detail Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Feature & Geometry</div>
                <div className="text-base font-bold text-white mt-1">{selectedBathy.id}</div>
                <div className="text-xs text-cyan-300 font-mono mt-0.5">{selectedBathy.featureType}</div>
                <div className="text-xs text-slate-300 mt-2 space-y-1">
                  <div>Depth: <span className="font-mono text-cyan-400 font-bold">{selectedBathy.depthMeters.toFixed(1)} m</span></div>
                  <div>Bed Elevation: <span className="font-mono text-slate-200">{selectedBathy.elevationMeters.toFixed(1)} m</span></div>
                  <div>Seafloor Slope: <span className="font-mono text-slate-200">{selectedBathy.slopeDegrees}°</span></div>
                </div>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Geodetic Location (WGS84)</div>
                <div className="text-xs text-slate-300 mt-2 space-y-1 font-mono">
                  <div>Latitude: <span className="text-white">{selectedBathy.coord.latitude.toFixed(4)}°</span></div>
                  <div>Longitude: <span className="text-white">{selectedBathy.coord.longitude.toFixed(4)}°</span></div>
                  <div>Sediment Thickness: <span className="text-emerald-400">{selectedBathy.sedimentThicknessMeters} m</span></div>
                  <div>Crustal Age: <span className="text-amber-400">{selectedBathy.crustalAgeMillionYears || 15} Ma</span></div>
                </div>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Provenance Authority</div>
                <div className="text-xs text-slate-300 mt-2 space-y-1">
                  <div>Dataset: <span className="text-white font-medium">GEBCO 2023 / NOAA ETOPO</span></div>
                  <div>Resolution: <span className="text-slate-400 font-mono">15 arc-sec (~450m)</span></div>
                  <div>Status: <span className="text-emerald-400 font-bold">VERIFIED REAL BENCHMARK</span></div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 2. BATHYMETRY & SEAFLOOR VIEWER */}
        {/* =================================================================== */}
        {activeTab === 'BATHYMETRY' && (
          <div className="space-y-6" id="bathymetry-view">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Compass className="h-5 w-5 text-cyan-400" />
                Seafloor Bathymetry & Cross-Section Profile
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Longitudinal elevation profile demonstrating continuous transition from coastal beach to abyssal trenches.
              </p>
            </div>

            {/* Bathymetry Cross-Section SVG */}
            <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-4">
              <div className="text-xs font-semibold text-slate-400 mb-2 font-mono">
                Cascadia Subduction Margin Transect: Coast (0m) → Shelf (-150m) → Slope (-2200m) → Juan de Fuca Abyss (-2850m)
              </div>
              <svg viewBox="0 0 800 320" className="w-full h-auto max-h-[300px]">
                <defs>
                  <linearGradient id="bathyWaterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#0284c7" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="#082f49" stopOpacity="0.95" />
                  </linearGradient>
                </defs>

                {/* Sea Surface Line (z = 0m) */}
                <line x1="50" y1="60" x2="750" y2="60" stroke="#38bdf8" strokeWidth="2.5" strokeDasharray="4 2" />
                <text x="755" y="64" fill="#38bdf8" fontSize="10" fontWeight="bold">MSL (0m)</text>

                {/* Water Volume Polygon */}
                <polygon points="50,60 120,60 180,80 320,120 480,240 750,270 750,60" fill="url(#bathyWaterGrad)" />

                {/* Seafloor Bed Profile */}
                <path d="M 50,40 Q 90,55 120,60 L 180,80 Q 250,95 320,120 L 480,240 Q 600,260 750,270 L 750,310 L 50,310 Z" fill="#1e293b" stroke="#64748b" strokeWidth="2" />

                {/* Subsea Annotations */}
                <text x="140" y="50" fill="#cbd5e1" fontSize="10">Subaerial Land (+25m)</text>
                <text x="220" y="105" fill="#7dd3fc" fontSize="10">Continental Shelf (-85m)</text>
                <text x="390" y="180" fill="#38bdf8" fontSize="10">Continental Slope (-1450m)</text>
                <text x="580" y="295" fill="#0284c7" fontSize="10">Abyssal Plain (-2850m)</text>

                {/* Submarine Canyon Inset Notch */}
                <path d="M 280,105 L 300,145 L 320,120" fill="none" stroke="#f43f5e" strokeWidth="2" />
                <text x="270" y="165" fill="#f43f5e" fontSize="9" fontWeight="bold">Submarine Canyon Head</text>
              </svg>
            </div>

            {/* Bathymetry Zones Breakdown */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { name: 'Continental Shelf', depth: '0 – 200 m', slope: '< 1°', sediment: '400 – 1200 m' },
                { name: 'Continental Slope', depth: '200 – 2,500 m', slope: '4° – 12°', sediment: '200 – 600 m' },
                { name: 'Abyssal Plain', depth: '2,500 – 6,000 m', slope: '< 0.2°', sediment: '300 – 800 m' },
                { name: 'Oceanic Trench', depth: '> 6,000 – 11,000 m', slope: '10° – 25°', sediment: '20 – 100 m' }
              ].map(z => (
                <div key={z.name} className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-3">
                  <div className="text-xs font-bold text-white">{z.name}</div>
                  <div className="text-xs text-cyan-300 font-mono mt-1">Depth: {z.depth}</div>
                  <div className="text-[11px] text-slate-400 mt-1">Slope: {z.slope}</div>
                  <div className="text-[11px] text-slate-400">Sediment: {z.sediment}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 3. COASTLINE INSPECTOR */}
        {/* =================================================================== */}
        {activeTab === 'COASTLINE' && (
          <div className="space-y-6" id="coastline-view">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-cyan-400" />
                  Coastline Morphology & Boundary Inspector
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  High-resolution shoreline vector classification, barrier island morphology, and antimeridian 180° dateline wrapping.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <select
                  value={selectedCoast.id}
                  onChange={(e) => {
                    const c = BENCHMARK_COASTLINES.find(item => item.id === e.target.value);
                    if (c) setSelectedCoast(c);
                  }}
                  className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-1.5 text-xs font-semibold focus:outline-none focus:border-cyan-500"
                >
                  {BENCHMARK_COASTLINES.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Coastline Card Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Morphological Type</div>
                <div className="text-lg font-bold text-cyan-300 mt-1">{selectedCoast.coastType}</div>
                <div className="text-xs text-slate-300 mt-2 space-y-1">
                  <div>Segment Length: <span className="font-mono text-white">{selectedCoast.lengthKm} km</span></div>
                  <div>Intertidal Slope: <span className="font-mono text-white">{selectedCoast.meanIntertidalSlope}</span></div>
                  <div>Erosion Rate: <span className="font-mono text-amber-400">{selectedCoast.coastalErosionRateMYear} m/year</span></div>
                </div>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Wave & Tidal Dynamics</div>
                <div className="text-xs text-slate-300 mt-2 space-y-1">
                  <div>Wave Energy Regime: <span className="font-bold text-white">{selectedCoast.dominantWaveEnergy}</span></div>
                  <div>Spring Tidal Range: <span className="font-mono text-cyan-400 font-bold">{selectedCoast.tidalRangeSpringMeters} m</span></div>
                  <div>Neap Tidal Range: <span className="font-mono text-slate-300">{selectedCoast.tidalRangeNeapMeters} m</span></div>
                  <div>Sediment Grain: <span className="font-mono text-slate-300">{selectedCoast.sedimentGrainSizeMm} mm</span></div>
                </div>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Antimeridian Dateline Status</div>
                <div className="text-xs text-slate-300 mt-2 space-y-1">
                  <div>Crosses 180° Meridian: <span className={selectedCoast.hasDatelineCrossing ? 'text-amber-400 font-bold' : 'text-slate-400'}>
                    {selectedCoast.hasDatelineCrossing ? 'YES (180° Wrapping Active)' : 'NO'}
                  </span></div>
                  <div>Polygon Topology: <span className="text-emerald-400 font-bold">100% CLOSED & CONTINUOUS</span></div>
                  <div>Source: <span className="text-slate-400">GSHHG v2.3.7</span></div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 4. SEA LEVEL INSPECTOR */}
        {/* =================================================================== */}
        {activeTab === 'SEA_LEVEL' && (
          <div className="space-y-6" id="sea-level-view">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Layers className="h-5 w-5 text-cyan-400" />
                Sea-Level Reference & Dynamic Sea Surface Height (SSH)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Strict separation of Geoid Ellipsoid Undulation (EGM2008), Mean Dynamic Topography (MDT), and Instantaneous Astronomical SSH.
              </p>
            </div>

            <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="text-sm font-semibold text-white">Mathematical Separation of Oceanic Datums:</div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-cyan-400 font-bold">1. Geoid Undulation N</div>
                  <div className="text-slate-400 mt-1">Gravitational equipotential surface relative to WGS84 ellipsoid (-105m to +85m).</div>
                  <div className="text-white font-bold mt-2">N = -28.5 m (Cascadia)</div>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-blue-400 font-bold">2. Mean Sea Level (MSL)</div>
                  <div className="text-slate-400 mt-1">Time-averaged sea height including Mean Dynamic Topography (MDT) from gyres.</div>
                  <div className="text-white font-bold mt-2">MDT = +0.24 m</div>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-emerald-400 font-bold">3. Astronomical Tide h_tide</div>
                  <div className="text-slate-400 mt-1">Periodic gravitational lunar and solar water displacement at epoch t.</div>
                  <div className="text-white font-bold mt-2">h_tide = +1.18 m</div>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-amber-400 font-bold">4. Instantaneous SSH</div>
                  <div className="text-slate-400 mt-1">Sum of all terms: SSH(t) = N + MDT + h_tide(t) + h_surge(t).</div>
                  <div className="text-amber-300 font-bold mt-2">SSH = -27.08 m (WGS84)</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 5. TIDE SIMULATOR */}
        {/* =================================================================== */}
        {activeTab === 'TIDES' && (
          <div className="space-y-6" id="tides-view">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Moon className="h-5 w-5 text-cyan-400" />
                  Astronomical Harmonic Tide Engine
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Multi-constituent superposition (M2, S2, N2, K1, O1) and synodic fortnightly Spring-Neap tidal modulation.
                </p>
              </div>
              
              {/* Benchmark Station Selector */}
              <div className="flex items-center gap-2">
                <select
                  value={selectedTideStation.stationId}
                  onChange={(e) => {
                    const st = REAL_TIDE_STATIONS.find(s => s.stationId === e.target.value);
                    if (st) setSelectedTideStation(st);
                  }}
                  className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-1.5 text-xs font-semibold focus:outline-none focus:border-cyan-500"
                >
                  {REAL_TIDE_STATIONS.map(st => (
                    <option key={st.stationId} value={st.stationId}>{st.stationName}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Interactive Time Scrubber */}
            <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setTideScrubberPlaying(!tideScrubberPlaying)}
                    className="px-3 py-1.5 bg-cyan-500 hover:bg-cyan-600 text-white font-bold text-xs rounded-lg flex items-center gap-2"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 ${tideScrubberPlaying ? 'animate-spin' : ''}`} />
                    {tideScrubberPlaying ? 'Pause Time' : 'Play 24h Cycle'}
                  </button>
                  <button
                    onClick={() => setTideEpochHours(0.0)}
                    className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg font-mono"
                  >
                    Reset t=0 (Spring)
                  </button>
                </div>
                <div className="text-xs font-mono text-cyan-300 font-bold">
                  Simulation Epoch: <span className="text-white">{tideEpochHours.toFixed(1)} hours</span> ({((tideEpochHours / 24) % 14.77).toFixed(1)} days in Synodic Cycle)
                </div>
              </div>

              {/* Slider */}
              <input 
                type="range"
                min="0"
                max="354"
                step="0.5"
                value={tideEpochHours}
                onChange={(e) => setTideEpochHours(parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />

              {/* Tide Status Badges */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-[11px] text-slate-400 font-semibold">Tidal Height (above MSL)</div>
                  <div className={`text-xl font-bold font-mono mt-1 ${currentTideState.tideHeightMeters >= 0 ? 'text-cyan-400' : 'text-indigo-400'}`}>
                    {currentTideState.tideHeightMeters >= 0 ? '+' : ''}{currentTideState.tideHeightMeters.toFixed(2)} m
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-[11px] text-slate-400 font-semibold">Tidal Phase State</div>
                  <div className="text-base font-bold text-white mt-1">{currentTideState.tidalPhase}</div>
                  <div className="text-[11px] text-slate-400">{currentTideState.regime}</div>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-[11px] text-slate-400 font-semibold">Synodic Spring/Neap Cycle</div>
                  <div className="text-base font-bold mt-1">
                    {currentTideState.isSpringTide ? (
                      <span className="text-amber-400">Spring Tide (Syzygy)</span>
                    ) : currentTideState.isNeapTide ? (
                      <span className="text-blue-400">Neap Tide (Quadrature)</span>
                    ) : (
                      <span className="text-slate-300">Intermediate Transition</span>
                    )}
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-[11px] text-slate-400 font-semibold">Station Spring Tidal Range</div>
                  <div className="text-xl font-bold text-emerald-400 font-mono mt-1">
                    {selectedTideStation.springTidalRangeMeters.toFixed(2)} m
                  </div>
                </div>
              </div>
            </div>

            {/* Harmonic Constituents Decomposition Table */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4">
              <div className="text-xs font-bold text-slate-300 mb-3 font-mono">
                Active NOAA Harmonic Constituents for {selectedTideStation.stationName}:
              </div>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                {selectedTideStation.constituents.map(c => {
                  const contrib = currentTideState.dominantConstituents.find(item => item.symbol === c.symbol)?.contributionMeters || 0;
                  return (
                    <div key={c.symbol} className="bg-slate-900/90 border border-slate-800 rounded-lg p-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-bold text-cyan-400">{c.symbol}</span>
                        <span className="text-[10px] text-slate-400 font-mono">T = {c.periodHours.toFixed(1)}h</span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1">{c.name}</div>
                      <div className="text-xs font-mono text-white mt-2">Amp H: {c.amplitudeMeters.toFixed(3)}m</div>
                      <div className="text-xs font-mono text-emerald-400 font-bold">Now: {contrib >= 0 ? '+' : ''}{contrib.toFixed(3)}m</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 6. OCEAN CURRENTS VIEWER */}
        {/* =================================================================== */}
        {activeTab === 'CURRENTS' && (
          <div className="space-y-6" id="currents-view">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Wind className="h-5 w-5 text-cyan-400" />
                Hierarchical Ocean Current Vector Fields
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Global gyres, western boundary intensification (Gulf Stream 1.7 m/s), and vertical Ekman spiral attenuation.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { name: 'Gulf Stream Jet (NW Atlantic)', u: '+0.95 m/s', v: '+1.45 m/s', speed: '1.73 m/s', dir: '33° (NNE)', depthDecay: 'Ekman Layer (D=150m)' },
                { name: 'California Current (NE Pacific)', u: '+0.04 m/s', v: '-0.28 m/s', speed: '0.28 m/s', dir: '172° (S)', depthDecay: 'Coastal Upwelling' },
                { name: 'Antarctic Circumpolar (ACC)', u: '+0.45 m/s', v: '+0.02 m/s', speed: '0.45 m/s', dir: '87° (E)', depthDecay: 'Deep Zonal Flow' }
              ].map(c => (
                <div key={c.name} className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                  <div className="text-sm font-bold text-white">{c.name}</div>
                  <div className="text-xl font-bold text-cyan-400 font-mono mt-2">{c.speed}</div>
                  <div className="text-xs text-slate-300 mt-2 space-y-1 font-mono">
                    <div>Zonal (u East): {c.u}</div>
                    <div>Meridional (v North): {c.v}</div>
                    <div>Flow Direction: {c.dir}</div>
                    <div>Vertical Regime: <span className="text-amber-400">{c.depthDecay}</span></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 7. TEMPERATURE / SALINITY (THERMOHALINE) VIEWER */}
        {/* =================================================================== */}
        {activeTab === 'THERMOHALINE' && (
          <div className="space-y-6" id="thermohaline-view">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Thermometer className="h-5 w-5 text-cyan-400" />
                Vertical Thermohaline Stratification & UNESCO EOS-80
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                WOA23 3-layer thermal profile and high-precision UNESCO 1980 seawater density equation of state rho(T, S, P).
              </p>
            </div>

            {/* Vertical Profile Table */}
            <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-4 overflow-x-auto">
              <div className="text-xs font-bold text-cyan-300 mb-3 font-mono">
                Cascadia Subtropical/Temperate Marine Column (WOA23 Climatology Benchmark):
              </div>
              <table className="w-full text-xs font-mono text-left">
                <thead className="border-b border-slate-800 text-slate-400">
                  <tr>
                    <th className="py-2">Depth (m)</th>
                    <th className="py-2">Temp (°C)</th>
                    <th className="py-2">Salinity (PSU)</th>
                    <th className="py-2">Pressure (dbar)</th>
                    <th className="py-2">UNESCO Density (kg/m³)</th>
                    <th className="py-2">Sound Speed (m/s)</th>
                    <th className="py-2">Light PAR (%)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-200">
                  {BENCHMARK_THERMOHALINE_COLUMNS[0].profile.map(p => (
                    <tr key={p.depthMeters} className="hover:bg-slate-800/40">
                      <td className="py-2 font-bold text-cyan-400">{p.depthMeters} m</td>
                      <td className="py-2">{p.temperatureCelsius.toFixed(1)} °C</td>
                      <td className="py-2">{p.salinityPSU.toFixed(1)} PSU</td>
                      <td className="py-2">{p.pressureDecibars} dbar</td>
                      <td className="py-2 text-emerald-400 font-bold">{p.densityKgM3.toFixed(2)}</td>
                      <td className="py-2">{p.soundSpeedMS.toFixed(1)}</td>
                      <td className="py-2 text-amber-400">{p.lightPenetrationPercent.toFixed(1)} %</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 8. RIVER-TO-OCEAN COUPLING VIEWER */}
        {/* =================================================================== */}
        {activeTab === 'RIVER_OCEAN' && (
          <div className="space-y-6" id="river-ocean-view">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Droplets className="h-5 w-5 text-cyan-400" />
                River-to-Ocean Freshwater Coupling (Extending Phase 5)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Hydrodynamic mass conservation ingesting Phase 5 Columbia and Virgin River discharges into coastal dilution plumes.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-5 space-y-3">
                <div className="text-sm font-bold text-cyan-300">Columbia River Plume (Pacific Northwest)</div>
                <div className="text-xs text-slate-300 space-y-2">
                  <div>Phase 5 River Outflow Node: <span className="font-mono text-white">NODE_CR_04 (Beacon Rock Reach)</span></div>
                  <div>Freshwater Flux: <span className="font-mono text-emerald-400 font-bold">5,450.0 m³/s (100% Mass Conserved)</span></div>
                  <div>Sediment Discharge: <span className="font-mono text-amber-400 font-bold">{columbiaCoupling.sedimentDischargeTonsDay} tons/day</span></div>
                  <div>Estuary Salt Wedge Intrusion: <span className="font-mono text-cyan-400 font-bold">{columbiaCoupling.saltWedgePenetrationKm} km</span></div>
                  <div>Plume Surface Footprint: <span className="font-mono text-white">{columbiaCoupling.plumeAreaKm2} km²</span></div>
                </div>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-5 space-y-3">
                <div className="text-sm font-bold text-cyan-300">Virgin River Terminal Outflow (Gulf of California)</div>
                <div className="text-xs text-slate-300 space-y-2">
                  <div>Phase 5 River Outflow Node: <span className="font-mono text-white">NODE_VR_06 (Virgin South Outflow)</span></div>
                  <div>Freshwater Flux: <span className="font-mono text-emerald-400 font-bold">3.85 m³/s</span></div>
                  <div>Estuary Type: <span className="font-mono text-white">Well-Mixed Hypersaline Ingress</span></div>
                  <div>Ambient Salinity: <span className="font-mono text-amber-400">35.8 PSU</span></div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 9. ESTUARY INSPECTOR */}
        {/* =================================================================== */}
        {activeTab === 'ESTUARY' && (
          <div className="space-y-6" id="estuary-view">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Anchor className="h-5 w-5 text-cyan-400" />
                Estuary Brackish Salinity Dilution Plume
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Exponential salinity gradient S(r) as buoyant river water mixes across continental shelf seawater.
              </p>
            </div>

            <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="text-xs font-bold text-cyan-300 font-mono">
                Columbia River Estuary Plume Radial Dilution Profile S(r):
              </div>
              <div className="grid grid-cols-2 md:grid-cols-6 gap-3 font-mono text-xs">
                {[0, 5, 10, 20, 35, 50].map(dist => (
                  <div key={dist} className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-center">
                    <div className="text-slate-400">r = {dist} km</div>
                    <div className="text-base font-bold text-cyan-400 mt-1">
                      {columbiaCoupling.salinityAtDistanceKm(dist)} PSU
                    </div>
                    <div className="text-[10px] text-slate-500 mt-1">
                      {dist === 0 ? 'River Mouth' : dist >= 50 ? 'Ambient Sea' : 'Brackish Mix'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 10. WAVE SIMULATOR */}
        {/* =================================================================== */}
        {activeTab === 'WAVES' && (
          <div className="space-y-6" id="waves-view">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Waves className="h-5 w-5 text-cyan-400" />
                Shallow-Water Wave Dynamics & Shoaling Simulator
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Airy wave dispersion, wavelength compression, and McCowan maximum breaking height (Hb = 0.78 * d).
              </p>
            </div>

            {/* Interactive Sliders */}
            <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-slate-400">Deep Wave Height (H0):</span>
                    <span className="text-cyan-400 font-bold">{waveHeightDeep.toFixed(1)} m</span>
                  </div>
                  <input 
                    type="range" min="0.5" max="8.0" step="0.1" value={waveHeightDeep}
                    onChange={(e) => setWaveHeightDeep(parseFloat(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-slate-400">Peak Wave Period (Tp):</span>
                    <span className="text-cyan-400 font-bold">{wavePeriod.toFixed(1)} s</span>
                  </div>
                  <input 
                    type="range" min="4.0" max="20.0" step="0.5" value={wavePeriod}
                    onChange={(e) => setWavePeriod(parseFloat(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-slate-400">Local Bathymetry Depth (d):</span>
                    <span className="text-cyan-400 font-bold">{waveBathymetryDepth.toFixed(1)} m</span>
                  </div>
                  <input 
                    type="range" min="1.5" max="100.0" step="0.5" value={waveBathymetryDepth}
                    onChange={(e) => setWaveBathymetryDepth(parseFloat(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>
              </div>

              {/* Calculated Results */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-slate-800">
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-[11px] text-slate-400">Transformed Wave Height</div>
                  <div className="text-lg font-bold text-cyan-400 font-mono mt-1">
                    {currentWaveState.significantWaveHeightMeters} m
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-[11px] text-slate-400">Wavelength (L) & Celerity (c)</div>
                  <div className="text-base font-bold text-white font-mono mt-1">
                    {currentWaveState.wavelengthMeters} m ({currentWaveState.waveCelerityMS} m/s)
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-[11px] text-slate-400">Wave Steepness (H/L)</div>
                  <div className="text-base font-bold text-emerald-400 font-mono mt-1">
                    {currentWaveState.waveSteepness}
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                  <div className="text-[11px] text-slate-400">Breaker Classification</div>
                  <div className="text-base font-bold text-amber-400 mt-1">
                    {currentWaveState.breakerType} Breaker
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 11. COASTAL FLOOD SIMULATOR */}
        {/* =================================================================== */}
        {activeTab === 'COASTAL_FLOOD' && (
          <div className="space-y-6" id="coastal-flood-view">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-400" />
                Compound Coastal Storm Surge & Flood Interface
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Phase 8 atmospheric contract interface combining Inverted Barometer, Wind Stress, Wave Setup, Tides, and River Flooding.
              </p>
            </div>

            <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-slate-400">Central Baro Pressure:</span>
                    <span className="text-cyan-400 font-bold">{stormBaroHPa} hPa</span>
                  </div>
                  <input 
                    type="range" min="930" max="1013" step="1" value={stormBaroHPa}
                    onChange={(e) => setStormBaroHPa(parseFloat(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-slate-400">Sustained Wind Speed:</span>
                    <span className="text-cyan-400 font-bold">{stormWindMS} m/s</span>
                  </div>
                  <input 
                    type="range" min="5" max="45" step="1" value={stormWindMS}
                    onChange={(e) => setStormWindMS(parseFloat(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-slate-400">Astronomical Tide:</span>
                    <span className="text-cyan-400 font-bold">+{stormTideOffset} m</span>
                  </div>
                  <input 
                    type="range" min="-1.5" max="4.5" step="0.1" value={stormTideOffset}
                    onChange={(e) => setStormTideOffset(parseFloat(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-slate-400">River Flood Stage:</span>
                    <span className="text-cyan-400 font-bold">+{stormRiverBackwater} m</span>
                  </div>
                  <input 
                    type="range" min="0.0" max="2.5" step="0.05" value={stormRiverBackwater}
                    onChange={(e) => setStormRiverBackwater(parseFloat(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>
              </div>

              {/* Total Surge Result */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row justify-between items-center gap-4">
                <div>
                  <div className="text-xs text-slate-400 font-semibold">Total Compound Coastal Water Level</div>
                  <div className="text-2xl font-bold text-amber-400 font-mono mt-0.5">
                    +{currentSurgeState.totalWaterLevelMeters} m above MSL
                  </div>
                  <div className="text-xs text-slate-400 mt-1">
                    Baro: +{currentSurgeState.barometricPressureInvertedMeters}m • Wind: +{currentSurgeState.windSetUpmMeters}m • Wave Setup: +{currentSurgeState.waveSetUpmMeters}m • Tide: +{currentSurgeState.astronomicalTideMeters}m • River: +{currentSurgeState.riverOutflowBackwaterMeters}m
                  </div>
                </div>

                <div className={`px-4 py-2 rounded-xl text-sm font-bold border ${
                  currentSurgeState.inundationRiskLevel === 'Catastrophic' ? 'bg-red-500/20 text-red-300 border-red-500/40' :
                  currentSurgeState.inundationRiskLevel === 'Severe' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' :
                  currentSurgeState.inundationRiskLevel === 'Moderate' ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40' :
                  'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                }`}>
                  {currentSurgeState.inundationRiskLevel.toUpperCase()} RISK
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 12. STREAMING & MULTI-TIER EXECUTION */}
        {/* =================================================================== */}
        {activeTab === 'STREAMING' && (
          <div className="space-y-6" id="streaming-view">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Cpu className="h-5 w-5 text-cyan-400" />
                  Ocean Tile Streaming & Multi-Tier Execution
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Decoupled multi-rate simulation scheduling and asynchronous LRU tile cache manager.
                </p>
              </div>
              <button
                onClick={handleTickMultiTier}
                className="px-3.5 py-1.5 bg-cyan-500 hover:bg-cyan-600 text-white text-xs font-bold rounded-lg flex items-center gap-2"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Trigger Multi-Tier Step
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {[
                { tier: 'Tier 0 (60Hz)', target: '16.6 ms', measured: `${multiTierStats.tier0TimeMs} ms`, scope: 'Local Wave Mesh & Surf Breakers (< 1km)' },
                { tier: 'Tier 1 (10Hz)', target: '100 ms', measured: `${multiTierStats.tier1TimeMs} ms`, scope: 'Coastal Tides & River Plumes (< 25km)' },
                { tier: 'Tier 2 (1Hz)', target: '1000 ms', measured: `${multiTierStats.tier2TimeMs} ms`, scope: 'Basin Currents & Thermohaline (< 250km)' },
                { tier: 'Tier 3 (0.1Hz)', target: '10000 ms', measured: `${multiTierStats.tier3TimeMs} ms`, scope: 'Global Spring-Neap & Sea Ice Pack' }
              ].map(t => (
                <div key={t.tier} className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                  <div className="text-xs font-bold text-white">{t.tier}</div>
                  <div className="text-lg font-bold text-emerald-400 font-mono mt-1">{t.measured}</div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">Budget: {t.target}</div>
                  <div className="text-[11px] text-slate-300 mt-2">{t.scope}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 13. MEMORY MONITOR */}
        {/* =================================================================== */}
        {activeTab === 'MEMORY' && (
          <div className="space-y-6" id="memory-view">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Database className="h-5 w-5 text-cyan-400" />
                Oceanographic Memory Model & Budget Tracking
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Real-time tracking of RAM allocations across bathymetry, current fields, thermohaline arrays, and tile buffers.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Allocated RAM</div>
                <div className="text-2xl font-bold text-emerald-400 font-mono mt-1">
                  {(memoryInfo.totalOceanRAMBytes / (1024 * 1024)).toFixed(1)} MB
                </div>
                <div className="text-xs text-slate-400 mt-1 font-mono">
                  Budget Cap: {(memoryInfo.maxRAMBudgetBytes / (1024 * 1024)).toFixed(0)} MB
                </div>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Active Ocean Tile Buffers</div>
                <div className="text-2xl font-bold text-cyan-400 font-mono mt-1">
                  {memoryInfo.activeTilesCount} / {memoryInfo.maxAllocatedTiles}
                </div>
                <div className="text-xs text-slate-400 mt-1 font-mono">
                  LRU Cache Hit Rate: {memoryInfo.cacheHitRatePercent}%
                </div>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Buffer Subsystem Breakdown</div>
                <div className="text-xs text-slate-300 mt-2 space-y-1 font-mono">
                  <div>Bathymetry: 12.0 MB</div>
                  <div>Current Fields: 8.0 MB</div>
                  <div>Thermohaline: 6.0 MB</div>
                  <div>Coastal Geometry: 4.0 MB</div>
                  <div>Wave Simulation: 2.0 MB</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* 14. VALIDATION SUITE (TC-601 TO TC-620) */}
        {/* =================================================================== */}
        {activeTab === 'VALIDATION' && (
          <div className="space-y-6" id="validation-view">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <ShieldAlert className="h-5 w-5 text-cyan-400" />
                  Phase 6 Automated Verification & Regression Suite
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  20 automated test cases (TC-601 to TC-620) covering physical accuracy, mass conservation, fault injection, and regression.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-1.5 text-xs font-semibold focus:outline-none"
                >
                  <option value="ALL">All Categories ({totalTestsCount})</option>
                  <option value="BATHYMETRY">Bathymetry</option>
                  <option value="COASTLINE">Coastline</option>
                  <option value="TIDES">Tides</option>
                  <option value="CURRENTS">Currents</option>
                  <option value="THERMOHALINE">Thermohaline</option>
                  <option value="RIVER_COUPLING">River Coupling</option>
                  <option value="WAVES">Waves</option>
                  <option value="COASTAL_FLOOD">Coastal Flood</option>
                  <option value="FAULT_INJECTION">Fault Injection</option>
                  <option value="REGRESSION">Regression</option>
                </select>

                <button
                  onClick={handleRunTests}
                  disabled={isRunningTests}
                  className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-600 text-white text-xs font-bold rounded-lg flex items-center gap-2 shadow-md"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${isRunningTests ? 'animate-spin' : ''}`} />
                  {isRunningTests ? 'Running Suite...' : 'Re-Run Suite'}
                </button>
              </div>
            </div>

            {/* Test Cards List */}
            <div className="space-y-3">
              {filteredTests.map(test => {
                const isPass = test.status === 'PASS';
                return (
                  <div 
                    key={test.id} 
                    className={`border rounded-xl p-4 transition-all ${
                      isPass 
                        ? 'bg-slate-950/70 border-slate-800 hover:border-slate-700' 
                        : 'bg-red-950/30 border-red-900/50'
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <span className={`px-2.5 py-0.5 rounded text-xs font-mono font-bold ${
                          isPass ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-red-500/20 text-red-300 border border-red-500/30'
                        }`}>
                          {test.id}
                        </span>
                        <span className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
                          [{test.category}]
                        </span>
                        <span className="text-xs font-bold text-white">{test.description}</span>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <span className="text-[11px] text-slate-400 font-mono">{test.executionTimeMs} ms</span>
                        <span className={`px-2 py-0.5 rounded text-xs font-bold flex items-center gap-1 ${
                          isPass ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {isPass ? <CheckCircle2 className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}
                          {test.status}
                        </span>
                      </div>
                    </div>

                    <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-2 text-xs font-mono bg-slate-900/80 rounded-lg p-2.5 border border-slate-800">
                      <div>
                        <span className="text-slate-500">Expected:</span>
                        <div className="text-slate-300 truncate">{test.expectedValue}</div>
                      </div>
                      <div>
                        <span className="text-slate-500">Measured:</span>
                        <div className="text-cyan-300 truncate">{test.measuredValue}</div>
                      </div>
                      <div>
                        <span className="text-slate-500">Provenance:</span>
                        <div className="text-amber-300 truncate">{test.datasetProvenance}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
