import { useState, useEffect } from 'react';
import { NPC, OceanTraits, GoapAction } from '../types';
import { Play, RotateCcw, HelpCircle, ChevronRight, User, TrendingUp, Info } from 'lucide-react';

const PRESET_NPCS: { name: string; desc: string; ocean: OceanTraits; cash: number; occupation: string }[] = [
  {
    name: "Aiden Vance",
    desc: "Highly conscientious researcher, highly introverted, ambitious.",
    occupation: "GIS Engineer",
    cash: 250,
    ocean: { openness: 0.85, conscientiousness: 0.9, extraversion: 0.25, agreeableness: 0.4, neuroticism: 0.6 }
  },
  {
    name: "Chloe Sterling",
    desc: "Extroverted, highly social event organizer, moderate neuroticism.",
    occupation: "Event Coordinator",
    cash: 180,
    ocean: { openness: 0.6, conscientiousness: 0.5, extraversion: 0.9, agreeableness: 0.8, neuroticism: 0.45 }
  },
  {
    name: "Barrett Miller",
    desc: "Anxious, low-income worker experiencing high financial stress.",
    occupation: "Courier",
    cash: 45,
    ocean: { openness: 0.4, conscientiousness: 0.7, extraversion: 0.5, agreeableness: 0.5, neuroticism: 0.85 }
  }
];

const ACTIONS_REGISTRY: GoapAction[] = [
  {
    id: "eat",
    name: "Eat Caloric Meal",
    category: "Survival",
    description: "Consume a full meal. Alleviates caloric deficit drastically.",
    affects: { nutrition: -0.6, hydration: -0.1, sleep: -0.05 },
    cashCost: 15,
    cashIncome: 0,
    energyCost: -0.05,
    icon: "🍔"
  },
  {
    id: "drink",
    name: "Drink Water",
    category: "Survival",
    description: "Quench hydration drive immediately.",
    affects: { hydration: -0.5 },
    cashCost: 2,
    cashIncome: 0,
    energyCost: 0,
    icon: "💧"
  },
  {
    id: "sleep",
    name: "Deep Sleep & Rest",
    category: "Survival",
    description: "Recharge energy levels, slightly decay other physiological parameters.",
    affects: { sleep: -0.8, safety: -0.1 },
    cashCost: 0,
    cashIncome: 0,
    energyCost: -0.8,
    icon: "🛌"
  },
  {
    id: "work",
    name: "Perform Work Shift",
    category: "Economic",
    description: "Exchange energy for liquidity. Improves esteem drive, depletes stamina.",
    affects: { sleep: 0.2, nutrition: 0.15, hydration: 0.1, esteem: -0.2, actualization: -0.05 },
    cashCost: 0,
    cashIncome: 65,
    energyCost: 0.2,
    icon: "💼"
  },
  {
    id: "socialize",
    name: "Socialize at Local Pub",
    category: "Social",
    description: "Connect with neighborhood peers. Quenches isolation, costs currency.",
    affects: { social: -0.55, sleep: 0.1, nutrition: -0.05 },
    cashCost: 25,
    cashIncome: 0,
    energyCost: 0.1,
    icon: "🍻"
  },
  {
    id: "craft",
    name: "Creative Crafting",
    category: "Self-Actualization",
    description: "Engage in personal artistic projects or coding.",
    affects: { actualization: -0.5, social: 0.05, sleep: 0.1 },
    cashCost: 8,
    cashIncome: 0,
    energyCost: 0.1,
    icon: "🎨"
  },
  {
    id: "read",
    name: "Read Scientific Paper",
    category: "Esteem & Mind",
    description: "Read books or design documents. Feeds purpose and intellectual esteem.",
    affects: { actualization: -0.3, esteem: -0.15, sleep: 0.05 },
    cashCost: 0,
    cashIncome: 0,
    energyCost: 0.05,
    icon: "📚"
  },
  {
    id: "lockdown",
    name: "Fortify Shelter Locks",
    category: "Safety",
    description: "Repair/upgrade structural defenses to decrease safety anxiety.",
    affects: { safety: -0.6, sleep: 0.05 },
    cashCost: 40,
    cashIncome: 0,
    energyCost: 0.05,
    icon: "🔒"
  },
  {
    id: "desperate_theft",
    name: "Shoplift Groceries",
    category: "Emergency",
    description: "Illicit acquisition of food. Highly risky, reduces safety and esteem.",
    affects: { nutrition: -0.4, safety: 0.45, esteem: 0.35 },
    cashCost: 0,
    cashIncome: 0,
    energyCost: 0.1,
    icon: "🥷"
  }
];

export default function NeedsSimulator() {
  const [npc, setNpc] = useState<NPC>({
    id: "npc-1",
    name: PRESET_NPCS[0].name,
    age: 26,
    gender: "Male",
    occupation: PRESET_NPCS[0].occupation,
    ocean: PRESET_NPCS[0].ocean,
    drives: {
      nutrition: 0.4,
      hydration: 0.3,
      sleep: 0.2,
      thermal: 0.15,
      safety: 0.25,
      social: 0.5,
      esteem: 0.4,
      actualization: 0.6
    },
    cash: PRESET_NPCS[0].cash,
    debt: 0,
    stress: 0.25,
    monthlyRent: 350,
    monthlyUtilities: 80,
    habits: { eat: 1.0, socialize: 1.0, read: 1.2 },
    history: ["Simulation initialized."],
    isPlayer: false
  });

  const [selectedPresetIndex, setSelectedPresetIndex] = useState(0);
  const [decayMultiplier, setDecayMultiplier] = useState(1.0);
  const [isLiveRunning, setIsLiveRunning] = useState(false);
  const [showFormulaBreakdown, setShowFormulaBreakdown] = useState<string | null>(null);

  // Apply presets
  const handleApplyPreset = (idx: number) => {
    const preset = PRESET_NPCS[idx];
    setSelectedPresetIndex(idx);
    setNpc((prev) => ({
      ...prev,
      name: preset.name,
      occupation: preset.occupation,
      ocean: preset.ocean,
      cash: preset.cash,
      drives: {
        nutrition: 0.4,
        hydration: 0.3,
        sleep: 0.2,
        thermal: 0.15,
        safety: 0.25,
        social: 0.5,
        esteem: 0.4,
        actualization: 0.6
      },
      history: [`Selected preset: ${preset.name}.`],
      stress: 0.25
    }));
  };

  // Adjust specific drives
  const handleDriveChange = (key: keyof NPC['drives'], value: number) => {
    setNpc((prev) => ({
      ...prev,
      drives: {
        ...prev.drives,
        [key]: Math.max(0.0, Math.min(1.0, value))
      }
    }));
  };

  // Adjust OCEAN traits
  const handleOceanChange = (key: keyof OceanTraits, value: number) => {
    setNpc((prev) => ({
      ...prev,
      ocean: {
        ...prev.ocean,
        [key]: Math.max(0.0, Math.min(1.0, value))
      }
    }));
  };

  // GOAP Equation Evaluator
  const evaluateActionUtility = (action: GoapAction, currentNpc: NPC) => {
    let utility = 0;
    const affects = action.affects;

    // Deficit weights based on hierarchy level importance
    const weightMap: { [key: string]: number } = {
      nutrition: 1.5,       // Level 1: Core Survival
      hydration: 1.8,       // Level 1: Hydration is even more urgent
      sleep: 1.2,           // Level 1
      thermal: 1.0,         // Level 2
      safety: 1.1,          // Level 2
      social: 0.8,          // Level 3
      esteem: 0.6,          // Level 4
      actualization: 0.5    // Level 5: Self-Actualization
    };

    // Calculate sum of alleviated drives using the exponential scaling equation
    const breakdownDetails: { [key: string]: { delta: number; rawDeficit: number; scaledValue: number; contribution: number } } = {};

    Object.entries(affects).forEach(([driveKey, delta]) => {
      const dVal = currentNpc.drives[driveKey as keyof NPC['drives']];
      const weight = weightMap[driveKey] || 0.5;

      // Note: Delta is negative if it Alleviates the deficit.
      // Therefore, the benefit (utility) is proportional to the negative of the delta (i.e. reducing deficit)
      const alleviation = -delta;

      // Exponential drive amplification: 1.0 / (1.01 - dVal)
      const denominator = Math.max(0.001, 1.01 - dVal);
      const amplification = 1.0 / denominator;
      const termContribution = alleviation * weight * amplification;

      utility += termContribution;

      breakdownDetails[driveKey] = {
        delta,
        rawDeficit: dVal,
        scaledValue: amplification,
        contribution: termContribution
      };
    });

    // Apply OCEAN Trait multipliers
    let oceanModifier = 1.0;
    if (action.category === "Social") {
      oceanModifier += (currentNpc.ocean.extraversion * 0.5) - ((1 - currentNpc.ocean.agreeableness) * 0.1);
    } else if (action.id === "work") {
      oceanModifier += (currentNpc.ocean.conscientiousness * 0.4) - (currentNpc.ocean.neuroticism * 0.15);
    } else if (action.category === "Self-Actualization" || action.id === "read") {
      oceanModifier += (currentNpc.ocean.openness * 0.5) + (currentNpc.ocean.conscientiousness * 0.2);
    } else if (action.id === "desperate_theft") {
      // Low conscientiousness and high neuroticism (stress) increase propensity
      oceanModifier += ((1.0 - currentNpc.ocean.conscientiousness) * 0.5) + (currentNpc.ocean.neuroticism * 0.3);
    }

    // Apply habit multipliers
    const habitMultiplier = currentNpc.habits[action.id] || 1.0;

    const finalUtility = utility * oceanModifier * habitMultiplier;

    return {
      finalUtility,
      rawUtility: utility,
      oceanModifier,
      habitMultiplier,
      breakdownDetails
    };
  };

  // Evaluate the winning action
  const actionsWithScores = ACTIONS_REGISTRY.map((action) => {
    // Shoplifting is only evaluated if cash is extremely low
    if (action.id === "desperate_theft" && npc.cash > 30) {
      return { action, score: -999, details: null };
    }
    // Work / buying food requires capital or is restricted
    if (action.cashCost > npc.cash) {
      return { action, score: -500, details: null }; // Cannot afford
    }

    const evaluation = evaluateActionUtility(action, npc);
    return {
      action,
      score: evaluation.finalUtility,
      details: evaluation
    };
  }).sort((a, b) => b.score - a.score);

  const winningAction = actionsWithScores[0];

  // Perform single low-frequency tick
  const handleTick = () => {
    setNpc((prev) => {
      // 1. Decay drives over time (hunger, hydration increase deficits)
      const newDrives = { ...prev.drives };
      const decayBase = 0.03 * decayMultiplier;

      newDrives.nutrition = Math.min(1.0, prev.drives.nutrition + decayBase * 1.0);
      newDrives.hydration = Math.min(1.0, prev.drives.hydration + decayBase * 1.5);
      newDrives.sleep = Math.min(1.0, prev.drives.sleep + decayBase * 0.8);
      newDrives.social = Math.min(1.0, prev.drives.social + decayBase * 0.6);
      newDrives.esteem = Math.min(1.0, prev.drives.esteem + decayBase * 0.4);
      newDrives.actualization = Math.min(1.0, prev.drives.actualization + decayBase * 0.5);
      newDrives.thermal = Math.max(0.0, Math.min(1.0, prev.drives.thermal + (Math.random() - 0.5) * 0.1));
      newDrives.safety = Math.min(1.0, prev.drives.safety + decayBase * 0.3);

      // 2. Perform the winning action
      const winner = winningAction.action;
      let newCash = prev.cash;
      newCash -= winner.cashCost;
      newCash += winner.cashIncome;

      // Apply the action modifications to drives
      Object.entries(winner.affects).forEach(([driveKey, value]) => {
        newDrives[driveKey as keyof NPC['drives']] = Math.max(0.0, Math.min(1.0, newDrives[driveKey as keyof NPC['drives']] + (value as number)));
      });

      // Update financial stress
      const monthlyFixed = prev.monthlyRent + prev.monthlyUtilities;
      const stressFin = 1.0 / (1.0 + Math.pow(newCash / (1.5 * (monthlyFixed / 30)), 2));
      const overallStress = Math.max(0.0, Math.min(1.0, (prev.stress * 0.7) + (stressFin * 0.3)));

      const timeStr = `Tick ${prev.history.length}`;
      const logEntry = `[${timeStr}] Executed: ${winner.icon} ${winner.name} (Utility: ${winningAction.score.toFixed(2)}). Cash: $${newCash}. drives refreshed.`;

      return {
        ...prev,
        drives: newDrives,
        cash: newCash,
        stress: overallStress,
        history: [logEntry, ...prev.history].slice(0, 50)
      };
    });
  };

  // Live simulator interval
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isLiveRunning) {
      interval = setInterval(() => {
        handleTick();
      }, 2500);
    }
    return () => clearInterval(interval);
  }, [isLiveRunning, winningAction]);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-8" id="needs-sim-root">
      {/* Left panel: NPC configuration & Preset Selectors */}
      <div className="xl:col-span-1 space-y-6" id="sim-config-panel">
        <div className="glass-panel rounded-2xl p-5" id="presets-card">
          <h3 className="text-sm font-bold text-white font-serif flex items-center gap-2 mb-4">
            <User className="h-4 w-4 text-pink-500" id="user-icon" /> NPC Template Presets
          </h3>
          <div className="grid grid-cols-3 gap-2" id="preset-grid">
            {PRESET_NPCS.map((preset, idx) => (
              <button
                id={`preset-btn-${idx}`}
                key={idx}
                onClick={() => handleApplyPreset(idx)}
                className={`p-2.5 rounded-lg border text-left transition-all ${
                  selectedPresetIndex === idx
                    ? 'bg-white border-white text-slate-950 shadow-md font-bold'
                    : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/15 hover:text-white'
                }`}
              >
                <div className="text-xs font-bold truncate" id={`preset-name-${idx}`}>{preset.name}</div>
                <div className="text-[9px] opacity-75 mt-0.5" id={`preset-occ-${idx}`}>{preset.occupation}</div>
              </button>
            ))}
          </div>
          <p className="text-[10px] text-slate-400 mt-3 leading-relaxed italic" id="preset-desc-box">
            "{PRESET_NPCS[selectedPresetIndex].desc}"
          </p>
        </div>

        {/* OCEAN Personality sliders */}
        <div className="glass-panel rounded-2xl p-5" id="ocean-card">
          <h3 className="text-sm font-bold text-white font-mono tracking-tight mb-4">OCEAN Personality Vector</h3>
          <div className="space-y-3.5" id="ocean-sliders">
            {Object.entries(npc.ocean).map(([trait, val]) => {
              const valNum = val as number;
              return (
                <div key={trait} className="space-y-1" id={`ocean-container-${trait}`}>
                  <div className="flex justify-between text-xs" id={`ocean-info-${trait}`}>
                    <span className="capitalize font-medium text-slate-300" id={`ocean-label-${trait}`}>{trait}</span>
                    <span className="font-mono text-pink-400 font-semibold" id={`ocean-val-${trait}`}>{valNum.toFixed(2)}</span>
                  </div>
                  <input
                    id={`ocean-slider-${trait}`}
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={valNum}
                    onChange={(e) => handleOceanChange(trait as keyof OceanTraits, parseFloat(e.target.value))}
                    className="w-full accent-pink-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Global Controls */}
        <div className="glass-panel rounded-2xl p-5 space-y-4" id="sim-controls-card">
          <h3 className="text-sm font-bold text-white font-serif">Sim Engine Controls</h3>
          <div className="space-y-1" id="decay-rate-container">
            <div className="flex justify-between text-xs text-slate-300" id="decay-info">
              <span>Drive Decay Rate Multiplier</span>
              <span className="font-mono text-cyan-400 font-bold">{decayMultiplier.toFixed(1)}x</span>
            </div>
            <input
              id="decay-multiplier-slider"
              type="range"
              min="0.5"
              max="3"
              step="0.5"
              value={decayMultiplier}
              onChange={(e) => setDecayMultiplier(parseFloat(e.target.value))}
              className="w-full accent-cyan-400 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
            />
          </div>

          <div className="flex gap-2 pt-2" id="control-buttons">
            <button
              id="tick-once-btn"
              onClick={handleTick}
              className="flex-1 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20 border border-white/20 font-semibold text-xs transition-all flex items-center justify-center gap-1.5 shadow-sm"
            >
              <ChevronRight className="h-4 w-4" id="tick-icon" /> Tick Simulator
            </button>
            <button
              id="toggle-live-btn"
              onClick={() => setIsLiveRunning(!isLiveRunning)}
              className={`flex-1 py-2 rounded-lg font-semibold text-xs transition-all flex items-center justify-center gap-1.5 shadow-sm ${
                isLiveRunning
                  ? 'bg-pink-600 text-white hover:bg-pink-500 hover:shadow-[0_0_15px_rgba(236,72,153,0.4)]'
                  : 'bg-cyan-600 text-white hover:bg-cyan-500 hover:shadow-[0_0_15px_rgba(6,182,212,0.4)]'
              }`}
            >
              <Play className="h-3.5 w-3.5" id="play-icon" /> {isLiveRunning ? 'Pause Engine' : 'Run Live Sim'}
            </button>
          </div>
        </div>
      </div>

      {/* Middle panel: Live Drive Deficit Levels */}
      <div className="xl:col-span-1 space-y-6" id="drives-display-panel">
        <div className="glass-panel rounded-2xl p-5" id="drives-card">
          <h3 className="text-sm font-bold text-white font-serif flex items-center gap-2 mb-4">
            <TrendingUp className="h-4 w-4 text-cyan-400" id="trending-icon" /> Drive Deficit Coefficients
          </h3>
          <div className="space-y-4" id="drives-sliders-container">
            {Object.entries(npc.drives).map(([drive, val]) => {
              const valNum = val as number;
              // Color spectrum based on urgency
              let color = 'bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.4)]';
              if (valNum > 0.8) color = 'bg-pink-600 shadow-[0_0_8px_rgba(236,72,153,0.4)]';
              else if (valNum > 0.5) color = 'bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.4)]';

              return (
                <div key={drive} className="space-y-1.5" id={`drive-wrapper-${drive}`}>
                  <div className="flex justify-between text-xs" id={`drive-info-${drive}`}>
                    <span className="capitalize font-semibold text-slate-300" id={`drive-label-${drive}`}>{drive}</span>
                    <span className="font-mono text-white font-bold" id={`drive-value-${drive}`}>
                      {(valNum * 100).toFixed(0)}% {(valNum > 0.8 ? '🚨 CRITICAL' : valNum > 0.5 ? '⚠️ ALERT' : '✅ OK')}
                    </span>
                  </div>
                  <div className="flex items-center gap-3" id={`drive-progress-container-${drive}`}>
                    <input
                      id={`drive-slider-input-${drive}`}
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={valNum}
                      onChange={(e) => handleDriveChange(drive as keyof NPC['drives'], parseFloat(e.target.value))}
                      className="w-24 accent-pink-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex-1 h-3 bg-white/5 rounded-full overflow-hidden border border-white/10" id={`drive-progress-bg-${drive}`}>
                      <div
                        id={`drive-progress-fill-${drive}`}
                        className={`h-full transition-all duration-300 ${color}`}
                        style={{ width: `${valNum * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-5 p-3.5 bg-white/5 border border-white/10 rounded-xl space-y-1" id="npc-status-box">
            <div className="flex justify-between text-xs" id="status-cash-stress">
              <span className="text-slate-400">Liquid Cash:</span>
              <span className="font-mono text-emerald-400 font-bold">${npc.cash.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-xs" id="status-anxiety">
              <span className="text-slate-400">Calculated Stress Score:</span>
              <span className="font-mono text-pink-400 font-bold">{(npc.stress * 100).toFixed(0)}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right panel: GOAP Plan & Solver Weights */}
      <div className="xl:col-span-1 space-y-6" id="goap-resolver-panel">
        <div className="glass-panel rounded-2xl p-5 text-slate-100 shadow-xl" id="resolver-card">
          <h3 className="text-sm font-bold text-white font-mono tracking-tight flex items-center justify-between mb-4" id="resolver-title">
            <span>GOAP Planner & Utility Solver</span>
            <span className="text-[10px] bg-pink-500/20 text-pink-300 border border-pink-500/30 px-2 py-0.5 rounded-full font-sans uppercase">Active Plan</span>
          </h3>

          <div className="bg-white/10 rounded-xl p-4 border border-white/15 mb-5" id="winning-action-box">
            <div className="text-[10px] uppercase text-slate-400 tracking-wider font-semibold font-sans mb-1" id="winning-tag">Winning Behavior Node</div>
            <div className="flex items-start gap-3" id="winning-flex">
              <div className="text-3xl bg-white/10 p-2 rounded-lg border border-white/10" id="winning-icon">
                {winningAction?.action?.icon || "💤"}
              </div>
              <div className="flex-1 min-w-0" id="winning-text">
                <h4 className="text-sm font-bold text-pink-300 truncate" id="winning-name">{winningAction?.action?.name || "Idle"}</h4>
                <p className="text-[11px] text-slate-300 leading-normal mt-0.5" id="winning-desc">{winningAction?.action?.description || "Contemplate and wait."}</p>
                <div className="flex items-center gap-2 mt-2" id="winning-metrics">
                  <span className="text-[10px] bg-white/5 text-slate-200 px-2 py-0.5 rounded-md border border-white/10" id="winning-cat">
                    Category: {winningAction?.action?.category}
                  </span>
                  <span className="text-[10px] font-bold text-cyan-400 font-mono" id="winning-utility">
                    Utility U(A) = {winningAction?.score?.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2.5 font-sans">Utility Rankings List</h4>
          <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1 glass-scrollbar" id="rankings-list">
            {actionsWithScores.map(({ action, score, details }, idx) => {
              const isWinner = action.id === winningAction?.action?.id;
              const isAffordable = score > -400;

              return (
                <div
                  id={`rank-item-${action.id}`}
                  key={action.id}
                  className={`p-2.5 rounded-lg border transition-all ${
                    isWinner
                      ? 'bg-pink-500/10 border-pink-500/40 text-white shadow-[0_0_10px_rgba(236,72,153,0.1)]'
                      : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  <div className="flex justify-between items-center" id={`rank-header-${action.id}`}>
                    <div className="flex items-center gap-2 text-xs font-semibold" id={`rank-name-container-${action.id}`}>
                      <span>{action.icon}</span>
                      <span className="truncate max-w-[150px]">{action.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5" id={`rank-score-container-${action.id}`}>
                      <span className="text-[10px] font-mono font-bold" id={`rank-score-${action.id}`}>
                        {isAffordable ? `U(A)=${score.toFixed(1)}` : '❌ UNABLE'}
                      </span>
                      {isAffordable && (
                        <button
                          id={`info-btn-${action.id}`}
                          onClick={() => setShowFormulaBreakdown(showFormulaBreakdown === action.id ? null : action.id)}
                          className="text-slate-400 hover:text-pink-400 p-0.5 rounded-md transition-colors"
                        >
                          <Info className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Formula Breakdown Section */}
                  {showFormulaBreakdown === action.id && details && (
                    <div className="mt-2 pt-2 border-t border-white/10 text-[10px] font-mono text-slate-400 space-y-1" id={`breakdown-details-${action.id}`}>
                      <div className="text-[9px] font-sans font-bold text-pink-400/80 uppercase">GOAP Calculations</div>
                      <div className="grid grid-cols-4 gap-1 border-b border-white/5 pb-1 font-semibold" id={`breakdown-headers-${action.id}`}>
                        <span>Drive</span>
                        <span>Delta</span>
                        <span>1/(1.01-D)</span>
                        <span>Contrib</span>
                      </div>
                      {Object.entries(details.breakdownDetails).map(([drv, data]) => (
                        <div key={drv} className="grid grid-cols-4 gap-1" id={`breakdown-row-${action.id}-${drv}`}>
                          <span className="capitalize">{drv}</span>
                          <span className={data.delta < 0 ? 'text-cyan-400' : 'text-slate-400'}>{data.delta}</span>
                          <span>{data.scaledValue.toFixed(1)}x</span>
                          <span className="text-pink-400">{data.contribution.toFixed(2)}</span>
                        </div>
                      ))}
                      <div className="pt-1 mt-1 border-t border-white/5 text-slate-300 flex justify-between" id={`breakdown-footer-${action.id}`}>
                        <span>OCEAN Trait Mod:</span>
                        <span>{details.oceanModifier.toFixed(2)}x</span>
                      </div>
                      <div className="flex justify-between text-slate-300" id={`breakdown-habit-${action.id}`}>
                        <span>Habit Mult:</span>
                        <span>{details.habitMultiplier.toFixed(2)}x</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* History Logger */}
        <div className="glass-panel rounded-2xl p-5" id="history-card">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 font-sans">Sim Decision History Logs</h3>
          <div className="space-y-2 h-[150px] overflow-y-auto font-mono text-[10.5px] leading-relaxed text-slate-300 pr-1 glass-scrollbar" id="history-logs">
            {npc.history.map((log, idx) => (
              <div key={idx} className="border-b border-white/5 pb-1.5 text-slate-300" id={`log-${idx}`}>
                {log}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
