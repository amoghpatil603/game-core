import { useState, useMemo } from 'react';
import { OceanTraits } from '../types';
import { Shield, Sparkles, Smile, MessageCircle, AlertTriangle, TrendingUp, Info } from 'lucide-react';

interface DevelopmentEvent {
  id: string;
  name: string;
  category: 'family' | 'school' | 'peers' | 'trauma';
  description: string;
  effects: Partial<OceanTraits>;
  icon: any;
}

const DEVELOPMENT_EVENTS: DevelopmentEvent[] = [
  {
    id: 'secure_attach',
    name: 'Secure Parental Attachment',
    category: 'family',
    description: 'Warm, consistent parental bonding. Drastically reduces Neuroticism, increases Agreeableness.',
    effects: { neuroticism: -0.25, agreeableness: 0.15, extraversion: 0.05 },
    icon: Smile
  },
  {
    id: 'school_bullying',
    name: 'Severe School Bullying',
    category: 'peers',
    description: 'Relentless peer exclusion during adolescence. Increases Neuroticism, severely harms Agreeableness.',
    effects: { neuroticism: 0.35, agreeableness: -0.2, extraversion: -0.15 },
    icon: AlertTriangle
  },
  {
    id: 'strict_discipline',
    name: 'Strict Academic Discipline',
    category: 'school',
    description: 'Highly structured rigorous educational setting. Boosts Conscientiousness, limits Openness.',
    effects: { conscientiousness: 0.25, openness: -0.1, neuroticism: 0.05 },
    icon: Shield
  },
  {
    id: 'creative_mentor',
    name: 'Creative Mentorship',
    category: 'school',
    description: 'A dedicated guide fosters curiosity. Enhances Openness and Extroversion.',
    effects: { openness: 0.3, extraversion: 0.1, agreeableness: 0.05 },
    icon: Sparkles
  },
  {
    id: 'peer_leadership',
    name: 'Elected Peer Leader',
    category: 'peers',
    description: 'Adolescent assumes responsibility in youth groups. Greatly increases Extraversion and Conscientiousness.',
    effects: { extraversion: 0.25, conscientiousness: 0.15, agreeableness: 0.1 },
    icon: MessageCircle
  },
  {
    id: 'family_poverty',
    name: 'Chronic Financial Instability',
    category: 'family',
    description: 'Fearing loss of shelter or basic goods during early years. Spikes baseline Neuroticism and anxiety.',
    effects: { neuroticism: 0.3, conscientiousness: 0.05, openness: -0.15 },
    icon: AlertTriangle
  }
];

export default function ChildDevelopment() {
  const [age, setAge] = useState(6);
  const [appliedEventIds, setAppliedEventIds] = useState<string[]>(['secure_attach']);

  // Dynamic coefficients using formulas
  const plasticity = useMemo(() => {
    if (age > 18) return 0.02;
    return 1.0 - Math.pow(age / 18.0, 2);
  }, [age]);

  const parentInfluence = useMemo(() => {
    return Math.exp(-0.15 * age);
  }, [age]);

  const peerInfluence = useMemo(() => {
    return 1.0 - Math.exp(-0.12 * age);
  }, [age]);

  // Genetic base traits
  const geneticBase: OceanTraits = {
    openness: 0.5,
    conscientiousness: 0.45,
    extraversion: 0.5,
    agreeableness: 0.5,
    neuroticism: 0.4
  };

  // Calculate dynamic ocean traits based on applied events and age plasticity
  const computedOcean = useMemo(() => {
    const finalTraits = { ...geneticBase };

    appliedEventIds.forEach((id) => {
      const event = DEVELOPMENT_EVENTS.find((e) => e.id === id);
      if (!event) return;

      // Event impact is modulated by the age plasticity at which it took place
      // (For simplification, we assume the cumulative impact scales with current age limits)
      Object.entries(event.effects).forEach(([trait, delta]) => {
        const key = trait as keyof OceanTraits;
        // The younger the child, the higher the plasticity impact on the genetic baseline
        finalTraits[key] = Math.max(0.0, Math.min(1.0, finalTraits[key] + (delta as number) * (1.0 + plasticity * 0.5)));
      });
    });

    return finalTraits;
  }, [appliedEventIds, age, plasticity]);

  const handleToggleEvent = (id: string) => {
    setAppliedEventIds((prev) => {
      if (prev.includes(id)) {
        return prev.filter((item) => item !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8" id="child-dev-root">
      {/* Left panel: Age slider & timeline curves */}
      <div className="lg:col-span-1 space-y-6" id="dev-timeline-panel">
        <div className="glass-panel rounded-2xl p-5 flex flex-col gap-5" id="timeline-card">
          <div className="flex justify-between items-center" id="timeline-header">
            <h3 className="text-sm font-bold text-white font-serif">Development Timeline</h3>
            <span className="text-xs bg-pink-500/20 text-pink-300 border border-pink-500/30 px-2.5 py-0.5 rounded-full font-mono font-bold" id="timeline-age-label">
              Age: {age} Years
            </span>
          </div>

          <div className="space-y-2" id="age-slider-box">
            <input
              id="age-timeline-slider"
              type="range"
              min="0"
              max="18"
              step="1"
              value={age}
              onChange={(e) => setAge(parseInt(e.target.value))}
              className="w-full accent-pink-500 h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-mono font-bold" id="age-slider-labels">
              <span>0 (INFANT)</span>
              <span>6 (PRIMARY)</span>
              <span>12 (ADOLESCENT)</span>
              <span>18 (ADULT)</span>
            </div>
          </div>

          <div className="border-t border-white/10 pt-4 space-y-4" id="timeline-metrics">
            {/* Plasticity */}
            <div className="space-y-1.5" id="metric-plasticity">
              <div className="flex justify-between text-xs" id="plasticity-info">
                <span className="text-slate-300 flex items-center gap-1">
                  Plasticity Coefficient <Info className="h-3.5 w-3.5 opacity-60" title="Defines how malleable the brain is to external environmental shifts." />
                </span>
                <span className="font-mono text-pink-400 font-bold">{(plasticity * 100).toFixed(0)}%</span>
              </div>
              <div className="h-2 bg-white/5 rounded-full overflow-hidden border border-white/10" id="plasticity-bar-bg">
                <div className="h-full bg-pink-500 shadow-[0_0_8px_rgba(236,72,153,0.4)] transition-all duration-300" style={{ width: `${plasticity * 100}%` }} id="plasticity-bar-fill" />
              </div>
            </div>

            {/* Parent vs Peer influence graphs */}
            <div className="space-y-3.5 pt-2" id="influence-curves">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-sans" id="influence-label">Influence Dynamics</div>

              {/* Parents */}
              <div className="space-y-1" id="parent-influence-box">
                <div className="flex justify-between text-xs" id="parent-influence-info">
                  <span className="text-slate-300 font-medium">Parental Attachment (e^-0.15t)</span>
                  <span className="font-mono text-white font-bold">{(parentInfluence * 100).toFixed(0)}%</span>
                </div>
                <div className="h-1.5 bg-white/5 rounded-full overflow-hidden" id="parent-bar-bg">
                  <div className="h-full bg-white/40 transition-all duration-300" style={{ width: `${parentInfluence * 100}%` }} id="parent-bar-fill" />
                </div>
              </div>

              {/* Peers */}
              <div className="space-y-1" id="peer-influence-box">
                <div className="flex justify-between text-xs" id="peer-influence-info">
                  <span className="text-slate-300 font-medium">Peer Group & School (1 - e^-0.12t)</span>
                  <span className="font-mono text-cyan-400 font-bold">{(peerInfluence * 100).toFixed(0)}%</span>
                </div>
                <div className="h-1.5 bg-white/5 rounded-full overflow-hidden" id="peer-bar-bg">
                  <div className="h-full bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.4)] transition-all duration-300" style={{ width: `${peerInfluence * 100}%` }} id="peer-bar-fill" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Middle panel: Trait Visualizer */}
      <div className="lg:col-span-1 space-y-6" id="dev-traits-panel">
        <div className="glass-panel rounded-2xl p-5" id="computed-traits-card">
          <h3 className="text-sm font-bold text-white font-serif flex items-center gap-2 mb-4">
            <TrendingUp className="h-4 w-4 text-cyan-400" /> Computed Trait Profiles
          </h3>

          <div className="space-y-4" id="computed-traits-list">
            {Object.entries(computedOcean).map(([trait, val]) => {
              const valNum = val as number;
              const baseVal = geneticBase[trait as keyof OceanTraits];
              const shift = valNum - baseVal;
              return (
                <div key={trait} className="space-y-1.5" id={`trait-row-${trait}`}>
                  <div className="flex justify-between text-xs" id={`trait-row-info-${trait}`}>
                    <span className="capitalize font-semibold text-slate-300">{trait}</span>
                    <div className="flex items-center gap-2" id={`trait-row-vals-${trait}`}>
                      <span className="font-mono text-white font-bold">{valNum.toFixed(2)}</span>
                      {Math.abs(shift) > 0.01 && (
                        <span className={`text-[10px] font-bold font-mono px-1.5 py-0.2 rounded-md ${
                          shift > 0 ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'bg-pink-500/20 text-pink-300 border border-pink-500/30'
                        }`} id={`trait-shift-badge-${trait}`}>
                          {shift > 0 ? '+' : ''}{shift.toFixed(2)}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="h-3 bg-white/5 rounded-full overflow-hidden border border-white/10 relative" id={`trait-progress-bar-container-${trait}`}>
                    {/* Genetic baseline anchor marker */}
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-white/40 z-10"
                      style={{ left: `${baseVal * 100}%` }}
                      title="Genetic Template Baseline"
                      id={`trait-baseline-marker-${trait}`}
                    />
                    <div
                      id={`trait-progress-fill-${trait}`}
                      className="h-full bg-gradient-to-r from-pink-500 to-indigo-500 transition-all duration-500"
                      style={{ width: `${valNum * 100}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-5 p-3.5 bg-white/5 border border-white/10 rounded-xl text-[10.5px] text-slate-400 font-mono leading-relaxed" id="genetic-baseline-box">
            <span className="font-semibold text-slate-200">Grey Vertical Lines</span> indicate raw genetically inherited baseline values. Differences represent active developmental adaptions from environment inputs.
          </div>
        </div>
      </div>

      {/* Right panel: Environmental Inputs Injector */}
      <div className="lg:col-span-1 space-y-6" id="dev-events-panel">
        <div className="glass-panel rounded-2xl p-5" id="events-card">
          <div className="flex justify-between items-center border-b border-white/10 pb-3 mb-4" id="events-header">
            <h3 className="text-sm font-bold text-white font-serif">Environmental Pressures</h3>
            <button
              id="clear-events-btn"
              onClick={() => setAppliedEventIds([])}
              className="text-[10px] text-slate-400 hover:text-pink-400 transition-colors uppercase font-bold font-mono"
            >
              Reset All
            </button>
          </div>

          <div className="space-y-3" id="environmental-events-list">
            {DEVELOPMENT_EVENTS.map((event) => {
              const isApplied = appliedEventIds.includes(event.id);
              const Icon = event.icon;
              return (
                <button
                  id={`event-btn-${event.id}`}
                  key={event.id}
                  onClick={() => handleToggleEvent(event.id)}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex items-start gap-3 ${
                    isApplied
                      ? 'bg-pink-500/10 border-pink-500/40 text-white shadow-[0_0_12px_rgba(236,72,153,0.1)]'
                      : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10 hover:border-white/20'
                  }`}
                >
                  <div className={`p-1.5 rounded-lg border shrink-0 ${isApplied ? 'bg-pink-500/20 border-pink-500/30 text-pink-300' : 'bg-white/5 border-white/10 text-slate-400'}`} id={`event-icon-container-${event.id}`}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0" id={`event-text-container-${event.id}`}>
                    <div className="flex items-center justify-between" id={`event-title-flex-${event.id}`}>
                      <h4 className="text-xs font-bold leading-tight" id={`event-name-${event.id}`}>{event.name}</h4>
                      <span className={`text-[8.5px] font-bold font-mono tracking-wider uppercase ${isApplied ? 'text-pink-400' : 'text-slate-400'}`} id={`event-cat-${event.id}`}>{event.category}</span>
                    </div>
                    <p className="text-[10.5px] text-slate-400 leading-normal mt-1.5" id={`event-desc-${event.id}`}>{event.description}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
