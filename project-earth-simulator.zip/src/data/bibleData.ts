import { BibleChapter } from '../types';

export const BIBLE_CHAPTERS: BibleChapter[] = [
  {
    id: 'vol-0',
    volume: 'PHASE 2 REFINEMENTS',
    title: 'Architectural Refinements & Scheduling',
    subTitle: 'System boundaries, discovery mechanics, multi-tier execution frequency, and fidelity matrices.',
    sections: [
      {
        title: '1. Realistic Engine Readiness Metrics',
        content: 'To prevent engineering overconfidence, the project readiness metrics distinguish architectural design completeness from early technical prototypes and production-grade stability.',
        matrices: [
          ['Metric Category', 'Rating', 'Current Phase Status'],
          ['Architectural Completeness', '96.0%', 'Systems & APIs fully specified'],
          ['Prototype Technical Readiness', '75.0%', 'Core headers & frameworks ready'],
          ['Full Production Maturity', '10.0%', 'Early foundation; production code pending']
        ]
      },
      {
        title: '2. Service Locator Boundaries',
        content: 'The FPEServiceLocator pattern is used strictly for cross-plugin discovery, while explicit ownership and dependency injection are enforced within individual plugin boundaries. Service registration is frozen after the PreDefault engine initialization phase to prevent runtime drift.',
        matrices: [
          ['Discovery Layer', 'Mechanic', 'Trade-off & Mitigation'],
          ['Within Plugin Boundaries', 'Explicit Dependency Injection', 'High compile-time safety, zero dynamic lookup overhead'],
          ['Across Plugin Boundaries', 'FPEServiceLocator Registry', 'Abstract interface pointers registered at bootstrap; frozen post-PreDefault']
        ]
      },
      {
        title: '3. Four-Tier Simulation Scheduling Hierarchy',
        content: 'To manage millions of entities across variable hardware budgets, system tasks execute within a strict four-tier scheduling hierarchy based on priority and player proximity.',
        matrices: [
          ['Priority Tier', 'Execution Budget', 'Target Systems'],
          ['TIER 0: Critical', 'Every Frame (60 Hz / 16.6ms)', 'Player Input, Local Physics, Camera, Active Collision Verification'],
          ['TIER 1: Important', 'High Frequency (15 - 30 Hz)', 'Nearby MassEntity ECS Movement, Pathing, Local Spatial Hash Queries'],
          ['TIER 2: Background', 'Time-Sliced Job Queue (1 - 5 Hz)', 'GOAP Tactical Planning, Utility AI, Local Store Inventories, Climate Map'],
          ['TIER 3: Dormant', 'Macro Batch (Hourly / Daily)', 'Far Unloaded Entities, Demographic Aggregations, Macro Economic Flow']
        ]
      },
      {
        title: '4. Decoupled Simulation vs. Render Fidelity Matrix',
        content: 'Render LOD (visual mesh representation) and Simulation Fidelity (cognitive and physics complexity) operate completely independently to maximize performance on dense crowds and global systems.',
        matrices: [
          ['', 'SIM 0: High Fidelity (Full GOAP & Physics)', 'SIM 1: Mid Fidelity (Lightweight ECS)', 'SIM 2: Abstracted (Statistical Batch)'],
          ['RENDER LOD 0 (Mesh)', 'Player & Nearby NPCs (Full Anim & High AI)', 'Dense City Crowds Near Camera (Instanced)', 'N/A (Invalid Combination)'],
          ['RENDER LOD 1 (Proxy)', 'High-Importance Entity Tracked From Afar', 'Mid-Distance Traffic & Pedestrian Streams', 'N/A'],
          ['RENDER HIDDEN', 'VIP NPC Executing Complex Plan Out-Of-Sight', 'Standard District Pedestrians Moving', 'Distant Cities & Global State Engine']
        ]
      }
    ]
  },
  {
    id: 'vol-1',
    volume: 'VOLUME I',
    title: 'Cognitive Architecture & Needs Hierarchy',
    subTitle: 'Mathematical formulation of drive-based utility selection, urgency curves, and OCEAN integration.',
    sections: [
      {
        title: '1. Fundamental Cognitive Model & Drive Theory',
        content: 'Synthetic humans are driven by a continuous drive-reduction model. Internal drives decay over time or increase due to environmental pressures. Unmet drives generate Need Urgency Scores, which serve as primary input weights for the GOAP action evaluator.',
        equations: [
          'D_n(t + Δt) = Clamp( D_n(t) + (α_n × ActivityModifier) Δt, 0.0, 1.0 )'
        ]
      },
      {
        title: '2. Mathematical Formulations of the Seven Core Drives',
        content: 'Each core drive is tracked as a floating-point value D_n ∈ [0.0, 1.0], where 0.0 represents complete satisfaction and 1.0 represents critical depletion. Drives decay incrementally per simulation hour based on specified decay rates.',
        matrices: [
          ['Drive Identifier', 'Base Decay Rate (α_n)', 'Primary Satisfier', 'Depletion Impact'],
          ['1. Hydration', '0.040 / Sim Hour', 'Water / Beverages', 'Health Damage'],
          ['2. Nutrition', '0.025 / Sim Hour', 'Food / Meals', 'Stamina Penalty'],
          ['3. Sleep / Rest', '0.035 / Sim Hour', 'Bed / Sleep Chair', 'Perception Penalty'],
          ['4. Thermal Safety', 'Environment Dependent', 'Shelter / Clothes', 'Injury / Freezing'],
          ['5. Financial Safety', 'Expense Dependent', 'Wage / Income', 'Stress / Desperation'],
          ['6. Social Belonging', '0.010 / Sim Hour', 'Conversations', 'Loneliness / Mood'],
          ['7. Self-Purpose', '0.005 / Sim Hour', 'Work / Mastery', 'Depression']
        ]
      },
      {
        title: '3. Need Urgency Curves & Emergency Override',
        content: 'Drive deficits do not scale linearly in their influence on behavior. A physiological drive spikes rapidly past a deficit of 0.7, causing exponential urgency growth. If any physiological drive urgency exceeds 0.90, the agent enters an Emergency Override State, suspending high-level social goals to force immediate survival actions.',
        equations: [
          'U_n(D_n) = (e^(k_n × D_n) - 1.0) / (e^(k_n) - 1.0)',
          'Physiological Drives (Hydration, Sleep): k_n = 6.0',
          'Social & Esteem Drives: k_n = 2.0',
          'Emergency Override: U_n(D_n) ≥ 0.90'
        ]
      },
      {
        title: '4. Integration with OCEAN Personality Profiles & Final Utility',
        content: 'An agent’s Big Five personality profile modulates how drives translate into final action utility scores. The total utility score V(A) for an action A targeting a satisfier is scaled by personality affinity coefficients and establishment bonuses for routines.',
        equations: [
          'V(A) = (U_n(D_n) × w_n) × (1.0 + Σ (β_i,A × P_i)) × HabitBonus(A)',
          'w_n: Base priority weight of drive n',
          'P_i ∈ [-1.0, 1.0]: Personality trait value i',
          'β_i,A: Affinity coefficient of trait i for action A',
          'HabitBonus(A) ∈ [1.0, 1.3]: Established routines reward'
        ]
      }
    ]
  },
  {
    id: 'vol-2',
    volume: 'VOLUME II',
    title: 'The Seven-Layer Memory Architecture & Emotional Dynamics',
    subTitle: 'Mathematical formulation of the 7-tier storage pipeline, emotional consolidation, sleep-state pruning, and context-aware retrieval.',
    sections: [
      {
        title: '1. The Seven-Layer Memory Hierarchy',
        content: 'Memory in Project Earth is partitioned into seven discrete, specialized layers. Rather than a flat list, experiences cascade or partition into these layers, each characterized by custom capacities, retention half-lives (H_L), and representational targets.',
        matrices: [
          ['Memory Layer', 'Capacity Limit', 'Half-Life (H_L)', 'Core Representational Target / Mechanic'],
          ['1. Sensory Memory', 'Virtually Unlimited', '200 - 500 ms', 'Pre-attentional sensory buffers (visual, auditory, spatial vectors)'],
          ['2. Working Memory', '4 - 7 active nodes', '15 - 30 seconds', 'Immediate cognitive attention workspace. Fast decay without rehearsal'],
          ['3. Short-Term Memory', '20 - 50 elements', '4 - 8 hours', 'Temporarily indexed daily experiences. Intermediate decay rate'],
          ['4. Long-Term Episodic', 'Proportionate to storage', '365+ Days', 'Detailed, localized personal history and autobiographical narrative nodes'],
          ['5. Semantic Memory', 'Extremely high', 'No decay (permanent)', 'Abstracted facts, concepts, rules, schemas, and structural associations'],
          ['6. Procedural Memory', 'Implicit skills', 'Permanent', 'Cognitive/motor habits, GOAP action patterns, routines, and skills'],
          ['7. Emotional Memory', 'Arousal-bound', 'Deep-seated permanent', 'Associated core affective states (trauma, extreme bliss, conditioned fears)']
        ]
      },
      {
        title: '2. Cognitive Memory Dynamics & Sleep Consolidation',
        content: 'Memories are dynamic structures undergoing active consolidation, distortion, and pruning. During the "Sleep Phase" (or macro-sim cycles), short-term buffers are swept, consolidating high-salience experiences into Episodic/Semantic layers, compressing details, and pruning junk. Under high Neuroticism or extreme threat, highly traumatic memories may be suppressed, while low-salience memories degrade, merging into composite "false memories".',
        equations: [
          'Memory Decay: R(t) = R_0 × e^(-λ × t)  (where λ is the decay constant, λ = ln(2) / H_L)',
          'Sleep Consolidation Rate: C_sleep = Agreeableness × SleepQuality × (1.0 + Arousal_Peak × 0.5)',
          'Distortion Rate (Composite Merging): M_dist = (1.0 - R(t)) × (1.0 + Neuroticism × 0.4) × Similarity_Score',
          'Traumatic Suppression: If Valence < -0.85 and Arousal > 0.8 and Neuroticism > 0.5: Active Memory is flagged as Suppressed (Recall probability drops by 90% unless triggered by related cue)'
        ]
      },
      {
        title: '3. Relationship-Bound Memory Nodes',
        content: 'NPC interpersonal dynamics are indexed directly through relationship-bound memory nodes. Rather than general global events, memories are tagged with directional entity IDs, logging meetings, arguments, kindness, and trust breaches. This direct associative history updates the directional Social Matrix.',
        matrices: [
          ['Relational Tag', 'Primary Triggers', 'Impact on Directional Social Vector'],
          ['First Meeting', 'Initial proximity encounter', 'Establishes baseline Trust, Respect, and Attraction based on O-C-E-A-N compatibility'],
          ['Acts of Kindness', 'Resource sharing, assistance, or high-agreeableness talk', 'ΔLove = +0.20 × A_A, ΔTrust = +0.15 × A_B'],
          ['Trust Breach / Betrayal', 'Unfilled transactions, hostile gossip, or broken GOAP plans', 'ΔTrust = -0.50, ΔRespect = -0.30, ΔConflict = +0.40'],
          ['Greatest Conflict', 'High-anger interactions or competitive goals', 'ΔConflict = +0.60, ΔLove = -0.35, increases relational Fear if dominance disparity']
        ]
      },
      {
        title: '4. Redesigned Context-Aware Memory Retrieval',
        content: 'To prevent simple, flat keyword matching, memory retrieval uses a multi-factor context-aware formula. When an NPC is in a situation, the probability of recalling a memory M depends on: Semantic similarity to the current query, Current Need deficit, Active GOAP Goals, Relationship context with nearby NPCs, Current Location, and Active PAD Emotion intensity.',
        equations: [
          'RetrievalScore(M) = [CosineSim(Query, M_vector) × w_sem] + [Need_Deficit_Match(M_cat, CurrentNeed) × w_need] + [Relationship_Match(M_entity, TargetNPC) × w_rel] + [Emotion_State_Congruency(M_valence, P) × w_emo]',
          'Emotional Recall Bias: High arousal (A) acts as a high-gain filter, boosting the recall probability of memories with extreme valence: P_recall(M) = BaseRecall × (1.0 + |M_valence| × Arousal)'
        ]
      }
    ]
  },
  {
    id: 'vol-3',
    volume: 'VOLUME III',
    title: 'Interpersonal & Relational Mathematics',
    subTitle: 'Mathematical formulation of the 9-vector social matrix and interaction dynamics.',
    sections: [
      {
        title: '1. The Directional Social Vector Matrix',
        content: 'Interpersonal relationships are stored as directional graphs. Agent A’s relationship vector toward Agent B contains 9 floating-point metrics. This matrix is updated following any direct interaction or through social gossip networks.',
        matrices: [
          ['Metric', 'Range', 'Key Behavioral Impact'],
          ['Love / Affinity', '[-1.0, 1.0]', 'Willingness to sacrifice financial resources for the other.'],
          ['Trust', '[-1.0, 1.0]', 'Likelihood of accepting information or trading assets without upfront payment.'],
          ['Respect', '[-1.0, 1.0]', 'Willingness to alter goals or beliefs based on their advice.'],
          ['Fear', '[0.0, 1.0]', 'Compliance under threat and avoidance when security drive is low.'],
          ['Jealousy', '[0.0, 1.0]', 'Propensity to experience tension during their economic success.'],
          ['Loyalty', '[0.0, 1.0]', 'Resistance to betraying secret information or leaving shared institutions.'],
          ['Dependency', '[0.0, 1.0]', 'Degree to which financial and social drives rely on this single agent.'],
          ['Forgiveness', '[0.0, 1.0]', 'Multiplicative decay factor for negative relational incidents.'],
          ['Conflict / Tension', '[0.0, 1.0]', 'Probability of micro-friction during conversation ticks.']
        ]
      },
      {
        title: '2. Social Interaction Resolver Formula',
        content: 'When two agents interact, the vector update is calculated based on the action type, context salience, their respective personalities, and the existing relationship state.',
        equations: [
          'ΔR_AB = f(Interaction, Context, P_A, P_B, R_AB)',
          'ΔTrust_AB = (BaseValue × (1.0 - Jealousy_BA)) × Agreeableness_A × Forgiveness_BA'
        ]
      }
    ]
  },
  {
    id: 'vol-4',
    volume: 'VOLUME IV',
    title: 'Child Development & Behavioral Formation',
    subTitle: 'Dynamics of personality trait vector shift from infancy to age 18.',
    sections: [
      {
        title: '1. Personality Plasticity Curve',
        content: 'Agents are born with random genetic temperaments. Over an 18-year timeline, their personality traits (OCEAN) adapt dynamically according to environmental pressures. Personality is highly plastic in infancy, rapidly solidifying as they reach young adulthood.',
        equations: [
          'Plasticity(Age) = 1.0 - (Age / 18.0)^2  (for Age ≤ 18)',
          'Plasticity(Age) = 0.02 (post-18, minimal stabilization adjustments)'
        ]
      },
      {
        title: '2. Interactive Peer & Parental Influences',
        content: 'Traits adapt in response to continuous inputs from parental attachments, family conflict, school environments, peer rejection, and childhood traumas. The influence weighting shifts heavily from parents to peers during adolescence.',
        equations: [
          'Influence_Parents(Age) = e^(-0.15 × Age)',
          'Influence_Peers(Age) = 1.0 - e^(-0.12 × Age)  (peaks during adolescence)'
        ]
      }
    ]
  },
  {
    id: 'vol-5',
    volume: 'VOLUME V',
    title: 'Micro-Economy & Recurring Financial Pressures',
    subTitle: 'Everyday cash flow dynamics, taxation, housing debt, and stress escalation.',
    sections: [
      {
        title: '1. Financial Ledger Integration',
        content: 'Agents exist in a fully simulated currency network. Every single financial interaction (rent, utilities, taxes, groceries, debt, salary) is recorded in a double-entry ledger. No money is printed; all funds must flow between systemic economic nodes.',
        equations: [
          'Cash_t = Cash_t-1 + Σ Income_items - Σ Fixed_Expenses - Variable_Expenses',
          'Rent_Due = BaseRent × InflationCoefficient',
          'Utilities_Due = FixedGridCost + (Usage_Rate × Consumption_Units)'
        ]
      },
      {
        title: '2. The Financial Stress Coefficient',
        content: 'When liquid capital falls below critical thresholds, financial anxiety acts as a high-weight override. This shifts the agent’s GOAP actions toward maximizing income, driving down the utility of resting, socializing, or self-actualization.',
        equations: [
          'Stress_Financial = 1.0 / [1.0 + (Cash / (1.5 × Monthly_Fixed_Costs))^2]',
          'UtilityMultiplier_Work = 1.0 + 3.5 × Stress_Financial',
          'UtilityMultiplier_Leisure = 1.0 - 0.9 × Stress_Financial'
        ]
      }
    ]
  },
  {
    id: 'vol-6',
    volume: 'VOLUME VI',
    title: 'Culture, Civic Life & Crowd Dynamics',
    subTitle: 'Elections, civic movements, community celebrations, and crowd attraction nodes.',
    sections: [
      {
        title: '1. Cultural Holidays & Festivals',
        content: 'The calendar system schedules periodic local and national events. These events inject temporary macro-goals into the GOAP systems of all regional agents. Businesses close, family affinity actions are prioritized, and community contact drives are satisfied in mass-gathering nodes.'
      },
      {
        title: '2. Democratic Elections & Civic Policy Shift',
        content: 'Every 24 in-game days (the equivalent of an electoral cycle), agents cast votes for local municipal councils. Agent votes are determined by their core political values, their own financial stress, and the perceived competency/trust metrics of running candidates.'
      }
    ]
  }
];
