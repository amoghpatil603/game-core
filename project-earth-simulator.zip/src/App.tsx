import { useState } from 'react';
import BibleReader from './components/BibleReader';
import NeedsSimulator from './components/NeedsSimulator';
import MemoryAffectiveSandbox from './components/MemoryAffectiveSandbox';
import RelationshipSandbox from './components/RelationshipSandbox';
import ChildDevelopment from './components/ChildDevelopment';
import MicroEconomy from './components/MicroEconomy';
import EarthEnvironmentSandbox from './components/EarthEnvironmentSandbox';
import RealEarthValidation from './components/RealEarthValidation';
import TerrainStreamingEngine from './components/TerrainStreamingEngine';
import GlobalCoordinateWorkbench from './components/GlobalCoordinateWorkbench';
import { HydrologyWorkbench } from './components/HydrologyWorkbench';
import { OceanWorkbench } from './components/OceanWorkbench';
import { ClimateWorkbench } from './components/ClimateWorkbench';
import { WeatherWorkbench } from './components/WeatherWorkbench';
import { BiomeWorkbench } from './components/BiomeWorkbench';
import { BIBLE_CHAPTERS } from './data/bibleData';
import { BookOpen, User, Brain, Users, GraduationCap, DollarSign, CheckCircle2, ChevronRight, AlertCircle, Globe, MapPin, Mountain, Anchor, Waves, Sun, CloudSun, Trees } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'needs' | 'memory' | 'relationships' | 'childhood' | 'economy' | 'bible' | 'environment' | 'real_earth' | 'terrain_streaming' | 'global_coords' | 'hydrology' | 'ocean' | 'climate' | 'weather' | 'biomes'>('biomes');
  const [signedOffChapters, setSignedOffChapters] = useState<string[]>(['vol-0']);

  const toggleSignOff = (chapterId: string) => {
    setSignedOffChapters((prev) => {
      if (prev.includes(chapterId)) {
        return prev.filter((id) => id !== chapterId);
      } else {
        return [...prev, chapterId];
      }
    });
  };

  const percentComplete = Math.round((signedOffChapters.length / BIBLE_CHAPTERS.length) * 100);

  return (
    <div className="min-h-screen radial-glow-background text-slate-100 flex flex-col font-sans selection:bg-pink-500/30 selection:text-white" id="app-root">
      {/* Upper header block */}
      <header className="glass-panel mx-6 mt-6 rounded-2xl shrink-0" id="app-header">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4" id="header-container">
          <div id="header-branding">
            <div className="flex items-center gap-2" id="branding-flex">
              <span className="text-[10px] bg-pink-600 text-white font-bold uppercase tracking-wider px-2 py-0.5 rounded-sm" id="badge-version">Phase 1.5</span>
              <span className="text-xs text-slate-400 font-bold tracking-widest font-mono" id="engine-spec-id">VERSION 2.1.0</span>
            </div>
            <h1 className="text-xl font-bold text-white tracking-tight font-serif mt-1 flex items-center gap-2" id="branding-title">
              PROJECT EARTH <span className="text-slate-600 font-normal font-sans">|</span> <span className="text-slate-400 font-normal font-sans text-sm">Human Simulation Workbench</span>
            </h1>
          </div>

          {/* Phase 1.5 Bible sign-off tracker */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center gap-4 max-w-sm w-full md:w-auto" id="bible-progress-tracker">
            <div className="shrink-0" id="progress-icon-container">
              <CheckCircle2 className="h-6 w-6 text-pink-500" id="progress-circle-icon" />
            </div>
            <div className="flex-1 min-w-0" id="progress-text">
              <div className="flex justify-between text-[11px] font-bold text-slate-400 mb-1" id="progress-labels">
                <span>Simulation Bible Approved</span>
                <span className="font-mono text-white">{percentComplete}%</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden w-40" id="progress-bar-bg">
                <div
                  className="h-full bg-gradient-to-r from-pink-500 to-indigo-500 transition-all duration-500 animate-pulse"
                  style={{ width: `${percentComplete}%` }}
                  id="progress-bar-fill"
                />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main navigation tabs bar */}
      <nav className="glass-panel mx-6 mt-4 rounded-xl sticky top-0 z-50 shrink-0" id="app-nav">
        <div className="max-w-7xl mx-auto px-4" id="nav-container">
          <div className="flex space-x-1 py-2 overflow-x-auto glass-scrollbar" id="nav-tabs-flex">
            {/* Needs Simulator Tab */}
            <button
              id="tab-btn-needs"
              onClick={() => setActiveTab('needs')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'needs'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <User className="h-4 w-4" /> Need & GOAP Simulator
            </button>

            {/* Memory & Affective Tab */}
            <button
              id="tab-btn-memory"
              onClick={() => setActiveTab('memory')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'memory'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <Brain className="h-4 w-4" /> Memory & Affective Dynamics
            </button>

            {/* Relationship tab */}
            <button
              id="tab-btn-relationships"
              onClick={() => setActiveTab('relationships')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'relationships'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <Users className="h-4 w-4" /> Interpersonal Matrix
            </button>

            {/* Childhood tab */}
            <button
              id="tab-btn-childhood"
              onClick={() => setActiveTab('childhood')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'childhood'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <GraduationCap className="h-4 w-4" /> Childhood Development
            </button>

            {/* Economy tab */}
            <button
              id="tab-btn-economy"
              onClick={() => setActiveTab('economy')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'economy'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <DollarSign className="h-4 w-4" /> Micro-Economy & Bills
            </button>

            {/* Environment tab */}
            <button
              id="tab-btn-environment"
              onClick={() => setActiveTab('environment')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'environment'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <Globe className="h-4 w-4" /> Earth Environment Engine
            </button>

            {/* Real Earth Data Validation Phase 3.5 Tab */}
            <button
              id="tab-btn-real-earth"
              onClick={() => setActiveTab('real_earth')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'real_earth'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <MapPin className="h-4 w-4 text-pink-400" /> Real Earth Validation (Phase 3.5)
            </button>

            {/* Real Earth Terrain Engine Phase 4 Tab */}
            <button
              id="tab-btn-terrain-streaming"
              onClick={() => setActiveTab('terrain_streaming')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'terrain_streaming'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <Mountain className="h-4 w-4 text-pink-400" /> Terrain Streaming Engine (Phase 4)
            </button>

            {/* Global Earth & UE5 Bridge Phase 4.5 Tab */}
            <button
              id="tab-btn-global-coords"
              onClick={() => setActiveTab('global_coords')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'global_coords'
                  ? 'bg-gradient-to-r from-indigo-500 to-pink-600 text-white shadow-md'
                  : 'text-indigo-300 hover:text-white hover:bg-indigo-500/10 border border-indigo-500/20'
              }`}
            >
              <Anchor className="h-4 w-4 text-indigo-400" /> Global Earth & UE5 Bridge (Phase 4.5)
            </button>

            {/* Hydrology & Water Surface Phase 5 Tab */}
            <button
              id="tab-btn-hydrology"
              onClick={() => setActiveTab('hydrology')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'hydrology'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                  : 'text-cyan-300 hover:text-white hover:bg-cyan-500/10 border border-cyan-500/20'
              }`}
            >
              <Waves className="h-4 w-4 text-cyan-400" /> Hydrology & Water Surface (Phase 5)
            </button>

            {/* Ocean & Coastal Simulation Phase 6 Tab */}
            <button
              id="tab-btn-ocean"
              onClick={() => setActiveTab('ocean')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'ocean'
                  ? 'bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-600 text-white shadow-md'
                  : 'text-cyan-200 hover:text-white hover:bg-cyan-500/20 border border-cyan-400/30'
              }`}
            >
              <Anchor className="h-4 w-4 text-cyan-300" /> Global Ocean & Coast (Phase 6)
            </button>

            {/* Global Atmospheric & Climate Engine Phase 7 Tab */}
            <button
              id="tab-btn-climate"
              onClick={() => setActiveTab('climate')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'climate'
                  ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-red-600 text-white shadow-md ring-1 ring-amber-400'
                  : 'text-amber-200 hover:text-white hover:bg-amber-500/20 border border-amber-400/30'
              }`}
            >
              <Sun className="h-4 w-4 text-amber-300" /> Atmospheric & Climate (Phase 7)
            </button>

            {/* Dynamic Weather & Atmospheric Simulation Phase 8 Tab */}
            <button
              id="tab-btn-weather"
              onClick={() => setActiveTab('weather')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'weather'
                  ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 text-white shadow-lg ring-1 ring-cyan-400'
                  : 'text-cyan-200 hover:text-white hover:bg-blue-600/20 border border-blue-400/30'
              }`}
            >
              <CloudSun className="h-4 w-4 text-cyan-300" /> Dynamic Weather Engine (Phase 8)
            </button>

            {/* Biomes & Ecological Succession Phase 9 Tab */}
            <button
              id="tab-btn-biomes"
              onClick={() => setActiveTab('biomes')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === 'biomes'
                  ? 'bg-gradient-to-r from-emerald-600 via-teal-600 to-green-500 text-white shadow-lg ring-1 ring-emerald-400'
                  : 'text-emerald-200 hover:text-white hover:bg-emerald-600/20 border border-emerald-400/30'
              }`}
            >
              <Trees className="h-4 w-4 text-emerald-300" /> Biomes & Ecology (Phase 9)
            </button>

            {/* Bible tab */}
            <button
              id="tab-btn-bible"
              onClick={() => setActiveTab('bible')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 relative whitespace-nowrap shrink-0 ${
                activeTab === 'bible'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <BookOpen className="h-4 w-4" /> Simulation Bible
              {signedOffChapters.length < BIBLE_CHAPTERS.length && (
                <span className="absolute top-1 right-1 h-1.5 w-1.5 bg-pink-500 rounded-full animate-pulse" id="bible-tab-badge" />
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Main display panel */}
      <main className="flex-1 max-w-7xl mx-auto px-6 py-8 w-full overflow-hidden" id="app-main-content">
        <div className="h-full" id="tab-content-container">
          {activeTab === 'needs' && <NeedsSimulator />}
          {activeTab === 'memory' && <MemoryAffectiveSandbox />}
          {activeTab === 'relationships' && <RelationshipSandbox />}
          {activeTab === 'childhood' && <ChildDevelopment />}
          {activeTab === 'economy' && <MicroEconomy />}
          {activeTab === 'environment' && <EarthEnvironmentSandbox />}
          {activeTab === 'real_earth' && <RealEarthValidation />}
          {activeTab === 'terrain_streaming' && <TerrainStreamingEngine />}
          {activeTab === 'global_coords' && <GlobalCoordinateWorkbench />}
          {activeTab === 'hydrology' && <HydrologyWorkbench />}
          {activeTab === 'ocean' && <OceanWorkbench />}
          {activeTab === 'climate' && <ClimateWorkbench />}
          {activeTab === 'weather' && <WeatherWorkbench />}
          {activeTab === 'biomes' && <BiomeWorkbench />}
          {activeTab === 'bible' && (
            <BibleReader signedOffChapters={signedOffChapters} toggleSignOff={toggleSignOff} />
          )}
        </div>
      </main>

      {/* Persistent global footer */}
      <footer className="glass-panel mx-6 mb-6 rounded-2xl py-4 shrink-0 text-center" id="app-footer">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center text-slate-400 text-xs gap-2" id="footer-container">
          <div className="flex items-center gap-2" id="footer-left">
            <AlertCircle className="h-3.5 w-3.5 text-pink-500 shrink-0" />
            <span>Project Earth C++ & GIS System Design Specification Draft</span>
          </div>
          <span id="footer-right">Confidential Specification Document • Phase 1.5 Active</span>
        </div>
      </footer>
    </div>
  );
}
