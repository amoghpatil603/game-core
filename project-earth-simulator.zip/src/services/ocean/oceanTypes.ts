/**
 * Project Earth: Phase 6 Global Ocean & Coastal Simulation Engine
 * Type Definitions & Architectural Interfaces
 * 
 * Canonical standards for:
 * - Bathymetry and Seafloor Terrain
 * - Coastline Geometry & Land-Ocean Boundaries
 * - Geoid, Mean Sea Level (MSL), and Instantaneous Sea Surface Height (SSH)
 * - Astronomical Harmonic Tides (M2, S2, N2, K1, O1)
 * - Hierarchical Ocean Current Vector Fields (Global Gyres, Boundary Currents, Local Plumes)
 * - Vertical Thermohaline Stratification & UNESCO Seawater Equation of State
 * - River-to-Ocean Estuary Influx & Salinity Dilution Plumes (Extending Phase 5)
 * - Shallow-Water Wave Transformation & Shoaling Dynamics
 * - Compound Coastal Flood & Storm Surge Interface (Phase 8 Atmospheric Contract)
 * - Sea Ice Thermodynamic Coverage & Marine Ecological Biome Descriptors (Phase 7/9/10 Contracts)
 * - Multi-Tier Simulation Ticks, LOD, and Streaming Tile Budgets
 */

import { WGS84GlobalCoord, ECEFCoord, ENUCoord } from '../coordinates/globalCoordinateEngine';
import { RiverSegment, WatershedBasin } from '../hydrology/hydrologyTypes';

export type OceanSimulationTier = 0 | 1 | 2 | 3;
// Tier 0: Local 60Hz Water Surface, Dynamic Wave Displacements, Surf Breaking (< 1 km from camera)
// Tier 1: Regional 10Hz Coastal Dynamics, Tidal Surge, Estuary Mixing (< 25 km)
// Tier 2: Basin-Scale 1Hz Ocean Currents, Thermohaline Circulation, Sea Ice Boundary (< 250 km)
// Tier 3: Macro Planetary 0.1Hz Global Thermohaline Circulation & Seasonal Astronomical Cycles

export type SeafloorFeatureType = 
  | 'ContinentalShelf'
  | 'ContinentalSlope'
  | 'ContinentalRise'
  | 'AbyssalPlain'
  | 'MidOceanRidge'
  | 'OceanTrench'
  | 'Seamount'
  | 'SubmarineCanyon'
  | 'Guyot'
  | 'AtollLagoon';

export type CoastlineType =
  | 'RockyCliff'
  | 'SandyBeach'
  | 'TidalMudflat'
  | 'Estuary'
  | 'RiverDelta'
  | 'MangroveSwamp'
  | 'Fjord'
  | 'BarrierIsland'
  | 'CoralReefLagoon';

export type TidalRegimeType = 
  | 'Semidiurnal'       // Two nearly equal high and low tides daily (e.g. Atlantic, UK, Bay of Fundy)
  | 'MixedSemidiurnal'  // Two unequal high and low tides daily (e.g. US West Coast, Columbia River, Pacific)
  | 'Diurnal';          // One high and one low tide daily (e.g. Gulf of Mexico, South China Sea)

export interface BathymetryPoint {
  id: string;
  coord: WGS84GlobalCoord;
  ecef?: ECEFCoord;
  depthMeters: number;             // Positive depth below Mean Sea Level (m)
  elevationMeters: number;         // Negative elevation relative to WGS84 ellipsoid / geoid (m)
  featureType: SeafloorFeatureType;
  slopeDegrees: number;
  sedimentThicknessMeters: number;
  crustalAgeMillionYears?: number;
  isRealData: boolean;             // True if sampled from GEBCO / NOAA ETOPO, false if synthetic fixture
}

export interface CoastlineSegment {
  id: string;
  name: string;
  coastType: CoastlineType;
  vertices: WGS84GlobalCoord[];
  lengthKm: number;
  meanIntertidalSlope: number;     // tan(theta)
  tidalRangeSpringMeters: number;
  tidalRangeNeapMeters: number;
  dominantWaveEnergy: 'High' | 'Moderate' | 'Sheltered';
  sedimentGrainSizeMm: number;
  coastalErosionRateMYear: number;
  hasDatelineCrossing: boolean;
}

export interface HarmonicTidalConstituent {
  symbol: string;        // 'M2', 'S2', 'N2', 'K1', 'O1', etc.
  name: string;          // e.g. 'Principal Lunar Semidiurnal'
  angularSpeedDegHour: number; // Degrees per solar hour (e.g. M2 = 28.9841042 deg/hr)
  periodHours: number;   // 360 / angular speed (e.g. M2 = 12.4206 hrs)
  amplitudeMeters: number; // Station-specific constituent amplitude H
  phaseLagDegrees: number; // Greenwich epoch phase lag G
}

export interface TideStationBenchmark {
  stationId: string;
  stationName: string;
  location: WGS84GlobalCoord;
  regime: TidalRegimeType;
  meanTidalRangeMeters: number;
  springTidalRangeMeters: number;
  neapTidalRangeMeters: number;
  highestAstronomicalTideMeters: number;
  lowestAstronomicalTideMeters: number;
  constituents: HarmonicTidalConstituent[];
  noaaStationId?: string;
  referenceSource: string;
  isRealData: boolean;
}

export interface OceanCurrentVector {
  uEastMS: number;       // Zonal velocity (+ = East, - = West) in m/s
  vNorthMS: number;     // Meridional velocity (+ = North, - = South) in m/s
  wVerticalMS: number;   // Upwelling/downwelling velocity in m/s
  speedMS: number;       // Magnitude = sqrt(u^2 + v^2)
  directionDeg: number;  // Compass heading toward which current flows [0, 360)
  depthMeters: number;   // Depth layer of vector (0 = surface)
}

export interface ThermohalineProfilePoint {
  depthMeters: number;
  temperatureCelsius: number;
  salinityPSU: number;            // Practical Salinity Units (g/kg salt)
  pressureDecibars: number;       // Approx ~ depth (m) * 1.01
  densityKgM3: number;            // Derived from UNESCO 1980 Equation of State
  potentialDensityAnomalySigma: number; // sigma_t = density - 1000 kg/m³
  soundSpeedMS: number;           // UNESCO / Mackenzie acoustic speed
  lightPenetrationPercent: number;// Beer-Lambert attenuation of PAR irradiance
}

export interface OceanStratificationColumn {
  pointId: string;
  location: WGS84GlobalCoord;
  seaSurfaceHeightMeters: number; // Instantaneous dynamic topography
  mixedLayerDepthMeters: number;  // Epipelagic turbulent mixed zone
  thermoclineTopDepthMeters: number;
  thermoclineBottomDepthMeters: number;
  deepWaterTemperatureC: number;
  deepWaterSalinityPSU: number;
  profile: ThermohalineProfilePoint[];
}

export interface RiverToOceanEstuaryPlume {
  estuaryId: string;
  name: string;
  connectedRiverSegmentId: string;
  connectedBasinId: string;
  riverMouthCoord: WGS84GlobalCoord;
  riverDischargeM3S: number;      // Influx from Phase 5 Hydrology DAG
  riverWaterTempC: number;
  riverSedimentKgS: number;
  estuaryType: 'SaltWedge' | 'PartiallyMixed' | 'WellMixed' | 'FjordEstuary';
  plumeLengthKm: number;
  plumeWidthKm: number;
  salinityGradientPSUPerKm: number;
  surfaceSalinityMouthPSU: number;
  oceanAmbientSalinityPSU: number;
  coastalCurrentInteractionAngleDeg: number;
}

export interface WaveSpectrumParameters {
  significantWaveHeightMeters: number; // H_s
  peakWavePeriodSeconds: number;       // T_p
  meanWaveDirectionDeg: number;        // Compass direction waves are travelling towards
  wavelengthMeters: number;            // L
  waveCelerityMS: number;              // c = L / T
  waveSteepness: number;               // H / L
  isShallowWater: boolean;             // d / L < 0.05 (shallow) or d / L > 0.5 (deep)
  surfBreakingZoneWidthMeters: number;
  breakerType: 'Spilling' | 'Plunging' | 'Surging' | 'Collapsing';
}

export interface CoastalStormSurgeState {
  astronomicalTideMeters: number;
  barometricPressureInvertedMeters: number; // Static inverse barometer (~ +1 cm per -1 hPa from 1013.25)
  windSetUpmMeters: number;                // Wind stress pushing water against coastal bathymetry
  waveSetUpmMeters: number;                // Radiation stress from breaking surf
  riverOutflowBackwaterMeters: number;     // Hydrodynamic backup during storm peak
  totalWaterLevelMeters: number;           // Sum of all components above MSL
  inundationRiskLevel: 'None' | 'Advisory' | 'Moderate' | 'Severe' | 'Catastrophic';
}

export interface SeaIceState {
  iceCoverageFraction: number;    // 0.0 (open water) to 1.0 (pack ice)
  iceThicknessMeters: number;     // Sea ice thickness (0 to 4.5m)
  snowCoverThicknessMeters: number;
  iceSurfaceTemperatureC: number;
  freezingPointSeawaterC: number; // T_f = -0.0575 * S + ... ~ -1.8°C
  iceType: 'OpenWater' | 'GreaseIce' | 'Nilas' | 'PancakeIce' | 'FirstYearIce' | 'MultiYearPack';
  albedo: number;                 // 0.06 for ocean to 0.85 for snow-covered pack ice
}

export interface MarineBiomeDescriptor {
  depthZone: 'Epipelagic_Photic' | 'Mesopelagic_Twilight' | 'Bathypelagic_Midnight' | 'Abyssal' | 'Hadal_Trench';
  benthicSubstrate: 'HardRock' | 'Sand' | 'Mud_Silt' | 'BiogenicOoze' | 'HydrothermalVent';
  photosyntheticActiveRadiationPercent: number;
  dissolvedOxygenMLPerL: number;
  primaryProductivityProxyGCM2Year: number;
  distanceFromCoastKm: number;
  habitatClassification: 'KelpForest' | 'CoralReef' | 'PelagicOpenOcean' | 'DeepBenthicPlains' | 'AbyssalChemosynthetic' | 'CoastalUpwellingZone';
}

export interface OceanTileCoordinate {
  zoomLOD: number; // 0 = Global (1 tile), 1 = Hemispheres, 2 = Basins, 3 = Regional Seas, 4 = Coastal detail
  tileX: number;
  tileY: number;
}

export interface OceanTileData {
  tileCoord: OceanTileCoordinate;
  boundsWGS84: {
    minLat: number;
    maxLat: number;
    minLng: number;
    maxLng: number;
  };
  gridResolution: number; // e.g. 16x16 or 32x32 nodes per tile
  bathymetryMatrix: number[][]; // Depth in meters (positive = ocean depth, negative = land elevation)
  currentVectorMatrix: { u: number; v: number }[][];
  surfaceTempMatrix: number[][];
  surfaceSalinityMatrix: number[][];
  isCoastal: boolean;
  hasSeaIce: boolean;
  memorySizeBytes: number;
  lastAccessTimestamp: number;
  status: 'LOADED' | 'STREAMING' | 'EVICTED';
}

export interface OceanMemoryBudget {
  bathymetryRAMBytes: number;
  currentFieldRAMBytes: number;
  thermohalineRAMBytes: number;
  coastalGeometryRAMBytes: number;
  waveSimulationRAMBytes: number;
  activeTilesCount: number;
  maxAllocatedTiles: number;
  totalOceanRAMBytes: number;
  maxRAMBudgetBytes: number; // Default 64 MB for prototype
  cacheHitRatePercent: number;
}
