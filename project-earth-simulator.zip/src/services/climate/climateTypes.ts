/**
 * Project Earth: Phase 7 Global Atmospheric & Climate Engine Types
 * 
 * Defines mathematical, physical, and computational interfaces for:
 * - Planetary Solar Insolation & Astronomical Geometry
 * - Radiative Energy Balance & Surface Albedo
 * - Temperature Climatology & Environmental Lapse Rates
 * - Atmospheric Pressure Fields & Hypsometric Levels
 * - Global Planetary Circulation (Hadley, Ferrel, Polar cells, ITCZ, Jet Streams)
 * - Wind Climatology (Trade Winds, Westerlies, Polar Easterlies)
 * - Humidity, Vapor Pressure & Potential Evaporation
 * - Precipitation Climatology & Orographic Mountain Rain Shadow
 * - Snow, Ice & Cryosphere Baseline State
 * - Cloud Fraction Climatology
 * - Deterministic Köppen-Geiger 30-Category Climate Classification Tree
 * - Hydrology (Phase 5) and Ocean (Phase 6) Multi-Physics Coupling
 * - Climate Tile Streaming, LOD Hierarchies & LRU Caching
 * - Multi-Tier Decoupled Simulation Execution (Tier 0..3)
 * - Phase 8 Dynamic Weather Interface Contract
 */

import { WGS84GlobalCoord } from '../coordinates/globalCoordinateEngine';
import { OceanStratificationColumn, ThermohalineProfilePoint } from '../ocean/oceanTypes';

export type ClimateDataClassification = 
  | 'REAL_DATA'
  | 'MODEL_DERIVED'
  | 'INTERPOLATED'
  | 'APPROXIMATION'
  | 'SYNTHETIC_TEST_FIXTURE';

export type SurfaceAlbedoType = 
  | 'OCEAN_OPEN_WATER'
  | 'OCEAN_SEA_ICE'
  | 'SNOW_FRESH'
  | 'SNOW_OLD_FIRN'
  | 'FOREST_CONIFEROUS'
  | 'FOREST_DECIDUOUS'
  | 'GRASSLAND_SAVANNA'
  | 'DESERT_SAND_ROCK'
  | 'TUNDRA_PERMAFROST'
  | 'AGRICULTURAL_CROPS'
  | 'URBAN_BUILT';

export type KoppenMajorGroup = 'A' | 'B' | 'C' | 'D' | 'E';

export type KoppenClimateCode = 
  | 'Af'  // Tropical rainforest
  | 'Am'  // Tropical monsoon
  | 'Aw'  // Tropical savanna
  | 'BWh' // Hot desert
  | 'BWk' // Cold desert
  | 'BSh' // Hot semi-arid (steppe)
  | 'BSk' // Cold semi-arid (steppe)
  | 'Csa' // Hot-summer Mediterranean
  | 'Csb' // Warm-summer Mediterranean
  | 'Csc' // Cold-summer Mediterranean
  | 'Cfa' // Humid subtropical
  | 'Cfb' // Oceanic (temperate marine)
  | 'Cfc' // Subpolar oceanic
  | 'Cwa' // Monsoon-influenced humid subtropical
  | 'Cwb' // Subtropical highland
  | 'Cwc' // Cold subtropical highland
  | 'Dfa' // Hot-summer humid continental
  | 'Dfb' // Warm-summer humid continental
  | 'Dfc' // Subarctic / Taiga
  | 'Dfd' // Extremely cold subarctic
  | 'Dwa' // Monsoon-influenced hot-summer continental
  | 'Dwb' // Monsoon-influenced warm-summer continental
  | 'Dwc' // Monsoon-influenced subarctic
  | 'Dwd' // Monsoon-influenced extremely cold subarctic
  | 'Dsa' // Mediterranean-influenced hot-summer continental
  | 'Dsb' // Mediterranean-influenced warm-summer continental
  | 'Dsc' // Mediterranean-influenced subarctic
  | 'Dsd' // Mediterranean-influenced extremely cold subarctic
  | 'ET'  // Tundra
  | 'EF'; // Ice cap / Polar perpetual frost

export interface SolarForcingState {
  dayOfYear: number; // 1 to 365.25
  solarDeclinationDeg: number; // -23.44° to +23.44°
  solarHourAngleDeg: number; // -180° to +180°
  solarElevationDeg: number; // -90° to +90°
  solarAzimuthDeg: number; // 0° to 360°
  dayLengthHours: number; // 0.0 to 24.0
  isPolarDay: boolean;
  isPolarNight: boolean;
  topOfAtmosphereInsolationWm2: number; // Solar Constant ~1361 W/m² modulated by eccentricity
  surfaceDirectInsolationWm2: number;
  surfaceDiffuseInsolationWm2: number;
  totalSurfaceInsolationWm2: number;
  atmosphericTransmissivity: number; // 0.0 to 1.0 (clear sky vs baseline aerosol/air mass)
}

export interface RadiativeEnergyBalance {
  incomingSolarShortwaveWm2: number;
  reflectedShortwaveWm2: number;
  surfaceAlbedo: number; // 0.0 to 1.0
  netShortwaveAbsorbedWm2: number;
  outgoingLongwaveRadiationWm2: number; // Stefan-Boltzmann sigma * T^4 modified by greenhouse
  atmosphericBackRadiationWm2: number;
  netRadiativeFluxWm2: number; // Rn = SW_net - LW_net
  sensibleHeatFluxWm2: number;
  latentHeatFluxWm2: number;
  groundOceanHeatStorageWm2: number;
}

export interface TemperatureClimateState {
  meanAnnualTemperatureC: number;
  monthlyMeanTemperatureC: number[]; // 12 months (Jan=0 .. Dec=11)
  currentDayMeanTemperatureC: number;
  diurnalTemperatureRangeC: number;
  minMonthlyTemperatureC: number;
  maxMonthlyTemperatureC: number;
  annualThermalAmplitudeC: number; // T_max - T_min (Continentality index)
  seaLevelEquivalentTemperatureC: number;
  elevationMeters: number;
  environmentalLapseRateCPerKm: number; // Standard -6.5 °C/km
  maritimeModerationFactor: number; // 0.0 (ultra-continental) to 1.0 (pure oceanic)
  seaSurfaceTemperatureC?: number;
}

export interface AtmosphericPressureState {
  surfacePressureHPa: number; // Standard MSL is 1013.25 hPa
  seaLevelPressureHPa: number;
  pressureLevel850hPaAltitudeM: number; // Geopotential height ~1500m
  pressureLevel500hPaAltitudeM: number; // Geopotential height ~5500m
  pressureLevel300hPaAltitudeM: number; // Jet stream level ~9000m
  dominantPressureSystem: 'EQUATORIAL_LOW_ITCZ' | 'SUBTROPICAL_HIGH' | 'SUBPOLAR_LOW' | 'POLAR_HIGH' | 'THERMAL_CONTINENTAL_LOW' | 'SIBERIAN_CANADIAN_HIGH';
}

export interface CirculationCellState {
  primaryCell: 'HADLEY' | 'FERREL' | 'POLAR';
  itczLatitudeDeg: number; // Seasonal migration -10° to +15°
  distanceToItczDeg: number;
  subtropicalRidgeLatitudeDeg: number; // ~30° N/S
  polarFrontLatitudeDeg: number; // ~60° N/S
  tradeWindStrengthMS: number;
  westerliesStrengthMS: number;
  polarEasterliesStrengthMS: number;
}

export interface JetStreamClimatology {
  subtropicalJetLatitudeDeg: number; // ~28° to 35°
  subtropicalJetSpeedMS: number; // 30 - 65 m/s at 200 hPa
  polarFrontJetLatitudeDeg: number; // ~45° to 65°
  polarFrontJetSpeedMS: number; // 25 - 80 m/s at 300 hPa
  jetAltitudeMeters: number;
  zonalFlowDirectionDeg: number; // Predominantly 270° (Westerly)
}

export interface WindClimatologyState {
  meanAnnualSpeedMS: number;
  meanMonthlySpeedMS: number[]; // 12 months
  prevailingDirectionDeg: number; // 0 to 360°
  zonalWindComponentUMS: number; // Eastward (+) / Westward (-)
  meridionalWindComponentVMS: number; // Northward (+) / Southward (-)
  windRegime: 'NORTHEAST_TRADES' | 'SOUTHEAST_TRADES' | 'DOLDRUMS_ITCZ' | 'ROARING_FORTIES_WESTERLIES' | 'NORTHERN_WESTERLIES' | 'POLAR_EASTERLIES' | 'COASTAL_SEA_BREEZE';
}

export interface HumidityClimateState {
  relativeHumidityPercent: number; // 0 to 100%
  specificHumidityGKg: number; // g water vapor / kg moist air
  dewPointTemperatureC: number;
  actualVaporPressureHPa: number;
  saturationVaporPressureHPa: number; // Tetens equation
  vaporPressureDeficitHPa: number;
}

export interface EvaporationClimateState {
  potentialEvapotranspirationMmDay: number; // PET (Priestley-Taylor / Penman formulation)
  annualPotentialEvapotranspirationMm: number;
  actualEvapotranspirationMmDay: number; // AET limited by soil & water availability
  evaporativeFraction: number; // AET / PET (Aridity index)
  oceanEvaporationRateMmDay: number;
}

export interface PrecipitationClimateState {
  annualPrecipitationMm: number;
  monthlyPrecipitationMm: number[]; // 12 months
  currentMonthPrecipitationMm: number;
  convectivePrecipitationMm: number;
  stratiformPrecipitationMm: number;
  orographicPrecipitationMultiplier: number; // > 1.0 windward, < 1.0 leeward rain shadow
  snowfallEquivalentMm: number;
  precipitationRegime: 'ALL_YEAR_WET' | 'SUMMER_MONSOON_WET' | 'WINTER_MEDITERRANEAN_WET' | 'ARID_PERPETUAL_DRY' | 'POLAR_NIVAL';
  wettestMonthIndex: number;
  driestMonthIndex: number;
  isRainShadow: boolean;
}

export interface WaterBalanceState {
  precipitationMinusPETMm: number; // P - PET (> 0 humid surplus, < 0 arid deficit)
  soilMoistureStorageIndex: number; // 0.0 to 1.0
  surfaceRunoffPotentialMm: number;
  climateAridityIndex: number; // P / PET (Budyko classification)
  hydrologyCouplingRechargeM3S: number;
}

export interface SnowCryosphereClimateState {
  permanentSnowLineElevationMeters: number; // Equilibrium Line Altitude (ELA)
  annualSnowCoverDays: number; // 0 to 365
  meanSnowDepthMeters: number;
  isGlaciatedOrPermanentIce: boolean;
  permafrostProbabilityFraction: number; // 0.0 to 1.0
  seasonalFreezingDegreeDays: number; // Cumulative FDD
  seasonalThawingDegreeDays: number; // Cumulative TDD
}

export interface CloudClimatologyState {
  annualMeanCloudFraction: number; // 0.0 to 1.0
  monthlyCloudFraction: number[]; // 12 months
  dominantCloudType: 'TROPICAL_CUMULUS_ITCZ' | 'STRATOCUMULUS_MARINE' | 'CIRRUS_HIGH_ALTITUDE' | 'STRATUS_OVERCAST_POLAR' | 'CLEAR_SKY_SUBTROPICAL';
}

export interface KoppenGeigerClassificationResult {
  code: KoppenClimateCode;
  majorGroup: KoppenMajorGroup;
  title: string;
  description: string;
  derivedFrom: {
    meanAnnualTempC: number;
    coldestMonthTempC: number;
    warmestMonthTempC: number;
    monthsAbove10C: number;
    annualPrecipMm: number;
    summerPrecipMm: number;
    winterPrecipMm: number;
    driestSummerPrecipMm: number;
    driestWinterPrecipMm: number;
    precipitationThresholdPThresh: number;
  };
  provenance: ClimateDataClassification;
}

export interface ClimateTileData {
  tileId: string;
  lodLevel: number;
  bounds: {
    minLat: number;
    maxLat: number;
    minLon: number;
    maxLon: number;
  };
  resolutionDeg: number;
  centerCoord: WGS84GlobalCoord;
  temperatureField: Float32Array; // 12-month or seasonal grids
  precipitationField: Float32Array;
  pressureField: Float32Array;
  windSpeedField: Float32Array;
  koppenCode: KoppenClimateCode;
  datasetProvenance: string;
  dataClassification: ClimateDataClassification;
  lastAccessTimestamp: number;
  memorySizeBytes: number;
}

export interface ClimateBenchmarkStation {
  id: string;
  name: string;
  region: string;
  location: WGS84GlobalCoord;
  elevationMeters: number;
  expectedKoppen: KoppenClimateCode;
  annualMeanTempC: number;
  annualPrecipMm: number;
  monthlyTemperaturesC: number[];
  monthlyPrecipitationMm: number[];
  provenance: string;
  classification: ClimateDataClassification;
}

export interface ClimateAnomalyState {
  temperatureAnomalyC: number; // Deviation from 30-year climatological baseline
  precipitationAnomalyPercent: number; // e.g. -40% (drought) or +120% (flood)
  standardizedPrecipitationIndex: number; // SPI (-3.0 extreme dry to +3.0 extreme wet)
  palmerDroughtSeverityIndex: number; // PDSI
  climateOscillationIndex: {
    ensoPhase: 'EL_NINO' | 'LA_NINA' | 'NEUTRAL';
    naoPhase: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
    pdoPhase: 'WARM' | 'COOL' | 'NEUTRAL';
  };
}

export interface Phase8ClimateInterfaceContract {
  GetClimateState(coord: WGS84GlobalCoord, dayOfYear: number): {
    solar: SolarForcingState;
    temperature: TemperatureClimateState;
    pressure: AtmosphericPressureState;
    wind: WindClimatologyState;
    humidity: HumidityClimateState;
    evaporation: EvaporationClimateState;
    precipitation: PrecipitationClimateState;
    clouds: CloudClimatologyState;
    koppen: KoppenGeigerClassificationResult;
  };
  GetTemperatureClimate(coord: WGS84GlobalCoord, dayOfYear: number): number;
  GetPrecipitationClimate(coord: WGS84GlobalCoord, monthIndex: number): number;
  GetHumidityClimate(coord: WGS84GlobalCoord, dayOfYear: number): number;
  GetPressureClimate(coord: WGS84GlobalCoord, altitudeMeters: number): number;
  GetWindClimatology(coord: WGS84GlobalCoord, monthIndex: number): { speedMS: number; directionDeg: number };
  GetSolarForcing(coord: WGS84GlobalCoord, dayOfYear: number, hourUtc: number): SolarForcingState;
  GetCloudClimatology(coord: WGS84GlobalCoord, monthIndex: number): number;
  GetClimateClassification(coord: WGS84GlobalCoord): KoppenGeigerClassificationResult;
  GetClimateAnomaly(coord: WGS84GlobalCoord, dayOfYear: number): ClimateAnomalyState;
  GetOceanInfluence(coord: WGS84GlobalCoord): { sstC: number; maritimeIndex: number; marineCurrentCoolingWarmingC: number };
  GetTerrainInfluence(coord: WGS84GlobalCoord): { lapseRateDeltaC: number; orographicMultiplier: number; rainShadowActive: boolean };
}
