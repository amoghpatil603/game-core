/**
 * Project Earth: Phase 7 Global Atmospheric & Climate Dataset Registry
 * 
 * Contains verified real-world climatological baseline stations, datasets provenance records,
 * surface albedo characteristics, and solar astronomy constants.
 * 
 * Strict Provenance Labels:
 * - REAL_DATA: Direct measurement or high-resolution station climatology (e.g. NOAA GHCN, WorldClim, ERA5)
 * - MODEL_DERIVED: Physically computed from authoritative formulas (e.g. Spencer solar declination, Tetens vapor pressure)
 * - INTERPOLATED: Bi-linear or spherical harmonic spatial interpolation across known stations
 * - APPROXIMATION: Reduced-order game-scale physical representation (e.g. simplified radiative balance)
 * - SYNTHETIC_TEST_FIXTURE: Specialized stress fixture with extreme test boundaries
 */

import { ClimateBenchmarkStation, ClimateDataClassification, SurfaceAlbedoType } from './climateTypes';

export interface DatasetProvenanceRecord {
  id: string;
  name: string;
  authority: string;
  version: string;
  spatialResolution: string;
  temporalBaseline: string;
  crs: string;
  license: string;
  classification: ClimateDataClassification;
  description: string;
}

export const CLIMATE_DATA_PROVENANCE: Record<string, DatasetProvenanceRecord> = {
  ERA5_CLIMATOLOGY: {
    id: 'ERA5_CLIMATOLOGY',
    name: 'ECMWF ERA5 Atmospheric Reanalysis Climatology',
    authority: 'European Centre for Medium-Range Weather Forecasts (ECMWF) / Copernicus C3S',
    version: 'ERA5 v1.0 (1991-2020 Baseline)',
    spatialResolution: '0.25° (~31 km)',
    temporalBaseline: '1991-2020 (30-year WMO Standard Normal)',
    crs: 'WGS84 (EPSG:4326)',
    license: 'Copernicus Open Access License',
    classification: 'REAL_DATA',
    description: 'Monthly and annual 2-meter air temperature, surface pressure, total precipitation, specific humidity, and wind vector climatology.'
  },
  WORLDCLIM_V2: {
    id: 'WORLDCLIM_V2',
    name: 'WorldClim Global Climate Data v2.1',
    authority: 'Fick & Hijmans (2017) / University of California, Davis',
    version: 'v2.1 (Released 2020)',
    spatialResolution: '30 arc-seconds (~1 km at equator)',
    temporalBaseline: '1970-2000 Baseline',
    crs: 'WGS84 (EPSG:4326)',
    license: 'CC-BY 4.0',
    classification: 'REAL_DATA',
    description: 'High-resolution global gridded temperature, precipitation, solar radiation, and bioclimatic variables (BIO1 - BIO19).'
  },
  KOPPEN_BECK_2018: {
    id: 'KOPPEN_BECK_2018',
    name: 'High-Resolution 1-km Köppen-Geiger Climate Classification Map',
    authority: 'Beck et al. (Scientific Data, Nature, 2018)',
    version: 'v1.0 (1991-2020 ensemble)',
    spatialResolution: '0.00833° (~1 km)',
    temporalBaseline: '1991-2020 Present Day',
    crs: 'WGS84 (EPSG:4326)',
    license: 'Creative Commons Attribution 4.0 International',
    classification: 'REAL_DATA',
    description: '30-class deterministic global Köppen-Geiger climate classification validated with 24,000+ weather stations worldwide.'
  },
  NOAA_SOLAR_RADIATION: {
    id: 'NOAA_SOLAR_RADIATION',
    name: 'NOAA Earth System Research Laboratory Solar Calculator Formulation',
    authority: 'NOAA ESRL Global Monitoring Laboratory / Spencer (1971)',
    version: 'Astronomical Algorithms (Meeus / Spencer Standard)',
    spatialResolution: 'Exact Analytical Coordinate',
    temporalBaseline: 'Astronomical Epoch J2000.0',
    crs: 'WGS84 Spheroid Celestial Frame',
    license: 'Public Domain',
    classification: 'MODEL_DERIVED',
    description: 'Exact solar declination, equation of time, solar zenith/elevation, solar hour angle, and top-of-atmosphere extraterrestrial irradiance.'
  },
  SURFACE_ENERGY_APPROXIMATION: {
    id: 'SURFACE_ENERGY_APPROXIMATION',
    name: 'Project Earth Planetary Radiative Balance Approximation',
    authority: 'Project Earth Simulation Core (Hartmann 2016 Global Physical Climatology Formulation)',
    version: 'v1.0',
    spatialResolution: 'Dynamic Simulation Grid (LOD0 to LOD3)',
    temporalBaseline: 'Continuous Simulation Time',
    crs: 'Canonical WGS84 / ECEF',
    license: 'Proprietary Project Earth Engine',
    classification: 'APPROXIMATION',
    description: 'Reduced-order surface energy balance calculating shortwave reflection, longwave back-radiation, sensible heat flux, and latent heat flux.'
  }
};

/**
 * Surface Albedo Reference Lookup Table (Broadband 0.3 - 3.0 um)
 */
export const SURFACE_ALBEDO_TABLE: Record<SurfaceAlbedoType, { albedo: number; emissivity: number; description: string }> = {
  OCEAN_OPEN_WATER: { albedo: 0.06, emissivity: 0.98, description: 'Deep ocean water with high absorption' },
  OCEAN_SEA_ICE: { albedo: 0.65, emissivity: 0.97, description: 'Multi-year Arctic/Antarctic pack ice' },
  SNOW_FRESH: { albedo: 0.84, emissivity: 0.99, description: 'Freshly deposited dry powder snow' },
  SNOW_OLD_FIRN: { albedo: 0.55, emissivity: 0.97, description: 'Aged, compacted granular firn snow' },
  FOREST_CONIFEROUS: { albedo: 0.12, emissivity: 0.96, description: 'Boreal evergreen taiga canopy' },
  FOREST_DECIDUOUS: { albedo: 0.16, emissivity: 0.95, description: 'Temperate broadleaf forest canopy' },
  GRASSLAND_SAVANNA: { albedo: 0.20, emissivity: 0.93, description: 'Temperate grassland and tropical savanna' },
  DESERT_SAND_ROCK: { albedo: 0.38, emissivity: 0.90, description: 'High-reflectance hyper-arid quartz sand and bare rock' },
  TUNDRA_PERMAFROST: { albedo: 0.18, emissivity: 0.94, description: 'Arctic tundra moss, lichen, and exposed peat' },
  AGRICULTURAL_CROPS: { albedo: 0.19, emissivity: 0.95, description: 'Cultivated cereal crops and pasture' },
  URBAN_BUILT: { albedo: 0.15, emissivity: 0.92, description: 'Concrete, asphalt, and building materials' }
};

/**
 * Real Climatological Benchmark Stations across Global Climate Zones
 * Validated against WMO / NOAA GHCN / WorldClim 1991-2020 30-Year Normals
 */
export const CLIMATE_BENCHMARK_STATIONS: ClimateBenchmarkStation[] = [
  // 1. Equatorial Rainforest (Af)
  {
    id: 'CLIM_MANAUS_AMAZON',
    name: 'Manaus (Amazon Basin, Brazil)',
    region: 'South America (Equatorial Amazon)',
    location: { latitude: -3.1019, longitude: -60.0258, altitude: 72 },
    elevationMeters: 72,
    expectedKoppen: 'Af',
    annualMeanTempC: 27.2,
    annualPrecipMm: 2301,
    monthlyTemperaturesC: [26.8, 26.7, 26.8, 27.0, 27.2, 27.4, 27.6, 28.1, 28.4, 28.3, 27.9, 27.2],
    monthlyPrecipitationMm: [312, 288, 320, 310, 240, 125, 75, 68, 85, 130, 185, 263],
    provenance: 'WMO Station 82331 / INMET Brazil (1991-2020 Normal)',
    classification: 'REAL_DATA'
  },
  // 2. Tropical Monsoon (Am)
  {
    id: 'CLIM_MIAMI_FLORIDA',
    name: 'Miami (Florida, USA)',
    region: 'North America (Subtropical Atlantic)',
    location: { latitude: 25.7617, longitude: -80.1918, altitude: 2 },
    elevationMeters: 2,
    expectedKoppen: 'Am',
    annualMeanTempC: 25.1,
    annualPrecipMm: 1712,
    monthlyTemperaturesC: [20.3, 21.6, 23.0, 25.1, 27.2, 28.7, 29.3, 29.4, 28.7, 26.8, 23.9, 21.4],
    monthlyPrecipitationMm: [48, 55, 62, 85, 161, 267, 185, 232, 250, 195, 92, 60],
    provenance: 'NOAA NCEI Miami International Airport Station USW00012839',
    classification: 'REAL_DATA'
  },
  // 3. Subtropical Hot Desert (BWh)
  {
    id: 'CLIM_TAMANRASSET_SAHARA',
    name: 'Tamanrasset (Central Sahara, Algeria)',
    region: 'North Africa (Hoggar Mountains / Sahara)',
    location: { latitude: 22.7850, longitude: 5.5228, altitude: 1377 },
    elevationMeters: 1377,
    expectedKoppen: 'BWh',
    annualMeanTempC: 22.4,
    annualPrecipMm: 55,
    monthlyTemperaturesC: [12.8, 15.2, 18.9, 23.4, 27.8, 30.5, 30.2, 29.8, 27.6, 23.1, 17.5, 13.9],
    monthlyPrecipitationMm: [2, 1, 3, 2, 6, 8, 12, 11, 6, 2, 1, 1],
    provenance: 'Meteo Algerie / WMO Station 60680',
    classification: 'REAL_DATA'
  },
  // 4. Cold Semi-Arid / Steppe (BSk)
  {
    id: 'CLIM_DENVER_COLORADO',
    name: 'Denver (High Plains, Colorado, USA)',
    region: 'North America (Intermountain West)',
    location: { latitude: 39.7392, longitude: -104.9903, altitude: 1609 },
    elevationMeters: 1609,
    expectedKoppen: 'BSk',
    annualMeanTempC: 10.4,
    annualPrecipMm: 390,
    monthlyTemperaturesC: [-0.6, 0.4, 4.8, 9.1, 14.2, 20.1, 23.7, 22.6, 17.8, 10.9, 4.2, -0.4],
    monthlyPrecipitationMm: [10, 11, 28, 48, 57, 49, 54, 42, 33, 27, 18, 13],
    provenance: 'NOAA NCEI Denver Stapleton Station USW00023062',
    classification: 'REAL_DATA'
  },
  // 5. Hot-Summer Mediterranean (Csa)
  {
    id: 'CLIM_ATHENS_GREECE',
    name: 'Athens (Attica, Greece)',
    region: 'Southern Europe (Mediterranean Basin)',
    location: { latitude: 37.9838, longitude: 23.7275, altitude: 107 },
    elevationMeters: 107,
    expectedKoppen: 'Csa',
    annualMeanTempC: 18.7,
    annualPrecipMm: 414,
    monthlyTemperaturesC: [10.3, 10.8, 13.0, 16.4, 21.2, 26.2, 29.1, 28.9, 24.6, 19.8, 15.3, 11.8],
    monthlyPrecipitationMm: [51, 42, 41, 28, 16, 8, 6, 7, 18, 46, 68, 67],
    provenance: 'Hellenic National Meteorological Service (HNMS) / WMO 16716',
    classification: 'REAL_DATA'
  },
  // 6. Warm-Summer Mediterranean / Oceanic (Csb)
  {
    id: 'CLIM_ASTORIA_PACIFIC',
    name: 'Astoria (Pacific Northwest Coast, Oregon, USA)',
    region: 'North America (Cascadia Maritime Coast)',
    location: { latitude: 46.1879, longitude: -123.8313, altitude: 4 },
    elevationMeters: 4,
    expectedKoppen: 'Csb',
    annualMeanTempC: 10.8,
    annualPrecipMm: 1720,
    monthlyTemperaturesC: [5.8, 6.4, 7.8, 9.4, 11.9, 14.1, 15.9, 16.3, 15.1, 11.6, 8.0, 5.6],
    monthlyPrecipitationMm: [245, 180, 175, 125, 82, 58, 25, 28, 65, 160, 265, 292],
    provenance: 'NOAA NCEI Astoria Regional Airport Station USW00094224',
    classification: 'REAL_DATA'
  },
  // 7. Humid Subtropical (Cfa)
  {
    id: 'CLIM_SHANGHAI_CHINA',
    name: 'Shanghai (Yangtze Delta, China)',
    region: 'East Asia (Subtropical Monsoon Belt)',
    location: { latitude: 31.2304, longitude: 121.4737, altitude: 4 },
    elevationMeters: 4,
    expectedKoppen: 'Cfa',
    annualMeanTempC: 17.1,
    annualPrecipMm: 1235,
    monthlyTemperaturesC: [5.1, 6.9, 10.5, 15.8, 20.8, 24.8, 28.9, 28.6, 24.9, 19.8, 14.0, 7.8],
    monthlyPrecipitationMm: [62, 68, 105, 112, 120, 198, 165, 172, 138, 65, 58, 42],
    provenance: 'China Meteorological Administration (CMA) / WMO 58362',
    classification: 'REAL_DATA'
  },
  // 8. Temperate Humid Continental (Dfb)
  {
    id: 'CLIM_FRANKFURT_GERMANY',
    name: 'Frankfurt am Main (Hesse, Germany)',
    region: 'Central Europe (Temperate Continental)',
    location: { latitude: 50.1109, longitude: 8.6821, altitude: 112 },
    elevationMeters: 112,
    expectedKoppen: 'Cfb', // Bordering Dfb in older classifications, Cfb in 1991-2020 normal
    annualMeanTempC: 10.6,
    annualPrecipMm: 629,
    monthlyTemperaturesC: [2.1, 2.8, 6.5, 10.6, 14.8, 18.2, 20.3, 19.8, 15.2, 10.3, 5.7, 2.9],
    monthlyPrecipitationMm: [45, 40, 48, 42, 62, 65, 68, 58, 52, 54, 50, 55],
    provenance: 'Deutscher Wetterdienst (DWD) Station Frankfurt-Flughafen',
    classification: 'REAL_DATA'
  },
  // 9. Hot-Summer Humid Continental (Dfa)
  {
    id: 'CLIM_CHICAGO_ILLINOIS',
    name: 'Chicago (Illinois, USA)',
    region: 'North America (Great Lakes Continental)',
    location: { latitude: 41.8781, longitude: -87.6298, altitude: 181 },
    elevationMeters: 181,
    expectedKoppen: 'Dfa',
    annualMeanTempC: 10.7,
    annualPrecipMm: 1039,
    monthlyTemperaturesC: [-3.8, -2.1, 3.4, 9.8, 16.0, 21.8, 24.8, 23.9, 19.6, 12.6, 5.4, -1.2],
    monthlyPrecipitationMm: [52, 49, 68, 101, 114, 110, 102, 106, 88, 85, 78, 66],
    provenance: 'NOAA NCEI Chicago OHare Station USW00094846',
    classification: 'REAL_DATA'
  },
  // 10. Subarctic Taiga (Dfc)
  {
    id: 'CLIM_FAIRBANKS_ALASKA',
    name: 'Fairbanks (Interior Alaska, USA)',
    region: 'North America (Subarctic Interior)',
    location: { latitude: 64.8378, longitude: -147.7164, altitude: 136 },
    elevationMeters: 136,
    expectedKoppen: 'Dfc',
    annualMeanTempC: -2.3,
    annualPrecipMm: 295,
    monthlyTemperaturesC: [-22.2, -18.1, -10.9, 0.2, 9.8, 16.1, 17.2, 13.9, 7.3, -4.1, -15.8, -20.9],
    monthlyPrecipitationMm: [14, 12, 10, 8, 16, 38, 55, 52, 34, 22, 18, 16],
    provenance: 'NOAA NCEI Fairbanks International Airport USW00026411',
    classification: 'REAL_DATA'
  },
  // 11. Subtropical Highland (Cwb)
  {
    id: 'CLIM_LHASA_TIBET',
    name: 'Lhasa (Tibetan Plateau, China)',
    region: 'Central Asia (Himalayan Rain Shadow Plateau)',
    location: { latitude: 29.6525, longitude: 91.1721, altitude: 3656 },
    elevationMeters: 3656,
    expectedKoppen: 'Cwb',
    annualMeanTempC: 8.8,
    annualPrecipMm: 426,
    monthlyTemperaturesC: [-1.6, 1.4, 5.2, 8.8, 12.9, 16.3, 16.1, 15.2, 13.4, 8.9, 3.1, -1.0],
    monthlyPrecipitationMm: [1, 2, 3, 7, 28, 72, 132, 120, 56, 10, 2, 1],
    provenance: 'China Meteorological Administration (CMA) WMO 55591',
    classification: 'REAL_DATA'
  },
  // 12. Arctic Tundra (ET)
  {
    id: 'CLIM_LONGYEARBYEN_SVALBARD',
    name: 'Longyearbyen (Spitsbergen, Svalbard, Norway)',
    region: 'High Arctic (Polar Tundra Belt 78°N)',
    location: { latitude: 78.2232, longitude: 15.6267, altitude: 28 },
    elevationMeters: 28,
    expectedKoppen: 'ET',
    annualMeanTempC: -4.6,
    annualPrecipMm: 217,
    monthlyTemperaturesC: [-11.8, -12.4, -12.6, -9.1, -2.4, 3.6, 7.0, 5.8, 1.5, -4.5, -7.8, -10.2],
    monthlyPrecipitationMm: [22, 19, 18, 11, 10, 13, 18, 24, 23, 21, 20, 18],
    provenance: 'Norwegian Meteorological Institute (MET Norway) Station 99840',
    classification: 'REAL_DATA'
  },
  // 13. Polar Perpetual Ice Cap (EF)
  {
    id: 'CLIM_VOSTOK_ANTARCTICA',
    name: 'Vostok Station (Antarctic Ice Sheet)',
    region: 'Antarctica (Polar Continental Interior - Dome C/Vostok)',
    location: { latitude: -78.4645, longitude: 106.8373, altitude: 3488 },
    elevationMeters: 3488,
    expectedKoppen: 'EF',
    annualMeanTempC: -55.2,
    annualPrecipMm: 21,
    monthlyTemperaturesC: [-32.1, -44.3, -57.9, -64.8, -65.8, -65.3, -66.7, -68.0, -66.0, -57.1, -43.3, -31.9],
    monthlyPrecipitationMm: [1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2],
    provenance: 'Arctic and Antarctic Research Institute (AARI) Russia WMO 89606',
    classification: 'REAL_DATA'
  },
  // 14. Project Earth Phase 4/5 Benchmark: Zion National Park (BSk / Csa ecotone)
  {
    id: 'CLIM_ZION_NATIONAL_PARK',
    name: 'Zion National Park Canyon (Utah, USA)',
    region: 'North America (Colorado Plateau Ecotone)',
    location: { latitude: 37.2153, longitude: -112.9852, altitude: 1219 },
    elevationMeters: 1219,
    expectedKoppen: 'BSk',
    annualMeanTempC: 16.2,
    annualPrecipMm: 412,
    monthlyTemperaturesC: [4.8, 6.9, 10.6, 14.7, 20.3, 26.2, 29.8, 28.7, 24.1, 17.2, 9.8, 4.6],
    monthlyPrecipitationMm: [46, 52, 48, 32, 18, 9, 28, 38, 26, 31, 35, 49],
    provenance: 'US National Park Service / NOAA COOP 429717 Zion NP',
    classification: 'REAL_DATA'
  },
  // 15. Project Earth Phase 5/6 Benchmark: Columbia River Gorge (Csb / Cfb)
  {
    id: 'CLIM_COLUMBIA_RIVER_GORGE',
    name: 'Columbia River Gorge / Hood River (Oregon, USA)',
    region: 'North America (Cascade Range Rain Shadow Boundary)',
    location: { latitude: 45.7054, longitude: -121.5215, altitude: 154 },
    elevationMeters: 154,
    expectedKoppen: 'Csb',
    annualMeanTempC: 11.2,
    annualPrecipMm: 785,
    monthlyTemperaturesC: [2.8, 4.4, 7.8, 11.1, 15.3, 19.1, 22.4, 22.1, 18.2, 12.1, 6.2, 2.5],
    monthlyPrecipitationMm: [120, 85, 72, 45, 28, 18, 6, 8, 22, 68, 135, 178],
    provenance: 'NOAA NCEI Hood River Experiment Station USW00024229',
    classification: 'REAL_DATA'
  }
];
