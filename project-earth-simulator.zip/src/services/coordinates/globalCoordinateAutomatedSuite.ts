/**
 * Project Earth: Phase 4.5 Global Coordinate & UE5 Bridge Automated Test Suite
 * 
 * Executes 13 comprehensive automated test cases validating planetary coordinate spaces,
 * polar stability, date-line continuity, floating-origin rebasing, and UE5 bridge compliance.
 */

import { GlobalCoordinateEngine, GLOBAL_BENCHMARK_LOCATIONS, WGS84GlobalCoord } from './globalCoordinateEngine';
import { REAL_EARTH_INFO } from '../../data/realEarthData';

export interface GlobalTestCaseResult {
  id: string;
  name: string;
  category: 'ECEF_CONVERSION' | 'POLAR_STABILITY' | 'DATE_LINE' | 'REBASING' | 'EXTREMES' | 'UE5_BRIDGE' | 'PRECISION';
  status: 'PASS' | 'FAIL' | 'NOT_TESTED';
  durationMs: number;
  measuredMetric: string;
  details: string;
}

export class GlobalCoordinateAutomatedSuite {
  private engine: GlobalCoordinateEngine;

  constructor(engine: GlobalCoordinateEngine = GlobalCoordinateEngine.getInstance()) {
    this.engine = engine;
  }

  public runAllGlobalTests(): GlobalTestCaseResult[] {
    const results: GlobalTestCaseResult[] = [];

    // 1. WGS84 <-> ECEF Forward & Inverse Exactness (Null Island 0°N, 0°E)
    const t1Start = performance.now();
    const nullIsland: WGS84GlobalCoord = { latitude: 0.0, longitude: 0.0, altitude: 0.0 };
    const ecefNull = this.engine.wgs84ToECEF(nullIsland);
    const recNull = this.engine.ecefToWGS84(ecefNull);
    const errNull = Math.abs(ecefNull.x - 6378137.0) + Math.abs(ecefNull.y) + Math.abs(ecefNull.z);
    const recErrNull = Math.abs(recNull.latitude) + Math.abs(recNull.longitude) + Math.abs(recNull.altitude);
    const t1Pass = errNull < 1e-6 && recErrNull < 1e-6;
    results.push({
      id: 'TC-451',
      name: 'WGS84 ↔ ECEF Forward & Inverse Exactness',
      category: 'ECEF_CONVERSION',
      status: t1Pass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t1Start) * 100) / 100,
      measuredMetric: `ECEF X = ${ecefNull.x.toFixed(2)} m (Error = ${errNull.toExponential(2)} m)`,
      details: 'Validated closed-form Bowring & Ferrari algorithms at Null Island; matched WGS84 semi-major axis exactly.'
    });

    // 2. ECEF <-> Local ENU Tangent Plane Transformation
    const t2Start = performance.now();
    const zion = GLOBAL_BENCHMARK_LOCATIONS[0].coord;
    const anchor = this.engine.createReferenceAnchor(zion, 'ANCHOR_TEST');
    const zionECEF = this.engine.wgs84ToECEF(zion);
    const zionENU = this.engine.ecefToENU(zionECEF, anchor);
    const zionECEFRecovered = this.engine.enuToECEF(zionENU, anchor);
    const enuDelta = Math.sqrt(
      Math.pow(zionECEF.x - zionECEFRecovered.x, 2) +
      Math.pow(zionECEF.y - zionECEFRecovered.y, 2) +
      Math.pow(zionECEF.z - zionECEFRecovered.z, 2)
    );
    const t2Pass = Math.abs(zionENU.east) < 1e-6 && Math.abs(zionENU.north) < 1e-6 && enuDelta < 1e-9;
    results.push({
      id: 'TC-452',
      name: 'ECEF ↔ Local Tangent Frame (ENU) Transformation',
      category: 'ECEF_CONVERSION',
      status: t2Pass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t2Start) * 100) / 100,
      measuredMetric: `ENU Origin Offset = ${Math.hypot(zionENU.east, zionENU.north).toExponential(2)} m, Delta = ${enuDelta.toExponential(2)} m`,
      details: 'Orthonormal 3x3 rotation matrix verified for local tangent frame projection centered at Zion Canyon.'
    });

    // 3. Local ENU <-> UE5 Coordinates Conversion (Centimeters, Axis Convention)
    const t3Start = performance.now();
    const testENU = { east: 125.5, north: 250.0, up: 45.25 };
    const testUE5 = this.engine.enuToUE5(testENU);
    const recENU = this.engine.ue5ToENU(testUE5);
    const ue5Pass = testUE5.ueX === 25000.0 && testUE5.ueY === 12550.0 && testUE5.ueZ === 4525.0 &&
      Math.abs(recENU.east - testENU.east) < 1e-9 &&
      Math.abs(recENU.north - testENU.north) < 1e-9 &&
      Math.abs(recENU.up - testENU.up) < 1e-9;
    results.push({
      id: 'TC-453',
      name: 'Local ENU ↔ Unreal Engine 5 Coordinate System Mapping',
      category: 'UE5_BRIDGE',
      status: ue5Pass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t3Start) * 100) / 100,
      measuredMetric: `UE5 [X: ${testUE5.ueX}, Y: ${testUE5.ueY}, Z: ${testUE5.ueZ}] cm`,
      details: 'Verified axis conversion (UE +X = North, +Y = East, +Z = Up) and metric-to-centimeter 100x scaling.'
    });

    // 4. Complete 6-Step Round-Trip Conversion Across All Benchmarks
    const t4Start = performance.now();
    let maxRoundTripError = 0.0;
    let allPassed = true;
    for (const loc of GLOBAL_BENCHMARK_LOCATIONS) {
      const trace = this.engine.executeTransformationTrace(loc.coord);
      if (trace.totalErrorMeters > maxRoundTripError) {
        maxRoundTripError = trace.totalErrorMeters;
      }
      if (!trace.passed) {
        allPassed = false;
      }
    }
    results.push({
      id: 'TC-454',
      name: 'Universal 6-Step Round-Trip Geodetic Transformation',
      category: 'PRECISION',
      status: allPassed ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t4Start) * 100) / 100,
      measuredMetric: `Max Planetary Error = ${maxRoundTripError.toExponential(3)} m (< 1.0 mm)`,
      details: `Executed WGS84 -> ECEF -> ENU -> UE5 -> ENU -> ECEF -> WGS84 across all ${GLOBAL_BENCHMARK_LOCATIONS.length} benchmark locations.`
    });

    // 5. Geographic North Pole (+90° Latitude) Stability & Singularity Immunity
    const t5Start = performance.now();
    const northPole: WGS84GlobalCoord = { latitude: 90.0, longitude: 0.0, altitude: 0.0 };
    const npECEF = this.engine.wgs84ToECEF(northPole);
    const npRec = this.engine.ecefToWGS84(npECEF);
    const npPass = Math.abs(npECEF.x) < 1e-6 && Math.abs(npECEF.y) < 1e-6 && Math.abs(npECEF.z - 6356752.314245) < 1e-3 && Math.abs(npRec.latitude - 90.0) < 1e-9;
    results.push({
      id: 'TC-455',
      name: 'North Pole (+90°) Singularity Immunity & Stability',
      category: 'POLAR_STABILITY',
      status: npPass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t5Start) * 100) / 100,
      measuredMetric: `ECEF Z = ${npECEF.z.toFixed(3)} m (Semi-Minor Axis Match)`,
      details: 'Eliminated polar meridian convergence gimbal lock by utilizing Cartesian ECEF representation.'
    });

    // 6. Geographic South Pole (-90° Latitude) Stability
    const t6Start = performance.now();
    const southPole: WGS84GlobalCoord = { latitude: -90.0, longitude: 0.0, altitude: 2835.0 };
    const spECEF = this.engine.wgs84ToECEF(southPole);
    const spRec = this.engine.ecefToWGS84(spECEF);
    const spExpectedZ = -(6356752.314245 + 2835.0);
    const spPass = Math.abs(spECEF.x) < 1e-6 && Math.abs(spECEF.y) < 1e-6 && Math.abs(spECEF.z - spExpectedZ) < 1e-3 && Math.abs(spRec.latitude - -90.0) < 1e-9;
    results.push({
      id: 'TC-456',
      name: 'South Pole (-90°) Antarctic High-Elevation Stability',
      category: 'POLAR_STABILITY',
      status: spPass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t6Start) * 100) / 100,
      measuredMetric: `ECEF Z = ${spECEF.z.toFixed(3)} m, Alt = ${spRec.altitude.toFixed(2)} m`,
      details: 'Confirmed negative rotational axis pole handling and +2835m ice sheet elevation offset precision.'
    });

    // 7. International Date Line (+180° / -180° Longitude) Spatial Continuity
    const t7Start = performance.now();
    const dateLineEast: WGS84GlobalCoord = { latitude: 0.0, longitude: 180.0, altitude: 0.0 };
    const dateLineWest: WGS84GlobalCoord = { latitude: 0.0, longitude: -180.0, altitude: 0.0 };
    const dlEastECEF = this.engine.wgs84ToECEF(dateLineEast);
    const dlWestECEF = this.engine.wgs84ToECEF(dateLineWest);
    const dlSpatialDelta = Math.sqrt(
      Math.pow(dlEastECEF.x - dlWestECEF.x, 2) +
      Math.pow(dlEastECEF.y - dlWestECEF.y, 2) +
      Math.pow(dlEastECEF.z - dlWestECEF.z, 2)
    );
    const dlPass = dlSpatialDelta < 1e-9 && Math.abs(dlEastECEF.x - -6378137.0) < 1e-6;
    results.push({
      id: 'TC-457',
      name: 'International Date Line (±180°) Spatial Continuity',
      category: 'DATE_LINE',
      status: dlPass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t7Start) * 100) / 100,
      measuredMetric: `Spatial Delta across ±180° = ${dlSpatialDelta.toExponential(2)} m`,
      details: 'Demonstrated zero Euclidean spatial discontinuity when crossing between Eastern and Western antimeridians.'
    });

    // 8. UTM Zone Boundary Crossing Comparison (Zone 12 to Zone 13)
    const t8Start = performance.now();
    const pointWestOfBoundary: WGS84GlobalCoord = { latitude: 37.0, longitude: -108.0001, altitude: 1900.0 };
    const pointEastOfBoundary: WGS84GlobalCoord = { latitude: 37.0, longitude: -107.9999, altitude: 1900.0 };
    const ecefW = this.engine.wgs84ToECEF(pointWestOfBoundary);
    const ecefE = this.engine.wgs84ToECEF(pointEastOfBoundary);
    const physicalDistance = Math.hypot(ecefW.x - ecefE.x, ecefW.y - ecefE.y, ecefW.z - ecefE.z);
    const expectedDistApprox = (0.0002 * (Math.PI / 180.0) * 6378137.0 * Math.cos(37.0 * Math.PI / 180.0));
    const distDelta = Math.abs(physicalDistance - expectedDistApprox);
    const t8Pass = distDelta < 0.1 && physicalDistance < 25.0;
    results.push({
      id: 'TC-458',
      name: 'UTM Zone Boundary (12N ↔ 13N) Transition Continuity',
      category: 'ECEF_CONVERSION',
      status: t8Pass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t8Start) * 100) / 100,
      measuredMetric: `Physical Delta across Boundary = ${physicalDistance.toFixed(2)} m (Continuous)`,
      details: 'Proved ECEF/ENU global pipeline is continuous across UTM meridians without 60km zone coordinate offsets.'
    });

    // 9. Floating-Origin Dynamic Reference-Anchor Rebasing
    const t9Start = performance.now();
    const initialAnchor = this.engine.createReferenceAnchor(zion, 'ANCHOR_ORIGINAL');
    const entityPositionsUE5 = [
      { ueX: 0.0, ueY: 0.0, ueZ: 148235.0 },
      { ueX: 50000.0, ueY: 50000.0, ueZ: 152000.0 },
      { ueX: -30000.0, ueY: 40000.0, ueZ: 141000.0 }
    ];
    // Jump anchor 5,000 meters North
    const shiftedAnchorCoord: WGS84GlobalCoord = {
      latitude: zion.latitude + (5000.0 / 111319.5),
      longitude: zion.longitude,
      altitude: zion.altitude
    };
    const rebaseResult = this.engine.rebaseReferenceAnchor(initialAnchor, shiftedAnchorCoord, entityPositionsUE5);
    const t9Pass = rebaseResult.maxDiscrepancyMeters < 1e-9 && rebaseResult.rebasedEntitiesUE5.length === 3;
    results.push({
      id: 'TC-459',
      name: 'Floating-Origin Dynamic Reference-Anchor Rebasing',
      category: 'REBASING',
      status: t9Pass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t9Start) * 100) / 100,
      measuredMetric: `World Invariant Discrepancy = ${rebaseResult.maxDiscrepancyMeters.toExponential(2)} m`,
      details: 'Simulated 5,000m reference anchor shift; verified all local entity coordinates translated without world drift.'
    });

    // 10. Deep Ocean Benthic Trench Stability (-10,994m Mariana Trench)
    const t10Start = performance.now();
    const mariana = GLOBAL_BENCHMARK_LOCATIONS[8].coord;
    const marianaTrace = this.engine.executeTransformationTrace(mariana);
    const t10Pass = marianaTrace.passed && Math.abs(marianaTrace.recoveredWGS84.altitude - -10994.0) < 1e-4;
    results.push({
      id: 'TC-460',
      name: 'Deep Ocean Benthic Sub-Surface Stability (-10,994m)',
      category: 'EXTREMES',
      status: t10Pass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t10Start) * 100) / 100,
      measuredMetric: `Recovered Altitude = ${marianaTrace.recoveredWGS84.altitude.toFixed(2)} m`,
      details: 'Verified negative subterranean and oceanic depth coordinates remain stable in ellipsoidal normal space.'
    });

    // 11. High-Altitude / Orbital Flight Stability (+400,000m LEO)
    const t11Start = performance.now();
    const leo = GLOBAL_BENCHMARK_LOCATIONS[9].coord;
    const leoTrace = this.engine.executeTransformationTrace(leo);
    const t11Pass = leoTrace.passed && Math.abs(leoTrace.recoveredWGS84.altitude - 400000.0) < 1e-4;
    results.push({
      id: 'TC-461',
      name: 'High-Altitude & Orbital Space Flight Stability (+400 km)',
      category: 'EXTREMES',
      status: t11Pass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t11Start) * 100) / 100,
      measuredMetric: `Orbital Error = ${leoTrace.totalErrorMeters.toExponential(2)} m`,
      details: 'Double precision math maintains sub-millimeter tracking at orbital radii without precision decay.'
    });

    // 12. Real Terrain Tile ECEF Bounding Box Consistency
    const t12Start = performance.now();
    const utmBounds = REAL_EARTH_INFO.utmBounds;
    const tileSwWGS84: WGS84GlobalCoord = { latitude: 37.1950, longitude: -113.0100, altitude: 1195.0 };
    const tileNeWGS84: WGS84GlobalCoord = { latitude: 37.2400, longitude: -112.9600, altitude: 2185.0 };
    const ecefSW = this.engine.wgs84ToECEF(tileSwWGS84);
    const ecefNE = this.engine.wgs84ToECEF(tileNeWGS84);
    const ecefDiag = Math.hypot(ecefNE.x - ecefSW.x, ecefNE.y - ecefSW.y, ecefNE.z - ecefSW.z);
    const t12Pass = ecefDiag > 5000.0 && ecefDiag < 8000.0;
    results.push({
      id: 'TC-462',
      name: 'Production Zion 3DEP Tile ECEF Extents Consistency',
      category: 'PRECISION',
      status: t12Pass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t12Start) * 100) / 100,
      measuredMetric: `3D ECEF Bounding Extent = ${(ecefDiag / 1000.0).toFixed(2)} km`,
      details: 'Confirmed 3D ECEF bounding volume encapsulates all 4 production Zion Canyon .peth tiles.'
    });

    // 13. UE5 LWC (Large World Coordinates) 64-bit Double Precision Compliance
    const t13Start = performance.now();
    const globalEverest = GLOBAL_BENCHMARK_LOCATIONS[7].coord;
    const everestTrace = this.engine.executeTransformationTrace(globalEverest, zion);
    const t13Pass = everestTrace.totalErrorMeters < 0.001 && everestTrace.ue5.ueX !== 0;
    results.push({
      id: 'TC-463',
      name: 'UE5 Large World Coordinates (LWC) Double Precision',
      category: 'UE5_BRIDGE',
      status: t13Pass ? 'PASS' : 'FAIL',
      durationMs: Math.round((performance.now() - t13Start) * 100) / 100,
      measuredMetric: `Continental Distance Error = ${everestTrace.totalErrorMeters.toExponential(3)} m`,
      details: 'Transformed Mount Everest relative to Zion anchor (> 11,000 km distance); achieved sub-millimeter precision in LWC.'
    });

    return results;
  }
}
