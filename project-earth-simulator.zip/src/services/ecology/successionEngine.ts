/**
 * Project Earth: Phase 9 Biomes & Ecological Succession Engine
 * Ecological Succession & Disturbance Dynamics Engine
 * 
 * Implements:
 * 1. Primary Succession (Bare substrate -> Pioneer Lichens -> Grasses -> Shrubs -> Woodland -> Climax)
 * 2. Secondary Succession (Disturbed ecosystem -> Herbaceous -> Shrub -> Early Trees -> Climax)
 * 3. Rothermel Wildfire Mechanics (Fuel load, fuel moisture, wind/slope spread, Byram fireline intensity)
 * 4. Post-Fire Ecological Recovery & Seral Reset Trajectories
 * 5. Drought Ecology & Hydraulic Cavitation Tree Mortality
 * 6. Flood Ecology, Anaerobic Soil Inundation & Riparian Transition
 * 7. Storm Windthrow, Canopy Gap Dynamics & Interspecific Competition
 */

import { WGS84GlobalCoord } from '../coordinates/globalCoordinateEngine';
import { 
  BiomeType, 
  SeralStage, 
  SuccessionType, 
  PlantFunctionalGroup, 
  PlantGroupFraction,
  VegetationCommunityState, 
  SoilState, 
  EcologicalSuccessionState, 
  WildfireState, 
  DisturbanceImpactState, 
  DisturbanceType,
  PhenologicalStage
} from './biomeTypes';
import { PLANT_FUNCTIONAL_TRAITS, ROTHERMEL_FUEL_MODELS } from './biomeDataset';

export class SuccessionEngine {
  private static instance: SuccessionEngine | null = null;

  public static getInstance(): SuccessionEngine {
    if (!SuccessionEngine.instance) {
      SuccessionEngine.instance = new SuccessionEngine();
    }
    return SuccessionEngine.instance;
  }

  // =========================================================================
  // 1. INITIALIZE SUCCESSION STATE
  // =========================================================================

  public initializeSuccessionState(
    climaxBiomeTarget: BiomeType,
    initialStage: SeralStage = 'STAGE_6_MATURE_CLIMAX_FOREST',
    successionType: SuccessionType = 'SECONDARY_SUCCESSION',
    initialAgeYears: number = 250
  ): EcologicalSuccessionState {
    const seralIndexMap: Record<SeralStage, number> = {
      STAGE_0_BARE_SUBSTRATE: 0,
      STAGE_1_PIONEER_CRUST_MOSS: 1,
      STAGE_2_EARLY_HERBACEOUS_GRASS: 2,
      STAGE_3_SHRUB_THICKET: 3,
      STAGE_4_EARLY_SERAL_PIONEER_WOODLAND: 4,
      STAGE_5_MID_SERAL_MIXED_FOREST: 5,
      STAGE_6_MATURE_CLIMAX_FOREST: 6,
      STAGE_7_OLD_GROWTH_COMPLEX: 7
    };

    const stageIdx = seralIndexMap[initialStage];
    const isClimax = stageIdx >= 6;
    const maturityFraction = Math.min(1.0, stageIdx / 6.0);

    return {
      successionType,
      currentSeralStage: initialStage,
      seralStageIndex: stageIdx,
      successionAgeYears: initialAgeYears,
      timeInCurrentStageYears: Math.min(initialAgeYears, 50),
      yearsToNextSeralTransition: isClimax ? 0 : this.calculateStageTransitionYears(stageIdx, climaxBiomeTarget),
      climaxBiomeTarget,
      climaxMaturityFraction: Math.round(maturityFraction * 100) / 100,
      seedBankViabilityIndex: Math.max(0.1, 1.0 - (stageIdx === 0 ? 0.95 : 0.0)),
      soilDevelopmentIndex: Math.min(1.0, (stageIdx + 1) / 7.0),
      isClimaxReached: isClimax
    };
  }

  private calculateStageTransitionYears(currentStageIdx: number, biome: BiomeType): number {
    // Base transition times (years) for temperate/boreal forests
    const baseYears = [5, 12, 20, 35, 60, 150, 300, 0];
    let biomeMultiplier = 1.0;

    if (biome === 'TROPICAL_RAINFOREST') {
      biomeMultiplier = 0.5; // Rapid succession in warm, moist tropics
    } else if (biome === 'BOREAL_FOREST_TAIGA' || biome === 'TUNDRA_ARCTIC') {
      biomeMultiplier = 2.5; // Slow growth in cold short growing seasons
    } else if (biome === 'HOT_DESERT' || biome === 'COLD_DESERT') {
      biomeMultiplier = 3.0; // Moisture-limited succession
    }

    return Math.round(baseYears[currentStageIdx] * biomeMultiplier);
  }

  // =========================================================================
  // 2. GENERATE VEGETATION COMMUNITY STATE FROM SERAL STAGE & BIOME
  // =========================================================================

  public generateVegetationCommunity(
    climaxBiome: BiomeType,
    seralStage: SeralStage,
    soil: SoilState,
    meanAnnualTempC: number,
    annualPrecipMm: number,
    dayOfYear: number = 180,
    healthIndex: number = 1.0
  ): VegetationCommunityState {
    const seralIndex = this.getSeralIndex(seralStage);
    const groups: PlantGroupFraction[] = [];

    // Stage 0: Bare substrate
    if (seralIndex === 0) {
      return {
        totalBiomassKgM2: 0.01,
        aboveGroundBiomassKgM2: 0.01,
        belowGroundBiomassKgM2: 0.0,
        totalCanopyCoverFraction: 0.0,
        leafAreaIndex: 0.01,
        meanCanopyHeightMeters: 0.01,
        maxRootDepthMeters: 0.01,
        vegetationHealthIndex: 1.0,
        phenologyStage: 'EVERGREEN_STABLE',
        functionalGroups: [{ group: 'LICHENS_CRUSTOSE', fraction: 1.0, biomassKgM2: 0.01, meanHeightMeters: 0.01, canopyCoverFraction: 0.0, rootDepthMeters: 0.01 }],
        dominantFunctionalGroup: 'LICHENS_CRUSTOSE',
        foliageMoistureContentPercent: 20,
        deadFuelFraction: 0.0
      };
    }

    // Allocate plant functional group fractions based on seral stage and climax biome
    if (seralIndex === 1) {
      // Lichens and Mosses
      groups.push({ group: 'LICHENS_CRUSTOSE', fraction: 0.6, biomassKgM2: 0.25, meanHeightMeters: 0.02, canopyCoverFraction: 0.20, rootDepthMeters: 0.02 });
      groups.push({ group: 'MOSSES_BRYOPHYTES', fraction: 0.4, biomassKgM2: 0.35, meanHeightMeters: 0.05, canopyCoverFraction: 0.25, rootDepthMeters: 0.04 });
    } else if (seralIndex === 2) {
      // Herbaceous / Grassland
      const isC4Favored = meanAnnualTempC >= 20.0;
      groups.push({ group: isC4Favored ? 'GRASSES_C4' : 'GRASSES_C3', fraction: 0.75, biomassKgM2: 1.4, meanHeightMeters: 0.6, canopyCoverFraction: 0.70, rootDepthMeters: 0.8 });
      groups.push({ group: 'SHRUBS_DECIDUOUS', fraction: 0.25, biomassKgM2: 0.6, meanHeightMeters: 1.0, canopyCoverFraction: 0.15, rootDepthMeters: 1.2 });
    } else if (seralIndex === 3) {
      // Shrub thicket
      const shrubGroup: PlantFunctionalGroup = climaxBiome === 'MEDITERRANEAN_SHRUBLAND' ? 'SHRUBS_EVERGREEN' : 'SHRUBS_DECIDUOUS';
      groups.push({ group: shrubGroup, fraction: 0.65, biomassKgM2: 4.2, meanHeightMeters: 2.2, canopyCoverFraction: 0.60, rootDepthMeters: 2.2 });
      groups.push({ group: 'GRASSES_C3', fraction: 0.25, biomassKgM2: 0.8, meanHeightMeters: 0.5, canopyCoverFraction: 0.25, rootDepthMeters: 0.6 });
      groups.push({ group: 'TREES_BROADLEAF_DECIDUOUS', fraction: 0.10, biomassKgM2: 1.5, meanHeightMeters: 4.0, canopyCoverFraction: 0.10, rootDepthMeters: 1.8 });
    } else if (seralIndex === 4) {
      // Early seral pioneer woodland
      const isConiferClimax = climaxBiome === 'BOREAL_FOREST_TAIGA' || climaxBiome === 'TEMPERATE_RAINFOREST';
      const pioneerTree: PlantFunctionalGroup = isConiferClimax ? 'TREES_NEEDLELEAF_EVERGREEN_CONIFER' : 'TREES_BROADLEAF_DECIDUOUS';
      groups.push({ group: pioneerTree, fraction: 0.55, biomassKgM2: 12.0, meanHeightMeters: 14.0, canopyCoverFraction: 0.55, rootDepthMeters: 2.5 });
      groups.push({ group: 'SHRUBS_DECIDUOUS', fraction: 0.30, biomassKgM2: 2.8, meanHeightMeters: 2.0, canopyCoverFraction: 0.25, rootDepthMeters: 1.8 });
      groups.push({ group: 'GRASSES_C3', fraction: 0.15, biomassKgM2: 0.5, meanHeightMeters: 0.4, canopyCoverFraction: 0.15, rootDepthMeters: 0.5 });
    } else if (seralIndex === 5) {
      // Mid-seral mixed forest
      const dominantTree = this.getClimaxDominantPFT(climaxBiome);
      groups.push({ group: dominantTree, fraction: 0.50, biomassKgM2: 22.0, meanHeightMeters: 22.0, canopyCoverFraction: 0.65, rootDepthMeters: 3.2 });
      groups.push({ group: 'TREES_BROADLEAF_DECIDUOUS', fraction: 0.30, biomassKgM2: 8.5, meanHeightMeters: 18.0, canopyCoverFraction: 0.25, rootDepthMeters: 2.8 });
      groups.push({ group: 'SHRUBS_DECIDUOUS', fraction: 0.20, biomassKgM2: 1.8, meanHeightMeters: 1.5, canopyCoverFraction: 0.15, rootDepthMeters: 1.5 });
    } else {
      // Climax or Old Growth (Stage 6 or 7)
      const dominantTree = this.getClimaxDominantPFT(climaxBiome);
      const traits = PLANT_FUNCTIONAL_TRAITS[dominantTree];
      const maxBio = traits.maxBiomassKgM2 * (seralIndex === 7 ? 1.25 : 1.0);
      const maxHeight = traits.maxCanopyHeightMeters * (seralIndex === 7 ? 1.15 : 1.0);

      groups.push({ group: dominantTree, fraction: 0.70, biomassKgM2: maxBio * 0.75, meanHeightMeters: maxHeight, canopyCoverFraction: 0.75, rootDepthMeters: traits.maxRootDepthMeters });
      
      // Understory layers
      if (climaxBiome.includes('FOREST') || climaxBiome.includes('RAINFOREST')) {
        groups.push({ group: 'SHRUBS_DECIDUOUS', fraction: 0.20, biomassKgM2: 3.5, meanHeightMeters: 2.5, canopyCoverFraction: 0.30, rootDepthMeters: 2.0 });
        groups.push({ group: 'MOSSES_BRYOPHYTES', fraction: 0.10, biomassKgM2: 1.2, meanHeightMeters: 0.08, canopyCoverFraction: 0.40, rootDepthMeters: 0.05 });
      } else if (climaxBiome === 'TROPICAL_SAVANNA') {
        groups.push({ group: 'GRASSES_C4', fraction: 0.30, biomassKgM2: 2.2, meanHeightMeters: 1.5, canopyCoverFraction: 0.60, rootDepthMeters: 1.8 });
      } else if (climaxBiome === 'HOT_DESERT' || climaxBiome === 'COLD_DESERT') {
        groups.push({ group: 'SUCCULENTS_CAM', fraction: 0.30, biomassKgM2: 0.8, meanHeightMeters: 1.2, canopyCoverFraction: 0.10, rootDepthMeters: 0.8 });
      } else {
        groups.push({ group: 'GRASSES_C3', fraction: 0.30, biomassKgM2: 1.2, meanHeightMeters: 0.6, canopyCoverFraction: 0.40, rootDepthMeters: 0.8 });
      }
    }

    // Total Biomass and Canopy metrics
    const totalBio = groups.reduce((sum, g) => sum + g.biomassKgM2, 0) * healthIndex;
    const aboveGroundBio = totalBio * 0.78;
    const belowGroundBio = totalBio * 0.22;

    const dominantGroup = groups.reduce((prev, curr) => curr.biomassKgM2 > prev.biomassKgM2 ? curr : prev).group;
    const dominantTrait = PLANT_FUNCTIONAL_TRAITS[dominantGroup];

    const meanHeight = groups.reduce((sum, g) => sum + (g.meanHeightMeters * (g.biomassKgM2 / Math.max(0.01, totalBio))), 0);
    const maxRoot = Math.max(...groups.map(g => g.rootDepthMeters));

    // Canopy cover fraction (Beer-Lambert light extinction proxy)
    const lai = Math.min(10.0, Math.max(0.02, totalBio * 0.22 * (dominantTrait.isEvergreen ? 0.8 : 1.1)));
    const canopyCover = Math.min(0.98, Math.max(0.01, 1.0 - Math.exp(-0.5 * lai)));

    // Phenology stage calculation
    const phenology = this.calculatePhenologicalStage(dominantTrait.isEvergreen, meanAnnualTempC, dayOfYear);

    return {
      totalBiomassKgM2: Math.round(totalBio * 100) / 100,
      aboveGroundBiomassKgM2: Math.round(aboveGroundBio * 100) / 100,
      belowGroundBiomassKgM2: Math.round(belowGroundBio * 100) / 100,
      totalCanopyCoverFraction: Math.round(canopyCover * 100) / 100,
      leafAreaIndex: Math.round(lai * 10) / 10,
      meanCanopyHeightMeters: Math.round(meanHeight * 10) / 10,
      maxRootDepthMeters: Math.round(maxRoot * 10) / 10,
      vegetationHealthIndex: Math.round(healthIndex * 100) / 100,
      phenologyStage: phenology,
      functionalGroups: groups,
      dominantFunctionalGroup: dominantGroup,
      foliageMoistureContentPercent: Math.max(30, Math.min(180, Math.round(soil.relativeSaturationIndex * 120 + 40))),
      deadFuelFraction: Math.round((1.0 - healthIndex) * 0.6 + (soil.relativeSaturationIndex < 0.2 ? 0.25 : 0.05) * 100) / 100
    };
  }

  private getClimaxDominantPFT(biome: BiomeType): PlantFunctionalGroup {
    switch (biome) {
      case 'TROPICAL_RAINFOREST':
      case 'TROPICAL_SEASONAL_FOREST':
        return 'TREES_BROADLEAF_EVERGREEN_TROPICAL';
      case 'TROPICAL_SAVANNA':
        return 'GRASSES_C4';
      case 'HOT_DESERT':
      case 'COLD_DESERT':
        return 'SUCCULENTS_CAM';
      case 'MEDITERRANEAN_SHRUBLAND':
        return 'SHRUBS_EVERGREEN';
      case 'TEMPERATE_GRASSLAND':
        return 'GRASSES_C3';
      case 'TEMPERATE_DECIDUOUS_FOREST':
        return 'TREES_BROADLEAF_DECIDUOUS';
      case 'TEMPERATE_RAINFOREST':
      case 'BOREAL_FOREST_TAIGA':
        return 'TREES_NEEDLELEAF_EVERGREEN_CONIFER';
      case 'TUNDRA_ARCTIC':
        return 'MOSSES_BRYOPHYTES';
      case 'ALPINE_MEADOW':
        return 'GRASSES_C3';
      case 'FRESHWATER_WETLAND':
        return 'WETLAND_EMERGENTS';
      case 'MANGROVE_SWAMP':
        return 'MANGROVE_HALOPHYTES';
      case 'SALT_MARSH':
        return 'WETLAND_EMERGENTS';
      case 'CORAL_REEF':
      case 'KELP_FOREST':
        return 'MARINE_MACROALGAE_KELP';
      default:
        return 'LICHENS_CRUSTOSE';
    }
  }

  private calculatePhenologicalStage(isEvergreen: boolean, meanTempC: number, dayOfYear: number): PhenologicalStage {
    if (isEvergreen) return 'EVERGREEN_STABLE';

    // Northern hemisphere assumption (day 1 to 365)
    // Spring greenup: day 80-120; Peak: 121-250; Senescence: 251-300; Dormancy: 301-79
    if (dayOfYear >= 80 && dayOfYear < 120) {
      return 'BUD_BURST_GREENUP';
    } else if (dayOfYear >= 120 && dayOfYear < 250) {
      return 'PEAK_CANOPY_ACTIVE';
    } else if (dayOfYear >= 250 && dayOfYear < 295) {
      return 'SENESCENCE_YELLOWING';
    } else if (dayOfYear >= 295 && dayOfYear < 325) {
      return 'LEAF_DROP';
    } else {
      return 'DORMANT';
    }
  }

  private getSeralIndex(stage: SeralStage): number {
    const map: Record<SeralStage, number> = {
      STAGE_0_BARE_SUBSTRATE: 0,
      STAGE_1_PIONEER_CRUST_MOSS: 1,
      STAGE_2_EARLY_HERBACEOUS_GRASS: 2,
      STAGE_3_SHRUB_THICKET: 3,
      STAGE_4_EARLY_SERAL_PIONEER_WOODLAND: 4,
      STAGE_5_MID_SERAL_MIXED_FOREST: 5,
      STAGE_6_MATURE_CLIMAX_FOREST: 6,
      STAGE_7_OLD_GROWTH_COMPLEX: 7
    };
    return map[stage] ?? 6;
  }

  // =========================================================================
  // 3. ADVANCE SUCCESSION TIMELINE
  // =========================================================================

  public advanceSuccession(
    currentSuccession: EcologicalSuccessionState,
    soil: SoilState,
    annualGrowthMultiplier: number,
    yearsElapsed: number
  ): EcologicalSuccessionState {
    const newAge = currentSuccession.successionAgeYears + yearsElapsed;
    let newTimeInStage = currentSuccession.timeInCurrentStageYears + yearsElapsed;
    let newStageIdx = currentSuccession.seralStageIndex;

    const transitionYears = this.calculateStageTransitionYears(newStageIdx, currentSuccession.climaxBiomeTarget);

    // Can only advance if soil development allows and transition time is reached
    const soilReady = (newStageIdx + 1) * 0.12 <= soil.soilDepthMeters;

    if (newStageIdx < 6 && newTimeInStage >= transitionYears && soilReady && annualGrowthMultiplier > 0.3) {
      newStageIdx++;
      newTimeInStage = 0;
    } else if (newStageIdx === 6 && newTimeInStage >= 250 && newAge >= 350) {
      newStageIdx = 7; // Transitions to old-growth complex
      newTimeInStage = 0;
    }

    const stages: SeralStage[] = [
      'STAGE_0_BARE_SUBSTRATE',
      'STAGE_1_PIONEER_CRUST_MOSS',
      'STAGE_2_EARLY_HERBACEOUS_GRASS',
      'STAGE_3_SHRUB_THICKET',
      'STAGE_4_EARLY_SERAL_PIONEER_WOODLAND',
      'STAGE_5_MID_SERAL_MIXED_FOREST',
      'STAGE_6_MATURE_CLIMAX_FOREST',
      'STAGE_7_OLD_GROWTH_COMPLEX'
    ];

    const newStage = stages[newStageIdx];
    const isClimax = newStageIdx >= 6;
    const maturity = Math.min(1.0, newStageIdx / 6.0);

    return {
      ...currentSuccession,
      currentSeralStage: newStage,
      seralStageIndex: newStageIdx,
      successionAgeYears: newAge,
      timeInCurrentStageYears: newTimeInStage,
      yearsToNextSeralTransition: isClimax ? 0 : Math.max(0, transitionYears - newTimeInStage),
      climaxMaturityFraction: Math.round(maturity * 100) / 100,
      isClimaxReached: isClimax
    };
  }

  // =========================================================================
  // 4. WILDFIRE MODEL (Rothermel & Byram Intensity)
  // =========================================================================

  public simulateWildfire(
    veg: VegetationCommunityState,
    soil: SoilState,
    windSpeedMS: number,
    temperatureC: number,
    relativeHumidityPercent: number,
    slopeDegrees: number
  ): { wildfire: WildfireState; disturbance: DisturbanceImpactState; resetSuccessionStage?: SeralStage } {
    // 1. Fine Fuel Moisture calculation (Fosberg / NFDRS model)
    let fineFuelMoisture = 0.03 + 0.28 * (relativeHumidityPercent / 100.0) - 0.0005 * temperatureC;
    fineFuelMoisture = Math.max(0.02, Math.min(0.35, fineFuelMoisture));

    // 2. Fuel Load from vegetation dead biomass & surface litter
    const fuelLoadKgM2 = Math.max(0.1, veg.totalBiomassKgM2 * (0.15 + veg.deadFuelFraction * 0.35));

    // 3. Ignition probability
    let ignitionProb = Math.max(0, (35.0 - relativeHumidityPercent * 0.45) + Math.max(0, temperatureC - 25.0) * 1.8);
    if (soil.relativeSaturationIndex < 0.2) ignitionProb += 25.0;
    ignitionProb = Math.min(98.0, Math.max(1.0, ignitionProb));

    // 4. Fire Danger Rating
    let rating: WildfireState['fireDangerRating'] = 'LOW';
    if (ignitionProb > 80 || fineFuelMoisture < 0.06) rating = 'EXTREME';
    else if (ignitionProb > 60 || fineFuelMoisture < 0.10) rating = 'VERY_HIGH';
    else if (ignitionProb > 40 || fineFuelMoisture < 0.15) rating = 'HIGH';
    else if (ignitionProb > 20) rating = 'MODERATE';

    // 5. Rothermel Rate of Spread (m/min)
    const windFactor = Math.pow(Math.max(0, windSpeedMS * 2.237), 1.2) * 0.15;
    const slopeFactor = 5.275 * Math.pow(Math.tan((slopeDegrees * Math.PI) / 180.0), 2);
    const moistureDamping = Math.max(0.05, 1.0 - (fineFuelMoisture / 0.25));

    const rateOfSpread = Math.max(0.2, (1.2 + windFactor + slopeFactor) * moistureDamping);

    // 6. Byram Fireline Intensity I = H * w * R (kW/m)
    // Heat content H ~ 18,600 kJ/kg
    const firelineIntensity = (18600.0 * (fuelLoadKgM2 * 0.6) * (rateOfSpread / 60.0));
    const flameLength = 0.0775 * Math.pow(firelineIntensity, 0.46); // Byram flame length formula

    // 7. Burn Severity & Seral Reset
    let burnSeverity = 0.1;
    let resetStage: SeralStage | undefined = undefined;

    if (firelineIntensity > 3500.0 || flameLength > 4.0) {
      // Stand-replacing crown fire
      burnSeverity = 0.95;
      resetStage = 'STAGE_1_PIONEER_CRUST_MOSS';
    } else if (firelineIntensity > 1200.0 || flameLength > 2.0) {
      // Mixed-severity fire
      burnSeverity = 0.60;
      resetStage = 'STAGE_3_SHRUB_THICKET';
    } else if (firelineIntensity > 400.0) {
      // Moderate surface fire
      burnSeverity = 0.30;
    }

    const wildfire: WildfireState = {
      fuelLoadKgM2: Math.round(fuelLoadKgM2 * 100) / 100,
      fineDeadFuelMoisturePercent: Math.round(fineFuelMoisture * 1000) / 10,
      fireDangerRating: rating,
      ignitionProbabilityPercent: Math.round(ignitionProb),
      rateOfSpreadMPerMin: Math.round(rateOfSpread * 10) / 10,
      flameLengthMeters: Math.round(flameLength * 10) / 10,
      firelineIntensityKWPerM: Math.round(firelineIntensity),
      burnSeverityFraction: Math.round(burnSeverity * 100) / 100,
      timeSinceLastFireYears: 0,
      postFireCarbonEmissionKgM2: Math.round(fuelLoadKgM2 * burnSeverity * 0.48 * 100) / 100,
      charcoalAshLayerDepthMm: Math.round(burnSeverity * 15.0)
    };

    const disturbance: DisturbanceImpactState = {
      activeDisturbance: 'WILDFIRE',
      disturbanceIntensity: burnSeverity,
      treeMortalityFraction: Math.min(1.0, burnSeverity * 1.1),
      shrubMortalityFraction: Math.min(1.0, burnSeverity * 0.9),
      grassMortalityFraction: Math.min(1.0, burnSeverity * 0.8),
      biomassConsumedFraction: Math.round(burnSeverity * 0.75 * 100) / 100,
      soilCompactionOrErosionDelta: 0.35,
      recoveryDeficitYears: Math.round(burnSeverity * 45.0)
    };

    return { wildfire, disturbance, resetSuccessionStage: resetStage };
  }

  // =========================================================================
  // 5. DROUGHT DISTURBANCE
  // =========================================================================

  public simulateDroughtStress(
    veg: VegetationCommunityState,
    soil: SoilState,
    consecutiveDroughtDays: number
  ): DisturbanceImpactState {
    const deficitFraction = 1.0 - soil.relativeSaturationIndex;
    const stressIntensity = Math.min(1.0, (consecutiveDroughtDays / 90.0) * deficitFraction);

    const treeMortality = Math.max(0, (stressIntensity - 0.5) * 0.6);
    const shrubMortality = Math.max(0, (stressIntensity - 0.6) * 0.5);
    const grassMortality = Math.max(0, (stressIntensity - 0.3) * 0.8);

    return {
      activeDisturbance: stressIntensity > 0.4 ? 'SEVERE_DROUGHT' : 'NONE',
      disturbanceIntensity: Math.round(stressIntensity * 100) / 100,
      treeMortalityFraction: Math.round(treeMortality * 100) / 100,
      shrubMortalityFraction: Math.round(shrubMortality * 100) / 100,
      grassMortalityFraction: Math.round(grassMortality * 100) / 100,
      biomassConsumedFraction: 0.0,
      soilCompactionOrErosionDelta: Math.round(stressIntensity * 0.2 * 100) / 100,
      recoveryDeficitYears: Math.round(stressIntensity * 8.0)
    };
  }

  // =========================================================================
  // 6. FLOOD DISTURBANCE & WETLAND ADAPTATION
  // =========================================================================

  public simulateFloodDisturbance(
    veg: VegetationCommunityState,
    inundationDepthMeters: number,
    inundationDurationDays: number
  ): DisturbanceImpactState {
    const isFloodActive = inundationDepthMeters > 0.05 && inundationDurationDays > 1;
    if (!isFloodActive) {
      return {
        activeDisturbance: 'NONE',
        disturbanceIntensity: 0.0,
        treeMortalityFraction: 0.0,
        shrubMortalityFraction: 0.0,
        grassMortalityFraction: 0.0,
        biomassConsumedFraction: 0.0,
        soilCompactionOrErosionDelta: 0.0,
        recoveryDeficitYears: 0
      };
    }

    const nonHydrophyteMortality = Math.min(0.9, (inundationDurationDays / 20.0) * (inundationDepthMeters / 1.5));

    return {
      activeDisturbance: 'FLOOD_INUNDATION',
      disturbanceIntensity: Math.min(1.0, Math.round((inundationDurationDays / 30.0) * 100) / 100),
      treeMortalityFraction: Math.round(nonHydrophyteMortality * 0.4 * 100) / 100,
      shrubMortalityFraction: Math.round(nonHydrophyteMortality * 0.6 * 100) / 100,
      grassMortalityFraction: Math.round(nonHydrophyteMortality * 0.8 * 100) / 100,
      biomassConsumedFraction: 0.0,
      soilCompactionOrErosionDelta: 0.15, // alluvial sediment deposition
      recoveryDeficitYears: Math.round((inundationDurationDays / 15.0) * 2.0)
    };
  }
}
