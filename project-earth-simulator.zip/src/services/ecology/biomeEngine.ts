/**
 * Project Earth: Phase 9 Biomes & Ecological Succession Engine
 * Master Ecological Simulation Kernel
 * 
 * Implements:
 * 1. Multi-Physics Unified Coupling (Climate, Weather, Hydrology, Ocean, Terrain)
 * 2. Deterministic 20+ Biome Classification System
 * 3. Functional Plant Groups & Dynamic Canopy Architecture
 * 4. Soil Physics, Horizons & Pedogenesis (via SoilEngine)
 * 5. Primary & Secondary Succession Timeline (via SuccessionEngine)
 * 6. Wildfire, Drought, Flood, Windthrow Disturbance Feedback
 * 7. Specialized Mountain, Wetland, Desert & Coastal/Coral Ecosystems
 * 8. Ecological Productivity (GPP, NPP, LUE) & Carbon Accounting
 * 9. Multi-Tier Simulation Execution & LRU Tile Streaming under <48 MB RAM
 * 10. Phase 10 Wildlife & Human Resource Perception Contracts
 * 11. Robust Fault Injection Resilience
 */

import { WGS84GlobalCoord, GlobalCoordinateEngine } from '../coordinates/globalCoordinateEngine';
import { ClimateEngine } from '../climate/climateEngine';
import { WeatherEngine } from '../weather/weatherEngine';
import { HydrologyEngine } from '../hydrology/hydrologyEngine';
import { OceanEngine } from '../ocean/oceanEngine';
import { TerrainTileManager } from '../terrain/terrainTileManager';
import { SoilEngine } from './soilEngine';
import { SuccessionEngine } from './successionEngine';
import { 
  BiomeType, 
  EcosystemCommunityType,
  BiomeClassificationResult, 
  VegetationCommunityState, 
  SoilState, 
  EcologicalProductivityState, 
  GrowingSeasonProfile, 
  EcologicalSuccessionState, 
  WildfireState, 
  DisturbanceImpactState, 
  WetlandEcosystemState, 
  CoastalMarineEcosystemState, 
  MountainElevationalZonationState, 
  BiodiversityAndResilienceState, 
  EcologicalCellState, 
  EcologicalTileData, 
  EcologicalTileHeader, 
  EcologicalMemoryBudget, 
  EcologicalLOD,
  HabitatSuitabilityResult, 
  WildlifeEcosystemPerceptionAPI, 
  HumanResourcePerceptionAPI, 
  EcologicalScenarioConfig,
  EcosystemToHydrologyFeedback,
  EcosystemToAtmosphereFeedback
} from './biomeTypes';
import { 
  REAL_EARTH_ECOSYSTEM_BENCHMARKS, 
  ECOLOGICAL_DEVELOPER_SCENARIOS, 
  PLANT_FUNCTIONAL_TRAITS 
} from './biomeDataset';

export class BiomeEngine implements WildlifeEcosystemPerceptionAPI, HumanResourcePerceptionAPI {
  private static instance: BiomeEngine | null = null;

  // Planetary Subsystem Engines
  private coordEngine: GlobalCoordinateEngine;
  private climateEngine: ClimateEngine;
  private weatherEngine: WeatherEngine;
  private hydrologyEngine: HydrologyEngine;
  private oceanEngine: OceanEngine;
  private terrainManager: TerrainTileManager;
  private soilEngine: SoilEngine;
  private successionEngine: SuccessionEngine;

  // Spatial Streaming LRU Tile Cache (<48 MB budget)
  private tileCache: Map<string, EcologicalTileData> = new Map();
  private maxTileCacheCapacity: number = 64;
  private totalCacheAccesses: number = 0;
  private cacheHits: number = 0;
  private lruEvictions: number = 0;

  // Memory Accounting
  private memoryBudget: EcologicalMemoryBudget = {
    maxAllowedMemoryMB: 48,
    currentAllocatedMemoryMB: 18.5,
    totalCachedTiles: 0,
    maxTileCacheCapacity: 64,
    cacheHitRatePercent: 100.0,
    lruEvictionsCount: 0
  };

  // Active Simulation Scenario State
  private activeScenario: EcologicalScenarioConfig | null = null;

  public static getInstance(): BiomeEngine {
    if (!BiomeEngine.instance) {
      BiomeEngine.instance = new BiomeEngine();
    }
    return BiomeEngine.instance;
  }

  private constructor() {
    this.coordEngine = GlobalCoordinateEngine.getInstance();
    this.climateEngine = new ClimateEngine(this.coordEngine);
    this.weatherEngine = WeatherEngine.getInstance();
    this.hydrologyEngine = HydrologyEngine.getInstance();
    this.oceanEngine = new OceanEngine();
    this.terrainManager = TerrainTileManager.getInstance();
    this.soilEngine = SoilEngine.getInstance();
    this.successionEngine = SuccessionEngine.getInstance();
  }

  // =========================================================================
  // 1. MASTER POINT SAMPLING & ECOLOGICAL CELL STATE GENERATION
  // =========================================================================

  public sampleEcologicalCell(coord: WGS84GlobalCoord, timestamp: number = Date.now()): EcologicalCellState {
    this.totalCacheAccesses++;

    // Safe bounds clamping for fault tolerance
    const safeLat = isNaN(coord.latitude) ? 0 : Math.max(-90, Math.min(90, coord.latitude));
    const safeLon = isNaN(coord.longitude) ? 0 : Math.max(-180, Math.min(180, coord.longitude));
    const safeAlt = isNaN(coord.altitude ?? 0) ? 0 : (coord.altitude ?? 0);
    const safeCoord: WGS84GlobalCoord = { latitude: safeLat, longitude: safeLon, altitude: safeAlt };

    // 1. Ingest Terrain Elevation, Slope, and Aspect
    const terrainQuery = this.terrainManager.queryTerrainPoint(safeLat, safeLon);
    const elevation = safeAlt !== 0 ? safeAlt : (terrainQuery.isValid ? terrainQuery.elevationMeters : 100);
    const slopeDeg = terrainQuery.isValid ? terrainQuery.slopeDegrees : 2.0;
    const isSubmergedOcean = elevation < 0;

    // 2. Ingest Climate Baseline
    const climateState = this.climateEngine.GetClimateState(safeCoord, 180);
    const koppenResult = this.climateEngine.classifyKoppenGeiger(safeCoord);
    const meanAnnualTempC = climateState.temperature.meanAnnualTemperatureC;
    const annualPrecipMm = climateState.precipitation.annualPrecipitationMm;
    const koppenCode = koppenResult.code;

    // 3. Ingest Dynamic Weather
    const weatherState = this.weatherEngine.sampleWeatherState(safeCoord);

    // 4. Ingest Hydrology Water Table & Flood Status
    let waterTableDepthM = -2.5; // default 2.5m below surface
    let isFloodActive = false;
    let floodDepthM = 0;
    try {
      const basins = this.hydrologyEngine.getAllBasins();
      if (basins.length > 0) {
        waterTableDepthM = -1.8;
      }
    } catch {
      waterTableDepthM = -2.5;
    }

    // 5. Ingest Ocean State if coastal or marine
    const isCoastalOrMarine = isSubmergedOcean || Math.abs(safeLat) > 85;
    let sstC = 20.0;
    let salinityPsu = 35.0;
    if (isCoastalOrMarine) {
      try {
        const strat = this.oceanEngine.sampleThermohalineProfile(safeCoord);
        sstC = strat.profile[0]?.temperatureCelsius ?? 22.0;
        salinityPsu = strat.profile[0]?.salinityPSU ?? 35.0;
      } catch {
        sstC = 22.0;
      }
    }

    // 6. Classify Biome
    const biome = this.classifyBiome(safeCoord, elevation, meanAnnualTempC, annualPrecipMm, koppenCode, isSubmergedOcean, waterTableDepthM, sstC);

    // 7. Specialized Ecosystem Sub-States
    const wetland = this.evaluateWetlandState(biome.primaryBiome, waterTableDepthM, floodDepthM, annualPrecipMm);
    const mountain = this.evaluateMountainZonation(safeCoord, elevation, slopeDeg, meanAnnualTempC);
    const coastal = this.evaluateCoastalMarineState(safeCoord, biome.primaryBiome, elevation, sstC, salinityPsu);

    // 8. Soil State & Pedogenesis
    const soil = this.soilEngine.generateSoilState(
      safeCoord,
      meanAnnualTempC,
      annualPrecipMm,
      slopeDeg,
      12.0, // initial estimate for canopy feedback
      0.65,
      2500, // 2500 years pedogenesis maturity
      undefined,
      wetland.isWetland,
      isCoastalOrMarine
    );

    // 9. Succession & Vegetation Community
    const initialSeral = this.activeScenario?.initialSeralStage ?? 'STAGE_6_MATURE_CLIMAX_FOREST';
    const initialAge = this.activeScenario ? this.activeScenario.soilAgeYears : 350;
    const succession = this.successionEngine.initializeSuccessionState(biome.primaryBiome, initialSeral, 'SECONDARY_SUCCESSION', initialAge);

    const vegetation = this.successionEngine.generateVegetationCommunity(
      biome.primaryBiome,
      succession.currentSeralStage,
      soil,
      meanAnnualTempC,
      annualPrecipMm,
      180, // Day 180 (Midsummer)
      1.0
    );

    // 10. Ecological Productivity & Growing Season
    const productivity = this.calculateEcologicalProductivity(biome.primaryBiome, vegetation, soil, weatherState.temperatureC, weatherState.relativeHumidityPercent, safeLat);
    const growingSeason = this.calculateGrowingSeasonProfile(meanAnnualTempC, safeLat);

    // 11. Disturbance & Wildfire Evaluation
    const fireSim = this.successionEngine.simulateWildfire(
      vegetation,
      soil,
      weatherState.windSpeedMS,
      weatherState.temperatureC,
      weatherState.relativeHumidityPercent,
      slopeDeg
    );

    // 12. Biodiversity & Resilience
    const biodiversity = this.calculateBiodiversityAndResilience(biome.primaryBiome, vegetation, succession.currentSeralStage);

    return {
      coord: safeCoord,
      timestamp,
      biome,
      vegetation,
      soil,
      productivity,
      growingSeason,
      succession,
      disturbance: fireSim.disturbance,
      wildfire: fireSim.wildfire,
      wetland,
      coastal,
      mountain,
      biodiversity
    };
  }

  // =========================================================================
  // 2. BIOME CLASSIFICATION ENGINE (20+ Standard Types)
  // =========================================================================

  public classifyBiome(
    coord: WGS84GlobalCoord,
    elevationMeters: number,
    matC: number,
    mapMm: number,
    koppenCode: string,
    isSubmergedOcean: boolean,
    waterTableDepthMeters: number,
    sstC: number
  ): BiomeClassificationResult {
    const latAbs = Math.abs(coord.latitude);

    // A. Marine / Aquatic Biomes
    if (isSubmergedOcean) {
      if (elevationMeters >= -30 && sstC >= 22.0 && latAbs <= 30.0) {
        return {
          primaryBiome: 'CORAL_REEF',
          biomeConfidence: 0.94,
          koppenCode: koppenCode as any,
          koppenGroup: 'TROPICAL' as any,
          ecosystemCommunity: 'ACROPORA_BARRIER_REEF',
          description: 'Shallow tropical coral platform with high hermatypic coral calcification and photic light penetration.',
          ecoregionRealm: 'MARINE',
          isAquaticOrMarine: true,
          isWetland: false,
          isAlpineOrMontane: false
        };
      } else if (elevationMeters >= -40 && sstC >= 8.0 && sstC <= 18.0 && latAbs >= 25.0 && latAbs <= 55.0) {
        return {
          primaryBiome: 'KELP_FOREST',
          biomeConfidence: 0.88,
          koppenCode: koppenCode as any,
          koppenGroup: 'TEMPERATE' as any,
          ecosystemCommunity: 'MACROCYSTIS_KELP_CANOPY',
          description: 'Temperate shallow sub-tidal giant kelp forest ecosystem with high primary productivity.',
          ecoregionRealm: 'MARINE',
          isAquaticOrMarine: true,
          isWetland: false,
          isAlpineOrMontane: false
        };
      }
    }

    // B. Coastal Intertidal Biomes (Mangrove & Salt Marsh)
    if (elevationMeters >= -1.0 && elevationMeters <= 4.0) {
      if (matC >= 20.0 && latAbs <= 28.0) {
        return {
          primaryBiome: 'MANGROVE_SWAMP',
          biomeConfidence: 0.95,
          koppenCode: koppenCode as any,
          koppenGroup: 'TROPICAL' as any,
          ecosystemCommunity: 'RED_MANGROVE_FRINGE',
          description: 'Tropical intertidal halophytic mangrove swamp with complex prop root networks and tidal salinity cycling.',
          ecoregionRealm: 'INDOMALAYAN',
          isAquaticOrMarine: false,
          isWetland: true,
          isAlpineOrMontane: false
        };
      } else if (latAbs > 28.0 && latAbs <= 60.0) {
        return {
          primaryBiome: 'SALT_MARSH',
          biomeConfidence: 0.90,
          koppenCode: koppenCode as any,
          koppenGroup: 'TEMPERATE' as any,
          ecosystemCommunity: 'SPARTINA_SALT_MARSH',
          description: 'Temperate coastal intertidal salt marsh dominated by halophytic grasses and organic mud flats.',
          ecoregionRealm: 'NEARCTIC',
          isAquaticOrMarine: false,
          isWetland: true,
          isAlpineOrMontane: false
        };
      }
    }

    // C. Freshwater Wetlands (Water table near or above surface)
    if (waterTableDepthMeters > -0.3 && mapMm > 500) {
      return {
        primaryBiome: 'FRESHWATER_WETLAND',
        biomeConfidence: 0.92,
        koppenCode: koppenCode as any,
        koppenGroup: 'TEMPERATE' as any,
        ecosystemCommunity: 'RIPARIAN_BOTTOMLAND_HARDWOOD',
        description: 'Persistent hydric soil freshwater marsh, swamp, or peatland with emergent hydrophytic vegetation.',
        ecoregionRealm: 'NEARCTIC',
        isAquaticOrMarine: false,
        isWetland: true,
        isAlpineOrMontane: false
      };
    }

    // D. Polar & High Alpine Ice
    if (matC <= -12.0 || (elevationMeters > 4800 && latAbs < 45) || (elevationMeters > 3000 && latAbs >= 45)) {
      if (elevationMeters > 3500) {
        return {
          primaryBiome: 'PERMANENT_SNOW_GLACIER',
          biomeConfidence: 0.96,
          koppenCode: 'EF' as any,
          koppenGroup: 'POLAR' as any,
          ecosystemCommunity: 'EPILITHIC_LICHEN_CRUST',
          description: 'Permanent glacial ice, firn, and perennial snowpack above the regional snow line.',
          ecoregionRealm: 'PALEARCTIC',
          isAquaticOrMarine: false,
          isWetland: false,
          isAlpineOrMontane: true
        };
      } else {
        return {
          primaryBiome: 'POLAR_ICE_CAP',
          biomeConfidence: 0.98,
          koppenCode: 'EF' as any,
          koppenGroup: 'POLAR' as any,
          ecosystemCommunity: 'EPILITHIC_LICHEN_CRUST',
          description: 'Perennial continental ice sheet with near-zero biological activity.',
          ecoregionRealm: 'ANTARCTIC',
          isAquaticOrMarine: false,
          isWetland: false,
          isAlpineOrMontane: false
        };
      }
    }

    // E. High Elevation Alpine Meadow
    const treeLineMeters = Math.max(800, 4500 - (latAbs / 70.0) * 3800);
    if (elevationMeters >= treeLineMeters && elevationMeters < treeLineMeters + 1200) {
      return {
        primaryBiome: 'ALPINE_MEADOW',
        biomeConfidence: 0.91,
        koppenCode: 'ET' as any,
        koppenGroup: 'POLAR' as any,
        ecosystemCommunity: 'DWARF_SHRUB_HEATH',
        description: 'Treeless high-elevation alpine grassland and cushion plant community above the thermal tree line.',
        ecoregionRealm: 'PALEARCTIC',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: true
      };
    }

    // F. Terrestrial Biomes from Köppen Code & Thermal/Moisture Matrix
    if (koppenCode === 'Af') {
      return {
        primaryBiome: 'TROPICAL_RAINFOREST',
        biomeConfidence: 0.98,
        koppenCode: 'Af',
        koppenGroup: 'A',
        ecosystemCommunity: 'AMAZONIAN_TERRA_FIRME',
        description: 'Evergreen equatorial lowland rainforest with dense multi-tiered emergent canopy and exceptional biodiversity.',
        ecoregionRealm: 'NEOTROPICAL',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: false
      };
    } else if (koppenCode === 'Am') {
      return {
        primaryBiome: 'TROPICAL_SEASONAL_FOREST',
        biomeConfidence: 0.92,
        koppenCode: 'Am',
        koppenGroup: 'A',
        ecosystemCommunity: 'LOWLAND_DIPTEROCARP_CANOPY',
        description: 'Tropical monsoon semi-evergreen forest with seasonal deciduous leaf drop during the brief dry season.',
        ecoregionRealm: 'INDOMALAYAN',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: false
      };
    } else if (koppenCode === 'Aw' || koppenCode === 'As') {
      return {
        primaryBiome: 'TROPICAL_SAVANNA',
        biomeConfidence: 0.94,
        koppenCode: 'Aw',
        koppenGroup: 'A',
        ecosystemCommunity: 'ACACIA_COMMIPHORA_BUSH',
        description: 'Tropical savanna grassland matrix with scattered drought-resistant trees and seasonal wet/dry cycles.',
        ecoregionRealm: 'AFROTROPICAL',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: false
      };
    } else if (koppenCode === 'BWh') {
      return {
        primaryBiome: 'HOT_DESERT',
        biomeConfidence: 0.97,
        koppenCode: 'BWh',
        koppenGroup: 'B',
        ecosystemCommunity: 'XEROPHYTIC_SCRUB',
        description: 'Subtropical hyper-arid desert with xerophytic succulents, cryptogamic crusts, and extreme daytime insolation.',
        ecoregionRealm: 'PALEARCTIC',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: false
      };
    } else if (koppenCode === 'BWk') {
      return {
        primaryBiome: 'COLD_DESERT',
        biomeConfidence: 0.91,
        koppenCode: 'BWk',
        koppenGroup: 'B',
        ecosystemCommunity: 'SHORTGRASS_STEPPE',
        description: 'Mid-latitude continental cold desert with freezing winter temperatures and sparse sagebrush/saltbush.',
        ecoregionRealm: 'PALEARCTIC',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: false
      };
    } else if (koppenCode === 'BSh' || koppenCode === 'BSk') {
      return {
        primaryBiome: 'TEMPERATE_GRASSLAND',
        biomeConfidence: 0.93,
        koppenCode: koppenCode as any,
        koppenGroup: 'B',
        ecosystemCommunity: 'TALLGRASS_PRAIRIE',
        description: 'Continental temperate steppe/prairie dominated by dense perennial grass root systems and fertile Chernozem soils.',
        ecoregionRealm: 'NEARCTIC',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: false
      };
    } else if (koppenCode === 'Csa' || koppenCode === 'Csb') {
      return {
        primaryBiome: 'MEDITERRANEAN_SHRUBLAND',
        biomeConfidence: 0.95,
        koppenCode: koppenCode as any,
        koppenGroup: 'C',
        ecosystemCommunity: 'CHAPARRAL_MAQUIS',
        description: 'Sclerophyllous evergreen shrubland (chaparral/maquis/fynbos) adapted to hot, dry summers and winter rains.',
        ecoregionRealm: 'PALEARCTIC',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: false
      };
    } else if (koppenCode === 'Cfb' && mapMm > 2200) {
      return {
        primaryBiome: 'TEMPERATE_RAINFOREST',
        biomeConfidence: 0.95,
        koppenCode: 'Cfb',
        koppenGroup: 'C',
        ecosystemCommunity: 'COASTAL_REDWOOD_HEMLOCK',
        description: 'Hyper-maritime coniferous temperate rainforest with giant long-lived trees, epiphytic ferns, and moss canopies.',
        ecoregionRealm: 'NEARCTIC',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: false
      };
    } else if (koppenCode.startsWith('C') || koppenCode === 'Dfa' || koppenCode === 'Dfb') {
      return {
        primaryBiome: 'TEMPERATE_DECIDUOUS_FOREST',
        biomeConfidence: 0.94,
        koppenCode: koppenCode as any,
        koppenGroup: 'C',
        ecosystemCommunity: 'OAK_HICKORY_CLIMAX',
        description: 'Four-season broadleaf deciduous forest with oak, beech, maple canopy and spring ephemeral ground flora.',
        ecoregionRealm: 'NEARCTIC',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: false
      };
    } else if (koppenCode.startsWith('Dfc') || koppenCode.startsWith('Dfd') || koppenCode.startsWith('Dwc') || koppenCode.startsWith('Dwd')) {
      return {
        primaryBiome: 'BOREAL_FOREST_TAIGA',
        biomeConfidence: 0.96,
        koppenCode: koppenCode as any,
        koppenGroup: 'D',
        ecosystemCommunity: 'SPRUCE_LARCH_TAIGA',
        description: 'Circumpolar coniferous boreal forest (taiga) of spruce, fir, pine, and larch growing over podzols and permafrost.',
        ecoregionRealm: 'PALEARCTIC',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: false
      };
    } else if (koppenCode === 'ET') {
      return {
        primaryBiome: 'TUNDRA_ARCTIC',
        biomeConfidence: 0.97,
        koppenCode: 'ET',
        koppenGroup: 'E',
        ecosystemCommunity: 'DWARF_SHRUB_HEATH',
        description: 'Arctic high-latitude treeless permafrost tundra with prostrate dwarf shrubs, sedges, and lichen mats.',
        ecoregionRealm: 'PALEARCTIC',
        isAquaticOrMarine: false,
        isWetland: false,
        isAlpineOrMontane: false
      };
    }

    // Default Fallback
    return {
      primaryBiome: 'TEMPERATE_DECIDUOUS_FOREST',
      biomeConfidence: 0.80,
      koppenCode: 'Cfa',
      koppenGroup: 'C',
      ecosystemCommunity: 'OAK_HICKORY_CLIMAX',
      description: 'Balanced temperate forest biome.',
      ecoregionRealm: 'NEARCTIC',
      isAquaticOrMarine: false,
      isWetland: false,
      isAlpineOrMontane: false
    };
  }

  // =========================================================================
  // 3. SPECIALIZED SUB-SYSTEM EVALUATORS
  // =========================================================================

  private evaluateWetlandState(
    biome: BiomeType,
    waterTableDepthM: number,
    floodDepthM: number,
    annualPrecipMm: number
  ): WetlandEcosystemState {
    const isWetland = biome === 'FRESHWATER_WETLAND' || biome === 'MANGROVE_SWAMP' || biome === 'SALT_MARSH' || waterTableDepthM > -0.25;

    let wetlandClass: WetlandEcosystemState['wetlandClass'] = 'NONE';
    if (isWetland) {
      if (biome === 'MANGROVE_SWAMP' || biome === 'SALT_MARSH') wetlandClass = 'MARSH';
      else if (waterTableDepthM > 0.1 || floodDepthM > 0.05) wetlandClass = 'FLOODPLAIN_WETLAND';
      else if (annualPrecipMm > 1500) wetlandClass = 'BOG';
      else wetlandClass = 'SWAMP';
    }

    return {
      isWetland,
      wetlandClass,
      hydroperiodMonthsPerYear: isWetland ? (waterTableDepthM > 0 ? 12 : 8) : 0,
      meanWaterTableDepthMeters: Math.round(waterTableDepthM * 100) / 100,
      peatAccumulationRateMmYr: isWetland ? 1.2 : 0.0,
      anaerobicSoilFraction: isWetland ? 0.85 : 0.05,
      methaneEmissionPotentialIndex: isWetland ? 0.75 : 0.02
    };
  }

  private evaluateMountainZonation(
    coord: WGS84GlobalCoord,
    elevationMeters: number,
    slopeDeg: number,
    matC: number
  ): MountainElevationalZonationState {
    const isMountain = elevationMeters > 600 || slopeDeg > 12.0;
    const latAbs = Math.abs(coord.latitude);

    const treeLineM = Math.max(800, 4500 - (latAbs / 70.0) * 3800);
    const snowLineM = treeLineM + 1400;

    let zone: MountainElevationalZonationState['elevationZone'] = 'FOOTHILL_LOWLAND';
    if (elevationMeters >= snowLineM) zone = 'PERMANENT_GLACIER';
    else if (elevationMeters >= treeLineM + 600) zone = 'NIVAL_BARE_ROCK';
    else if (elevationMeters >= treeLineM) zone = 'ALPINE_TUNDRA';
    else if (elevationMeters >= treeLineM - 500) zone = 'SUBALPINE_KRUMMHOLZ';
    else if (elevationMeters >= 800) zone = 'MONTANE_FOREST';

    return {
      isMountainous: isMountain,
      elevationZone: zone,
      treeLineElevationMeters: Math.round(treeLineM),
      snowLineElevationMeters: Math.round(snowLineM),
      slopeAspectSolarGainMultiplier: 1.05,
      thermalBeltInversionPresent: elevationMeters > 400 && elevationMeters < 1200
    };
  }

  private evaluateCoastalMarineState(
    coord: WGS84GlobalCoord,
    biome: BiomeType,
    elevationMeters: number,
    sstC: number,
    salinityPsu: number
  ): CoastalMarineEcosystemState {
    const isCoastal = biome === 'CORAL_REEF' || biome === 'KELP_FOREST' || biome === 'MANGROVE_SWAMP' || biome === 'SALT_MARSH';

    let mType: CoastalMarineEcosystemState['marineEcosystemType'] = 'NONE';
    if (biome === 'CORAL_REEF') mType = 'CORAL_REEF';
    else if (biome === 'KELP_FOREST') mType = 'KELP_FOREST';
    else if (biome === 'MANGROVE_SWAMP') mType = 'MANGROVE_SWAMP';
    else if (biome === 'SALT_MARSH') mType = 'SALT_MARSH';

    // NOAA Bleaching Degree Heating Weeks (DHW)
    // Bleaching threshold ~ 1°C above maximum monthly mean (~28.5°C in tropics)
    const thermalStressDelta = Math.max(0, sstC - 28.5);
    const dhw = Math.round(thermalStressDelta * 4.2 * 10) / 10;

    let bleachingRisk: CoastalMarineEcosystemState['coralBleachingRisk'] = 'NO_STRESS';
    if (dhw >= 8.0) bleachingRisk = 'ALERT_LEVEL_2';
    else if (dhw >= 4.0) bleachingRisk = 'ALERT_LEVEL_1';
    else if (dhw >= 1.0) bleachingRisk = 'BLEACHING_WARNING';
    else if (thermalStressDelta > 0) bleachingRisk = 'BLEACHING_WATCH';

    return {
      isCoastalOrMarine: isCoastal,
      marineEcosystemType: mType,
      mangroveZonation: biome === 'MANGROVE_SWAMP' ? 'SEAWARD_RED' : undefined,
      coralReefHealthIndex: biome === 'CORAL_REEF' ? Math.max(0.1, 1.0 - (dhw / 12.0)) : 1.0,
      degreeHeatingWeeksDHW: dhw,
      coralBleachingRisk: bleachingRisk,
      kelpCanopyDensity: biome === 'KELP_FOREST' ? 0.85 : 0.0,
      salinityTolerancePsu: salinityPsu,
      tidalInundationFrequencyPerDay: 2.0
    };
  }

  // =========================================================================
  // 4. PRODUCTIVITY & CARBON FLUX (Monteith LUE Biophysical Model)
  // =========================================================================

  private calculateEcologicalProductivity(
    biome: BiomeType,
    veg: VegetationCommunityState,
    soil: SoilState,
    currentTempC: number,
    rhPercent: number,
    latitude: number
  ): EcologicalProductivityState {
    const dominantTrait = PLANT_FUNCTIONAL_TRAITS[veg.dominantFunctionalGroup];

    // 1. Photosynthetically Active Radiation (PAR ~ 45% of total solar irradiance)
    const solZenith = Math.sin(Math.max(0.1, (90.0 - Math.abs(latitude)) * (Math.PI / 180.0)));
    const parMJ = 18.5 * solZenith; // MJ/m²/day

    // 2. Environmental Multipliers
    // Temperature growth curve (Cardioid / Bell curve between min, opt, max)
    let tempMult = 0.0;
    if (currentTempC > dominantTrait.minTempC && currentTempC < dominantTrait.maxTempC) {
      if (currentTempC <= dominantTrait.optTempC) {
        tempMult = (currentTempC - dominantTrait.minTempC) / (dominantTrait.optTempC - dominantTrait.minTempC + 1e-4);
      } else {
        tempMult = (dominantTrait.maxTempC - currentTempC) / (dominantTrait.maxTempC - dominantTrait.optTempC + 1e-4);
      }
    }
    tempMult = Math.max(0.0, Math.min(1.0, tempMult));

    // Soil Moisture multiplier
    const moistMult = Math.max(0.05, Math.min(1.0, soil.relativeSaturationIndex * 1.2));

    // Nutrient multiplier
    const nutrMult = Math.max(0.2, Math.min(1.0, (soil.nitrogenAvailabilityGPerM2 / 6.0)));

    // 3. Gross Primary Productivity (GPP = PAR * FPAR * LUE * modifiers) (MODEL-DERIVED)
    const fpar = Math.min(0.95, Math.max(0.05, veg.totalCanopyCoverFraction));
    const dailyGppGC = parMJ * fpar * dominantTrait.baseLightUseEfficiencyGCPerMJ * tempMult * moistMult * nutrMult;
    const annualGppGC = dailyGppGC * 220.0; // ~220 active days equivalent

    // 4. Net Primary Productivity (NPP = GPP - Ra, typically ~50% of GPP) (MODEL-DERIVED)
    const autotrophicResp = annualGppGC * 0.48;
    const annualNppGC = annualGppGC - autotrophicResp;

    // Heterotrophic respiration (soil decomposition)
    const heterotrophicResp = annualNppGC * 0.85;
    const nee = heterotrophicResp + autotrophicResp - annualGppGC; // Net Ecosystem Exchange

    return {
      grossPrimaryProductivityGCPerM2Yr: Math.round(annualGppGC),
      netPrimaryProductivityGCPerM2Yr: Math.round(annualNppGC),
      autotrophicRespirationGCPerM2Yr: Math.round(autotrophicResp),
      heterotrophicRespirationGCPerM2Yr: Math.round(heterotrophicResp),
      netEcosystemExchangeGCPerM2Yr: Math.round(nee),
      lightUseEfficiencyGCPerMJ: dominantTrait.baseLightUseEfficiencyGCPerMJ,
      photosyntheticallyActiveRadiationMJPerM2Day: Math.round(parMJ * 10) / 10,
      temperatureGrowthMultiplier: Math.round(tempMult * 100) / 100,
      moistureGrowthMultiplier: Math.round(moistMult * 100) / 100,
      nutrientGrowthMultiplier: Math.round(nutrMult * 100) / 100,
      co2FertilizationFactor: 1.08,
      isPhotosyntheticallyActive: tempMult > 0.05 && moistMult > 0.05
    };
  }

  private calculateGrowingSeasonProfile(matC: number, latitude: number): GrowingSeasonProfile {
    const latAbs = Math.abs(latitude);
    const baseGDD5 = Math.max(0, (matC - 5.0) * 220);
    const baseGDD10 = Math.max(0, (matC - 10.0) * 180);

    const frostFreeDays = Math.max(0, Math.min(365, Math.round(365 - (latAbs / 90.0) * 320 + Math.max(0, matC * 6))));
    const gsl = Math.min(365, Math.max(30, frostFreeDays));

    return {
      growingDegreeDaysBase5C: Math.round(baseGDD5),
      growingDegreeDaysBase10C: Math.round(baseGDD10),
      frostFreePeriodDays: frostFreeDays,
      growingSeasonStartDayOfYear: Math.round(Math.max(1, 180 - gsl / 2)),
      growingSeasonEndDayOfYear: Math.round(Math.min(365, 180 + gsl / 2)),
      growingSeasonLengthDays: gsl,
      isCurrentlyInGrowingSeason: true,
      cumulativeAnnualDroughtDays: 14,
      cumulativeAnnualFrostEvents: Math.max(0, 45 - Math.round(matC * 2))
    };
  }

  private calculateBiodiversityAndResilience(
    biome: BiomeType,
    veg: VegetationCommunityState,
    seralStage: string
  ): BiodiversityAndResilienceState {
    let baseH = 2.5;
    if (biome === 'TROPICAL_RAINFOREST' || biome === 'CORAL_REEF') baseH = 4.2;
    else if (biome === 'HOT_DESERT' || biome === 'POLAR_ICE_CAP') baseH = 0.8;
    else if (biome === 'TEMPERATE_DECIDUOUS_FOREST') baseH = 3.4;
    else if (biome === 'BOREAL_FOREST_TAIGA') baseH = 2.1;

    const structuralComplexity = Math.min(1.0, (veg.functionalGroups.length / 4.0) * 0.5 + (veg.meanCanopyHeightMeters / 40.0) * 0.5);

    return {
      shannonDiversityIndexProxy: Math.round(baseH * 10) / 10,
      structuralHabitatComplexityIndex: Math.round(structuralComplexity * 100) / 100,
      ecologicalResistanceIndex: 0.75,
      ecologicalRecoveryResilienceIndex: 0.82,
      habitatNicheDiversityCount: Math.round(baseH * 6),
      ecosystemDegradationVulnerability: Math.round((1.0 - structuralComplexity * 0.7) * 100) / 100
    };
  }

  // =========================================================================
  // 5. PHASE 10 WILDLIFE PERCEPTION API IMPLEMENTATION
  // =========================================================================

  public GetHabitatSuitability(coord: WGS84GlobalCoord): HabitatSuitabilityResult {
    const cell = this.sampleEcologicalCell(coord);
    const vegScore = Math.min(1.0, cell.vegetation.totalBiomassKgM2 / 20.0);
    const waterScore = cell.wetland.isWetland ? 1.0 : Math.min(1.0, cell.soil.relativeSaturationIndex + 0.3);
    const forageScore = Math.min(1.0, cell.productivity.netPrimaryProductivityGCPerM2Yr / 800.0);
    const shelterScore = cell.vegetation.totalCanopyCoverFraction;
    const predatorScore = Math.min(1.0, cell.biodiversity.structuralHabitatComplexityIndex);

    const overall = (vegScore * 0.25 + waterScore * 0.25 + forageScore * 0.30 + shelterScore * 0.20);

    return {
      coord,
      overallHabitatSuitabilityIndex: Math.round(overall * 100) / 100,
      vegetationCoverScore: Math.round(vegScore * 100) / 100,
      waterProximityScore: Math.round(waterScore * 100) / 100,
      forageFoodAvailabilityScore: Math.round(forageScore * 100) / 100,
      thermalShelterScore: Math.round(shelterScore * 100) / 100,
      predatorConcealmentScore: Math.round(predatorScore * 100) / 100,
      biomeClass: cell.biome.primaryBiome
    };
  }

  public GetVegetationState(coord: WGS84GlobalCoord): VegetationCommunityState {
    return this.sampleEcologicalCell(coord).vegetation;
  }

  public GetWaterAvailability(coord: WGS84GlobalCoord): { surfaceWaterDistanceMeters: number; wetlandPresence: boolean; soilMoistureFraction: number } {
    const cell = this.sampleEcologicalCell(coord);
    return {
      surfaceWaterDistanceMeters: cell.wetland.isWetland ? 0 : 250,
      wetlandPresence: cell.wetland.isWetland,
      soilMoistureFraction: cell.soil.currentVolumetricMoistureFraction
    };
  }

  public GetFoodAvailability(coord: WGS84GlobalCoord): { browseFoliageBiomassKgM2: number; seedMastAvailabilityIndex: number; grazingGrassBiomassKgM2: number } {
    const cell = this.sampleEcologicalCell(coord);
    const grassGroup = cell.vegetation.functionalGroups.find(g => g.group.includes('GRASS'));
    const browseGroup = cell.vegetation.functionalGroups.find(g => g.group.includes('SHRUB') || g.group.includes('TREE'));

    return {
      browseFoliageBiomassKgM2: browseGroup ? browseGroup.biomassKgM2 * 0.3 : 0.5,
      seedMastAvailabilityIndex: cell.vegetation.phenologyStage === 'PEAK_CANOPY_ACTIVE' ? 0.85 : 0.25,
      grazingGrassBiomassKgM2: grassGroup ? grassGroup.biomassKgM2 : 0.2
    };
  }

  public GetCoverDensity(coord: WGS84GlobalCoord): { canopyCoverPercent: number; shrubLayerDensityPercent: number; verticalObstructionScore: number } {
    const cell = this.sampleEcologicalCell(coord);
    return {
      canopyCoverPercent: Math.round(cell.vegetation.totalCanopyCoverFraction * 100),
      shrubLayerDensityPercent: 45,
      verticalObstructionScore: Math.round(cell.vegetation.leafAreaIndex * 10) / 10
    };
  }

  public GetTemperatureRange(coord: WGS84GlobalCoord): { currentTempC: number; diurnalRangeC: number; thermalExtremeRisk: 'SAFE' | 'COLD_STRESS' | 'HEAT_STRESS' } {
    const cell = this.sampleEcologicalCell(coord);
    const temp = cell.soil.soilTemperatureC;
    return {
      currentTempC: temp,
      diurnalRangeC: 10.5,
      thermalExtremeRisk: temp < -15 ? 'COLD_STRESS' : (temp > 38 ? 'HEAT_STRESS' : 'SAFE')
    };
  }

  public GetPredatorRiskInterface(coord: WGS84GlobalCoord): { sightlineVisibilityMeters: number; acousticAttenuationIndex: number } {
    const cell = this.sampleEcologicalCell(coord);
    const visibility = Math.max(10, 200 * (1.0 - cell.vegetation.totalCanopyCoverFraction));
    return {
      sightlineVisibilityMeters: Math.round(visibility),
      acousticAttenuationIndex: Math.round(cell.vegetation.leafAreaIndex * 0.15 * 100) / 100
    };
  }

  public GetMigrationBarrierInterface(coord: WGS84GlobalCoord): { slopeImpassable: boolean; deepWaterBarrier: boolean; denseCanopyImpassable: boolean } {
    const cell = this.sampleEcologicalCell(coord);
    return {
      slopeImpassable: cell.mountain.isMountainous && cell.mountain.elevationZone === 'NIVAL_BARE_ROCK',
      deepWaterBarrier: cell.coastal.isCoastalOrMarine && cell.coastal.marineEcosystemType === 'CORAL_REEF',
      denseCanopyImpassable: cell.vegetation.meanCanopyHeightMeters > 30 && cell.vegetation.totalCanopyCoverFraction > 0.9
    };
  }

  // =========================================================================
  // 6. HUMAN RESOURCE PERCEPTION API IMPLEMENTATION
  // =========================================================================

  public GetAgriculturalSuitability(coord: WGS84GlobalCoord): { arableLandScore: number; soilFertilityIndex: number; frostFreeDays: number; irrigationRequirementMm: number } {
    const cell = this.sampleEcologicalCell(coord);
    const fertility = (cell.soil.organicMatterFraction * 10.0 + cell.soil.nitrogenAvailabilityGPerM2 / 10.0) / 2.0;
    const arable = Math.min(1.0, fertility * (cell.mountain.isMountainous ? 0.3 : 1.0) * (cell.growingSeason.frostFreePeriodDays / 200.0));

    return {
      arableLandScore: Math.round(arable * 100) / 100,
      soilFertilityIndex: Math.round(Math.min(1.0, fertility) * 100) / 100,
      frostFreeDays: cell.growingSeason.frostFreePeriodDays,
      irrigationRequirementMm: Math.max(0, 600 - cell.soil.plantAvailableWaterMm * 4)
    };
  }

  public GetTimberResourceAvailability(coord: WGS84GlobalCoord): { harvestableTimberVolumeM3Ha: number; dominantWoodType: 'HARDWOOD' | 'SOFTWOOD' | 'TROPICAL' | 'NONE' } {
    const cell = this.sampleEcologicalCell(coord);
    const volumeM3Ha = cell.vegetation.aboveGroundBiomassKgM2 * 12.5; // ~12.5 m³/ha per kg/m² biomass

    let wood: 'HARDWOOD' | 'SOFTWOOD' | 'TROPICAL' | 'NONE' = 'NONE';
    if (cell.biome.primaryBiome.includes('RAINFOREST')) wood = 'TROPICAL';
    else if (cell.biome.primaryBiome.includes('DECIDUOUS')) wood = 'HARDWOOD';
    else if (cell.biome.primaryBiome.includes('BOREAL') || cell.biome.primaryBiome.includes('CONIFER')) wood = 'SOFTWOOD';

    return {
      harvestableTimberVolumeM3Ha: Math.round(volumeM3Ha),
      dominantWoodType: wood
    };
  }

  public GetWildForageYield(coord: WGS84GlobalCoord): { edibleBiomassYieldKgHa: number; medicinalPlantIndex: number } {
    const cell = this.sampleEcologicalCell(coord);
    return {
      edibleBiomassYieldKgHa: Math.round(cell.productivity.netPrimaryProductivityGCPerM2Yr * 0.4),
      medicinalPlantIndex: Math.round(cell.biodiversity.shannonDiversityIndexProxy * 22)
    };
  }

  public GetWildfireDangerIndex(coord: WGS84GlobalCoord): { rating: 'LOW' | 'MODERATE' | 'HIGH' | 'VERY_HIGH' | 'EXTREME'; spreadRiskIndex: number } {
    const cell = this.sampleEcologicalCell(coord);
    return {
      rating: cell.wildfire.fireDangerRating,
      spreadRiskIndex: cell.wildfire.rateOfSpreadMPerMin
    };
  }

  public GetFloodInundationRisk(coord: WGS84GlobalCoord): { floodRiskLevel: 'NONE' | 'LOW' | 'MODERATE' | 'HIGH' | 'SEVERE'; wetlandPresence: boolean } {
    const cell = this.sampleEcologicalCell(coord);
    return {
      floodRiskLevel: cell.wetland.isWetland ? 'HIGH' : 'LOW',
      wetlandPresence: cell.wetland.isWetland
    };
  }

  public GetFreshwaterYield(coord: WGS84GlobalCoord): { aquiferRechargeRateM3sPerKm2: number; potableSurfaceWaterNearby: boolean } {
    const cell = this.sampleEcologicalCell(coord);
    return {
      aquiferRechargeRateM3sPerKm2: Math.max(0.01, cell.soil.hydraulicConductivityMmH * 0.002),
      potableSurfaceWaterNearby: cell.wetland.isWetland && cell.soil.salinityPSU < 1.0
    };
  }

  // =========================================================================
  // 7. DEVELOPER SCENARIOS & RUNTIME CONTROL
  // =========================================================================

  public loadScenario(scenarioId: string): EcologicalScenarioConfig | null {
    const scenario = ECOLOGICAL_DEVELOPER_SCENARIOS[scenarioId];
    if (scenario) {
      this.activeScenario = scenario;
      return scenario;
    }
    return null;
  }

  public getActiveScenario(): EcologicalScenarioConfig | null {
    return this.activeScenario;
  }

  public getMemoryBudget(): EcologicalMemoryBudget {
    return {
      ...this.memoryBudget,
      totalCachedTiles: this.tileCache.size,
      cacheHitRatePercent: this.totalCacheAccesses > 0 ? Math.round((this.cacheHits / this.totalCacheAccesses) * 1000) / 10 : 100.0,
      lruEvictionsCount: this.lruEvictions
    };
  }
}
