/**
 * Project Earth: Phase 9 Biomes & Ecological Succession Engine
 * Soil State Engine & Pedogenesis Simulator
 * 
 * Implements:
 * 1. Multi-Layer Soil Horizon State (O, A, B, C, R horizons)
 * 2. Pedogenesis & Weathering Rate Dynamics (Chemical & physical bedrock breakdown over centuries)
 * 3. Saxton-Rawls Soil Moisture & Hydraulic Physics (Field capacity, wilting point, hydraulic conductivity)
 * 4. Soil Hydrology Coupling with Phase 5 Hydrology (Infiltration, capillary rise, saturation, percolation)
 * 5. Soil Organic Carbon (SOC) Accumulation & Century-Model Decomposition Kinetics
 * 6. Nitrogen & Phosphorus Mineralization & Nutrient Availability
 * 7. Topographic Erosion (USLE / RUSLE mechanics mitigated by vegetation canopy & root anchoring)
 */

import { WGS84GlobalCoord } from '../coordinates/globalCoordinateEngine';
import { 
  SoilState, 
  SoilHorizonLayer, 
  USDASoilTextureClass 
} from './biomeTypes';
import { USDA_SOIL_TEXTURE_TABLE } from './biomeDataset';

export class SoilEngine {
  private static instance: SoilEngine | null = null;

  public static getInstance(): SoilEngine {
    if (!SoilEngine.instance) {
      SoilEngine.instance = new SoilEngine();
    }
    return SoilEngine.instance;
  }

  /**
   * Initializes or calculates the physical soil state based on climate, topography, vegetation, and historical age
   */
  public generateSoilState(
    coord: WGS84GlobalCoord,
    meanAnnualTempC: number,
    annualPrecipMm: number,
    slopeDegrees: number,
    vegetationBiomassKgM2: number,
    canopyCoverFraction: number,
    soilAgeYears: number = 2000,
    forcedTexture?: USDASoilTextureClass,
    isWetland: boolean = false,
    isOceanOrCoastal: boolean = false
  ): SoilState {
    // 1. Determine Texture Class based on climate, parent material & weathering age
    let textureClass: USDASoilTextureClass = forcedTexture || this.inferTextureClass(meanAnnualTempC, annualPrecipMm, soilAgeYears, isWetland);
    const textureParams = USDA_SOIL_TEXTURE_TABLE[textureClass];

    // 2. Pedogenesis: Soil Depth Calculation
    // Base weathering rate ~ 0.05 mm/yr under moderate climate, scaled by moisture & heat
    const climateWeatheringFactor = Math.max(0.1, (annualPrecipMm / 800.0) * Math.exp((meanAnnualTempC - 10.0) / 15.0));
    const potentialSoilDepthMeters = Math.min(3.5, 0.05 + 0.85 * Math.log10(Math.max(1, soilAgeYears)) * (climateWeatheringFactor * 0.35));

    // Topographic slope erosion reduction (USLE topographic factor LS)
    const slopeRad = (slopeDegrees * Math.PI) / 180.0;
    const slopeErosionPenalty = Math.max(0.1, Math.cos(slopeRad) * (1.0 - Math.min(0.85, Math.sin(slopeRad) * 1.5)));
    
    // Vegetation canopy & root anchoring protects soil from erosion
    const vegetationProtection = 0.2 + 0.8 * Math.min(1.0, canopyCoverFraction + (vegetationBiomassKgM2 / 20.0) * 0.5);
    
    let soilDepthM = Math.max(0.02, potentialSoilDepthMeters * slopeErosionPenalty * vegetationProtection);
    if (isOceanOrCoastal && coord.altitude && coord.altitude < 0) {
      soilDepthM = 0.5; // Marine sediment layer
    }

    // 3. Soil Organic Carbon (SOC) and Organic Matter (SOM)
    // Cold, wet climates accumulate thick organic layers (Histosols/Gelisols); hot dry climates have low organic matter
    let baseOrganicMatter = 0.035; // 3.5% baseline
    if (isWetland) {
      baseOrganicMatter = 0.25; // Peat accumulation in anaerobic waterlogged wetlands
    } else if (meanAnnualTempC < 0) {
      baseOrganicMatter = Math.min(0.20, 0.05 + (annualPrecipMm / 3000.0) * 0.15); // Arctic tundra / Boreal peat
    } else if (meanAnnualTempC > 20 && annualPrecipMm > 1500) {
      baseOrganicMatter = 0.045; // Tropical rainforest (rapid turnover, thin litter)
    } else if (annualPrecipMm < 250) {
      baseOrganicMatter = 0.008; // Arid desert
    } else {
      baseOrganicMatter = Math.min(0.08, 0.02 + (vegetationBiomassKgM2 / 40.0) * 0.05);
    }

    // Organic matter accumulation over time
    const ageMaturityFactor = Math.min(1.0, Math.sqrt(soilAgeYears / 500.0));
    const finalOrganicMatter = Math.max(0.005, baseOrganicMatter * ageMaturityFactor);
    const socKgM2 = Math.round(finalOrganicMatter * 1000.0 * soilDepthM * 0.58 * 100) / 100; // SOC = SOM * 0.58

    // 4. Hydraulic Properties (Saxton-Rawls pedotransfer models)
    const fieldCapacity = Math.min(0.50, textureParams.fieldCapacityMoisture + finalOrganicMatter * 0.3);
    const wiltingPoint = Math.min(fieldCapacity - 0.03, textureParams.wiltingPointMoisture + finalOrganicMatter * 0.1);
    const porosity = Math.min(0.65, textureParams.totalPorosity + finalOrganicMatter * 0.2);

    // Initial Volumetric Moisture: equilibrium between precip, PET, and field capacity
    let moistureFraction = fieldCapacity * Math.min(1.2, Math.max(0.25, annualPrecipMm / 1000.0));
    if (isWetland) {
      moistureFraction = porosity * 0.98; // Saturated
    } else if (annualPrecipMm < 200) {
      moistureFraction = Math.max(0.02, wiltingPoint * 0.5); // Drought
    }
    moistureFraction = Math.min(porosity, Math.max(0.02, moistureFraction));

    const relativeSaturation = Math.min(1.0, Math.max(0.0, (moistureFraction - wiltingPoint) / (fieldCapacity - wiltingPoint + 1e-5)));
    const plantAvailableWaterMm = Math.max(0.0, (moistureFraction - wiltingPoint) * soilDepthM * 1000.0);

    // 5. Soil pH and Salinity
    let soilPH = 6.5; // neutral baseline
    if (annualPrecipMm > 1500) {
      soilPH = 4.8; // Acidic leaching in rainforests/coniferous taiga
    } else if (annualPrecipMm < 300) {
      soilPH = 8.2; // Alkaline calcium carbonate accumulation in arid soils
    }

    let salinityPsu = 0.1; // Freshwater baseline
    if (isOceanOrCoastal) {
      salinityPsu = 28.0; // Brackish/marine mangrove/marsh
    } else if (annualPrecipMm < 200 && meanAnnualTempC > 18) {
      salinityPsu = 3.5; // Evaporative salt crust in arid playas
    }

    // 6. Nutrient Availability (Mineral N and P)
    // N mineralization rate = f(SOM, Temperature, Moisture)
    const tempMod = Math.max(0.1, Math.min(2.5, Math.pow(2.0, (meanAnnualTempC - 20.0) / 10.0)));
    const moistMod = Math.sin(relativeSaturation * Math.PI); // Peak at intermediate moisture (~60% field capacity)
    const nitrogenAvailability = Math.max(0.5, finalOrganicMatter * 120.0 * tempMod * Math.max(0.2, moistMod));
    const phosphorusAvailability = Math.max(0.1, nitrogenAvailability * 0.12 * (soilPH >= 6.0 && soilPH <= 7.5 ? 1.0 : 0.6));

    // 7. Soil Horizons
    const horizons: SoilHorizonLayer[] = [
      {
        name: 'O_ORGANIC',
        depthMeters: Math.min(0.15, soilDepthM * 0.10 * finalOrganicMatter * 10.0),
        organicMatterPercent: Math.min(80, finalOrganicMatter * 300),
        bulkDensityKgM3: 350,
        sandFraction: textureParams.sandFraction * 0.5,
        siltFraction: textureParams.siltFraction * 0.5,
        clayFraction: textureParams.clayFraction * 0.5,
        porosityFraction: 0.75
      },
      {
        name: 'A_TOPSOIL',
        depthMeters: Math.min(0.30, soilDepthM * 0.35),
        organicMatterPercent: Math.min(15, finalOrganicMatter * 100),
        bulkDensityKgM3: textureParams.bulkDensityKgM3 * 0.9,
        sandFraction: textureParams.sandFraction,
        siltFraction: textureParams.siltFraction,
        clayFraction: textureParams.clayFraction,
        porosityFraction: porosity
      },
      {
        name: 'B_SUBSOIL',
        depthMeters: Math.min(1.2, soilDepthM * 0.45),
        organicMatterPercent: Math.min(3, finalOrganicMatter * 30),
        bulkDensityKgM3: textureParams.bulkDensityKgM3 * 1.05,
        sandFraction: Math.max(0.05, textureParams.sandFraction - 0.05),
        siltFraction: textureParams.siltFraction,
        clayFraction: Math.min(0.70, textureParams.clayFraction + 0.05),
        porosityFraction: porosity * 0.9
      },
      {
        name: 'C_SUBSTRATUM',
        depthMeters: Math.max(0.1, soilDepthM * 0.10),
        organicMatterPercent: 0.5,
        bulkDensityKgM3: textureParams.bulkDensityKgM3 * 1.15,
        sandFraction: textureParams.sandFraction + 0.1,
        siltFraction: textureParams.siltFraction * 0.8,
        clayFraction: textureParams.clayFraction * 0.6,
        porosityFraction: 0.38
      }
    ];

    return {
      soilDepthMeters: Math.round(soilDepthM * 100) / 100,
      textureClass,
      sandFraction: textureParams.sandFraction,
      siltFraction: textureParams.siltFraction,
      clayFraction: textureParams.clayFraction,
      organicMatterFraction: Math.round(finalOrganicMatter * 1000) / 1000,
      soilOrganicCarbonKgM2: socKgM2,
      soilBulkDensityKgM3: textureParams.bulkDensityKgM3,
      totalPorosityFraction: Math.round(porosity * 100) / 100,
      fieldCapacityMoistureFraction: Math.round(fieldCapacity * 100) / 100,
      wiltingPointMoistureFraction: Math.round(wiltingPoint * 100) / 100,
      currentVolumetricMoistureFraction: Math.round(moistureFraction * 100) / 100,
      relativeSaturationIndex: Math.round(relativeSaturation * 100) / 100,
      plantAvailableWaterMm: Math.round(plantAvailableWaterMm * 10) / 10,
      hydraulicConductivityMmH: textureParams.saturatedHydraulicConductivityMmH,
      soilPH: Math.round(soilPH * 10) / 10,
      salinityPSU: Math.round(salinityPsu * 10) / 10,
      soilTemperatureC: Math.round((meanAnnualTempC + 1.2) * 10) / 10,
      nitrogenAvailabilityGPerM2: Math.round(nitrogenAvailability * 10) / 10,
      phosphorusAvailabilityGPerM2: Math.round(phosphorusAvailability * 10) / 10,
      erosionSusceptibilityIndex: Math.round(textureParams.erodibilityKFactor * (1.0 - vegetationProtection * 0.8) * 100) / 100,
      horizons,
      pedogenesisAgeYears: soilAgeYears
    };
  }

  /**
   * Infers soil texture from climatic weathering regimes
   */
  private inferTextureClass(
    meanAnnualTempC: number,
    annualPrecipMm: number,
    ageYears: number,
    isWetland: boolean
  ): USDASoilTextureClass {
    if (isWetland) return 'SILTY_CLAY';
    if (ageYears < 50) return 'SAND'; // Young raw unweathered regolith

    if (annualPrecipMm < 250) {
      return 'SAND'; // Deserts: physical weathering produces coarse sand
    } else if (annualPrecipMm < 500) {
      return 'SANDY_LOAM'; // Semi-arid grasslands
    } else if (meanAnnualTempC > 22 && annualPrecipMm > 1800) {
      return 'CLAY'; // Tropical Oxisols/Ultisols: intense chemical leaching produces fine kaolinitic clays
    } else if (meanAnnualTempC < 0) {
      return 'SILTY_CLAY_LOAM'; // Permafrost cryoturbation
    } else if (annualPrecipMm > 1200) {
      return 'SILT_LOAM'; // Temperate deciduous forest alfisols
    } else {
      return 'LOAM'; // Balanced temperate soils
    }
  }

  /**
   * Simulates short-term soil moisture response to precipitation events and evapotranspiration
   */
  public updateSoilMoisture(
    currentState: SoilState,
    rainfallMm: number,
    evapotranspirationMm: number,
    deltaDays: number = 1.0,
    shallowWaterTablePresent: boolean = false
  ): SoilState {
    const porosity = currentState.totalPorosityFraction;
    const fc = currentState.fieldCapacityMoistureFraction;
    const wp = currentState.wiltingPointMoistureFraction;
    const depthMm = currentState.soilDepthMeters * 1000.0;

    let currentMoistureVol = currentState.currentVolumetricMoistureFraction;
    let currentWaterMm = currentMoistureVol * depthMm;

    // 1. Infiltration of rainfall
    const maxInfiltrationMm = currentState.hydraulicConductivityMmH * 24.0 * deltaDays;
    const infiltratedMm = Math.min(rainfallMm, maxInfiltrationMm);
    currentWaterMm += infiltratedMm;

    // 2. Evapotranspiration loss
    // Plants extract water easily above field capacity, but stress increases near wilting point
    const moistureStressFraction = Math.max(0.05, Math.min(1.0, (currentMoistureVol - wp) / (fc - wp + 1e-4)));
    const actualET = evapotranspirationMm * moistureStressFraction * deltaDays;
    currentWaterMm -= actualET;

    // 3. Capillary rise from shallow water table
    if (shallowWaterTablePresent) {
      currentWaterMm += 2.5 * deltaDays; // 2.5 mm/day upward flux
    }

    // 4. Deep percolation below root zone when exceeding field capacity
    let newMoistureVol = currentWaterMm / depthMm;
    if (newMoistureVol > fc) {
      const excessMm = (newMoistureVol - fc) * depthMm;
      const drainageMm = excessMm * Math.min(1.0, (currentState.hydraulicConductivityMmH / 20.0) * deltaDays);
      currentWaterMm -= drainageMm;
      newMoistureVol = currentWaterMm / depthMm;
    }

    // Bounds clamp
    newMoistureVol = Math.max(0.01, Math.min(porosity, newMoistureVol));
    const relativeSat = Math.max(0.0, Math.min(1.0, (newMoistureVol - wp) / (fc - wp + 1e-5)));
    const pawMm = Math.max(0.0, (newMoistureVol - wp) * depthMm);

    return {
      ...currentState,
      currentVolumetricMoistureFraction: Math.round(newMoistureVol * 1000) / 1000,
      relativeSaturationIndex: Math.round(relativeSat * 100) / 100,
      plantAvailableWaterMm: Math.round(pawMm * 10) / 10
    };
  }

  /**
   * Advances long-term pedogenesis (soil formation and organic carbon accumulation)
   */
  public advancePedogenesis(
    currentState: SoilState,
    annualBiomassInputKgM2: number,
    meanAnnualTempC: number,
    annualPrecipMm: number,
    yearsElapsed: number
  ): SoilState {
    const newAge = currentState.pedogenesisAgeYears + yearsElapsed;

    // Weathering generates new soil depth at decreasing rate as depth increases (exponential shielding)
    const baseWeatheringRateMPerYr = 0.00004; // 0.04 mm/year
    const shielding = Math.exp(-currentState.soilDepthMeters * 1.5);
    const climateMultiplier = (annualPrecipMm / 1000.0) * Math.max(0.2, (meanAnnualTempC + 10.0) / 25.0);
    const depthAddedM = baseWeatheringRateMPerYr * shielding * climateMultiplier * yearsElapsed;

    const newDepth = Math.min(3.5, currentState.soilDepthMeters + depthAddedM);

    // SOC dynamics: dC/dt = Litterfall - Decomposition
    // Decomposition rate k ~ 0.05 yr⁻¹ at 20°C
    const decompRateK = 0.05 * Math.pow(2.0, (meanAnnualTempC - 20.0) / 10.0);
    const litterInput = annualBiomassInputKgM2 * 0.45 * 0.15; // 15% annual turnover as litter carbon
    const currentSOC = currentState.soilOrganicCarbonKgM2;
    
    // Equilibrium SOC: C_eq = Input / k
    const equilibriumSOC = litterInput / Math.max(0.005, decompRateK);
    const deltaSOC = (equilibriumSOC - currentSOC) * (1.0 - Math.exp(-decompRateK * yearsElapsed));
    const newSOC = Math.max(0.1, currentSOC + deltaSOC);
    const newSOM = newSOC / (newDepth * currentState.soilBulkDensityKgM3 * 0.58);

    return {
      ...currentState,
      pedogenesisAgeYears: newAge,
      soilDepthMeters: Math.round(newDepth * 100) / 100,
      soilOrganicCarbonKgM2: Math.round(newSOC * 100) / 100,
      organicMatterFraction: Math.round(Math.min(0.40, newSOM) * 1000) / 1000
    };
  }
}
