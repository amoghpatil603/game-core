/**
 * Project Earth: Phase 9 Biomes & Ecological Succession Engine
 * Type Definitions & System Architecture Interfaces
 * 
 * Defines all data contracts for:
 * 1. Biome & Ecosystem Classifications (20+ standard ecological classes)
 * 2. Functional Plant Groups & Vegetation Community States
 * 3. Soil Physics, Texture, Nutrient & Pedogenesis State
 * 4. Ecological Productivity (GPP, NPP, LUE) & Growing Season Dynamics
 * 5. Primary & Secondary Ecological Succession & Seral Transitions
 * 6. Disturbance Dynamics (Wildfire, Drought, Flood, Storm Windthrow, Freeze)
 * 7. Specialized Ecosystem Engines (Wetlands, Mangroves, Coral Reefs, Mountain Zonation, Deserts)
 * 8. Biodiversity, Habitat Complexity & Ecosystem Resilience Indices
 * 9. Carbon & Nutrient Accounting Interfaces
 * 10. Multi-Physics Coupling (Climate, Weather, Hydrology, Ocean, Terrain)
 * 11. Multi-Tier Simulation Scheduler & Spatial Streaming Tile Formats (<48 MB RAM)
 * 12. Phase 10 Wildlife & Future Human Perception Interfaces
 */

import { WGS84GlobalCoord } from '../coordinates/globalCoordinateEngine';
import { KoppenClimateCode, KoppenMajorGroup } from '../climate/climateTypes';
import { WeatherState } from '../weather/weatherTypes';

// ============================================================================
// 1. BIOME & ECOSYSTEM CLASSIFICATION TYPES
// ============================================================================

export type BiomeType =
  | 'TROPICAL_RAINFOREST'
  | 'TROPICAL_SEASONAL_FOREST'
  | 'TROPICAL_SAVANNA'
  | 'HOT_DESERT'
  | 'COLD_DESERT'
  | 'MEDITERRANEAN_SHRUBLAND'
  | 'TEMPERATE_GRASSLAND'
  | 'TEMPERATE_DECIDUOUS_FOREST'
  | 'TEMPERATE_RAINFOREST'
  | 'BOREAL_FOREST_TAIGA'
  | 'TUNDRA_ARCTIC'
  | 'ALPINE_MEADOW'
  | 'FRESHWATER_WETLAND'
  | 'MANGROVE_SWAMP'
  | 'SALT_MARSH'
  | 'CORAL_REEF'
  | 'KELP_FOREST'
  | 'POLAR_ICE_CAP'
  | 'BARE_ROCK_SCREE'
  | 'PERMANENT_SNOW_GLACIER';

export type EcosystemCommunityType =
  | 'LOWLAND_DIPTEROCARP_CANOPY'
  | 'AMAZONIAN_TERRA_FIRME'
  | 'ACACIA_COMMIPHORA_BUSH'
  | 'XEROPHYTIC_SCRUB'
  | 'CHAPARRAL_MAQUIS'
  | 'SHORTGRASS_STEPPE'
  | 'TALLGRASS_PRAIRIE'
  | 'OAK_HICKORY_CLIMAX'
  | 'COASTAL_REDWOOD_HEMLOCK'
  | 'SPRUCE_LARCH_TAIGA'
  | 'DWARF_SHRUB_HEATH'
  | 'RIPARIAN_BOTTOMLAND_HARDWOOD'
  | 'PEAT_SPHAGNUM_BOG'
  | 'RED_MANGROVE_FRINGE'
  | 'SPARTINA_SALT_MARSH'
  | 'ACROPORA_BARRIER_REEF'
  | 'MACROCYSTIS_KELP_CANOPY'
  | 'EPILITHIC_LICHEN_CRUST';

export interface BiomeClassificationResult {
  primaryBiome: BiomeType;
  secondaryBiome?: BiomeType;
  biomeConfidence: number; // 0.0 to 1.0
  koppenCode: KoppenClimateCode;
  koppenGroup: KoppenMajorGroup;
  ecosystemCommunity: EcosystemCommunityType;
  description: string;
  ecoregionRealm: 'NEARCTIC' | 'PALEARCTIC' | 'NEOTROPICAL' | 'AFROTROPICAL' | 'INDOMALAYAN' | 'AUSTRALASIAN' | 'OCEANIAN' | 'ANTARCTIC' | 'MARINE';
  isAquaticOrMarine: boolean;
  isWetland: boolean;
  isAlpineOrMontane: boolean;
}

// ============================================================================
// 2. FUNCTIONAL PLANT GROUPS & VEGETATION COMMUNITY
// ============================================================================

export type PlantFunctionalGroup =
  | 'GRASSES_C3'
  | 'GRASSES_C4'
  | 'SHRUBS_DECIDUOUS'
  | 'SHRUBS_EVERGREEN'
  | 'TREES_BROADLEAF_DECIDUOUS'
  | 'TREES_BROADLEAF_EVERGREEN_TROPICAL'
  | 'TREES_NEEDLELEAF_EVERGREEN_CONIFER'
  | 'TREES_NEEDLELEAF_DECIDUOUS_LARCH'
  | 'SUCCULENTS_CAM'
  | 'WETLAND_EMERGENTS'
  | 'MANGROVE_HALOPHYTES'
  | 'MOSSES_BRYOPHYTES'
  | 'LICHENS_CRUSTOSE'
  | 'AQUATIC_SUBMERGED_SEAGRASS'
  | 'MARINE_MACROALGAE_KELP';

export type PhenologicalStage =
  | 'DORMANT'
  | 'BUD_BURST_GREENUP'
  | 'PEAK_CANOPY_ACTIVE'
  | 'SENESCENCE_YELLOWING'
  | 'LEAF_DROP'
  | 'EVERGREEN_STABLE';

export interface PlantGroupFraction {
  group: PlantFunctionalGroup;
  fraction: number; // 0.0 to 1.0 (sums to <= 1.0)
  biomassKgM2: number;
  meanHeightMeters: number;
  canopyCoverFraction: number;
  rootDepthMeters: number;
}

export interface VegetationCommunityState {
  totalBiomassKgM2: number;
  aboveGroundBiomassKgM2: number;
  belowGroundBiomassKgM2: number;
  totalCanopyCoverFraction: number; // 0.0 to 1.0
  leafAreaIndex: number; // LAI (m²/m²) e.g. 0 to 10
  meanCanopyHeightMeters: number;
  maxRootDepthMeters: number;
  vegetationHealthIndex: number; // 0.0 (dead) to 1.0 (optimal)
  phenologyStage: PhenologicalStage;
  functionalGroups: PlantGroupFraction[];
  dominantFunctionalGroup: PlantFunctionalGroup;
  foliageMoistureContentPercent: number;
  deadFuelFraction: number;
}

// ============================================================================
// 3. SOIL PHYSICS, HORIZONS, TEXTURE & NUTRIENTS
// ============================================================================

export type USDASoilTextureClass =
  | 'SAND'
  | 'LOAMY_SAND'
  | 'SANDY_LOAM'
  | 'LOAM'
  | 'SILT_LOAM'
  | 'SILT'
  | 'SANDY_CLAY_LOAM'
  | 'CLAY_LOAM'
  | 'SILTY_CLAY_LOAM'
  | 'SANDY_CLAY'
  | 'SILTY_CLAY'
  | 'CLAY';

export interface SoilHorizonLayer {
  name: 'O_ORGANIC' | 'A_TOPSOIL' | 'B_SUBSOIL' | 'C_SUBSTRATUM' | 'R_BEDROCK';
  depthMeters: number;
  organicMatterPercent: number;
  bulkDensityKgM3: number;
  sandFraction: number;
  siltFraction: number;
  clayFraction: number;
  porosityFraction: number;
}

export interface SoilState {
  soilDepthMeters: number;
  textureClass: USDASoilTextureClass;
  sandFraction: number;
  siltFraction: number;
  clayFraction: number;
  organicMatterFraction: number; // 0.0 to 0.30+
  soilOrganicCarbonKgM2: number;
  soilBulkDensityKgM3: number;
  totalPorosityFraction: number;
  fieldCapacityMoistureFraction: number; // volumetric m³/m³
  wiltingPointMoistureFraction: number;  // volumetric m³/m³
  currentVolumetricMoistureFraction: number;
  relativeSaturationIndex: number; // 0.0 (bone dry) to 1.0 (fully saturated)
  plantAvailableWaterMm: number;
  hydraulicConductivityMmH: number;
  soilPH: number; // typically 3.5 to 9.0
  salinityPSU: number; // ppt
  soilTemperatureC: number;
  nitrogenAvailabilityGPerM2: number;
  phosphorusAvailabilityGPerM2: number;
  erosionSusceptibilityIndex: number; // 0.0 to 1.0 (K-factor proxy)
  horizons: SoilHorizonLayer[];
  pedogenesisAgeYears: number;
}

// ============================================================================
// 4. ECOLOGICAL PRODUCTIVITY & GROWING SEASON
// ============================================================================

export interface EcologicalProductivityState {
  grossPrimaryProductivityGCPerM2Yr: number; // GPP (MODEL-DERIVED)
  netPrimaryProductivityGCPerM2Yr: number;   // NPP (MODEL-DERIVED)
  autotrophicRespirationGCPerM2Yr: number;
  heterotrophicRespirationGCPerM2Yr: number;
  netEcosystemExchangeGCPerM2Yr: number; // NEE
  lightUseEfficiencyGCPerMJ: number;
  photosyntheticallyActiveRadiationMJPerM2Day: number;
  temperatureGrowthMultiplier: number; // 0.0 to 1.0
  moistureGrowthMultiplier: number;    // 0.0 to 1.0
  nutrientGrowthMultiplier: number;    // 0.0 to 1.0
  co2FertilizationFactor: number;
  isPhotosyntheticallyActive: boolean;
}

export interface GrowingSeasonProfile {
  growingDegreeDaysBase5C: number;
  growingDegreeDaysBase10C: number;
  frostFreePeriodDays: number;
  growingSeasonStartDayOfYear: number;
  growingSeasonEndDayOfYear: number;
  growingSeasonLengthDays: number;
  isCurrentlyInGrowingSeason: boolean;
  cumulativeAnnualDroughtDays: number;
  cumulativeAnnualFrostEvents: number;
}

// ============================================================================
// 5. ECOLOGICAL SUCCESSION & SERAL STAGES
// ============================================================================

export type SuccessionType = 'PRIMARY_SUCCESSION' | 'SECONDARY_SUCCESSION';

export type SeralStage =
  | 'STAGE_0_BARE_SUBSTRATE'
  | 'STAGE_1_PIONEER_CRUST_MOSS'
  | 'STAGE_2_EARLY_HERBACEOUS_GRASS'
  | 'STAGE_3_SHRUB_THICKET'
  | 'STAGE_4_EARLY_SERAL_PIONEER_WOODLAND'
  | 'STAGE_5_MID_SERAL_MIXED_FOREST'
  | 'STAGE_6_MATURE_CLIMAX_FOREST'
  | 'STAGE_7_OLD_GROWTH_COMPLEX';

export interface EcologicalSuccessionState {
  successionType: SuccessionType;
  currentSeralStage: SeralStage;
  seralStageIndex: number; // 0 to 7
  successionAgeYears: number;
  timeInCurrentStageYears: number;
  yearsToNextSeralTransition: number;
  climaxBiomeTarget: BiomeType;
  climaxMaturityFraction: number; // 0.0 to 1.0
  seedBankViabilityIndex: number;
  soilDevelopmentIndex: number; // 0.0 to 1.0
  isClimaxReached: boolean;
}

// ============================================================================
// 6. DISTURBANCE DYNAMICS (WILDFIRE, DROUGHT, FLOOD, STORM, FREEZE)
// ============================================================================

export type DisturbanceType =
  | 'NONE'
  | 'WILDFIRE'
  | 'SEVERE_DROUGHT'
  | 'FLOOD_INUNDATION'
  | 'STORM_WINDTHROW'
  | 'EXTREME_FREEZE'
  | 'LANDSLIDE_MASS_WASTING'
  | 'VOLCANIC_TEPHRA';

export interface WildfireState {
  fuelLoadKgM2: number;
  fineDeadFuelMoisturePercent: number;
  fireDangerRating: 'LOW' | 'MODERATE' | 'HIGH' | 'VERY_HIGH' | 'EXTREME';
  ignitionProbabilityPercent: number;
  rateOfSpreadMPerMin: number;
  flameLengthMeters: number;
  firelineIntensityKWPerM: number;
  burnSeverityFraction: number; // 0.0 (unburned) to 1.0 (complete crown consumption)
  timeSinceLastFireYears: number;
  postFireCarbonEmissionKgM2: number;
  charcoalAshLayerDepthMm: number;
}

export interface DisturbanceImpactState {
  activeDisturbance: DisturbanceType;
  disturbanceIntensity: number; // 0.0 to 1.0
  treeMortalityFraction: number;
  shrubMortalityFraction: number;
  grassMortalityFraction: number;
  biomassConsumedFraction: number;
  soilCompactionOrErosionDelta: number;
  recoveryDeficitYears: number;
}

// ============================================================================
// 7. SPECIALIZED ECOSYSTEM MODULE STATES
// ============================================================================

export interface WetlandEcosystemState {
  isWetland: boolean;
  wetlandClass: 'NONE' | 'MARSH' | 'SWAMP' | 'BOG' | 'FEN' | 'FLOODPLAIN_WETLAND';
  hydroperiodMonthsPerYear: number;
  meanWaterTableDepthMeters: number; // negative = below ground, positive = standing surface water
  peatAccumulationRateMmYr: number;
  anaerobicSoilFraction: number;
  methaneEmissionPotentialIndex: number;
}

export interface CoastalMarineEcosystemState {
  isCoastalOrMarine: boolean;
  marineEcosystemType: 'NONE' | 'MANGROVE_SWAMP' | 'SALT_MARSH' | 'SEAGRASS_BED' | 'KELP_FOREST' | 'CORAL_REEF' | 'INTERTIDAL_ROCKY';
  mangroveZonation?: 'SEAWARD_RED' | 'MID_BLACK' | 'LANDWARD_WHITE' | 'BUTTONWOOD';
  coralReefHealthIndex: number; // 0.0 to 1.0
  degreeHeatingWeeksDHW: number; // NOAA Bleaching thermal stress proxy
  coralBleachingRisk: 'NO_STRESS' | 'BLEACHING_WATCH' | 'BLEACHING_WARNING' | 'ALERT_LEVEL_1' | 'ALERT_LEVEL_2';
  kelpCanopyDensity: number;
  salinityTolerancePsu: number;
  tidalInundationFrequencyPerDay: number;
}

export interface MountainElevationalZonationState {
  isMountainous: boolean;
  elevationZone: 'FOOTHILL_LOWLAND' | 'MONTANE_FOREST' | 'SUBALPINE_KRUMMHOLZ' | 'ALPINE_TUNDRA' | 'NIVAL_BARE_ROCK' | 'PERMANENT_GLACIER';
  treeLineElevationMeters: number;
  snowLineElevationMeters: number;
  slopeAspectSolarGainMultiplier: number;
  thermalBeltInversionPresent: boolean;
}

// ============================================================================
// 8. BIODIVERSITY, HABITAT & RESILIENCE
// ============================================================================

export interface BiodiversityAndResilienceState {
  shannonDiversityIndexProxy: number; // approx 0.5 (desert/ice) to 4.5+ (tropical rainforest)
  structuralHabitatComplexityIndex: number; // 0.0 to 1.0 (vertical foliage layers, dead snags, microtopography)
  ecologicalResistanceIndex: number; // capacity to withstand disturbance without state shift
  ecologicalRecoveryResilienceIndex: number; // speed of returning to pre-disturbance state
  habitatNicheDiversityCount: number;
  ecosystemDegradationVulnerability: number; // 0.0 (pristine/robust) to 1.0 (fragile/collapsing)
}

// ============================================================================
// 9. COMPLETE ECOLOGICAL CELL STATE
// ============================================================================

export interface EcologicalCellState {
  coord: WGS84GlobalCoord;
  timestamp: number;
  biome: BiomeClassificationResult;
  vegetation: VegetationCommunityState;
  soil: SoilState;
  productivity: EcologicalProductivityState;
  growingSeason: GrowingSeasonProfile;
  succession: EcologicalSuccessionState;
  disturbance: DisturbanceImpactState;
  wildfire: WildfireState;
  wetland: WetlandEcosystemState;
  coastal: CoastalMarineEcosystemState;
  mountain: MountainElevationalZonationState;
  biodiversity: BiodiversityAndResilienceState;
}

// ============================================================================
// 10. MULTI-PHYSICS COUPLING INTERFACES
// ============================================================================

export interface EcosystemToHydrologyFeedback {
  vegetationTranspirationFluxM3sPerKm2: number;
  soilInfiltrationEnhancementFactor: number; // e.g. 1.0 (bare) to 2.5 (deep forest roots)
  canopyInterceptionCapacityMm: number;
  surfaceRoughnessManningsN: number;
  soilErosionSedimentYieldKgM2: number;
}

export interface EcosystemToAtmosphereFeedback {
  surfaceAlbedoModified: number;
  evapotranspirationMoistureFluxWm2: number;
  biogenicVolatileOrganicCompoundsFluxIndex: number;
  surfaceRoughnessLengthZ0Meters: number;
  wildfireSmokeParticulatePPM: number;
}

// ============================================================================
// 11. SPATIAL STREAMING & LRU TILE CONFIGURATION
// ============================================================================

export type EcologicalLOD = 0 | 1 | 2 | 3; // 0: Player-Local, 1: Local, 2: Regional, 3: Global

export interface EcologicalTileHeader {
  tileId: string;
  lod: EcologicalLOD;
  gridResolution: number; // e.g. 16x16 or 32x32
  minLat: number;
  maxLat: number;
  minLon: number;
  maxLon: number;
  primaryBiomeType: BiomeType;
  meanBiomassKgM2: number;
  meanSoilMoisture: number;
  checksumSha256: string;
}

export interface EcologicalTileData {
  header: EcologicalTileHeader;
  cells: EcologicalCellState[][];
  lastAccessTimestamp: number;
  memorySizeEstimateBytes: number;
}

export interface EcologicalMemoryBudget {
  maxAllowedMemoryMB: number;
  currentAllocatedMemoryMB: number;
  totalCachedTiles: number;
  maxTileCacheCapacity: number;
  cacheHitRatePercent: number;
  lruEvictionsCount: number;
}

// ============================================================================
// 12. PHASE 10 WILDLIFE & HUMAN PERCEPTION INTERFACES
// ============================================================================

export interface HabitatSuitabilityResult {
  coord: WGS84GlobalCoord;
  overallHabitatSuitabilityIndex: number; // 0.0 to 1.0
  vegetationCoverScore: number;
  waterProximityScore: number;
  forageFoodAvailabilityScore: number;
  thermalShelterScore: number;
  predatorConcealmentScore: number;
  biomeClass: BiomeType;
}

export interface WildlifeEcosystemPerceptionAPI {
  GetHabitatSuitability(coord: WGS84GlobalCoord): HabitatSuitabilityResult;
  GetVegetationState(coord: WGS84GlobalCoord): VegetationCommunityState;
  GetWaterAvailability(coord: WGS84GlobalCoord): { surfaceWaterDistanceMeters: number; wetlandPresence: boolean; soilMoistureFraction: number };
  GetFoodAvailability(coord: WGS84GlobalCoord): { browseFoliageBiomassKgM2: number; seedMastAvailabilityIndex: number; grazingGrassBiomassKgM2: number };
  GetCoverDensity(coord: WGS84GlobalCoord): { canopyCoverPercent: number; shrubLayerDensityPercent: number; verticalObstructionScore: number };
  GetTemperatureRange(coord: WGS84GlobalCoord): { currentTempC: number; diurnalRangeC: number; thermalExtremeRisk: 'SAFE' | 'COLD_STRESS' | 'HEAT_STRESS' };
  GetPredatorRiskInterface(coord: WGS84GlobalCoord): { sightlineVisibilityMeters: number; acousticAttenuationIndex: number };
  GetMigrationBarrierInterface(coord: WGS84GlobalCoord): { slopeImpassable: boolean; deepWaterBarrier: boolean; denseCanopyImpassable: boolean };
}

export interface HumanResourcePerceptionAPI {
  GetAgriculturalSuitability(coord: WGS84GlobalCoord): { arableLandScore: number; soilFertilityIndex: number; frostFreeDays: number; irrigationRequirementMm: number };
  GetTimberResourceAvailability(coord: WGS84GlobalCoord): { harvestableTimberVolumeM3Ha: number; dominantWoodType: 'HARDWOOD' | 'SOFTWOOD' | 'TROPICAL' | 'NONE' };
  GetWildForageYield(coord: WGS84GlobalCoord): { edibleBiomassYieldKgHa: number; medicinalPlantIndex: number };
  GetWildfireDangerIndex(coord: WGS84GlobalCoord): { rating: 'LOW' | 'MODERATE' | 'HIGH' | 'VERY_HIGH' | 'EXTREME'; spreadRiskIndex: number };
  GetFloodInundationRisk(coord: WGS84GlobalCoord): { floodRiskLevel: 'NONE' | 'LOW' | 'MODERATE' | 'HIGH' | 'SEVERE'; wetlandPresence: boolean };
  GetFreshwaterYield(coord: WGS84GlobalCoord): { aquiferRechargeRateM3sPerKm2: number; potableSurfaceWaterNearby: boolean };
}

// ============================================================================
// 13. DEVELOPER SCENARIOS & PROVENANCE DATA
// ============================================================================

export interface EcologicalScenarioConfig {
  id: string;
  name: string;
  description: string;
  category: 'PRIMARY_SUCCESSION' | 'SECONDARY_SUCCESSION' | 'DISTURBANCE_EXPERIMENT' | 'EXTREME_ECOSYSTEM' | 'COASTAL_MARINE';
  targetCoord: WGS84GlobalCoord;
  initialBiome: BiomeType;
  initialSeralStage: SeralStage;
  soilAgeYears: number;
  climateOverrideId?: string;
  weatherScenarioId?: string;
  forcedDisturbance?: DisturbanceType;
  isSyntheticFixture: true;
}

export type ProvenanceClassification =
  | 'REAL_OBSERVATION'
  | 'REANALYSIS'
  | 'MODEL_DERIVED'
  | 'INTERPOLATED'
  | 'APPROXIMATION'
  | 'SYNTHETIC_TEST_FIXTURE';

export interface DatasetProvenanceRecord {
  datasetId: string;
  name: string;
  provider: string;
  version: string;
  spatialResolution: string;
  temporalCoverage: string;
  geographicCoverage: string;
  license: string;
  classification: ProvenanceClassification;
  processingPipeline: string;
  scientificLimitations: string[];
}
