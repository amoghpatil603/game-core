/**
 * Project Earth: Phase 9 Biomes & Ecological Succession Engine
 * Ecological Datasets, Plant Functional Traits, Soil Physics Benchmarks & Scenario Fixtures
 * 
 * Defines:
 * 1. Global Benchmark Ecosystem Profiles (Real Earth validation stations)
 * 2. Plant Functional Group (PFT) Trait Parameters
 * 3. USDA Soil Texture Physical Parameters (Saxton-Rawls pedotransfer models)
 * 4. Rothermel Wildfire Fuel Models (Standard 13 fuel types)
 * 5. 10 Developer Scenarios (Clearly labeled SYNTHETIC_TEST_FIXTURE)
 * 6. Formal Dataset Provenance Registry
 */

import { WGS84GlobalCoord } from '../coordinates/globalCoordinateEngine';
import { 
  BiomeType, 
  PlantFunctionalGroup, 
  USDASoilTextureClass, 
  SeralStage,
  EcologicalScenarioConfig, 
  DatasetProvenanceRecord 
} from './biomeTypes';

// ============================================================================
// 1. GLOBAL BENCHMARK ECOSYSTEM PROFILES (Real Earth Validation)
// ============================================================================

export interface RealEarthEcosystemBenchmark {
  id: string;
  name: string;
  region: string;
  coord: WGS84GlobalCoord;
  expectedBiome: BiomeType;
  expectedKoppenCode: string;
  observedAnnualPrecipMm: number;
  observedMeanAnnualTempC: number;
  observedBiomassKgM2: number;
  observedCanopyDensityPercent: number;
  dominantPlantGroup: PlantFunctionalGroup;
  soilTexture: USDASoilTextureClass;
  elevationMeters: number;
  description: string;
}

export const REAL_EARTH_ECOSYSTEM_BENCHMARKS: RealEarthEcosystemBenchmark[] = [
  {
    id: 'BENCHMARK-AMAZON-RAINFOREST',
    name: 'Amazon Lowland Evergreen Rainforest',
    region: 'Manaus, Brazil',
    coord: { latitude: -3.119, longitude: -60.021, altitude: 72 },
    expectedBiome: 'TROPICAL_RAINFOREST',
    expectedKoppenCode: 'Af',
    observedAnnualPrecipMm: 2300,
    observedMeanAnnualTempC: 26.8,
    observedBiomassKgM2: 32.5,
    observedCanopyDensityPercent: 92,
    dominantPlantGroup: 'TREES_BROADLEAF_EVERGREEN_TROPICAL',
    soilTexture: 'CLAY',
    elevationMeters: 72,
    description: 'Hyper-diverse equatorial multi-strata rainforest with high year-round rainfall and no dry season.'
  },
  {
    id: 'BENCHMARK-SAHARA-DESERT',
    name: 'Sahara Hyper-Arid Erg',
    region: 'Tamanrasset, Algeria',
    coord: { latitude: 22.785, longitude: 5.522, altitude: 1370 },
    expectedBiome: 'HOT_DESERT',
    expectedKoppenCode: 'BWh',
    observedAnnualPrecipMm: 45,
    observedMeanAnnualTempC: 21.7,
    observedBiomassKgM2: 0.15,
    observedCanopyDensityPercent: 1,
    dominantPlantGroup: 'SUCCULENTS_CAM',
    soilTexture: 'SAND',
    elevationMeters: 1370,
    description: 'Subtropical high-pressure descending limb hyper-arid desert with minimal vegetation.'
  },
  {
    id: 'BENCHMARK-SERENGETI-SAVANNA',
    name: 'Serengeti Acacia Savanna',
    region: 'Serengeti National Park, Tanzania',
    coord: { latitude: -2.333, longitude: 34.833, altitude: 1500 },
    expectedBiome: 'TROPICAL_SAVANNA',
    expectedKoppenCode: 'Aw',
    observedAnnualPrecipMm: 950,
    observedMeanAnnualTempC: 22.4,
    observedBiomassKgM2: 6.8,
    observedCanopyDensityPercent: 28,
    dominantPlantGroup: 'GRASSES_C4',
    soilTexture: 'SANDY_CLAY_LOAM',
    elevationMeters: 1500,
    description: 'Bimodal rainfall tropical savanna grassland matrix interspersed with drought-tolerant Acacia shrubs.'
  },
  {
    id: 'BENCHMARK-PNW-RAINFOREST',
    name: 'Pacific Northwest Temperate Rainforest',
    region: 'Hoh River Valley, Olympic Peninsula, USA',
    coord: { latitude: 47.860, longitude: -123.934, altitude: 180 },
    expectedBiome: 'TEMPERATE_RAINFOREST',
    expectedKoppenCode: 'Cfb',
    observedAnnualPrecipMm: 3600,
    observedMeanAnnualTempC: 10.2,
    observedBiomassKgM2: 58.0,
    observedCanopyDensityPercent: 95,
    dominantPlantGroup: 'TREES_NEEDLELEAF_EVERGREEN_CONIFER',
    soilTexture: 'SILT_LOAM',
    elevationMeters: 180,
    description: 'Hyper-maritime coniferous rainforest with Sitka spruce, Western hemlock, dense epiphytic mosses.'
  },
  {
    id: 'BENCHMARK-SIBERIAN-TAIGA',
    name: 'Central Siberian Boreal Taiga',
    region: 'Yakutsk, Russian Federation',
    coord: { latitude: 62.033, longitude: 129.733, altitude: 102 },
    expectedBiome: 'BOREAL_FOREST_TAIGA',
    expectedKoppenCode: 'Dfd',
    observedAnnualPrecipMm: 240,
    observedMeanAnnualTempC: -8.8,
    observedBiomassKgM2: 12.0,
    observedCanopyDensityPercent: 55,
    dominantPlantGroup: 'TREES_NEEDLELEAF_DECIDUOUS_LARCH',
    soilTexture: 'LOAM',
    elevationMeters: 102,
    description: 'Extreme subarctic continental taiga over continuous permafrost with Dahurian larch.'
  },
  {
    id: 'BENCHMARK-ARCTIC-TUNDRA',
    name: 'North Slope Arctic Tundra',
    region: 'Utqiaġvik (Barrow), Alaska, USA',
    coord: { latitude: 71.290, longitude: -156.788, altitude: 4 },
    expectedBiome: 'TUNDRA_ARCTIC',
    expectedKoppenCode: 'ET',
    observedAnnualPrecipMm: 130,
    observedMeanAnnualTempC: -11.3,
    observedBiomassKgM2: 1.2,
    observedCanopyDensityPercent: 35,
    dominantPlantGroup: 'MOSSES_BRYOPHYTES',
    soilTexture: 'SILTY_CLAY',
    elevationMeters: 4,
    description: 'High-latitude treeless permafrost tundra with prostrate dwarf willows, sedges, and lichen crust.'
  },
  {
    id: 'BENCHMARK-HIMALAYAN-ALPINE',
    name: 'Himalayan High Alpine Meadow',
    region: 'Solukhumbu, Nepal',
    coord: { latitude: 27.800, longitude: 86.720, altitude: 4400 },
    expectedBiome: 'ALPINE_MEADOW',
    expectedKoppenCode: 'ET',
    observedAnnualPrecipMm: 650,
    observedMeanAnnualTempC: 1.5,
    observedBiomassKgM2: 1.8,
    observedCanopyDensityPercent: 40,
    dominantPlantGroup: 'GRASSES_C3',
    soilTexture: 'SANDY_LOAM',
    elevationMeters: 4400,
    description: 'High-elevation montane zone above tree line with cushion plants, rhododendron shrubs, and alpine grasses.'
  },
  {
    id: 'BENCHMARK-AUSTRALIAN-DESERT',
    name: 'Great Victoria Desert Spinifex Scrub',
    region: 'Alice Springs Outback, Australia',
    coord: { latitude: -23.700, longitude: 133.880, altitude: 545 },
    expectedBiome: 'HOT_DESERT',
    expectedKoppenCode: 'BWh',
    observedAnnualPrecipMm: 280,
    observedMeanAnnualTempC: 21.4,
    observedBiomassKgM2: 0.9,
    observedCanopyDensityPercent: 12,
    dominantPlantGroup: 'GRASSES_C4',
    soilTexture: 'SAND',
    elevationMeters: 545,
    description: 'Semi-arid to arid red sand dune biome dominated by hummock spinifex grass and sparse mulga shrubs.'
  },
  {
    id: 'BENCHMARK-SUNDARBANS-MANGROVE',
    name: 'Sundarbans Coastal Mangrove Tidal Delta',
    region: 'Khulna, Bangladesh / West Bengal, India',
    coord: { latitude: 21.949, longitude: 89.183, altitude: 2 },
    expectedBiome: 'MANGROVE_SWAMP',
    expectedKoppenCode: 'Am',
    observedAnnualPrecipMm: 1800,
    observedMeanAnnualTempC: 26.0,
    observedBiomassKgM2: 24.0,
    observedCanopyDensityPercent: 88,
    dominantPlantGroup: 'MANGROVE_HALOPHYTES',
    soilTexture: 'SILTY_CLAY',
    elevationMeters: 2,
    description: 'World largest halophytic intertidal mangrove delta with stilt roots, pneumatophores, and tidal fluxes.'
  },
  {
    id: 'BENCHMARK-GREAT-BARRIER-REEF',
    name: 'Great Barrier Reef Shallow Coral Platform',
    region: 'Cairns Offshore, Australia',
    coord: { latitude: -16.850, longitude: 146.200, altitude: -8 },
    expectedBiome: 'CORAL_REEF',
    expectedKoppenCode: 'Af',
    observedAnnualPrecipMm: 2000,
    observedMeanAnnualTempC: 26.5,
    observedBiomassKgM2: 8.5,
    observedCanopyDensityPercent: 65,
    dominantPlantGroup: 'MARINE_MACROALGAE_KELP',
    soilTexture: 'SAND',
    elevationMeters: -8,
    description: 'Tropical hermatypic coral reef ecosystem dependent on shallow photic water and ocean salinity.'
  },
  {
    id: 'BENCHMARK-MEDITERRANEAN-MAQUIS',
    name: 'Mediterranean Sclerophyllous Maquis',
    region: 'Marseille / Provence, France',
    coord: { latitude: 43.296, longitude: 5.369, altitude: 60 },
    expectedBiome: 'MEDITERRANEAN_SHRUBLAND',
    expectedKoppenCode: 'Csa',
    observedAnnualPrecipMm: 520,
    observedMeanAnnualTempC: 15.8,
    observedBiomassKgM2: 7.2,
    observedCanopyDensityPercent: 45,
    dominantPlantGroup: 'SHRUBS_EVERGREEN',
    soilTexture: 'CLAY_LOAM',
    elevationMeters: 60,
    description: 'Summer-dry sclerophyllous evergreen shrubland adapted to drought and periodic wildfire regimes.'
  },
  {
    id: 'BENCHMARK-MISSISSIPPI-FLOODPLAIN',
    name: 'Mississippi Bottomland Hardwood Wetland',
    region: 'Vicksburg, Mississippi, USA',
    coord: { latitude: 32.350, longitude: -90.875, altitude: 25 },
    expectedBiome: 'FRESHWATER_WETLAND',
    expectedKoppenCode: 'Cfa',
    observedAnnualPrecipMm: 1400,
    observedMeanAnnualTempC: 18.2,
    observedBiomassKgM2: 28.0,
    observedCanopyDensityPercent: 85,
    dominantPlantGroup: 'WETLAND_EMERGENTS',
    soilTexture: 'SILTY_CLAY',
    elevationMeters: 25,
    description: 'Periodically inundated alluvial floodplain wetland supporting bald cypress, water tupelo, and hydric soils.'
  }
];

// ============================================================================
// 2. PLANT FUNCTIONAL GROUP (PFT) TRAIT MATRIX
// ============================================================================

export interface PlantFunctionalTrait {
  group: PlantFunctionalGroup;
  name: string;
  minTempC: number;
  optTempC: number;
  maxTempC: number;
  minAnnualPrecipMm: number;
  droughtTolerance: number; // 0.0 (intolerant) to 1.0 (extreme xerophyte)
  fireResilience: number;   // 0.0 (killed by fire) to 1.0 (serotinous/resprouter)
  maxBiomassKgM2: number;
  maxCanopyHeightMeters: number;
  maxRootDepthMeters: number;
  baseLightUseEfficiencyGCPerMJ: number;
  isEvergreen: boolean;
  leafLifespanMonths: number;
  specificLeafAreaM2PerKg: number;
  c3OrC4OrCAM: 'C3' | 'C4' | 'CAM' | 'ALGAE';
}

export const PLANT_FUNCTIONAL_TRAITS: Record<PlantFunctionalGroup, PlantFunctionalTrait> = {
  GRASSES_C3: {
    group: 'GRASSES_C3',
    name: 'Temperate C3 Grasses & Forbs',
    minTempC: -5.0,
    optTempC: 18.0,
    maxTempC: 32.0,
    minAnnualPrecipMm: 250,
    droughtTolerance: 0.55,
    fireResilience: 0.85,
    maxBiomassKgM2: 1.5,
    maxCanopyHeightMeters: 0.8,
    maxRootDepthMeters: 1.2,
    baseLightUseEfficiencyGCPerMJ: 1.1,
    isEvergreen: false,
    leafLifespanMonths: 6,
    specificLeafAreaM2PerKg: 22.0,
    c3OrC4OrCAM: 'C3'
  },
  GRASSES_C4: {
    group: 'GRASSES_C4',
    name: 'Tropical / Savanna C4 Grasses',
    minTempC: 8.0,
    optTempC: 30.0,
    maxTempC: 45.0,
    minAnnualPrecipMm: 200,
    droughtTolerance: 0.75,
    fireResilience: 0.90,
    maxBiomassKgM2: 2.2,
    maxCanopyHeightMeters: 1.8,
    maxRootDepthMeters: 2.0,
    baseLightUseEfficiencyGCPerMJ: 1.6,
    isEvergreen: false,
    leafLifespanMonths: 6,
    specificLeafAreaM2PerKg: 18.0,
    c3OrC4OrCAM: 'C4'
  },
  SHRUBS_DECIDUOUS: {
    group: 'SHRUBS_DECIDUOUS',
    name: 'Temperate Deciduous Shrubs',
    minTempC: -20.0,
    optTempC: 20.0,
    maxTempC: 35.0,
    minAnnualPrecipMm: 350,
    droughtTolerance: 0.60,
    fireResilience: 0.70,
    maxBiomassKgM2: 4.5,
    maxCanopyHeightMeters: 3.0,
    maxRootDepthMeters: 2.5,
    baseLightUseEfficiencyGCPerMJ: 1.0,
    isEvergreen: false,
    leafLifespanMonths: 6,
    specificLeafAreaM2PerKg: 16.0,
    c3OrC4OrCAM: 'C3'
  },
  SHRUBS_EVERGREEN: {
    group: 'SHRUBS_EVERGREEN',
    name: 'Sclerophyllous Evergreen Shrubs',
    minTempC: -8.0,
    optTempC: 22.0,
    maxTempC: 40.0,
    minAnnualPrecipMm: 250,
    droughtTolerance: 0.85,
    fireResilience: 0.80,
    maxBiomassKgM2: 6.0,
    maxCanopyHeightMeters: 3.5,
    maxRootDepthMeters: 4.0,
    baseLightUseEfficiencyGCPerMJ: 0.85,
    isEvergreen: true,
    leafLifespanMonths: 24,
    specificLeafAreaM2PerKg: 9.5,
    c3OrC4OrCAM: 'C3'
  },
  TREES_BROADLEAF_DECIDUOUS: {
    group: 'TREES_BROADLEAF_DECIDUOUS',
    name: 'Temperate Broadleaf Deciduous Trees',
    minTempC: -25.0,
    optTempC: 22.0,
    maxTempC: 36.0,
    minAnnualPrecipMm: 600,
    droughtTolerance: 0.45,
    fireResilience: 0.40,
    maxBiomassKgM2: 28.0,
    maxCanopyHeightMeters: 32.0,
    maxRootDepthMeters: 3.5,
    baseLightUseEfficiencyGCPerMJ: 1.25,
    isEvergreen: false,
    leafLifespanMonths: 6,
    specificLeafAreaM2PerKg: 20.0,
    c3OrC4OrCAM: 'C3'
  },
  TREES_BROADLEAF_EVERGREEN_TROPICAL: {
    group: 'TREES_BROADLEAF_EVERGREEN_TROPICAL',
    name: 'Tropical Broadleaf Evergreen Trees',
    minTempC: 14.0,
    optTempC: 27.0,
    maxTempC: 38.0,
    minAnnualPrecipMm: 1500,
    droughtTolerance: 0.25,
    fireResilience: 0.15,
    maxBiomassKgM2: 45.0,
    maxCanopyHeightMeters: 50.0,
    maxRootDepthMeters: 5.0,
    baseLightUseEfficiencyGCPerMJ: 1.45,
    isEvergreen: true,
    leafLifespanMonths: 18,
    specificLeafAreaM2PerKg: 14.0,
    c3OrC4OrCAM: 'C3'
  },
  TREES_NEEDLELEAF_EVERGREEN_CONIFER: {
    group: 'TREES_NEEDLELEAF_EVERGREEN_CONIFER',
    name: 'Needleleaf Evergreen Conifers',
    minTempC: -40.0,
    optTempC: 16.0,
    maxTempC: 30.0,
    minAnnualPrecipMm: 350,
    droughtTolerance: 0.65,
    fireResilience: 0.60,
    maxBiomassKgM2: 38.0,
    maxCanopyHeightMeters: 65.0,
    maxRootDepthMeters: 3.0,
    baseLightUseEfficiencyGCPerMJ: 0.95,
    isEvergreen: true,
    leafLifespanMonths: 36,
    specificLeafAreaM2PerKg: 7.0,
    c3OrC4OrCAM: 'C3'
  },
  TREES_NEEDLELEAF_DECIDUOUS_LARCH: {
    group: 'TREES_NEEDLELEAF_DECIDUOUS_LARCH',
    name: 'Boreal Deciduous Conifers (Larix)',
    minTempC: -65.0,
    optTempC: 15.0,
    maxTempC: 28.0,
    minAnnualPrecipMm: 180,
    droughtTolerance: 0.50,
    fireResilience: 0.65,
    maxBiomassKgM2: 18.0,
    maxCanopyHeightMeters: 22.0,
    maxRootDepthMeters: 1.5,
    baseLightUseEfficiencyGCPerMJ: 1.1,
    isEvergreen: false,
    leafLifespanMonths: 4,
    specificLeafAreaM2PerKg: 12.0,
    c3OrC4OrCAM: 'C3'
  },
  SUCCULENTS_CAM: {
    group: 'SUCCULENTS_CAM',
    name: 'Desert CAM Succulents & Cacti',
    minTempC: 2.0,
    optTempC: 32.0,
    maxTempC: 50.0,
    minAnnualPrecipMm: 50,
    droughtTolerance: 0.98,
    fireResilience: 0.20,
    maxBiomassKgM2: 3.0,
    maxCanopyHeightMeters: 6.0,
    maxRootDepthMeters: 1.0,
    baseLightUseEfficiencyGCPerMJ: 0.45,
    isEvergreen: true,
    leafLifespanMonths: 48,
    specificLeafAreaM2PerKg: 4.0,
    c3OrC4OrCAM: 'CAM'
  },
  WETLAND_EMERGENTS: {
    group: 'WETLAND_EMERGENTS',
    name: 'Hydrophytic Wetland Emergents (Typha/Phragmites)',
    minTempC: -10.0,
    optTempC: 24.0,
    maxTempC: 38.0,
    minAnnualPrecipMm: 700,
    droughtTolerance: 0.10,
    fireResilience: 0.50,
    maxBiomassKgM2: 8.0,
    maxCanopyHeightMeters: 3.5,
    maxRootDepthMeters: 1.5,
    baseLightUseEfficiencyGCPerMJ: 1.8,
    isEvergreen: false,
    leafLifespanMonths: 6,
    specificLeafAreaM2PerKg: 24.0,
    c3OrC4OrCAM: 'C3'
  },
  MANGROVE_HALOPHYTES: {
    group: 'MANGROVE_HALOPHYTES',
    name: 'Intertidal Mangrove Halophytes (Rhizophora)',
    minTempC: 16.0,
    optTempC: 28.0,
    maxTempC: 40.0,
    minAnnualPrecipMm: 1000,
    droughtTolerance: 0.50,
    fireResilience: 0.05,
    maxBiomassKgM2: 35.0,
    maxCanopyHeightMeters: 25.0,
    maxRootDepthMeters: 2.0,
    baseLightUseEfficiencyGCPerMJ: 1.15,
    isEvergreen: true,
    leafLifespanMonths: 18,
    specificLeafAreaM2PerKg: 8.5,
    c3OrC4OrCAM: 'C3'
  },
  MOSSES_BRYOPHYTES: {
    group: 'MOSSES_BRYOPHYTES',
    name: 'Poikilohydric Mosses & Bryophytes',
    minTempC: -45.0,
    optTempC: 12.0,
    maxTempC: 26.0,
    minAnnualPrecipMm: 150,
    droughtTolerance: 0.70,
    fireResilience: 0.10,
    maxBiomassKgM2: 1.5,
    maxCanopyHeightMeters: 0.1,
    maxRootDepthMeters: 0.05,
    baseLightUseEfficiencyGCPerMJ: 0.55,
    isEvergreen: true,
    leafLifespanMonths: 24,
    specificLeafAreaM2PerKg: 28.0,
    c3OrC4OrCAM: 'C3'
  },
  LICHENS_CRUSTOSE: {
    group: 'LICHENS_CRUSTOSE',
    name: 'Epilithic Pioneer Lichens',
    minTempC: -60.0,
    optTempC: 8.0,
    maxTempC: 30.0,
    minAnnualPrecipMm: 50,
    droughtTolerance: 0.95,
    fireResilience: 0.02,
    maxBiomassKgM2: 0.4,
    maxCanopyHeightMeters: 0.02,
    maxRootDepthMeters: 0.01,
    baseLightUseEfficiencyGCPerMJ: 0.20,
    isEvergreen: true,
    leafLifespanMonths: 60,
    specificLeafAreaM2PerKg: 10.0,
    c3OrC4OrCAM: 'C3'
  },
  AQUATIC_SUBMERGED_SEAGRASS: {
    group: 'AQUATIC_SUBMERGED_SEAGRASS',
    name: 'Submerged Marine Seagrasses (Zostera)',
    minTempC: 4.0,
    optTempC: 22.0,
    maxTempC: 32.0,
    minAnnualPrecipMm: 0,
    droughtTolerance: 0.0,
    fireResilience: 0.0,
    maxBiomassKgM2: 3.5,
    maxCanopyHeightMeters: 1.2,
    maxRootDepthMeters: 0.5,
    baseLightUseEfficiencyGCPerMJ: 1.3,
    isEvergreen: true,
    leafLifespanMonths: 8,
    specificLeafAreaM2PerKg: 30.0,
    c3OrC4OrCAM: 'C3'
  },
  MARINE_MACROALGAE_KELP: {
    group: 'MARINE_MACROALGAE_KELP',
    name: 'Subtidal Giant Kelp (Macrocystis)',
    minTempC: 2.0,
    optTempC: 14.0,
    maxTempC: 20.0,
    minAnnualPrecipMm: 0,
    droughtTolerance: 0.0,
    fireResilience: 0.0,
    maxBiomassKgM2: 12.0,
    maxCanopyHeightMeters: 30.0,
    maxRootDepthMeters: 0.1,
    baseLightUseEfficiencyGCPerMJ: 2.5,
    isEvergreen: true,
    leafLifespanMonths: 6,
    specificLeafAreaM2PerKg: 35.0,
    c3OrC4OrCAM: 'ALGAE'
  }
};

// ============================================================================
// 3. USDA SOIL TEXTURE PHYSICAL PARAMETERS
// ============================================================================

export interface USDASoilTextureParameters {
  textureClass: USDASoilTextureClass;
  sandFraction: number;
  siltFraction: number;
  clayFraction: number;
  bulkDensityKgM3: number;
  totalPorosity: number;
  fieldCapacityMoisture: number; // m³/m³
  wiltingPointMoisture: number;  // m³/m³
  saturatedHydraulicConductivityMmH: number;
  erodibilityKFactor: number;
}

export const USDA_SOIL_TEXTURE_TABLE: Record<USDASoilTextureClass, USDASoilTextureParameters> = {
  SAND: {
    textureClass: 'SAND',
    sandFraction: 0.92,
    siltFraction: 0.05,
    clayFraction: 0.03,
    bulkDensityKgM3: 1550,
    totalPorosity: 0.43,
    fieldCapacityMoisture: 0.10,
    wiltingPointMoisture: 0.03,
    saturatedHydraulicConductivityMmH: 120.0,
    erodibilityKFactor: 0.15
  },
  LOAMY_SAND: {
    textureClass: 'LOAMY_SAND',
    sandFraction: 0.82,
    siltFraction: 0.12,
    clayFraction: 0.06,
    bulkDensityKgM3: 1500,
    totalPorosity: 0.44,
    fieldCapacityMoisture: 0.14,
    wiltingPointMoisture: 0.06,
    saturatedHydraulicConductivityMmH: 60.0,
    erodibilityKFactor: 0.20
  },
  SANDY_LOAM: {
    textureClass: 'SANDY_LOAM',
    sandFraction: 0.65,
    siltFraction: 0.25,
    clayFraction: 0.10,
    bulkDensityKgM3: 1450,
    totalPorosity: 0.45,
    fieldCapacityMoisture: 0.20,
    wiltingPointMoisture: 0.09,
    saturatedHydraulicConductivityMmH: 30.0,
    erodibilityKFactor: 0.28
  },
  LOAM: {
    textureClass: 'LOAM',
    sandFraction: 0.40,
    siltFraction: 0.42,
    clayFraction: 0.18,
    bulkDensityKgM3: 1350,
    totalPorosity: 0.48,
    fieldCapacityMoisture: 0.27,
    wiltingPointMoisture: 0.12,
    saturatedHydraulicConductivityMmH: 15.0,
    erodibilityKFactor: 0.34
  },
  SILT_LOAM: {
    textureClass: 'SILT_LOAM',
    sandFraction: 0.20,
    siltFraction: 0.65,
    clayFraction: 0.15,
    bulkDensityKgM3: 1300,
    totalPorosity: 0.50,
    fieldCapacityMoisture: 0.33,
    wiltingPointMoisture: 0.14,
    saturatedHydraulicConductivityMmH: 10.0,
    erodibilityKFactor: 0.42
  },
  SILT: {
    textureClass: 'SILT',
    sandFraction: 0.08,
    siltFraction: 0.85,
    clayFraction: 0.07,
    bulkDensityKgM3: 1250,
    totalPorosity: 0.52,
    fieldCapacityMoisture: 0.35,
    wiltingPointMoisture: 0.15,
    saturatedHydraulicConductivityMmH: 8.0,
    erodibilityKFactor: 0.48
  },
  SANDY_CLAY_LOAM: {
    textureClass: 'SANDY_CLAY_LOAM',
    sandFraction: 0.60,
    siltFraction: 0.15,
    clayFraction: 0.25,
    bulkDensityKgM3: 1400,
    totalPorosity: 0.46,
    fieldCapacityMoisture: 0.26,
    wiltingPointMoisture: 0.15,
    saturatedHydraulicConductivityMmH: 12.0,
    erodibilityKFactor: 0.26
  },
  CLAY_LOAM: {
    textureClass: 'CLAY_LOAM',
    sandFraction: 0.32,
    siltFraction: 0.34,
    clayFraction: 0.34,
    bulkDensityKgM3: 1320,
    totalPorosity: 0.49,
    fieldCapacityMoisture: 0.32,
    wiltingPointMoisture: 0.18,
    saturatedHydraulicConductivityMmH: 6.0,
    erodibilityKFactor: 0.30
  },
  SILTY_CLAY_LOAM: {
    textureClass: 'SILTY_CLAY_LOAM',
    sandFraction: 0.10,
    siltFraction: 0.56,
    clayFraction: 0.34,
    bulkDensityKgM3: 1280,
    totalPorosity: 0.51,
    fieldCapacityMoisture: 0.37,
    wiltingPointMoisture: 0.21,
    saturatedHydraulicConductivityMmH: 4.5,
    erodibilityKFactor: 0.36
  },
  SANDY_CLAY: {
    textureClass: 'SANDY_CLAY',
    sandFraction: 0.52,
    siltFraction: 0.08,
    clayFraction: 0.40,
    bulkDensityKgM3: 1380,
    totalPorosity: 0.47,
    fieldCapacityMoisture: 0.30,
    wiltingPointMoisture: 0.20,
    saturatedHydraulicConductivityMmH: 3.0,
    erodibilityKFactor: 0.22
  },
  SILTY_CLAY: {
    textureClass: 'SILTY_CLAY',
    sandFraction: 0.08,
    siltFraction: 0.47,
    clayFraction: 0.45,
    bulkDensityKgM3: 1240,
    totalPorosity: 0.53,
    fieldCapacityMoisture: 0.39,
    wiltingPointMoisture: 0.24,
    saturatedHydraulicConductivityMmH: 1.8,
    erodibilityKFactor: 0.28
  },
  CLAY: {
    textureClass: 'CLAY',
    sandFraction: 0.20,
    siltFraction: 0.20,
    clayFraction: 0.60,
    bulkDensityKgM3: 1200,
    totalPorosity: 0.54,
    fieldCapacityMoisture: 0.42,
    wiltingPointMoisture: 0.28,
    saturatedHydraulicConductivityMmH: 1.0,
    erodibilityKFactor: 0.24
  }
};

// ============================================================================
// 4. ROTHERMEL WILDFIRE FUEL MODELS
// ============================================================================

export interface RothermelFuelModel {
  modelNumber: number;
  name: string;
  fuelBedDepthMeters: number;
  fineFuelLoadKgM2: number;
  extinctionMoisturePercent: number;
  heatContentKJKg: number;
  typicalBiome: BiomeType;
}

export const ROTHERMEL_FUEL_MODELS: Record<number, RothermelFuelModel> = {
  1: { modelNumber: 1, name: 'Short Grass (1 ft)', fuelBedDepthMeters: 0.3, fineFuelLoadKgM2: 0.16, extinctionMoisturePercent: 12, heatContentKJKg: 18600, typicalBiome: 'TEMPERATE_GRASSLAND' },
  2: { modelNumber: 2, name: 'Timber Grass and Understory', fuelBedDepthMeters: 0.6, fineFuelLoadKgM2: 0.45, extinctionMoisturePercent: 15, heatContentKJKg: 18600, typicalBiome: 'TROPICAL_SAVANNA' },
  3: { modelNumber: 3, name: 'Tall Grass (3 ft)', fuelBedDepthMeters: 0.9, fineFuelLoadKgM2: 0.68, extinctionMoisturePercent: 25, heatContentKJKg: 18600, typicalBiome: 'TEMPERATE_GRASSLAND' },
  4: { modelNumber: 4, name: 'Chaparral / High Shrub (6 ft)', fuelBedDepthMeters: 1.8, fineFuelLoadKgM2: 1.15, extinctionMoisturePercent: 20, heatContentKJKg: 19500, typicalBiome: 'MEDITERRANEAN_SHRUBLAND' },
  5: { modelNumber: 5, name: 'Brush (2 ft)', fuelBedDepthMeters: 0.6, fineFuelLoadKgM2: 0.23, extinctionMoisturePercent: 20, heatContentKJKg: 18600, typicalBiome: 'HOT_DESERT' },
  8: { modelNumber: 8, name: 'Closed Timber Litter (Hardwood)', fuelBedDepthMeters: 0.1, fineFuelLoadKgM2: 0.35, extinctionMoisturePercent: 30, heatContentKJKg: 18600, typicalBiome: 'TEMPERATE_DECIDUOUS_FOREST' },
  9: { modelNumber: 9, name: 'Hardwood Litter (Pine/Oak)', fuelBedDepthMeters: 0.15, fineFuelLoadKgM2: 0.65, extinctionMoisturePercent: 25, heatContentKJKg: 18600, typicalBiome: 'TEMPERATE_DECIDUOUS_FOREST' },
  10: { modelNumber: 10, name: 'Timber Litter and Heavy Down Fuel', fuelBedDepthMeters: 0.3, fineFuelLoadKgM2: 1.80, extinctionMoisturePercent: 25, heatContentKJKg: 18600, typicalBiome: 'BOREAL_FOREST_TAIGA' }
};

// ============================================================================
// 5. DEVELOPER SCENARIOS (Explicitly SYNTHETIC_TEST_FIXTURE)
// ============================================================================

export const ECOLOGICAL_DEVELOPER_SCENARIOS: Record<string, EcologicalScenarioConfig> = {
  'SCENARIO-1-BARE-VOLCANIC-SUBSTRATE': {
    id: 'SCENARIO-1-BARE-VOLCANIC-SUBSTRATE',
    name: 'Primary Succession on Basaltic Lava',
    description: 'Pristine unweathered volcanic basalt undergoing primary pedogenesis, crustose lichen colonization, and pioneer moss formation.',
    category: 'PRIMARY_SUCCESSION',
    targetCoord: { latitude: 19.421, longitude: -155.287, altitude: 1200 }, // Kilauea, Hawaii
    initialBiome: 'BARE_ROCK_SCREE',
    initialSeralStage: 'STAGE_0_BARE_SUBSTRATE',
    soilAgeYears: 0,
    isSyntheticFixture: true
  },
  'SCENARIO-2-ABANDONED-DISTURBED-LAND': {
    id: 'SCENARIO-2-ABANDONED-DISTURBED-LAND',
    name: 'Old-Field Secondary Succession',
    description: 'Post-agricultural abandoned field transitioning from annual weeds to perennial grasses, blackberry shrubs, and pioneer pine.',
    category: 'SECONDARY_SUCCESSION',
    targetCoord: { latitude: 35.913, longitude: -79.056, altitude: 150 }, // Piedmont, NC, USA
    initialBiome: 'TEMPERATE_GRASSLAND',
    initialSeralStage: 'STAGE_2_EARLY_HERBACEOUS_GRASS',
    soilAgeYears: 150,
    isSyntheticFixture: true
  },
  'SCENARIO-3-TEMPERATE-FOREST-SUCCESSION': {
    id: 'SCENARIO-3-TEMPERATE-FOREST-SUCCESSION',
    name: 'Temperate Deciduous Climax Succession',
    description: 'Mid-seral pioneer birch/aspen transitioning to shade-tolerant oak, beech, and sugar maple climax canopy over 250 years.',
    category: 'SECONDARY_SUCCESSION',
    targetCoord: { latitude: 42.536, longitude: -72.188, altitude: 320 }, // Harvard Forest, MA, USA
    initialBiome: 'TEMPERATE_DECIDUOUS_FOREST',
    initialSeralStage: 'STAGE_5_MID_SERAL_MIXED_FOREST',
    soilAgeYears: 500,
    isSyntheticFixture: true
  },
  'SCENARIO-4-POST-FIRE-FOREST-RECOVERY': {
    id: 'SCENARIO-4-POST-FIRE-FOREST-RECOVERY',
    name: 'Post-Wildfire Coniferous Forest Recovery',
    description: 'High-severity crown fire aftermath with complete canopy destruction, charcoal layer deposition, fireweed emergence, and lodgepole pine serotiny.',
    category: 'DISTURBANCE_EXPERIMENT',
    targetCoord: { latitude: 44.428, longitude: -110.588, altitude: 2350 }, // Yellowstone, WY, USA
    initialBiome: 'BOREAL_FOREST_TAIGA',
    initialSeralStage: 'STAGE_1_PIONEER_CRUST_MOSS',
    soilAgeYears: 1200,
    forcedDisturbance: 'WILDFIRE',
    isSyntheticFixture: true
  },
  'SCENARIO-5-DROUGHT-STRESSED-GRASSLAND': {
    id: 'SCENARIO-5-DROUGHT-STRESSED-GRASSLAND',
    name: 'Semi-Arid Savanna Megadrought',
    description: 'Prolonged multi-year soil moisture deficit triggering vegetation browning, stomatal closure, root dieback, and heightened wildfire ignition risk.',
    category: 'DISTURBANCE_EXPERIMENT',
    targetCoord: { latitude: -2.333, longitude: 34.833, altitude: 1500 }, // Serengeti
    initialBiome: 'TROPICAL_SAVANNA',
    initialSeralStage: 'STAGE_6_MATURE_CLIMAX_FOREST',
    soilAgeYears: 3000,
    forcedDisturbance: 'SEVERE_DROUGHT',
    isSyntheticFixture: true
  },
  'SCENARIO-6-FLOODPLAIN-WETLAND-FORMATION': {
    id: 'SCENARIO-6-FLOODPLAIN-WETLAND-FORMATION',
    name: 'Riparian Floodplain Wetland Inundation',
    description: 'Sustained hydrologic overbank flooding creating anaerobic hydric soil conditions, cattail/sedge colonization, and peat accumulation.',
    category: 'DISTURBANCE_EXPERIMENT',
    targetCoord: { latitude: 32.350, longitude: -90.875, altitude: 25 }, // Mississippi
    initialBiome: 'FRESHWATER_WETLAND',
    initialSeralStage: 'STAGE_3_SHRUB_THICKET',
    soilAgeYears: 800,
    forcedDisturbance: 'FLOOD_INUNDATION',
    isSyntheticFixture: true
  },
  'SCENARIO-7-MOUNTAIN-ELEVATIONAL-GRADIENT': {
    id: 'SCENARIO-7-MOUNTAIN-ELEVATIONAL-GRADIENT',
    name: 'Cascade Mountain Elevational Transect',
    description: 'Dynamic ecological zonation from Douglas-fir lowland forest through subalpine fir krummholz to alpine cushion tundra and nival ice.',
    category: 'EXTREME_ECOSYSTEM',
    targetCoord: { latitude: 46.852, longitude: -121.760, altitude: 3200 }, // Mt Rainier, WA
    initialBiome: 'ALPINE_MEADOW',
    initialSeralStage: 'STAGE_6_MATURE_CLIMAX_FOREST',
    soilAgeYears: 2500,
    isSyntheticFixture: true
  },
  'SCENARIO-8-DESERT-RAINFALL-PULSE': {
    id: 'SCENARIO-8-DESERT-RAINFALL-PULSE',
    name: 'Desert Ephemeral Superbloom Pulse',
    description: 'Extreme episodic deluge event across hyper-arid desert activating dormant seed bank into explosive ephemeral wildflower productivity.',
    category: 'EXTREME_ECOSYSTEM',
    targetCoord: { latitude: -24.500, longitude: -69.500, altitude: 2200 }, // Atacama Desert
    initialBiome: 'HOT_DESERT',
    initialSeralStage: 'STAGE_1_PIONEER_CRUST_MOSS',
    soilAgeYears: 10000,
    isSyntheticFixture: true
  },
  'SCENARIO-9-MANGROVE-COASTAL-ECOSYSTEM': {
    id: 'SCENARIO-9-MANGROVE-COASTAL-ECOSYSTEM',
    name: 'Intertidal Halophytic Mangrove Zonation',
    description: 'Tidal saline inundation gradient structuring seaward red mangrove, mid-intertidal black mangrove with pneumatophores, and landward white mangrove.',
    category: 'COASTAL_MARINE',
    targetCoord: { latitude: 21.949, longitude: 89.183, altitude: 2 }, // Sundarbans
    initialBiome: 'MANGROVE_SWAMP',
    initialSeralStage: 'STAGE_6_MATURE_CLIMAX_FOREST',
    soilAgeYears: 1500,
    isSyntheticFixture: true
  },
  'SCENARIO-10-CORAL-BLEACHING-STRESS': {
    id: 'SCENARIO-10-CORAL-BLEACHING-STRESS',
    name: 'Marine Heatwave Coral Bleaching Event',
    description: 'Elevated sea surface temperature sustained above thermal threshold leading to zooxanthellae expulsion, calcification collapse, and algal overgrowth.',
    category: 'COASTAL_MARINE',
    targetCoord: { latitude: -16.850, longitude: 146.200, altitude: -8 }, // Great Barrier Reef
    initialBiome: 'CORAL_REEF',
    initialSeralStage: 'STAGE_6_MATURE_CLIMAX_FOREST',
    soilAgeYears: 5000,
    isSyntheticFixture: true
  }
};

// ============================================================================
// 6. FORMAL DATASET PROVENANCE REGISTRY
// ============================================================================

export const ECOLOGICAL_DATASET_PROVENANCE_REGISTRY: DatasetProvenanceRecord[] = [
  {
    datasetId: 'ESA-WORLDCOVER-10M',
    name: 'ESA WorldCover 10m Global Land Cover',
    provider: 'European Space Agency (ESA) / VITO Remote Sensing',
    version: 'v200 (2021)',
    spatialResolution: '10 meters (Global)',
    temporalCoverage: '2020-2021 annual composite',
    geographicCoverage: 'Global terrestrial (80°N to 60°S)',
    license: 'Creative Commons CC-BY 4.0 International',
    classification: 'REAL_OBSERVATION',
    processingPipeline: 'Sentinel-1 SAR and Sentinel-2 optical multi-temporal deep learning classification algorithm.',
    scientificLimitations: [
      'Cloud contamination in persistent equatorial zones',
      'Small fragmented wetland classes underrepresented at 10m resolution',
      'Mixed pixels along sharp agricultural-natural boundaries'
    ]
  },
  {
    datasetId: 'MODIS-MCD12Q1-LANDCOVER',
    name: 'MODIS/Terra+Aqua Land Cover Type Yearly L3 Global 500m',
    provider: 'NASA LP DAAC / USGS EROS',
    version: 'Collection 6.1 (2001-Present)',
    spatialResolution: '500 meters (Sinusoidal Grid)',
    temporalCoverage: '2001-2023 Annual',
    geographicCoverage: 'Global terrestrial',
    license: 'NASA Open Data Policy (Public Domain)',
    classification: 'REAL_OBSERVATION',
    processingPipeline: 'Supervised decision-tree classification using annual MODIS surface reflectance and thermal dynamics.',
    scientificLimitations: [
      'Coarse 500m spatial scale aggregates microtopographic riparian wetlands',
      'High-latitude snow cover misclassification during transition months'
    ]
  },
  {
    datasetId: 'MODIS-MOD17A3-NPP',
    name: 'MODIS Global Net Primary Production (NPP) & GPP',
    provider: 'NASA Numerical Terradynamic Simulation Group (NTSG)',
    version: 'Collection 6.1',
    spatialResolution: '500 meters',
    temporalCoverage: '2000-2023 Annual',
    geographicCoverage: 'Global vegetated land',
    license: 'NASA Open Data Policy (Public Domain)',
    classification: 'MODEL_DERIVED',
    processingPipeline: 'Monteith Light-Use Efficiency (LUE) bio-physical model forced by MOD15A2 FPAR/LAI and GMAO meteorological reanalysis.',
    scientificLimitations: [
      'LUE maximum parameters are parameterized per coarse PFT, not per species',
      'Vapor Pressure Deficit (VPD) stress model can underestimate extreme drought mortality'
    ]
  },
  {
    datasetId: 'ISRIC-SOILGRIDS-250M',
    name: 'SoilGrids250m Global Gridded Soil Information',
    provider: 'ISRIC - World Soil Information',
    version: 'v2.0 (2020)',
    spatialResolution: '250 meters (0-200cm depth intervals)',
    temporalCoverage: 'Static baseline',
    geographicCoverage: 'Global terrestrial',
    license: 'Creative Commons CC-BY 4.0',
    classification: 'MODEL_DERIVED',
    processingPipeline: 'Machine learning (Random Forest, Quantile Regression) spatial pedotransfer interpolation trained on 240,000+ soil profile observations.',
    scientificLimitations: [
      'Sparse profile sampling density in remote boreal and Sahara regions',
      'Depth-to-bedrock uncertainty in steep mountainous topography'
    ]
  },
  {
    datasetId: 'GLOBAL-MANGROVE-WATCH',
    name: 'Global Mangrove Watch (GMW) Coastal Extents',
    provider: 'JAXA / Aberystwyth University / Wetlands International',
    version: 'v3.0 (1996-2020)',
    spatialResolution: '25 meters',
    temporalCoverage: '1996-2020 multi-epoch',
    geographicCoverage: 'Global tropical and subtropical coastlines',
    license: 'Creative Commons CC-BY 4.0',
    classification: 'REAL_OBSERVATION',
    processingPipeline: 'ALOS PALSAR radar and Landsat optical time-series classification.',
    scientificLimitations: [
      'Tidal state during satellite overpass affects edge delineation',
      'Does not distinguish all fine-scale mangrove sub-zonation species'
    ]
  },
  {
    datasetId: 'UNEP-WCMC-CORAL-REEFS',
    name: 'Global Distribution of Coral Reefs',
    provider: 'UNEP World Conservation Monitoring Centre / WorldFish',
    version: 'v4.1 (2021)',
    spatialResolution: 'Vector polygon / 1:250,000 equivalent',
    temporalCoverage: '1954-2018 compiled',
    geographicCoverage: 'Global marine shallow waters',
    license: 'UNEP-WCMC Data Use Agreement',
    classification: 'REAL_OBSERVATION',
    processingPipeline: 'Millennium Coral Reef Mapping Project Landsat interpretation combined with in-situ field surveys.',
    scientificLimitations: [
      'Does not capture deep mesophotic reefs (>30m depth)',
      'Temporal lag in post-bleaching reef mortality updates'
    ]
  },
  {
    datasetId: 'SYNTHETIC-ECOLOGICAL-BENCHMARKS',
    name: 'Project Earth Phase 9 Developer Succession Fixtures',
    provider: 'Project Earth Engineering Core',
    version: '9.0.0 (2026)',
    spatialResolution: 'Continuous Point & Analytical Grid',
    temporalCoverage: '0 to 1000 years simulation time',
    geographicCoverage: 'Global coordinate test targets',
    license: 'Project Earth Internal',
    classification: 'SYNTHETIC_TEST_FIXTURE',
    processingPipeline: 'Deterministic multi-physics coupling combining Köppen climate, Richards soil moisture, Rothermel fire spread, and Lotka-Volterra competition.',
    scientificLimitations: [
      'Engineered specifically for verification of seral transitions and stress test boundaries',
      'Must never be cited as real empirical ecological observations'
    ]
  }
];
