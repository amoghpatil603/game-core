/**
 * Project Earth: Phase 5 Hydrology & Water Surface Engine
 * Type Definitions & Architectural Interfaces
 * Canonical standards for River Networks, Watersheds, Hydraulic Flow, Groundwater, and Flood Dynamics.
 */

export type WaterBodyType = 'River' | 'Stream' | 'Tributary' | 'Lake' | 'Reservoir' | 'Aquifer' | 'Wetland' | 'Ocean_Outflow';

export type FlowRegime = 'Perennial' | 'Intermittent' | 'Ephemeral' | 'Braided' | 'Gorge_Rapid';

export type SimulationTier = 0 | 1 | 2 | 3;
// Tier 0: Local 60Hz Hydraulic Mesh & Dynamic Wave Displacements (<400m from camera)
// Tier 1: Nearby 10Hz 1D Saint-Venant / Manning Channel Flow (<2.5km)
// Tier 2: Regional 1Hz DAG Flow Routing & Mass Balance (<25km)
// Tier 3: Macro Dormant Seasonal Hydrograph Interpolation (Global / Planetary)

export interface RiverCoordinate {
  lat: number;
  lng: number;
  altMeters: number;
  eastingUTM?: number;
  northingUTM?: number;
}

export interface RiverNode {
  nodeId: string;
  nodeName: string;
  coord: RiverCoordinate;
  bedElevationMeters: number;
  waterSurfaceElevationMeters: number;
  waterDepthMeters: number;
  channelWidthMeters: number;
  isConfluence: boolean;
  isSource: boolean;
  isOutflow: boolean;
  strahlerOrder: number;
  basinId: string;
}

export interface RiverSegment {
  segmentId: string;
  segmentName: string;
  waterType: WaterBodyType;
  flowRegime: FlowRegime;
  strahlerOrder: number;
  basinId: string;
  
  // Topological Graph Links (DAG)
  fromNodeId: string;
  toNodeId: string;
  upstreamSegmentIds: string[];
  downstreamSegmentId: string | null;

  // Spatial Path Vertices (Geodetic / Metric)
  pathVertices: RiverCoordinate[];
  lengthMeters: number;

  // Hydraulic & Physical Parameters
  gradientPercent: number;        // Bed slope S = dh / dL
  manningRoughnessN: number;      // Manning's n (0.025 for smooth gravel to 0.075 for boulder gorge)
  baseflowM3S: number;           // Mean annual discharge Q (m³/s)
  currentDischargeM3S: number;    // Dynamic instantaneous discharge Q
  flowVelocityMS: number;         // Mean flow velocity v (m/s)
  bankfullWidthMeters: number;    // Channel top width W
  bankfullDepthMeters: number;    // Maximum bankfull depth D
  currentDepthMeters: number;     // Active water depth d
  crossSectionalAreaM2: number;   // Wetted cross-section A = W * d
  hydraulicRadiusMeters: number;  // R_h = A / P_wetted
  froudeNumber: number;           // Fr = v / sqrt(g * D) (< 1 subcritical, > 1 supercritical)

  // Water Quality & Environment
  waterTemperatureC: number;
  dissolvedOxygenMgL: number;
  turbidityNTU: number;
  sedimentLoadKgS: number;
}

export interface WatershedBasin {
  basinId: string;
  basinName: string;
  macroRegion: string;
  drainageAreaKm2: number;
  primaryOutflowNodeId: string;
  meanAnnualPrecipitationMm: number;
  meanElevationMeters: number;
  maxElevationMeters: number;
  minElevationMeters: number;
  totalRiverLengthKm: number;
  mainstemLengthKm: number;
  drainageDensityKmPerKm2: number; // Total length / Area
  timeOfConcentrationHours: number; // Hydrograph response time
  averageRunoffCoefficient: number; // Weighted average from land cover
  baseflowContributionPercent: number;
  aquiferRechargeRateMmYear: number;
  boundingPolyCoordinates: { lat: number; lng: number }[];
}

export interface GroundwaterAquiferCell {
  cellId: string;
  utmEasting: number;
  utmNorthing: number;
  groundSurfaceElevationMeters: number;
  waterTableElevationMeters: number;
  waterTableDepthMeters: number; // Surface - WaterTable
  hydraulicConductivityMDay: number; // K (m/day)
  porosityFraction: number; // e.g. 0.25 (sandstone) to 0.40 (alluvium)
  saturationPercent: number; // 0 to 100%
  baseflowSeepageM3SPerKm2: number;
}

export interface HydrographDataPoint {
  timeHours: number;
  rainfallRateMmHr: number;
  dischargeM3S: number;
  waterStageMeters: number;
  inundatedAreaM2: number;
}

export interface FloodSimulationConfig {
  rainfallIntensityMmHr: number; // Storm rainfall intensity (e.g. 5 mm/hr light to 80 mm/hr torrential)
  stormDurationHours: number;     // Duration of precipitation event
  antecedentMoistureCondition: 'Dry' | 'Moderate' | 'Saturated'; // Soil moisture state
  activeBasinId: string;
  returnPeriodYears: 2 | 10 | 50 | 100 | 500; // Flood recurrence interval
  hydroFlatteningEnabled: boolean;
}

export interface FloodInundationGridCell {
  gridX: number;
  gridY: number;
  terrainElevationMeters: number;
  waterDepthMeters: number;
  waterSurfaceElevationMeters: number;
  isChannelCell: boolean;
  isInundated: boolean;
  flowVelocityVector: { vx: number; vy: number };
  floodHazardCategory: 'None' | 'Low' | 'Moderate' | 'Severe' | 'Extreme';
}

export interface HydrologyMetricsSummary {
  totalBasinAreaKm2: number;
  totalActiveDischargeM3S: number;
  peakFloodDischargeM3S: number;
  activeRiverSegmentsCount: number;
  totalChannelLengthMeters: number;
  inundatedSurfaceAreaM2: number;
  groundwaterAverageDepthMeters: number;
  massConservationDeltaM3S: number;
  hydraulicPerformanceFps: number;
  activeSimulationTier: SimulationTier;
}
