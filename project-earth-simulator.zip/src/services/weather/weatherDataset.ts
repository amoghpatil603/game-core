/**
 * Project Earth: Phase 8 Dynamic Weather & Atmospheric Simulation Engine
 * Data Provenance Registry, Physical Constants & 10 Synthetic Test Scenarios
 */

import { WeatherDataClassification, WeatherScenarioConfig } from './weatherTypes';

export interface MeteorologicalDataProvenance {
  id: string;
  datasetName: string;
  sourceOrganization: string;
  version: string;
  spatialResolution: string;
  temporalCoverage: string;
  license: string;
  classification: WeatherDataClassification;
  ingestPipeline: string;
  knownLimitations: string[];
}

export const METEOROLOGICAL_PROVENANCE_REGISTRY: MeteorologicalDataProvenance[] = [
  {
    id: 'ERA5-HOURLY-REANALYSIS',
    datasetName: 'ERA5 Hourly Atmospheric Reanalysis',
    sourceOrganization: 'ECMWF (European Centre for Medium-Range Weather Forecasts)',
    version: 'ERA5-v1.4',
    spatialResolution: '0.25° (~31 km)',
    temporalCoverage: '1979 - 2023 (Hourly)',
    license: 'Copernicus Climate Change Service Open Licence',
    classification: 'REANALYSIS',
    ingestPipeline: 'Harmonic decomposition of 10m u/v winds, 2m temp, surface pressure and convective precipitation',
    knownLimitations: [
      'Sub-kilometer convective storms and local valley microclimates are parameterized rather than explicitly resolved',
      'Orographic precipitation on sharp coastal ridges smoothed by 0.25-deg grid cell averaging'
    ]
  },
  {
    id: 'NOAA-GFS-SYNOPTIC',
    datasetName: 'Global Forecast System (GFS) Atmospheric Analysis',
    sourceOrganization: 'NOAA / NCEP (National Centers for Environmental Prediction)',
    version: 'GFS v16.3',
    spatialResolution: '0.25° (~28 km)',
    temporalCoverage: 'Operational Daily 00z/06z/12z/18z',
    license: 'Public Domain / US Government Work (17 U.S.C. 105)',
    classification: 'MODEL_DERIVED',
    ingestPipeline: 'Numerical parameter calibration for synoptic pressure gradient to geostrophic wind conversion',
    knownLimitations: [
      'Model-derived numerical initializations exhibit boundary dissipation beyond 120-hour forecast projections',
      'Assumes hydrostatic equilibrium at macro grid cells'
    ]
  },
  {
    id: 'NOAA-HURDAT2-CYCLONES',
    datasetName: 'Atlantic & East Pacific Hurricane Database (HURDAT2)',
    sourceOrganization: 'NOAA / NHC (National Hurricane Center)',
    version: 'HURDAT2-2023b',
    spatialResolution: 'Best Track Points (0.1° accuracy)',
    temporalCoverage: '1851 - 2023',
    license: 'Public Domain (US Government)',
    classification: 'REAL_OBSERVATION',
    ingestPipeline: 'Empirical extraction of tropical cyclone pressure-wind relationships, eye radius, and track velocity',
    knownLimitations: [
      'Pre-satellite era (before 1966) storm intensity estimates have higher observational uncertainty',
      'Eye radius measurements reconstructed from aircraft reconnaissance logs'
    ]
  },
  {
    id: 'STAGE-IV-RADAR-PRECIP',
    datasetName: 'NCEP Stage IV Multi-Sensor Quantitative Precipitation Estimates',
    sourceOrganization: 'NOAA / NWS National River Forecast Centers',
    version: 'Stage IV v2.0',
    spatialResolution: '4 km national mosaic',
    temporalCoverage: '2002 - Present',
    license: 'Public Domain (US Government)',
    classification: 'REAL_OBSERVATION',
    ingestPipeline: 'Calibration curve for convective vs stratiform precipitation rates and extreme deluge thresholds',
    knownLimitations: [
      'Radar beam blockage in deep mountainous terrain (e.g. Rockies / Cascades)',
      'Hail contamination requires ground-gauge dual-polarization corrections'
    ]
  },
  {
    id: 'SYNTHETIC-ATMOSPHERIC-BENCHMARKS',
    datasetName: 'Project Earth Phase 8 Synthetic Test Fixture Scenarios',
    sourceOrganization: 'Project Earth Autonomous Verification Engine',
    version: '8.0.0-PROTOTYPE',
    spatialResolution: 'Exact WGS84 coordinates',
    temporalCoverage: 'Multi-scale 0.1 Hz to 60 Hz simulation',
    license: 'Internal Architecture / Open MIT',
    classification: 'SYNTHETIC_TEST_FIXTURE',
    ingestPipeline: 'Deterministic physics-driven scenario generation with multi-system coupling test harness',
    knownLimitations: [
      'Synthetic scenarios represent controlled boundary stress tests rather than real-time operational weather forecasts'
    ]
  }
];

/**
 * Physical Constants for Atmospheric Thermodynamics
 */
export const ATMOSPHERIC_CONSTANTS = {
  // Gas & Thermodynamics
  DRY_AIR_GAS_CONSTANT_RD: 287.058, // J/(kg*K)
  WATER_VAPOR_GAS_CONSTANT_RV: 461.5, // J/(kg*K)
  SPECIFIC_HEAT_CP: 1004.64, // J/(kg*K)
  LATENT_HEAT_VAPORIZATION_LV: 2.501e6, // J/kg at 0°C
  LATENT_HEAT_FUSION_LF: 3.34e5, // J/kg
  STEFAN_BOLTZMANN_SIGMA: 5.670374e-8, // W/(m^2*K^4)
  STANDARD_GRAVITY: 9.80665, // m/s^2
  EARTH_ROTATION_RATE_OMEGA: 7.292115e-5, // rad/s

  // Standard Sea Level Atmosphere
  STANDARD_SEA_LEVEL_PRESSURE_HPA: 1013.25,
  STANDARD_SEA_LEVEL_TEMP_K: 288.15, // 15°C
  DRY_ADIABATIC_LAPSE_RATE_C_PER_KM: 9.8,
  MOIST_ADIABATIC_LAPSE_RATE_C_PER_KM: 5.5,
  ENVIRONMENTAL_LAPSE_RATE_C_PER_KM: 6.5,

  // Magnus-Tetens Vapor Pressure Parameters (Buck 1981)
  MAGNUS_WATER_A: 6.1121, // hPa
  MAGNUS_WATER_B: 17.67,
  MAGNUS_WATER_C: 243.5, // °C
  MAGNUS_ICE_B: 22.587,
  MAGNUS_ICE_C: 273.86 // °C
};

/**
 * 10 Developer Test Scenarios (Strictly Labeled as Synthetic Fixtures)
 */
export const WEATHER_DEVELOPER_SCENARIOS: WeatherScenarioConfig[] = [
  {
    id: 'SCENARIO-1-CLEAR-SUMMER',
    name: 'Clear Midsummer Anticyclone (Great Plains)',
    description: 'High-pressure subsidence dome producing stable atmosphere, minimal cloud cover, strong diurnal solar heating, and light boundary layer breezes.',
    category: 'BENCHMARK',
    targetCoord: { latitude: 38.5, longitude: -98.0, altitude: 450 },
    seasonDayOfYear: 195, // Mid-July
    initialHourUtc: 14.0, // 2:00 PM local sun
    forcedEntities: {
      pressureSystems: [{
        id: 'SYS-HIGH-01',
        type: 'HIGH_PRESSURE_ANTICYCLONE',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 38.5, longitude: -98.0, altitude: 450 },
        centralPressureHPa: 1028.5,
        baselineAnomalyHPa: 15.0,
        radiusKm: 750,
        movementSpeedKmh: 12.0,
        movementHeadingDeg: 95.0,
        maxSurfaceWindMS: 4.5,
        verticalMotionState: 'SUBSIDENCE_CLEARING'
      }]
    }
  },
  {
    id: 'SCENARIO-2-MONSOON-DELUGE',
    name: 'South Asian Summer Monsoon Inflow (Cherrapunji)',
    description: 'Extreme orographic moisture convergence from Bay of Bengal driving continuous stratiform and convective deluge against the Meghalaya plateau.',
    category: 'EXTREME_STORM',
    targetCoord: { latitude: 25.27, longitude: 91.73, altitude: 1313 },
    seasonDayOfYear: 180, // June/July Monsoon Peak
    initialHourUtc: 8.0,
    forcedEntities: {
      pressureSystems: [{
        id: 'SYS-MONSOON-LOW',
        type: 'LOW_PRESSURE_CYCLONIC',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 23.5, longitude: 90.0, altitude: 10 },
        centralPressureHPa: 994.0,
        baselineAnomalyHPa: -18.0,
        radiusKm: 900,
        movementSpeedKmh: 8.0,
        movementHeadingDeg: 350.0,
        maxSurfaceWindMS: 16.0,
        verticalMotionState: 'CONVERGENCE_LIFTING'
      }]
    }
  },
  {
    id: 'SCENARIO-3-WINTER-BLIZZARD',
    name: 'Nor\'easter Winter Blizzard (Boston / New England)',
    description: 'Deep bomb-cyclone low off the Atlantic coast drawing sub-freezing Arctic air into moist maritime air mass, producing heavy snow, gales, and near-zero visibility.',
    category: 'EXTREME_STORM',
    targetCoord: { latitude: 42.36, longitude: -71.06, altitude: 40 },
    seasonDayOfYear: 30, // January
    initialHourUtc: 11.0,
    forcedEntities: {
      pressureSystems: [{
        id: 'SYS-BLIZZARD-LOW',
        type: 'LOW_PRESSURE_CYCLONIC',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 40.5, longitude: -70.0, altitude: 0 },
        centralPressureHPa: 968.0,
        baselineAnomalyHPa: -45.0,
        radiusKm: 650,
        movementSpeedKmh: 42.0,
        movementHeadingDeg: 35.0,
        maxSurfaceWindMS: 28.5,
        verticalMotionState: 'CONVERGENCE_LIFTING'
      }],
      fronts: [{
        id: 'FRONT-OCCLUDED-01',
        type: 'OCCLUDED_FRONT',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 41.5, longitude: -71.5, altitude: 0 },
        headingDeg: 45.0,
        speedKmh: 40.0,
        lengthKm: 500,
        widthKm: 120,
        temperatureGradientCPer100Km: 8.5,
        pressureDeficitHPa: 12.0,
        humidityGradientPercentPer100Km: 25.0,
        precipitationRateMultiplier: 3.2,
        windShiftAngleDeg: 65.0
      }]
    }
  },
  {
    id: 'SCENARIO-4-CASCADE-RAIN-SHADOW',
    name: 'Pacific Northwest Orographic Rain Shadow (Seattle to Yakima)',
    description: 'Maritime westerly wind flow lifting over the Cascade Crest (heavy rain at Snoqualmie Pass) followed by leeward adiabatic compression and drying in the rain shadow basin.',
    category: 'LOCAL_PHENOMENON',
    targetCoord: { latitude: 46.9, longitude: -120.5, altitude: 325 }, // Yakima Valley
    seasonDayOfYear: 320, // Mid-November
    initialHourUtc: 18.0,
    forcedEntities: {
      pressureSystems: [{
        id: 'SYS-PACIFIC-TROUGH',
        type: 'LOW_PRESSURE_CYCLONIC',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 49.0, longitude: -128.0, altitude: 0 },
        centralPressureHPa: 988.0,
        baselineAnomalyHPa: -22.0,
        radiusKm: 800,
        movementSpeedKmh: 30.0,
        movementHeadingDeg: 80.0,
        maxSurfaceWindMS: 18.0,
        verticalMotionState: 'CONVERGENCE_LIFTING'
      }]
    }
  },
  {
    id: 'SCENARIO-5-COASTAL-FOG',
    name: 'San Francisco Marine Layer & Coastal Advection Fog',
    description: 'Moist marine boundary layer advecting over cold coastal upwelling water (Phase 6 California Current), condensing into dense advection stratus and rolling through the Golden Gate.',
    category: 'LOCAL_PHENOMENON',
    targetCoord: { latitude: 37.77, longitude: -122.42, altitude: 15 },
    seasonDayOfYear: 215, // August
    initialHourUtc: 6.0, // Early morning
    forcedEntities: {
      pressureSystems: [{
        id: 'SYS-THERMAL-LOW-VALLEY',
        type: 'THERMAL_LOW',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 37.5, longitude: -120.8, altitude: 50 },
        centralPressureHPa: 1008.0,
        baselineAnomalyHPa: -6.0,
        radiusKm: 300,
        movementSpeedKmh: 0,
        movementHeadingDeg: 0,
        maxSurfaceWindMS: 6.0,
        verticalMotionState: 'NEUTRAL'
      }]
    }
  },
  {
    id: 'SCENARIO-6-SEVERE-SUPERCELL',
    name: 'Tornado Alley Supercell Thunderstorm (Moore, Oklahoma)',
    description: 'High CAPE (>3500 J/kg), low CIN, strong vertical directional wind shear along a sharp dryline/cold front producing an explosive rotating updraft, severe hail, and tornado touchdown.',
    category: 'EXTREME_STORM',
    targetCoord: { latitude: 35.33, longitude: -97.48, altitude: 382 },
    seasonDayOfYear: 140, // Late May
    initialHourUtc: 20.5, // 3:30 PM CST
    forcedEntities: {
      thunderstorms: [{
        id: 'STORM-SUPERCELL-MOORE',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 35.33, longitude: -97.48, altitude: 382 },
        diameterKm: 28.0,
        cloudTopAltitudeMeters: 16200,
        capeJkg: 3850,
        updraftVelocityMS: 48.0,
        downdraftVelocityMS: 24.0,
        peakPrecipitationRateMmH: 115.0,
        hasHail: true,
        hailDiameterMm: 65, // Baseball size
        lightningFlashRatePerMin: 72,
        microburstWindGustMS: 38.0,
        tornadoProbabilityPercent: 88.0,
        ageMinutes: 45,
        maxLifetimeMinutes: 180
      }],
      fronts: [{
        id: 'FRONT-COLD-DRYLINE',
        type: 'COLD_FRONT',
        lifecycle: 'INTENSIFYING',
        centerCoord: { latitude: 35.3, longitude: -97.8, altitude: 400 },
        headingDeg: 80.0,
        speedKmh: 45.0,
        lengthKm: 450,
        widthKm: 60,
        temperatureGradientCPer100Km: 14.0,
        pressureDeficitHPa: 8.0,
        humidityGradientPercentPer100Km: 55.0,
        precipitationRateMultiplier: 4.5,
        windShiftAngleDeg: 90.0
      }]
    }
  },
  {
    id: 'SCENARIO-7-TROPICAL-CYCLONE',
    name: 'Category 5 Super Typhoon / Hurricane (Gulf Coast / Caribbean)',
    description: 'Deep warm SST ocean coupling (>29.5°C), high upper-tropospheric outflow, low vertical shear producing 915 hPa central eye pressure, 165 kt peak gusts, and a 6.2m storm surge.',
    category: 'EXTREME_STORM',
    targetCoord: { latitude: 27.5, longitude: -88.0, altitude: 0 },
    seasonDayOfYear: 240, // Late August
    initialHourUtc: 16.0,
    forcedEntities: {
      cyclones: [{
        id: 'CYCLONE-ZEUS-CAT5',
        name: 'Super Cyclone Zeus',
        category: 'CATEGORY_5',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 27.5, longitude: -88.0, altitude: 0 },
        centralPressureHPa: 912.0,
        eyeRadiusKm: 18.0,
        radiusOfMaximumWindsKm: 32.0,
        radiusOfGaleWindsKm: 320.0,
        maxSustainedWindMS: 72.5, // ~140 kt sustained
        peakWindGustMS: 88.0,
        forwardSpeedKmh: 20.0,
        trackHeadingDeg: 325.0,
        oceanSstAtCenterC: 30.2,
        stormSurgeHeightEstimateMeters: 5.8,
        historicalTrack: [
          { coord: { latitude: 24.0, longitude: -84.0, altitude: 0 }, timeHours: 0, pressureHPa: 975, windMS: 38 },
          { coord: { latitude: 25.5, longitude: -86.0, altitude: 0 }, timeHours: 12, pressureHPa: 940, windMS: 55 },
          { coord: { latitude: 27.5, longitude: -88.0, altitude: 0 }, timeHours: 24, pressureHPa: 912, windMS: 72.5 }
        ],
        ageHours: 48
      }]
    }
  },
  {
    id: 'SCENARIO-8-HEAT-WAVE',
    name: 'Stagnant Continental Heat Dome (Paris / Western Europe)',
    description: 'Persistent blocking anticyclone with high geopotential heights, suppressing cloud formation and trapping sensible heat, raising temperatures +12°C above baseline with severe heat stress.',
    category: 'BENCHMARK',
    targetCoord: { latitude: 48.85, longitude: 2.35, altitude: 35 },
    seasonDayOfYear: 205, // Late July
    initialHourUtc: 15.0,
    forcedEntities: {
      thermalAnomalies: [{
        id: 'ANOM-HEAT-DOME-EU',
        type: 'HEAT_WAVE',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 48.85, longitude: 2.35, altitude: 35 },
        radiusKm: 600,
        temperatureAnomalyC: 11.5,
        relativeHumidityAnomalyPercent: -22.0,
        durationDays: 14,
        ageDays: 6,
        heatIndexC: 43.5
      }]
    }
  },
  {
    id: 'SCENARIO-9-COLD-WAVE',
    name: 'Polar Vortex Arctic Outbreak (Minneapolis / Upper Midwest)',
    description: 'Displaced tropospheric polar vortex delivering Siberian/Arctic air mass directly southward, dropping surface temperatures to -34°C with lethal wind chills below -48°C.',
    category: 'BENCHMARK',
    targetCoord: { latitude: 44.97, longitude: -93.26, altitude: 250 },
    seasonDayOfYear: 20, // Mid January
    initialHourUtc: 7.0, // Pre-dawn minimum
    forcedEntities: {
      thermalAnomalies: [{
        id: 'ANOM-POLAR-VORTEX',
        type: 'COLD_WAVE',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 44.97, longitude: -93.26, altitude: 250 },
        radiusKm: 950,
        temperatureAnomalyC: -21.0,
        relativeHumidityAnomalyPercent: -10.0,
        durationDays: 8,
        ageDays: 3,
        windChillC: -47.0
      }]
    }
  },
  {
    id: 'SCENARIO-10-FLOOD-PRODUCING-STORM',
    name: 'Atmospheric River Pineapple Express & Flash Flood (Cascadia / Coastal Oregon)',
    description: 'Narrow corridor of extreme tropical moisture advection hitting mountain topography, yielding persistent rainfall >25 mm/hr, saturated soil profiles, and massive hydrology runoff.',
    category: 'EXTREME_STORM',
    targetCoord: { latitude: 45.5, longitude: -122.6, altitude: 50 },
    seasonDayOfYear: 340, // December
    initialHourUtc: 12.0,
    forcedEntities: {
      pressureSystems: [{
        id: 'SYS-ATM-RIVER-TROUGH',
        type: 'LOW_PRESSURE_CYCLONIC',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 47.0, longitude: -128.0, altitude: 0 },
        centralPressureHPa: 980.0,
        baselineAnomalyHPa: -32.0,
        radiusKm: 1100,
        movementSpeedKmh: 28.0,
        movementHeadingDeg: 75.0,
        maxSurfaceWindMS: 24.0,
        verticalMotionState: 'CONVERGENCE_LIFTING'
      }],
      fronts: [{
        id: 'FRONT-STATIONARY-MOISTURE',
        type: 'STATIONARY_FRONT',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 45.2, longitude: -123.0, altitude: 100 },
        headingDeg: 80.0,
        speedKmh: 4.0,
        lengthKm: 700,
        widthKm: 180,
        temperatureGradientCPer100Km: 4.0,
        pressureDeficitHPa: 14.0,
        humidityGradientPercentPer100Km: 15.0,
        precipitationRateMultiplier: 4.8,
        windShiftAngleDeg: 40.0
      }]
    }
  }
];
