/**
 * Project Earth: Phase 8 Dynamic Weather & Atmospheric Simulation Engine
 * Atmospheric Front Engine (Cold, Warm, Stationary, and Occluded Fronts)
 * 
 * Simulates:
 * - 2D/3D Frontal geometry and movement through the planetary coordinate space
 * - Frontal slope lifting (Cold front steep ~1:50 vs Warm front gentle ~1:200)
 * - Sharp temperature, dew point, and pressure discontinuities
 * - Wind directional veering / backing across frontal troughs
 * - Lifecycle: Frontogenesis -> Intensifying -> Mature -> Frontolysis
 */

import { WGS84GlobalCoord } from '../coordinates/globalCoordinateEngine';
import { WeatherFrontState, FrontType, StormLifecyclePhase } from './weatherTypes';

export class WeatherFrontEngine {
  private activeFronts: WeatherFrontState[] = [];

  constructor() {
    this.initializeDefaultFronts();
  }

  private initializeDefaultFronts(): void {
    // Seed an active synoptic cold front over North America / Atlantic
    this.activeFronts = [
      {
        id: 'FRONT-DEFAULT-COLD-01',
        type: 'COLD_FRONT',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 42.0, longitude: -85.0, altitude: 0 },
        headingDeg: 110.0, // Moving ESE
        speedKmh: 35.0,
        lengthKm: 1200.0,
        widthKm: 80.0,
        temperatureGradientCPer100Km: 9.0,
        pressureDeficitHPa: 6.5,
        humidityGradientPercentPer100Km: 30.0,
        precipitationRateMultiplier: 3.5,
        windShiftAngleDeg: 70.0,
        ageHours: 18.0,
        maxLifetimeHours: 72.0
      },
      {
        id: 'FRONT-DEFAULT-WARM-01',
        type: 'WARM_FRONT',
        lifecycle: 'MATURE',
        centerCoord: { latitude: 46.5, longitude: -78.0, altitude: 0 },
        headingDeg: 45.0, // Moving NE
        speedKmh: 20.0,
        lengthKm: 900.0,
        widthKm: 250.0,
        temperatureGradientCPer100Km: 5.0,
        pressureDeficitHPa: 4.0,
        humidityGradientPercentPer100Km: 20.0,
        precipitationRateMultiplier: 2.2,
        windShiftAngleDeg: 45.0,
        ageHours: 24.0,
        maxLifetimeHours: 96.0
      }
    ];
  }

  /**
   * Advances all active fronts by deltaSeconds
   */
  public update(deltaSeconds: number): void {
    const deltaHours = deltaSeconds / 3600.0;

    for (let i = this.activeFronts.length - 1; i >= 0; i--) {
      const front = this.activeFronts[i];
      front.ageHours += deltaHours;

      // Update lifecycle
      const progress = front.ageHours / front.maxLifetimeHours;
      if (progress < 0.15) {
        front.lifecycle = 'DEVELOPING';
      } else if (progress < 0.35) {
        front.lifecycle = 'INTENSIFYING';
      } else if (progress < 0.8) {
        front.lifecycle = 'MATURE';
      } else if (progress < 1.0) {
        front.lifecycle = 'DECAYING';
      } else {
        front.lifecycle = 'DISSIPATED';
        this.activeFronts.splice(i, 1);
        continue;
      }

      // Advect center coordinate along heading
      const distanceKm = front.speedKmh * deltaHours;
      const headingRad = (front.headingDeg * Math.PI) / 180.0;
      const latDelta = (distanceKm * Math.cos(headingRad)) / 111.32;
      const cosLat = Math.cos((front.centerCoord.latitude * Math.PI) / 180.0);
      const lonDelta = (distanceKm * Math.sin(headingRad)) / (111.32 * Math.max(0.01, cosLat));

      front.centerCoord.latitude += latDelta;
      front.centerCoord.longitude += lonDelta;

      // Wrap longitude
      if (front.centerCoord.longitude > 180) front.centerCoord.longitude -= 360;
      if (front.centerCoord.longitude < -180) front.centerCoord.longitude += 360;
    }
  }

  /**
   * Evaluates the influence of all active fronts on a target WGS84 coordinate
   */
  public sampleFrontsAt(coord: WGS84GlobalCoord): {
    overlappingFronts: WeatherFrontState[];
    temperatureDeltaC: number;
    dewPointDeltaC: number;
    pressureDeltaHPa: number;
    precipitationMultiplier: number;
    windVeeringAngleDeg: number;
    frontalLiftVerticalMS: number;
  } {
    const overlapping: WeatherFrontState[] = [];
    let totalTempDelta = 0;
    let totalDewPointDelta = 0;
    let totalPressureDelta = 0;
    let maxPrecipMultiplier = 1.0;
    let maxWindVeer = 0;
    let maxLiftVelocity = 0;

    for (const front of this.activeFronts) {
      const distanceKm = this.calculateDistanceToFrontLine(coord, front);
      
      // Check if coordinate is within the active frontal zone
      const halfWidth = front.widthKm / 2.0;
      if (distanceKm <= halfWidth) {
        overlapping.push(front);
        const intensity = 1.0 - (distanceKm / halfWidth);
        const signedDist = this.getSignedDistanceAcrossFront(coord, front);

        if (front.type === 'COLD_FRONT') {
          // Cold front: sharp cold drop behind the front (negative signed distance)
          if (signedDist < 0) {
            totalTempDelta -= (front.temperatureGradientCPer100Km * (Math.abs(signedDist) / 100.0) + 4.0) * intensity;
            totalDewPointDelta -= 5.0 * intensity;
          }
          totalPressureDelta -= front.pressureDeficitHPa * intensity;
          maxPrecipMultiplier = Math.max(maxPrecipMultiplier, front.precipitationRateMultiplier * intensity);
          maxWindVeer = Math.max(maxWindVeer, front.windShiftAngleDeg * intensity);
          maxLiftVelocity = Math.max(maxLiftVelocity, 2.5 * intensity); // Strong steep wedge lift
        } else if (front.type === 'WARM_FRONT') {
          // Warm front: steady warming, high humidity ahead of the front
          if (signedDist > 0) {
            totalTempDelta += 2.0 * intensity;
            totalDewPointDelta += 4.0 * intensity;
          }
          totalPressureDelta -= front.pressureDeficitHPa * intensity;
          maxPrecipMultiplier = Math.max(maxPrecipMultiplier, (front.precipitationRateMultiplier * 0.7) * intensity);
          maxWindVeer = Math.max(maxWindVeer, (front.windShiftAngleDeg * 0.6) * intensity);
          maxLiftVelocity = Math.max(maxLiftVelocity, 0.8 * intensity); // Gentle gliding lift
        } else if (front.type === 'OCCLUDED_FRONT') {
          totalTempDelta -= 3.0 * intensity;
          totalDewPointDelta += 2.0 * intensity;
          totalPressureDelta -= front.pressureDeficitHPa * 1.3 * intensity;
          maxPrecipMultiplier = Math.max(maxPrecipMultiplier, front.precipitationRateMultiplier * 1.2 * intensity);
          maxWindVeer = Math.max(maxWindVeer, front.windShiftAngleDeg * intensity);
          maxLiftVelocity = Math.max(maxLiftVelocity, 1.8 * intensity);
        } else {
          // Stationary
          totalPressureDelta -= front.pressureDeficitHPa * 0.8 * intensity;
          maxPrecipMultiplier = Math.max(maxPrecipMultiplier, front.precipitationRateMultiplier * intensity);
          maxLiftVelocity = Math.max(maxLiftVelocity, 1.0 * intensity);
        }
      }
    }

    return {
      overlappingFronts: overlapping,
      temperatureDeltaC: totalTempDelta,
      dewPointDeltaC: totalDewPointDelta,
      pressureDeltaHPa: totalPressureDelta,
      precipitationMultiplier: maxPrecipMultiplier,
      windVeeringAngleDeg: maxWindVeer,
      frontalLiftVerticalMS: maxLiftVelocity
    };
  }

  /**
   * Distance from a coordinate to the linear front segment
   */
  private calculateDistanceToFrontLine(coord: WGS84GlobalCoord, front: WeatherFrontState): number {
    // Front orientation is perpendicular to its movement heading
    const frontOrientationDeg = (front.headingDeg + 90.0) % 360.0;
    const halfLen = front.lengthKm / 2.0;

    // Approximate planar coordinate distance around center
    const dLat = (coord.latitude - front.centerCoord.latitude) * 111.32;
    const cosLat = Math.cos((front.centerCoord.latitude * Math.PI) / 180.0);
    const dLon = (coord.longitude - front.centerCoord.longitude) * 111.32 * cosLat;

    const angleRad = (frontOrientationDeg * Math.PI) / 180.0;
    const alongFront = dLat * Math.cos(angleRad) + dLon * Math.sin(angleRad);
    const acrossFront = -dLat * Math.sin(angleRad) + dLon * Math.cos(angleRad);

    if (Math.abs(alongFront) > halfLen) {
      const extraAlong = Math.abs(alongFront) - halfLen;
      return Math.sqrt(acrossFront * acrossFront + extraAlong * extraAlong);
    }

    return Math.abs(acrossFront);
  }

  /**
   * Returns positive if ahead of front (in warm sector), negative if behind front (in cold sector)
   */
  private getSignedDistanceAcrossFront(coord: WGS84GlobalCoord, front: WeatherFrontState): number {
    const headingRad = (front.headingDeg * Math.PI) / 180.0;
    const dLat = (coord.latitude - front.centerCoord.latitude) * 111.32;
    const cosLat = Math.cos((front.centerCoord.latitude * Math.PI) / 180.0);
    const dLon = (coord.longitude - front.centerCoord.longitude) * 111.32 * cosLat;

    // Dot product with heading direction vector
    return dLat * Math.cos(headingRad) + dLon * Math.sin(headingRad);
  }

  public getActiveFronts(): WeatherFrontState[] {
    return this.activeFronts;
  }

  public addFront(front: WeatherFrontState): void {
    this.activeFronts.push(front);
  }

  public clearFronts(): void {
    this.activeFronts = [];
  }
}
