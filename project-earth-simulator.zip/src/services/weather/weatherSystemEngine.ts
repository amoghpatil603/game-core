/**
 * Project Earth: Phase 8 Dynamic Weather & Atmospheric Simulation Engine
 * Synoptic Pressure Systems, Convective Thunderstorms, Tropical Cyclones, Tornadoes & Thermal Anomalies
 * 
 * Simulates:
 * - High and Low pressure systems with barometric gradients and cyclonic/anticyclonic wind circulation
 * - Convective thunderstorms, supercells, hail, microbursts, and lightning bus
 * - Dependent tornado vortices governed by parent storm rotation
 * - Tropical cyclone eyewall mechanics, Saffir-Simpson scaling, and storm surge integration
 * - Persistent heat dome and polar vortex cold wave events
 */

import { WGS84GlobalCoord } from '../coordinates/globalCoordinateEngine';
import { ATMOSPHERIC_CONSTANTS } from './weatherDataset';
import {
  PressureSystemEntity,
  ThunderstormEntity,
  TornadoEntity,
  TropicalCycloneEntity,
  ThermalAnomalyEvent,
  LightningStrikeEvent,
  StormLifecyclePhase,
  TropicalCycloneCategory
} from './weatherTypes';

export class WeatherSystemEngine {
  private pressureSystems: PressureSystemEntity[] = [];
  private thunderstorms: ThunderstormEntity[] = [];
  private tornadoes: TornadoEntity[] = [];
  private cyclones: TropicalCycloneEntity[] = [];
  private thermalAnomalies: ThermalAnomalyEvent[] = [];
  private lightningEvents: LightningStrikeEvent[] = [];

  constructor() {
    this.initializeDefaultSystems();
  }

  private initializeDefaultSystems(): void {
    // 1. Great Plains Subtropical High (Bermuda High ridge extension)
    this.pressureSystems.push({
      id: 'SYS-HIGH-DEFAULT-01',
      type: 'HIGH_PRESSURE_ANTICYCLONE',
      lifecycle: 'MATURE',
      centerCoord: { latitude: 35.0, longitude: -70.0, altitude: 0 },
      centralPressureHPa: 1026.0,
      baselineAnomalyHPa: 12.0,
      radiusKm: 1100,
      movementSpeedKmh: 14.0,
      movementHeadingDeg: 80.0,
      maxSurfaceWindMS: 8.0,
      verticalMotionState: 'SUBSIDENCE_CLEARING',
      ageHours: 48,
      maxLifetimeHours: 168
    });

    // 2. Aleutian / Gulf of Alaska Synoptic Low
    this.pressureSystems.push({
      id: 'SYS-LOW-DEFAULT-01',
      type: 'LOW_PRESSURE_CYCLONIC',
      lifecycle: 'MATURE',
      centerCoord: { latitude: 54.0, longitude: -145.0, altitude: 0 },
      centralPressureHPa: 984.0,
      baselineAnomalyHPa: -28.0,
      radiusKm: 950,
      movementSpeedKmh: 32.0,
      movementHeadingDeg: 95.0,
      maxSurfaceWindMS: 24.0,
      verticalMotionState: 'CONVERGENCE_LIFTING',
      ageHours: 36,
      maxLifetimeHours: 120
    });

    // 3. Moderate Convective Cell
    this.thunderstorms.push({
      id: 'STORM-CELL-DEFAULT-01',
      lifecycle: 'INTENSIFYING',
      centerCoord: { latitude: 33.5, longitude: -86.5, altitude: 200 },
      diameterKm: 18.0,
      cloudTopAltitudeMeters: 12500,
      capeJkg: 2200,
      updraftVelocityMS: 28.0,
      downdraftVelocityMS: 14.0,
      peakPrecipitationRateMmH: 45.0,
      hasHail: true,
      hailDiameterMm: 18,
      lightningFlashRatePerMin: 22,
      microburstWindGustMS: 21.0,
      tornadoProbabilityPercent: 12.0,
      ageMinutes: 25,
      maxLifetimeMinutes: 90
    });
  }

  /**
   * Advances synoptic systems, convective cells, cyclones, tornadoes, and thermal anomalies
   */
  public update(deltaSeconds: number, simulationHourUtc: number): void {
    const deltaHours = deltaSeconds / 3600.0;
    const deltaMinutes = deltaSeconds / 60.0;

    // 1. Advance Pressure Systems
    for (let i = this.pressureSystems.length - 1; i >= 0; i--) {
      const sys = this.pressureSystems[i];
      sys.ageHours += deltaHours;
      const progress = sys.ageHours / sys.maxLifetimeHours;

      if (progress >= 1.0) {
        this.pressureSystems.splice(i, 1);
        continue;
      }

      sys.lifecycle = progress < 0.2 ? 'DEVELOPING' : progress < 0.4 ? 'INTENSIFYING' : progress < 0.8 ? 'MATURE' : 'DECAYING';

      // Move system center
      const distKm = sys.movementSpeedKmh * deltaHours;
      const headingRad = (sys.movementHeadingDeg * Math.PI) / 180.0;
      const latDelta = (distKm * Math.cos(headingRad)) / 111.32;
      const cosLat = Math.cos((sys.centerCoord.latitude * Math.PI) / 180.0);
      const lonDelta = (distKm * Math.sin(headingRad)) / (111.32 * Math.max(0.01, cosLat));

      sys.centerCoord.latitude += latDelta;
      sys.centerCoord.longitude += lonDelta;
      if (sys.centerCoord.longitude > 180) sys.centerCoord.longitude -= 360;
      if (sys.centerCoord.longitude < -180) sys.centerCoord.longitude += 360;
    }

    // 2. Advance Thunderstorms
    for (let i = this.thunderstorms.length - 1; i >= 0; i--) {
      const storm = this.thunderstorms[i];
      storm.ageMinutes += deltaMinutes;
      const progress = storm.ageMinutes / storm.maxLifetimeMinutes;

      if (progress >= 1.0) {
        // Remove storm and any attached tornadoes
        this.tornadoes = this.tornadoes.filter(t => t.parentStormId !== storm.id);
        this.thunderstorms.splice(i, 1);
        continue;
      }

      storm.lifecycle = progress < 0.25 ? 'DEVELOPING' : progress < 0.5 ? 'INTENSIFYING' : progress < 0.8 ? 'MATURE' : 'DECAYING';

      // Generate simulation lightning events during mature storm phase
      if (storm.lifecycle === 'MATURE' && Math.random() < (storm.lightningFlashRatePerMin / 60.0) * (deltaSeconds / 10.0)) {
        this.emitLightning(storm);
      }
    }

    // 3. Advance Tornadoes (Linked to parent storms)
    for (let i = this.tornadoes.length - 1; i >= 0; i--) {
      const tor = this.tornadoes[i];
      tor.ageMinutes += deltaMinutes;
      if (tor.ageMinutes >= tor.durationMinutes) {
        this.tornadoes.splice(i, 1);
        continue;
      }

      // Advect tornado along forward track
      const distKm = (tor.forwardSpeedKmh * (deltaSeconds / 3600.0));
      const rad = (tor.trackHeadingDeg * Math.PI) / 180.0;
      tor.centerCoord.latitude += (distKm * Math.cos(rad)) / 111.32;
      const cosLat = Math.cos((tor.centerCoord.latitude * Math.PI) / 180.0);
      tor.centerCoord.longitude += (distKm * Math.sin(rad)) / (111.32 * Math.max(0.01, cosLat));
    }

    // 4. Advance Tropical Cyclones
    for (let i = this.cyclones.length - 1; i >= 0; i--) {
      const cyc = this.cyclones[i];
      cyc.ageHours += deltaHours;

      // Advect along track
      const distKm = cyc.forwardSpeedKmh * deltaHours;
      const headingRad = (cyc.trackHeadingDeg * Math.PI) / 180.0;
      const latDelta = (distKm * Math.cos(headingRad)) / 111.32;
      const cosLat = Math.cos((cyc.centerCoord.latitude * Math.PI) / 180.0);
      const lonDelta = (distKm * Math.sin(headingRad)) / (111.32 * Math.max(0.01, cosLat));

      cyc.centerCoord.latitude += latDelta;
      cyc.centerCoord.longitude += lonDelta;

      // Log historical track points periodically
      if (cyc.historicalTrack.length === 0 || (cyc.ageHours - cyc.historicalTrack[cyc.historicalTrack.length - 1].timeHours) >= 3.0) {
        cyc.historicalTrack.push({
          coord: { ...cyc.centerCoord },
          timeHours: cyc.ageHours,
          pressureHPa: cyc.centralPressureHPa,
          windMS: cyc.maxSustainedWindMS
        });
      }

      // Saffir-Simpson intensity calculation based on central pressure
      this.recomputeCycloneIntensity(cyc);
    }

    // 5. Advance Thermal Anomalies
    for (let i = this.thermalAnomalies.length - 1; i >= 0; i--) {
      const anom = this.thermalAnomalies[i];
      anom.ageDays += deltaHours / 24.0;
      if (anom.ageDays >= anom.durationDays) {
        this.thermalAnomalies.splice(i, 1);
      }
    }

    // Clean up lightning strikes older than 30 seconds
    const now = Date.now();
    this.lightningEvents = this.lightningEvents.filter(e => (now - e.timestampMs) < 30000);
  }

  /**
   * Evaluates synoptic pressure deficit / surplus and horizontal gradient at a given point
   */
  public samplePressureFieldAt(coord: WGS84GlobalCoord): {
    totalAnomalyHPa: number;
    gradientVectorU: number; // West-to-East pressure gradient
    gradientVectorV: number; // South-to-North pressure gradient
    inducedWindU: number;    // Zonal wind perturbation
    inducedWindV: number;    // Meridional wind perturbation
    verticalMotionState: 'SUBSIDENCE_CLEARING' | 'CONVERGENCE_LIFTING' | 'NEUTRAL';
  } {
    let totalAnomaly = 0;
    let gradU = 0;
    let gradV = 0;
    let windU = 0;
    let windV = 0;
    let dominantVertical: 'SUBSIDENCE_CLEARING' | 'CONVERGENCE_LIFTING' | 'NEUTRAL' = 'NEUTRAL';

    const lat = coord.latitude;
    const coriolisF = 2.0 * ATMOSPHERIC_CONSTANTS.EARTH_ROTATION_RATE_OMEGA * Math.sin((lat * Math.PI) / 180.0);
    const airDensity = 1.225; // kg/m^3

    // 1. Sample Pressure Systems
    for (const sys of this.pressureSystems) {
      const distKm = this.getApproxDistanceKm(coord, sys.centerCoord);
      if (distKm < sys.radiusKm) {
        const normDist = distKm / sys.radiusKm;
        // Bell-curve anomaly distribution
        const weight = Math.exp(-2.5 * normDist * normDist);
        const anomaly = sys.baselineAnomalyHPa * weight;
        totalAnomaly += anomaly;

        if (Math.abs(anomaly) > 4.0) {
          dominantVertical = sys.verticalMotionState;
        }

        // Compute vector from system center to point
        const dLat = (coord.latitude - sys.centerCoord.latitude) * 111.32;
        const cosLat = Math.cos((coord.latitude * Math.PI) / 180.0);
        const dLon = (coord.longitude - sys.centerCoord.longitude) * 111.32 * cosLat;
        const r = Math.max(10.0, distKm);

        // Radial pressure gradient: dP/dr
        const dPdr = (-5.0 * normDist / sys.radiusKm) * anomaly; // hPa / km
        const dPdrPaPerM = (dPdr * 100.0) / 1000.0; // Pa / m

        const cosTheta = dLon / r;
        const sinTheta = dLat / r;

        gradU += dPdrPaPerM * cosTheta;
        gradV += dPdrPaPerM * sinTheta;

        // Geostrophic wind approximation: Vg = (1 / (rho * f)) * (k x grad P)
        // With boundary layer surface friction deflection (Ekman angle ~20°)
        if (Math.abs(coriolisF) > 1e-6) {
          const vgMagnitude = Math.min(sys.maxSurfaceWindMS, Math.abs(dPdrPaPerM) / (airDensity * Math.abs(coriolisF)));
          const hemisphereSign = lat >= 0 ? 1 : -1;
          const circulationDirection = (sys.baselineAnomalyHPa < 0 ? 1 : -1) * hemisphereSign;

          // Tangential unit vector around center
          const tangU = -sinTheta * circulationDirection;
          const tangV = cosTheta * circulationDirection;

          // Ekman angle deflection towards low / away from high (inward angle ~22°)
          const ekmanRad = (22.0 * Math.PI) / 180.0 * (sys.baselineAnomalyHPa < 0 ? 1 : -1);
          const deflU = tangU * Math.cos(ekmanRad) - tangV * Math.sin(ekmanRad);
          const deflV = tangU * Math.sin(ekmanRad) + tangV * Math.cos(ekmanRad);

          windU += deflU * vgMagnitude * weight;
          windV += deflV * vgMagnitude * weight;
        }
      }
    }

    // 2. Sample Tropical Cyclones (Intense Holland pressure profile)
    for (const cyc of this.cyclones) {
      const distKm = this.getApproxDistanceKm(coord, cyc.centerCoord);
      if (distKm < cyc.radiusOfGaleWindsKm) {
        const r = Math.max(1.0, distKm);
        const rm = cyc.radiusOfMaximumWindsKm;
        const pDrop = (1013.25 - cyc.centralPressureHPa);
        
        // Holland B parameter approximation (~1.3)
        const B = 1.35;
        const hollandFactor = Math.pow(rm / r, B);
        const anomaly = -pDrop * Math.exp(-hollandFactor);
        totalAnomaly += anomaly;
        dominantVertical = 'CONVERGENCE_LIFTING';

        // Holland wind profile: V(r) = sqrt((B * (rm/r)^B * pDrop * exp(-(rm/r)^B)) / rho + (r*f/2)^2) - (r*f/2)
        const vTangential = Math.min(cyc.peakWindGustMS, 
          Math.sqrt(Math.max(0, (B * hollandFactor * (pDrop * 100.0) * Math.exp(-hollandFactor)) / airDensity))
        );

        const dLat = (coord.latitude - cyc.centerCoord.latitude) * 111.32;
        const cosLat = Math.cos((coord.latitude * Math.PI) / 180.0);
        const dLon = (coord.longitude - cyc.centerCoord.longitude) * 111.32 * cosLat;
        const sinTheta = dLat / r;
        const cosTheta = dLon / r;

        // Cyclonic rotation: Counterclockwise in NH (+1), Clockwise in SH (-1)
        const hemiSign = lat >= 0 ? 1 : -1;
        const tangU = -sinTheta * hemiSign;
        const tangV = cosTheta * hemiSign;

        // High inflow angle near eyewall (~25°)
        const inflowRad = (25.0 * Math.PI) / 180.0;
        windU += (tangU * Math.cos(inflowRad) - tangV * Math.sin(inflowRad)) * vTangential;
        windV += (tangU * Math.sin(inflowRad) + tangV * Math.cos(inflowRad)) * vTangential;
      }
    }

    return {
      totalAnomalyHPa: totalAnomaly,
      gradientVectorU: gradU,
      gradientVectorV: gradV,
      inducedWindU: windU,
      inducedWindV: windV,
      verticalMotionState: dominantVertical
    };
  }

  /**
   * Evaluates active convective storms, supercells, microbursts, and tornadoes at target point
   */
  public sampleConvectionAt(coord: WGS84GlobalCoord): {
    overlappingStorms: ThunderstormEntity[];
    overlappingTornadoes: TornadoEntity[];
    maxConvectivePrecipMmH: number;
    maxMicroburstGustMS: number;
    hasHail: boolean;
    maxHailSizeMm: number;
    tornadoPresent: boolean;
    convectiveCloudFraction: number;
  } {
    const overlapping: ThunderstormEntity[] = [];
    const activeTors: TornadoEntity[] = [];
    let maxPrecip = 0;
    let maxGust = 0;
    let hailPresent = false;
    let maxHail = 0;
    let tornadoActive = false;
    let convectiveClouds = 0;

    for (const storm of this.thunderstorms) {
      const distKm = this.getApproxDistanceKm(coord, storm.centerCoord);
      const stormRadius = storm.diameterKm / 2.0;

      if (distKm < stormRadius * 1.5) {
        convectiveClouds = Math.max(convectiveClouds, 0.95);
      }

      if (distKm <= stormRadius) {
        overlapping.push(storm);
        const intensity = 1.0 - (distKm / stormRadius);
        maxPrecip = Math.max(maxPrecip, storm.peakPrecipitationRateMmH * intensity);
        maxGust = Math.max(maxGust, storm.microburstWindGustMS * intensity);
        if (storm.hasHail && intensity > 0.4) {
          hailPresent = true;
          maxHail = Math.max(maxHail, storm.hailDiameterMm * intensity);
        }
      }
    }

    for (const tor of this.tornadoes) {
      const distMeters = this.getApproxDistanceKm(coord, tor.centerCoord) * 1000.0;
      if (distMeters <= tor.pathWidthMeters) {
        activeTors.push(tor);
        tornadoActive = true;
        maxGust = Math.max(maxGust, (tor.peakWindSpeedKmh / 3.6));
      }
    }

    return {
      overlappingStorms: overlapping,
      overlappingTornadoes: activeTors,
      maxConvectivePrecipMmH: maxPrecip,
      maxMicroburstGustMS: maxGust,
      hasHail: hailPresent,
      maxHailSizeMm: maxHail,
      tornadoPresent: tornadoActive,
      convectiveCloudFraction: convectiveClouds
    };
  }

  /**
   * Evaluates persistent heat and cold anomalies
   */
  public sampleThermalAnomaliesAt(coord: WGS84GlobalCoord): {
    temperatureAnomalyC: number;
    humidityAnomalyPercent: number;
    activeEvent?: ThermalAnomalyEvent;
  } {
    let tempDelta = 0;
    let humDelta = 0;
    let primaryEvent: ThermalAnomalyEvent | undefined;

    for (const anom of this.thermalAnomalies) {
      const distKm = this.getApproxDistanceKm(coord, anom.centerCoord);
      if (distKm <= anom.radiusKm) {
        const weight = Math.cos((distKm / anom.radiusKm) * (Math.PI / 2.0));
        tempDelta += anom.temperatureAnomalyC * weight;
        humDelta += anom.relativeHumidityAnomalyPercent * weight;
        if (!primaryEvent || Math.abs(anom.temperatureAnomalyC) > Math.abs(primaryEvent.temperatureAnomalyC)) {
          primaryEvent = anom;
        }
      }
    }

    return {
      temperatureAnomalyC: tempDelta,
      humidityAnomalyPercent: humDelta,
      activeEvent: primaryEvent
    };
  }

  private recomputeCycloneIntensity(cyc: TropicalCycloneEntity): void {
    const p = cyc.centralPressureHPa;
    if (p > 1000) {
      cyc.category = 'TROPICAL_DEPRESSION';
      cyc.maxSustainedWindMS = 15.0;
    } else if (p > 985) {
      cyc.category = 'TROPICAL_STORM';
      cyc.maxSustainedWindMS = 26.0;
    } else if (p > 970) {
      cyc.category = 'CATEGORY_1';
      cyc.maxSustainedWindMS = 35.0;
    } else if (p > 955) {
      cyc.category = 'CATEGORY_2';
      cyc.maxSustainedWindMS = 46.0;
    } else if (p > 940) {
      cyc.category = 'CATEGORY_3';
      cyc.maxSustainedWindMS = 55.0;
    } else if (p > 920) {
      cyc.category = 'CATEGORY_4';
      cyc.maxSustainedWindMS = 65.0;
    } else {
      cyc.category = 'CATEGORY_5';
      cyc.maxSustainedWindMS = 75.0;
    }

    cyc.peakWindGustMS = cyc.maxSustainedWindMS * 1.25;
    // Storm surge estimation: ~1m surge per 10 hPa pressure drop below 1013 hPa + wind setup
    const deltaP = Math.max(0, 1013.25 - p);
    cyc.stormSurgeHeightEstimateMeters = (deltaP * 0.08) + (cyc.maxSustainedWindMS * 0.04);
  }

  private emitLightning(storm: ThunderstormEntity): void {
    const radiusKm = (storm.diameterKm / 2.0) * Math.random();
    const angleRad = Math.random() * 2.0 * Math.PI;
    const latDelta = (radiusKm * Math.cos(angleRad)) / 111.32;
    const cosLat = Math.cos((storm.centerCoord.latitude * Math.PI) / 180.0);
    const lonDelta = (radiusKm * Math.sin(angleRad)) / (111.32 * Math.max(0.01, cosLat));

    const strike: LightningStrikeEvent = {
      id: `LIGHTNING-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestampMs: Date.now(),
      coord: {
        latitude: storm.centerCoord.latitude + latDelta,
        longitude: storm.centerCoord.longitude + lonDelta,
        altitude: storm.centerCoord.altitude
      },
      peakCurrentKA: 15.0 + Math.random() * 65.0, // 15 to 80 kA
      isCloudToGround: Math.random() > 0.35,
      thunderAudibleRadiusKm: 16.0
    };

    this.lightningEvents.push(strike);
  }

  private getApproxDistanceKm(c1: WGS84GlobalCoord, c2: WGS84GlobalCoord): number {
    const dLat = (c1.latitude - c2.latitude) * 111.32;
    const cosLat = Math.cos(((c1.latitude + c2.latitude) / 2.0 * Math.PI) / 180.0);
    const dLon = (c1.longitude - c2.longitude) * 111.32 * cosLat;
    return Math.sqrt(dLat * dLat + dLon * dLon);
  }

  // Accessors & Mutators
  public getPressureSystems(): PressureSystemEntity[] { return this.pressureSystems; }
  public getThunderstorms(): ThunderstormEntity[] { return this.thunderstorms; }
  public getTornadoes(): TornadoEntity[] { return this.tornadoes; }
  public getCyclones(): TropicalCycloneEntity[] { return this.cyclones; }
  public getThermalAnomalies(): ThermalAnomalyEvent[] { return this.thermalAnomalies; }
  public getRecentLightning(): LightningStrikeEvent[] { return this.lightningEvents; }

  public addPressureSystem(sys: PressureSystemEntity): void { this.pressureSystems.push(sys); }
  public addThunderstorm(storm: ThunderstormEntity): void { this.thunderstorms.push(storm); }
  public addTornado(tor: TornadoEntity): void { this.tornadoes.push(tor); }
  public addCyclone(cyc: TropicalCycloneEntity): void { this.cyclones.push(cyc); }
  public addThermalAnomaly(anom: ThermalAnomalyEvent): void { this.thermalAnomalies.push(anom); }

  public clearAll(): void {
    this.pressureSystems = [];
    this.thunderstorms = [];
    this.tornadoes = [];
    this.cyclones = [];
    this.thermalAnomalies = [];
    this.lightningEvents = [];
  }
}
