/**
 * Project Earth: Phase 8 Dynamic Weather & Atmospheric Simulation Engine
 * Core TypeScript Definitions and Architectural Interfaces
 * 
 * Strict architectural separation:
 * - Simulation Layer (physics, state evolution, fronts, cyclones, convection, thermodynamic balance)
 * - Rendering Layer (visual representations, particle counts, sky shaders, audio hooks)
 * - Cross-Phase Planetary Coupling (Climate -> Weather -> Hydrology -> Ocean -> Terrain)
 * - Future NPC Perception & Phase 9 Ecosystem Contract Interfaces
 */

import { WGS84GlobalCoord } from '../coordinates/globalCoordinateEngine';
import { KoppenClimateCode, SolarForcingState } from '../climate/climateTypes';

export type WeatherDataClassification = 
  | 'REAL_OBSERVATION'
  | 'REANALYSIS'
  | 'MODEL_DERIVED'
  | 'APPROXIMATION'
  | 'SYNTHETIC_TEST_FIXTURE';

export type PrecipitationType = 
  | 'NONE'
  | 'DRIZZLE'
  | 'RAIN'
  | 'HEAVY_RAIN'
  | 'SNOW'
  | 'HEAVY_SNOW'
  | 'SLEET'
  | 'FREEZING_RAIN'
  | 'HAIL';

export type CloudCoverageType = 
  | 'CLEAR'       // 0 - 10%
  | 'FEW'         // 10 - 25%
  | 'SCATTERED'   // 25 - 50%
  | 'BROKEN'      // 50 - 85%
  | 'OVERCAST';   // 85 - 100%

export type CloudGenus = 
  | 'CIRRUS'
  | 'CIRROSTRATUS'
  | 'CIRROCUMULUS'
  | 'ALTOSTRATUS'
  | 'ALTOCUMULUS'
  | 'STRATUS'
  | 'STRATOCUMULUS'
  | 'CUMULUS'
  | 'CUMULONIMBUS'
  | 'NIMBOSTRATUS';

export type FrontType = 
  | 'COLD_FRONT'
  | 'WARM_FRONT'
  | 'STATIONARY_FRONT'
  | 'OCCLUDED_FRONT';

export type PressureSystemType = 
  | 'HIGH_PRESSURE_ANTICYCLONE'
  | 'LOW_PRESSURE_CYCLONIC'
  | 'TROPICAL_CYCLONE'
  | 'THERMAL_LOW'
  | 'CUTOFF_LOW';

export type TropicalCycloneCategory = 
  | 'TROPICAL_DISTURBANCE'
  | 'TROPICAL_DEPRESSION'
  | 'TROPICAL_STORM'
  | 'CATEGORY_1'
  | 'CATEGORY_2'
  | 'CATEGORY_3'
  | 'CATEGORY_4'
  | 'CATEGORY_5'
  | 'EXTRATROPICAL_TRANSITION'
  | 'DISSIPATING';

export type FogType = 
  | 'NONE'
  | 'RADIATION_FOG'
  | 'ADVECTION_FOG'
  | 'VALLEY_FOG'
  | 'COASTAL_FOG'
  | 'PRECIPITATION_FOG';

export type StormLifecyclePhase = 
  | 'DEVELOPING'
  | 'INTENSIFYING'
  | 'MATURE'
  | 'DECAYING'
  | 'DISSIPATED';

/**
 * Vertical atmospheric layers (simplified 4-tier column model)
 */
export interface AtmosphericLayerState {
  layerName: 'SURFACE' | 'BOUNDARY_LAYER' | 'LOWER_TROPOSPHERE' | 'UPPER_TROPOSPHERE';
  altitudeMeters: number;
  pressureHPa: number;
  temperatureC: number;
  dewPointC: number;
  relativeHumidityPercent: number;
  windSpeedMS: number;
  windDirectionDeg: number;
  verticalVelocityMS: number; // Positive = updraft, Negative = subsidence
}

/**
 * 3D Atmospheric column soundings (Skew-T log-P proxy)
 */
export interface AtmosphericColumnProfile {
  surfacePressureHPa: number;
  surfaceTempC: number;
  surfaceDewPointC: number;
  liftingCondensationLevelM: number; // LCL
  levelOfFreeConvectionM: number;    // LFC
  equilibriumLevelM: number;          // EL
  capeJkg: number;                    // Convective Available Potential Energy
  cinJkg: number;                     // Convective Inhibition
  kIndex: number;                     // Thunderstorm potential
  liftedIndexC: number;
  layers: AtmosphericLayerState[];
}

/**
 * Moving Atmospheric Front Entity
 */
export interface WeatherFrontState {
  id: string;
  type: FrontType;
  lifecycle: StormLifecyclePhase;
  centerCoord: WGS84GlobalCoord;
  headingDeg: number;
  speedKmh: number;
  lengthKm: number;
  widthKm: number;
  temperatureGradientCPer100Km: number;
  pressureDeficitHPa: number;
  humidityGradientPercentPer100Km: number;
  precipitationRateMultiplier: number;
  windShiftAngleDeg: number;
  ageHours: number;
  maxLifetimeHours: number;
}

/**
 * Synoptic Scale High / Low Pressure System
 */
export interface PressureSystemEntity {
  id: string;
  type: PressureSystemType;
  lifecycle: StormLifecyclePhase;
  centerCoord: WGS84GlobalCoord;
  centralPressureHPa: number;
  baselineAnomalyHPa: number; // Difference from Phase 7 baseline pressure
  radiusKm: number;
  movementSpeedKmh: number;
  movementHeadingDeg: number;
  maxSurfaceWindMS: number;
  verticalMotionState: 'SUBSIDENCE_CLEARING' | 'CONVERGENCE_LIFTING' | 'NEUTRAL';
  ageHours: number;
  maxLifetimeHours: number;
}

/**
 * Convective Thunderstorm & Supercell Entity
 */
export interface ThunderstormEntity {
  id: string;
  lifecycle: StormLifecyclePhase;
  centerCoord: WGS84GlobalCoord;
  diameterKm: number;
  cloudTopAltitudeMeters: number;
  capeJkg: number;
  updraftVelocityMS: number;
  downdraftVelocityMS: number;
  peakPrecipitationRateMmH: number;
  hasHail: boolean;
  hailDiameterMm: number;
  lightningFlashRatePerMin: number;
  microburstWindGustMS: number;
  tornadoProbabilityPercent: number;
  ageMinutes: number;
  maxLifetimeMinutes: number;
}

/**
 * Lightning Strike Event (Simulation Event Bus)
 */
export interface LightningStrikeEvent {
  id: string;
  timestampMs: number;
  coord: WGS84GlobalCoord;
  peakCurrentKA: number;
  isCloudToGround: boolean;
  thunderAudibleRadiusKm: number;
}

/**
 * Tornado Vortex Structure (Parent storm dependent)
 */
export interface TornadoEntity {
  id: string;
  parentStormId: string;
  lifecycle: StormLifecyclePhase;
  centerCoord: WGS84GlobalCoord;
  enhancedFujitaRating: 'EF0' | 'EF1' | 'EF2' | 'EF3' | 'EF4' | 'EF5';
  pathWidthMeters: number;
  peakWindSpeedKmh: number;
  vortexRadiusMeters: number;
  trackHeadingDeg: number;
  forwardSpeedKmh: number;
  durationMinutes: number;
  ageMinutes: number;
}

/**
 * Tropical Cyclone / Hurricane Entity
 */
export interface TropicalCycloneEntity {
  id: string;
  name: string;
  category: TropicalCycloneCategory;
  lifecycle: StormLifecyclePhase;
  centerCoord: WGS84GlobalCoord;
  centralPressureHPa: number;
  eyeRadiusKm: number;
  radiusOfMaximumWindsKm: number;
  radiusOfGaleWindsKm: number; // 34-knot wind radius
  maxSustainedWindMS: number;
  peakWindGustMS: number;
  forwardSpeedKmh: number;
  trackHeadingDeg: number;
  oceanSstAtCenterC: number;
  stormSurgeHeightEstimateMeters: number;
  historicalTrack: { coord: WGS84GlobalCoord; timeHours: number; pressureHPa: number; windMS: number }[];
  ageHours: number;
}

/**
 * Thermal Anomalies (Heat Waves / Cold Waves)
 */
export interface ThermalAnomalyEvent {
  id: string;
  type: 'HEAT_WAVE' | 'COLD_WAVE';
  lifecycle: StormLifecyclePhase;
  centerCoord: WGS84GlobalCoord;
  radiusKm: number;
  temperatureAnomalyC: number;
  relativeHumidityAnomalyPercent: number;
  durationDays: number;
  ageDays: number;
  heatIndexC?: number;
  windChillC?: number;
}

/**
 * Unified Instantaneous Weather State at any WGS84 point
 */
export interface WeatherState {
  timestampMs: number;
  simulationDay: number;
  simulationHourUtc: number;
  coord: WGS84GlobalCoord;
  
  // Phase 7 Climate Baselines for this coordinate & time
  climateBaseline: {
    meanMonthlyTempC: number;
    baselinePressureHPa: number;
    baselineHumidityPercent: number;
    baselinePrecipMmH: number;
    baselineWindSpeedMS: number;
    baselineWindDirectionDeg: number;
    koppenCode: KoppenClimateCode;
  };

  // Instantaneous Thermal & Barometric State
  temperatureC: number;
  apparentTemperatureC: number; // Heat Index or Wind Chill
  dewPointC: number;
  relativeHumidityPercent: number;
  surfacePressureHPa: number;
  seaLevelPressureHPa: number;
  pressureTendencyHPaPer3Hours: number; // Rising, falling, steady barometric trend

  // Instantaneous Wind Field
  windSpeedMS: number;
  windDirectionDeg: number;
  windGustMS: number;
  coriolisFactorF: number; // f = 2*omega*sin(phi)
  boundaryLayerFrictionDamping: number;

  // Clouds & Visibility
  cloudFraction: number; // 0.0 to 1.0
  cloudCoverageType: CloudCoverageType;
  dominantCloudGenus: CloudGenus;
  cloudBaseAltitudeM: number;
  cloudTopAltitudeM: number;
  fogType: FogType;
  visibilityMeters: number;
  horizontalObstruction: 'NONE' | 'FOG' | 'HEAVY_RAIN' | 'HEAVY_SNOW' | 'HAZE' | 'DUST';

  // Precipitation & Convection
  precipitationRateMmH: number;
  precipitationType: PrecipitationType;
  isConvectivePrecipitation: boolean;
  orographicLiftMultiplier: number;
  groundWetnessIndex: number; // 0.0 dry to 1.0 saturated
  freshSnowAccumulationCm: number;

  // Active Atmospheric Entities overlapping this coordinate
  activeFronts: WeatherFrontState[];
  activePressureSystems: PressureSystemEntity[];
  activeThunderstorms: ThunderstormEntity[];
  activeCyclone?: TropicalCycloneEntity;
  activeThermalAnomaly?: ThermalAnomalyEvent;

  // Solar & Radiative flux
  solarInsolationWm2: number;
  uvIndex: number;

  // Atmospheric Stability & Sounding
  sounding: AtmosphericColumnProfile;
}

/**
 * Short-term weather forecast prediction interface
 */
export interface WeatherForecastWindow {
  forecastHourOffset: number;
  temperatureC: number;
  precipitationProbabilityPercent: number;
  precipitationRateMmH: number;
  precipitationType: PrecipitationType;
  windSpeedMS: number;
  windDirectionDeg: number;
  cloudFraction: number;
  confidenceScore: number; // 0.0 to 1.0 (decays over time)
}

export interface WeatherForecastResult {
  generatedAtTimestampMs: number;
  coord: WGS84GlobalCoord;
  currentWeather: WeatherState;
  hourlyForecast: WeatherForecastWindow[]; // +1h to +48h
  dailyForecast: {
    dayOffset: number;
    minTempC: number;
    maxTempC: number;
    dominantWeather: PrecipitationType;
    totalPrecipitationMm: number;
    confidenceScore: number;
  }[];
  synopticThreats: string[];
}

/**
 * Developer Test Scenario Configuration
 */
export interface WeatherScenarioConfig {
  id: string;
  name: string;
  description: string;
  category: 'BENCHMARK' | 'EXTREME_STORM' | 'LOCAL_PHENOMENON' | 'SYNTHETIC_STRESS';
  targetCoord: WGS84GlobalCoord;
  seasonDayOfYear: number;
  initialHourUtc: number;
  forcedEntities: {
    fronts?: Partial<WeatherFrontState>[];
    pressureSystems?: Partial<PressureSystemEntity>[];
    thunderstorms?: Partial<ThunderstormEntity>[];
    cyclones?: Partial<TropicalCycloneEntity>[];
    thermalAnomalies?: Partial<ThermalAnomalyEvent>[];
  };
}

/**
 * Planetary Weather Coupling Outputs (To Hydrology & Ocean)
 */
export interface WeatherToHydrologyCouplingPayload {
  coord: WGS84GlobalCoord;
  instantaneousRainfallRateM3sPerKm2: number;
  snowmeltRateM3sPerKm2: number;
  soilInfiltrationCapacityMmH: number;
  surfaceRunoffVolumetricM3sPerKm2: number;
  evapotranspirationFluxM3sPerKm2: number;
}

export interface WeatherToOceanCouplingPayload {
  coord: WGS84GlobalCoord;
  surfaceWindStressPascals: number;
  windVectorU10: number;
  windVectorV10: number;
  barometricPressureDeficitSurgeMeters: number;
  dynamicWindSetupSurgeMeters: number;
  totalEstimatedStormSurgeMeters: number;
  oceanFreshwaterFluxMmDay: number;
}

/**
 * Future NPC Perception API (Exposed to future agents, zero NPC logic implemented here)
 */
export interface NPCWeatherPerceptionAPI {
  GetCurrentWeather(coord: WGS84GlobalCoord): WeatherState;
  GetForecast(coord: WGS84GlobalCoord, horizonHours: number): WeatherForecastResult;
  GetOutdoorComfortIndex(coord: WGS84GlobalCoord): {
    heatStressLevel: 'NONE' | 'CAUTION' | 'EXTREME_CAUTION' | 'DANGER' | 'EXTREME_DANGER';
    coldStressLevel: 'NONE' | 'CHILL' | 'FREEZING' | 'FROSTBITE_RISK' | 'EXTREME_SURVIVAL';
    windImpairment: boolean;
    visibilityImpairment: boolean;
  };
  GetTravelHazardScore(coord: WGS84GlobalCoord): {
    roadSlipperinessIndex: number; // 0 (dry) to 1.0 (black ice / hydroplaning)
    aviationTurbulenceIndex: number;
    marineGaleWarning: boolean;
    flashFloodWarning: boolean;
  };
}

/**
 * Future Phase 9 Ecosystem Interface Contract (Zero Phase 9 implementation)
 */
export interface Phase9EcosystemInterfaceContract {
  GetVegetationGrowingDegreeDays(coord: WGS84GlobalCoord, baseTempC: number): number;
  GetSoilMoistureDeficit(coord: WGS84GlobalCoord): number;
  GetPhotosyntheticallyActiveRadiation(coord: WGS84GlobalCoord): number;
  GetDroughtStressScore(coord: WGS84GlobalCoord): number;
  GetFrostEventCount(coord: WGS84GlobalCoord, daysHistory: number): number;
}
