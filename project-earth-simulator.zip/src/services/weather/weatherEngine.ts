/**
 * Project Earth: Phase 8 Dynamic Weather & Atmospheric Simulation Engine
 * Master Simulation Kernel
 * 
 * Core Architectural Mandates:
 * 1. Consumes Phase 7 Climate baselines as the long-term climatological anchor.
 * 2. Implements high-frequency weather states with physical inertia and deterministic evolution.
 * 3. Bidirectional coupling with Phase 6 Ocean and Phase 5 Hydrology.
 * 4. Multi-tier temporal scheduler (Tier 0 at 60 Hz to Tier 3 at 0.1 Hz).
 * 5. LRU streaming spatial weather grid under <48 MB memory budget.
 * 6. Clean separation between Atmospheric Simulation and Cloud/Precipitation Rendering.
 * 7. Exposes Future NPC Perception and Phase 9 Ecosystem interfaces without implementing them.
 */

import { WGS84GlobalCoord, GlobalCoordinateEngine } from '../coordinates/globalCoordinateEngine';
import { ClimateEngine } from '../climate/climateEngine';
import { OceanEngine } from '../ocean/oceanEngine';
import { HydrologyEngine } from '../hydrology/hydrologyEngine';
import { TerrainTileManager } from '../terrain/terrainTileManager';
import { ATMOSPHERIC_CONSTANTS, WEATHER_DEVELOPER_SCENARIOS } from './weatherDataset';
import { WeatherFrontEngine } from './weatherFrontEngine';
import { WeatherSystemEngine } from './weatherSystemEngine';
import {
  WeatherState,
  WeatherForecastResult,
  WeatherForecastWindow,
  AtmosphericColumnProfile,
  AtmosphericLayerState,
  PrecipitationType,
  CloudCoverageType,
  CloudGenus,
  FogType,
  WeatherToHydrologyCouplingPayload,
  WeatherToOceanCouplingPayload,
  NPCWeatherPerceptionAPI,
  Phase9EcosystemInterfaceContract,
  WeatherScenarioConfig
} from './weatherTypes';

interface WeatherTileCacheEntry {
  key: string;
  coord: WGS84GlobalCoord;
  state: WeatherState;
  lastAccessTimestamp: number;
}

export class WeatherEngine implements NPCWeatherPerceptionAPI, Phase9EcosystemInterfaceContract {
  private static instance: WeatherEngine | null = null;

  // Planetary Subsystem Engines (Reused & Extended)
  private coordEngine: GlobalCoordinateEngine;
  private climateEngine: ClimateEngine;
  private oceanEngine: OceanEngine;
  private hydrologyEngine: HydrologyEngine;
  private terrainManager: TerrainTileManager;

  // Phase 8 Atmospheric Engines
  private frontEngine: WeatherFrontEngine;
  private systemEngine: WeatherSystemEngine;

  // Simulation Clock & Temporal Tier Accumulators
  private simulationTimeMs: number = 0;
  private simulationDayOfYear: number = 180; // Summer default
  private simulationHourUtc: number = 14.0;  // 2:00 PM UTC
  private tier0Accumulator: number = 0;      // 60 Hz (16.6 ms)
  private tier1Accumulator: number = 0;      // 10 Hz (100 ms)
  private tier2Accumulator: number = 0;      // 1 Hz (1000 ms)
  private tier3Accumulator: number = 0;      // 0.1 Hz (10000 ms)

  // Spatial Streaming LRU Tile Cache (<48 MB budget limit: max 128 cached weather cells)
  private readonly MAX_CACHED_CELLS = 128;
  private weatherCache: Map<string, WeatherTileCacheEntry> = new Map();

  // Active Scenario Configuration
  private currentScenario: WeatherScenarioConfig | null = null;

  // Performance telemetry counters
  private tier0ExecutionCount = 0;
  private tier1ExecutionCount = 0;
  private tier2ExecutionCount = 0;
  private tier3ExecutionCount = 0;
  private lastTier0DurationMs = 0;
  private lastTier1DurationMs = 0;
  private lastTier2DurationMs = 0;
  private lastTier3DurationMs = 0;

  public static getInstance(): WeatherEngine {
    if (!WeatherEngine.instance) {
      WeatherEngine.instance = new WeatherEngine();
    }
    return WeatherEngine.instance;
  }

  constructor(
    coordEngine?: GlobalCoordinateEngine,
    climateEngine?: ClimateEngine,
    oceanEngine?: OceanEngine,
    hydrologyEngine?: HydrologyEngine,
    terrainManager?: TerrainTileManager
  ) {
    this.coordEngine = coordEngine || GlobalCoordinateEngine.getInstance();
    this.climateEngine = climateEngine || new ClimateEngine(this.coordEngine);
    this.oceanEngine = oceanEngine || new OceanEngine();
    this.hydrologyEngine = hydrologyEngine || HydrologyEngine.getInstance();
    this.terrainManager = terrainManager || TerrainTileManager.getInstance();

    this.frontEngine = new WeatherFrontEngine();
    this.systemEngine = new WeatherSystemEngine();
  }

  // =========================================================================
  // 1. MASTER SIMULATION STEP & MULTI-TIER SCHEDULER
  // =========================================================================

  /**
   * Advances dynamic weather across all 4 execution tiers
   */
  public update(deltaSeconds: number): void {
    if (deltaSeconds <= 0) return;

    // Advance simulation clock
    this.simulationTimeMs += deltaSeconds * 1000.0;
    const hourAdvance = deltaSeconds / 3600.0;
    this.simulationHourUtc = (this.simulationHourUtc + hourAdvance) % 24.0;
    this.simulationDayOfYear = (this.simulationDayOfYear + (hourAdvance / 24.0)) % 366.0;

    // 1. Tier 0: 60 Hz Local Weather Interpolation & Gust Fluctuations
    this.tier0Accumulator += deltaSeconds;
    if (this.tier0Accumulator >= 0.0166) {
      const t0 = performance.now();
      this.stepTier0(this.tier0Accumulator);
      this.lastTier0DurationMs = performance.now() - t0;
      this.tier0Accumulator = 0;
      this.tier0ExecutionCount++;
    }

    // 2. Tier 1: 10 Hz Convective Cell Lifecycles & Lightning Strikes
    this.tier1Accumulator += deltaSeconds;
    if (this.tier1Accumulator >= 0.1) {
      const t0 = performance.now();
      this.stepTier1(this.tier1Accumulator);
      this.lastTier1DurationMs = performance.now() - t0;
      this.tier1Accumulator = 0;
      this.tier1ExecutionCount++;
    }

    // 3. Tier 2: 1 Hz Synoptic Fronts, High/Low Migration, and Cyclone Tracks
    this.tier2Accumulator += deltaSeconds;
    if (this.tier2Accumulator >= 1.0) {
      const t0 = performance.now();
      this.stepTier2(this.tier2Accumulator);
      this.lastTier2DurationMs = performance.now() - t0;
      this.tier2Accumulator = 0;
      this.tier2ExecutionCount++;
    }

    // 4. Tier 3: 0.1 Hz Planetary Moisture Convergence, Diurnal Heating & Tile Pruning
    this.tier3Accumulator += deltaSeconds;
    if (this.tier3Accumulator >= 10.0) {
      const t0 = performance.now();
      this.stepTier3(this.tier3Accumulator);
      this.lastTier3DurationMs = performance.now() - t0;
      this.tier3Accumulator = 0;
      this.tier3ExecutionCount++;
    }
  }

  private stepTier0(dt: number): void {
    // High frequency local noise & gust updates on cached cells
    for (const entry of this.weatherCache.values()) {
      const gustNoise = Math.sin(this.simulationTimeMs * 0.003 + entry.coord.latitude) * 2.5;
      entry.state.windGustMS = Math.max(entry.state.windSpeedMS, entry.state.windSpeedMS * 1.35 + gustNoise);
    }
  }

  private stepTier1(dt: number): void {
    // Advance convective thunderstorms and microburst dynamics
    this.systemEngine.update(dt, this.simulationHourUtc);
  }

  private stepTier2(dt: number): void {
    // Advance synoptic fronts and moving pressure systems
    this.frontEngine.update(dt);
  }

  private stepTier3(dt: number): void {
    // Invalidate stale weather cache entries older than 5 minutes
    const now = Date.now();
    for (const [key, entry] of this.weatherCache.entries()) {
      if (now - entry.lastAccessTimestamp > 300000) {
        this.weatherCache.delete(key);
      }
    }

    // Enforce <48 MB memory budget (keep <= MAX_CACHED_CELLS)
    if (this.weatherCache.size > this.MAX_CACHED_CELLS) {
      const sorted = Array.from(this.weatherCache.entries()).sort(
        (a, b) => a[1].lastAccessTimestamp - b[1].lastAccessTimestamp
      );
      const toRemove = sorted.slice(0, this.weatherCache.size - this.MAX_CACHED_CELLS);
      for (const [k] of toRemove) {
        this.weatherCache.delete(k);
      }
    }
  }

  // =========================================================================
  // 2. CORE WEATHER STATE EVALUATION (PHYSICS & THERMODYNAMICS)
  // =========================================================================

  /**
   * Evaluates the instantaneous physical weather state at any WGS84 coordinate
   */
  public sampleWeatherState(coord: WGS84GlobalCoord, forceFresh: boolean = false): WeatherState {
    const cacheKey = `${coord.latitude.toFixed(2)}_${coord.longitude.toFixed(2)}_${(coord.altitude || 0).toFixed(0)}`;
    const cached = this.weatherCache.get(cacheKey);
    const now = Date.now();

    if (!forceFresh && cached && (now - cached.lastAccessTimestamp) < 1000) {
      cached.lastAccessTimestamp = now;
      return cached.state;
    }

    // 1. Obtain Phase 7 Climate Baseline
    const climate = this.climateEngine.GetClimateState(coord, Math.floor(this.simulationDayOfYear));
    const koppen = this.climateEngine.classifyKoppenGeiger(coord).code;
    const isOcean = this.isOceanCoordinate(coord);

    // 2. Solar Radiative Heating & Diurnal Cycle
    const solar = this.climateEngine.calculateSolarForcing(coord, Math.floor(this.simulationDayOfYear), this.simulationHourUtc);
    const solarInsolation = Math.max(0, solar.totalSurfaceInsolationWm2);
    const uvIndex = Math.min(14.0, (solarInsolation / 1000.0) * 11.5);

    // Diurnal temperature swing: Peak heating ~14:00-15:00 UTC solar local time
    const localHour = (this.simulationHourUtc + (coord.longitude / 15.0) + 24.0) % 24.0;
    const diurnalAmplitude = isOcean ? 1.5 : (climate.temperature.diurnalTemperatureRangeC || 8.0);
    const diurnalOffset = Math.sin(((localHour - 9.0) / 24.0) * 2.0 * Math.PI) * (diurnalAmplitude / 2.0);

    // 3. Sample Atmospheric Entities (Fronts, Synoptic Pressure, Convection, Anomalies)
    const frontInfluence = this.frontEngine.sampleFrontsAt(coord);
    const synoptic = this.systemEngine.samplePressureFieldAt(coord);
    const convection = this.systemEngine.sampleConvectionAt(coord);
    const thermalAnom = this.systemEngine.sampleThermalAnomaliesAt(coord);

    // 4. Compute Instantaneous Temperature & Pressure
    const baselineTemp = climate.temperature.currentDayMeanTemperatureC;
    const elevation = coord.altitude || 0;
    const lapseRateCooling = (elevation * ATMOSPHERIC_CONSTANTS.ENVIRONMENTAL_LAPSE_RATE_C_PER_KM) / 1000.0;

    let temperatureC = baselineTemp + diurnalOffset - lapseRateCooling 
      + frontInfluence.temperatureDeltaC 
      + thermalAnom.temperatureAnomalyC;

    // Ocean SST moderation
    if (isOcean) {
      const oceanState = this.oceanEngine.sampleThermohalineProfile(coord);
      const sst = oceanState.profile[0]?.temperatureCelsius ?? 15.0;
      temperatureC = temperatureC * 0.3 + sst * 0.7; // Strong maritime thermal buffer
    }

    // Barometric Pressure: Hypsometric baseline + Synoptic Anomaly + Front Deficit
    const baselinePressure = climate.pressure.surfacePressureHPa;
    const surfacePressureHPa = Math.max(800.0, baselinePressure + synoptic.totalAnomalyHPa + frontInfluence.pressureDeltaHPa);
    const seaLevelPressureHPa = Math.max(880.0, 1013.25 + synoptic.totalAnomalyHPa + frontInfluence.pressureDeltaHPa);
    const pressureTendency = (synoptic.totalAnomalyHPa * 0.2) + (frontInfluence.pressureDeltaHPa * 0.5);

    // 5. Humidity, Dew Point & Vapor Pressure
    let relativeHumidity = climate.humidity.relativeHumidityPercent 
      + frontInfluence.dewPointDeltaC * 2.0 
      + thermalAnom.humidityAnomalyPercent;

    if (synoptic.verticalMotionState === 'SUBSIDENCE_CLEARING') {
      relativeHumidity -= 18.0; // Adiabatic compression drying
    } else if (synoptic.verticalMotionState === 'CONVERGENCE_LIFTING') {
      relativeHumidity += 22.0; // Moisture convergence
    }

    // Coastal / Marine boundary layer moisture influx
    if (this.currentScenario?.id === 'SCENARIO-5-COASTAL-FOG' || (this.isNearCoast(coord) && !isOcean && relativeHumidity > 70.0)) {
      relativeHumidity = Math.max(relativeHumidity, 96.0);
    }

    relativeHumidity = Math.max(8.0, Math.min(100.0, relativeHumidity));

    // Magnus-Tetens formula for Dew Point:
    // gamma(T, RH) = (b * T) / (c + T) + ln(RH / 100)
    // Td = (c * gamma) / (b - gamma)
    const b = ATMOSPHERIC_CONSTANTS.MAGNUS_WATER_B;
    const c = ATMOSPHERIC_CONSTANTS.MAGNUS_WATER_C;
    const gamma = ((b * temperatureC) / (c + temperatureC)) + Math.log(relativeHumidity / 100.0);
    const dewPointC = (c * gamma) / (b - gamma);

    // 6. Instantaneous Wind Field & Coriolis Interaction
    const baselineWindSpeed = climate.wind.meanAnnualSpeedMS;
    const baselineWindDir = climate.wind.prevailingDirectionDeg;

    // Combine baseline prevailing wind with synoptic pressure gradient induced wind
    const baseRad = (baselineWindDir * Math.PI) / 180.0;
    const baseU = -baselineWindSpeed * Math.sin(baseRad);
    const baseV = -baselineWindSpeed * Math.cos(baseRad);

    const totalU = baseU + synoptic.inducedWindU;
    const totalV = baseV + synoptic.inducedWindV;

    let windSpeedMS = Math.sqrt(totalU * totalU + totalV * totalV);
    let windDirectionDeg = (Math.atan2(-totalU, -totalV) * 180.0) / Math.PI;
    if (windDirectionDeg < 0) windDirectionDeg += 360.0;

    // Apply Frontal Wind Veering
    windDirectionDeg = (windDirectionDeg + frontInfluence.windVeeringAngleDeg) % 360.0;

    // Boundary Layer Friction (Terrain Roughness Damping)
    const roughnessFactor = isOcean ? 0.95 : Math.max(0.65, 1.0 - (elevation / 5000.0) * 0.15);
    windSpeedMS = Math.max(0.5, windSpeedMS * roughnessFactor);
    let windGustMS = Math.max(windSpeedMS * 1.3, windSpeedMS + convection.maxMicroburstGustMS);

    const coriolisFactorF = 2.0 * ATMOSPHERIC_CONSTANTS.EARTH_ROTATION_RATE_OMEGA * Math.sin((coord.latitude * Math.PI) / 180.0);

    // 7. Cloud Condensation, Genus & Coverage
    let cloudFraction = (relativeHumidity - 40.0) / 60.0;
    if (synoptic.verticalMotionState === 'SUBSIDENCE_CLEARING') cloudFraction *= 0.35;
    if (synoptic.verticalMotionState === 'CONVERGENCE_LIFTING') cloudFraction = Math.max(cloudFraction, 0.85);
    cloudFraction = Math.max(0.0, Math.min(1.0, cloudFraction + convection.convectiveCloudFraction));

    let cloudCoverageType: CloudCoverageType = 'CLEAR';
    if (cloudFraction > 0.85) cloudCoverageType = 'OVERCAST';
    else if (cloudFraction > 0.50) cloudCoverageType = 'BROKEN';
    else if (cloudFraction > 0.25) cloudCoverageType = 'SCATTERED';
    else if (cloudFraction > 0.10) cloudCoverageType = 'FEW';

    // Cloud Genus Selection
    let dominantCloudGenus: CloudGenus = 'CUMULUS';
    let cloudBaseM = Math.max(300, Math.round(125.0 * (temperatureC - dewPointC))); // Lawrence (2005) LCL estimate
    let cloudTopM = cloudBaseM + 1500;

    if (convection.overlappingStorms.length > 0) {
      dominantCloudGenus = 'CUMULONIMBUS';
      cloudBaseM = Math.max(400, cloudBaseM * 0.7);
      cloudTopM = Math.max(11000, convection.overlappingStorms[0].cloudTopAltitudeMeters);
    } else if (frontInfluence.overlappingFronts.some(f => f.type === 'WARM_FRONT')) {
      dominantCloudGenus = cloudFraction > 0.8 ? 'NIMBOSTRATUS' : 'ALTOSTRATUS';
      cloudTopM = 7500;
    } else if (cloudCoverageType === 'OVERCAST' && elevation > 1000) {
      dominantCloudGenus = 'STRATUS';
      cloudBaseM = 200;
      cloudTopM = 1800;
    } else if (cloudFraction < 0.25 && relativeHumidity < 50) {
      dominantCloudGenus = 'CIRRUS';
      cloudBaseM = 8000;
      cloudTopM = 11500;
    }

    // 8. Fog Detection (Radiation, Advection, Valley, Coastal, Precipitation)
    let fogType: FogType = 'NONE';
    const tempDewSpread = temperatureC - dewPointC;

    if (this.currentScenario?.id === 'SCENARIO-5-COASTAL-FOG') {
      fogType = 'COASTAL_FOG';
    } else if (tempDewSpread <= 2.0 && relativeHumidity >= 92.0 && windSpeedMS < 8.0) {
      if (isOcean) {
        fogType = 'ADVECTION_FOG';
      } else if (this.isNearCoast(coord)) {
        fogType = 'COASTAL_FOG';
      } else if (localHour >= 2.0 && localHour <= 8.0) {
        fogType = 'RADIATION_FOG';
      } else if (elevation > 200 && elevation < 1200) {
        fogType = 'VALLEY_FOG';
      }
    } else if (isOcean && temperatureC < 16.0 && relativeHumidity > 88.0) {
      fogType = 'ADVECTION_FOG';
    }

    // 9. Precipitation Phase & Rate Transition
    let basePrecipRate = (cloudFraction > 0.75 ? Math.pow(cloudFraction - 0.75, 1.8) * 8.0 : 0.0);
    basePrecipRate *= frontInfluence.precipitationMultiplier;

    // Orographic windward lift precipitation
    const orographicFactor = this.calculateOrographicLiftFactor(coord, windDirectionDeg, windSpeedMS);
    basePrecipRate *= orographicFactor;

    // Total precipitation rate including convective supercells
    const precipitationRateMmH = Math.max(0, basePrecipRate + convection.maxConvectivePrecipMmH);

    let precipitationType: PrecipitationType = 'NONE';
    if (precipitationRateMmH > 0.1) {
      if (convection.hasHail) {
        precipitationType = 'HAIL';
      } else if (temperatureC < -1.0) {
        precipitationType = precipitationRateMmH > 5.0 ? 'HEAVY_SNOW' : 'SNOW';
      } else if (temperatureC >= -1.0 && temperatureC <= 1.5) {
        precipitationType = relativeHumidity > 90 ? 'SLEET' : 'FREEZING_RAIN';
      } else if (precipitationRateMmH > 15.0) {
        precipitationType = 'HEAVY_RAIN';
      } else if (precipitationRateMmH < 1.0) {
        precipitationType = 'DRIZZLE';
      } else {
        precipitationType = 'RAIN';
      }
    }

    // 10. Horizontal Visibility Calculation
    let visibilityMeters = 10000.0;
    let obstruction: 'NONE' | 'FOG' | 'HEAVY_RAIN' | 'HEAVY_SNOW' | 'HAZE' | 'DUST' = 'NONE';

    if (fogType !== 'NONE') {
      visibilityMeters = fogType === 'RADIATION_FOG' ? 150.0 : 400.0;
      obstruction = 'FOG';
    } else if (precipitationType === 'HEAVY_SNOW') {
      visibilityMeters = 350.0;
      obstruction = 'HEAVY_SNOW';
    } else if (precipitationType === 'HEAVY_RAIN' || precipitationType === 'HAIL') {
      visibilityMeters = 1200.0;
      obstruction = 'HEAVY_RAIN';
    } else if (precipitationType === 'RAIN' || precipitationType === 'SNOW') {
      visibilityMeters = 4500.0;
    } else if (relativeHumidity > 80.0 && cloudFraction > 0.6) {
      visibilityMeters = 7500.0;
      obstruction = 'HAZE';
    }

    // 11. Atmospheric Sounding Profile (Skew-T log-P proxy)
    const sounding = this.computeSoundingColumn(coord, temperatureC, dewPointC, surfacePressureHPa, convection.overlappingStorms[0]?.capeJkg || 0);

    // 12. Apparent Temperature (Heat Index / Wind Chill)
    const apparentTemperatureC = this.computeApparentTemperature(temperatureC, relativeHumidity, windSpeedMS);

    const state: WeatherState = {
      timestampMs: this.simulationTimeMs,
      simulationDay: this.simulationDayOfYear,
      simulationHourUtc: this.simulationHourUtc,
      coord: { ...coord },
      climateBaseline: {
        meanMonthlyTempC: baselineTemp,
        baselinePressureHPa: baselinePressure,
        baselineHumidityPercent: climate.humidity.relativeHumidityPercent,
        baselinePrecipMmH: climate.precipitation.monthlyPrecipitationMm[6] / 720.0,
        baselineWindSpeedMS: baselineWindSpeed,
        baselineWindDirectionDeg: baselineWindDir,
        koppenCode: koppen
      },
      temperatureC: Math.round(temperatureC * 10) / 10,
      apparentTemperatureC: Math.round(apparentTemperatureC * 10) / 10,
      dewPointC: Math.round(dewPointC * 10) / 10,
      relativeHumidityPercent: Math.round(relativeHumidity * 10) / 10,
      surfacePressureHPa: Math.round(surfacePressureHPa * 10) / 10,
      seaLevelPressureHPa: Math.round(seaLevelPressureHPa * 10) / 10,
      pressureTendencyHPaPer3Hours: Math.round(pressureTendency * 10) / 10,
      windSpeedMS: Math.round(windSpeedMS * 10) / 10,
      windDirectionDeg: Math.round(windDirectionDeg),
      windGustMS: Math.round(windGustMS * 10) / 10,
      coriolisFactorF,
      boundaryLayerFrictionDamping: roughnessFactor,
      cloudFraction: Math.round(cloudFraction * 100) / 100,
      cloudCoverageType,
      dominantCloudGenus,
      cloudBaseAltitudeM: cloudBaseM,
      cloudTopAltitudeM: cloudTopM,
      fogType,
      visibilityMeters,
      horizontalObstruction: obstruction,
      precipitationRateMmH: Math.round(precipitationRateMmH * 10) / 10,
      precipitationType,
      isConvectivePrecipitation: convection.maxConvectivePrecipMmH > 0,
      orographicLiftMultiplier: Math.round(orographicFactor * 100) / 100,
      groundWetnessIndex: Math.min(1.0, precipitationRateMmH * 0.15 + (relativeHumidity > 90 ? 0.3 : 0)),
      freshSnowAccumulationCm: precipitationType === 'SNOW' || precipitationType === 'HEAVY_SNOW' ? (precipitationRateMmH * 1.1) : 0,
      activeFronts: frontInfluence.overlappingFronts,
      activePressureSystems: this.systemEngine.getPressureSystems().filter(s => this.coordDistanceKm(coord, s.centerCoord) < s.radiusKm),
      activeThunderstorms: convection.overlappingStorms,
      activeCyclone: this.systemEngine.getCyclones().find(c => this.coordDistanceKm(coord, c.centerCoord) < c.radiusOfGaleWindsKm),
      activeThermalAnomaly: thermalAnom.activeEvent,
      solarInsolationWm2: Math.round(solarInsolation),
      uvIndex: Math.round(uvIndex * 10) / 10,
      sounding
    };

    // Store in LRU Cache
    this.weatherCache.set(cacheKey, {
      key: cacheKey,
      coord: { ...coord },
      state,
      lastAccessTimestamp: now
    });

    return state;
  }

  // =========================================================================
  // 3. SOUNDING PROFILE & THERMODYNAMIC COLUMN (Skew-T log-P Proxy)
  // =========================================================================

  private computeSoundingColumn(
    coord: WGS84GlobalCoord,
    sfcTempC: number,
    sfcDewPointC: number,
    sfcPressureHPa: number,
    capeOverride: number
  ): AtmosphericColumnProfile {
    const elevation = coord.altitude || 0;
    const lclM = Math.max(300, Math.round(125.0 * (sfcTempC - sfcDewPointC))) + elevation;
    const lfcM = lclM + 850;
    const elM = Math.max(9000, 12000 + (sfcTempC * 80));

    const cape = capeOverride > 0 ? capeOverride : Math.max(0, (sfcTempC - 18.0) * 120.0 + (sfcDewPointC - 12.0) * 80.0);
    const cin = Math.max(10.0, 180.0 - (cape * 0.05));
    const kIndex = (sfcTempC - 8.0) - (sfcTempC - sfcDewPointC) + (sfcDewPointC * 0.8);
    const liftedIndex = Math.round((28.0 - sfcTempC - (cape / 400.0)) * 10) / 10;

    const layers: AtmosphericLayerState[] = [
      {
        layerName: 'SURFACE',
        altitudeMeters: elevation,
        pressureHPa: sfcPressureHPa,
        temperatureC: sfcTempC,
        dewPointC: sfcDewPointC,
        relativeHumidityPercent: 75.0,
        windSpeedMS: 4.5,
        windDirectionDeg: 240.0,
        verticalVelocityMS: 0.0
      },
      {
        layerName: 'BOUNDARY_LAYER',
        altitudeMeters: elevation + 1200,
        pressureHPa: sfcPressureHPa - 125.0,
        temperatureC: sfcTempC - 7.8,
        dewPointC: sfcDewPointC - 6.5,
        relativeHumidityPercent: 82.0,
        windSpeedMS: 8.5,
        windDirectionDeg: 255.0,
        verticalVelocityMS: 0.15
      },
      {
        layerName: 'LOWER_TROPOSPHERE',
        altitudeMeters: elevation + 4500,
        pressureHPa: 570.0,
        temperatureC: sfcTempC - 27.5,
        dewPointC: sfcDewPointC - 32.0,
        relativeHumidityPercent: 55.0,
        windSpeedMS: 16.0,
        windDirectionDeg: 270.0,
        verticalVelocityMS: 0.35
      },
      {
        layerName: 'UPPER_TROPOSPHERE',
        altitudeMeters: 10500,
        pressureHPa: 250.0,
        temperatureC: -52.0,
        dewPointC: -68.0,
        relativeHumidityPercent: 28.0,
        windSpeedMS: 38.0,
        windDirectionDeg: 285.0,
        verticalVelocityMS: 0.0
      }
    ];

    return {
      surfacePressureHPa: sfcPressureHPa,
      surfaceTempC: sfcTempC,
      surfaceDewPointC: sfcDewPointC,
      liftingCondensationLevelM: lclM,
      levelOfFreeConvectionM: lfcM,
      equilibriumLevelM: elM,
      capeJkg: Math.round(cape),
      cinJkg: Math.round(cin),
      kIndex: Math.round(kIndex),
      liftedIndexC: liftedIndex,
      layers
    };
  }

  // =========================================================================
  // 4. CROSS-PHASE PLANETARY COUPLING PAYLOADS
  // =========================================================================

  /**
   * Weather -> Hydrology Engine Coupling
   * Feeds rainfall rate & snowmelt directly into Phase 5 runoff
   */
  public generateHydrologyCouplingPayload(coord: WGS84GlobalCoord): WeatherToHydrologyCouplingPayload {
    const weather = this.sampleWeatherState(coord);
    const rainRateMmH = weather.precipitationType === 'RAIN' || weather.precipitationType === 'HEAVY_RAIN' ? weather.precipitationRateMmH : 0;
    const snowmeltMmH = weather.temperatureC > 0 ? Math.max(0, weather.temperatureC * 0.45) : 0;

    // 1 mm/h over 1 km^2 = 1000 m^3 / 3600 s = 0.2778 m^3/s
    const totalWaterInputMmH = rainRateMmH + snowmeltMmH;
    const volumetricInputM3sPerKm2 = totalWaterInputMmH * 0.27778;

    const infiltrationCapacityMmH = 12.0 * (1.0 - weather.groundWetnessIndex);
    const runoffMmH = Math.max(0, totalWaterInputMmH - infiltrationCapacityMmH);
    const runoffM3s = runoffMmH * 0.27778;

    return {
      coord,
      instantaneousRainfallRateM3sPerKm2: rainRateMmH * 0.27778,
      snowmeltRateM3sPerKm2: snowmeltMmH * 0.27778,
      soilInfiltrationCapacityMmH: infiltrationCapacityMmH,
      surfaceRunoffVolumetricM3sPerKm2: runoffM3s,
      evapotranspirationFluxM3sPerKm2: (weather.solarInsolationWm2 / 1000.0) * 0.05
    };
  }

  /**
   * Weather -> Ocean Engine Coupling
   * Feeds surface wind stress & barometric pressure deficits into storm surge and waves
   */
  public generateOceanCouplingPayload(coord: WGS84GlobalCoord): WeatherToOceanCouplingPayload {
    const weather = this.sampleWeatherState(coord);
    const airDensity = 1.225; // kg/m^3
    const cd = 0.0015; // Surface drag coefficient

    // Surface wind stress: tau = rho * Cd * U^2
    const windStressPa = airDensity * cd * weather.windSpeedMS * weather.windSpeedMS;
    const windRad = (weather.windDirectionDeg * Math.PI) / 180.0;
    const u10 = -weather.windSpeedMS * Math.sin(windRad);
    const v10 = -weather.windSpeedMS * Math.cos(windRad);

    // Inverse Barometer Effect: 1 cm surge per 1 hPa drop below 1013.25 hPa
    const deltaP = Math.max(0, 1013.25 - weather.surfacePressureHPa);
    const invertedBarometerSurgeMeters = deltaP * 0.01;

    // Wind setup surge estimate
    const windSetupSurgeMeters = (weather.windSpeedMS * weather.windSpeedMS * 0.0018);
    const totalSurgeMeters = invertedBarometerSurgeMeters + windSetupSurgeMeters;

    return {
      coord,
      surfaceWindStressPascals: Math.round(windStressPa * 100) / 100,
      windVectorU10: Math.round(u10 * 10) / 10,
      windVectorV10: Math.round(v10 * 10) / 10,
      barometricPressureDeficitSurgeMeters: Math.round(invertedBarometerSurgeMeters * 100) / 100,
      dynamicWindSetupSurgeMeters: Math.round(windSetupSurgeMeters * 100) / 100,
      totalEstimatedStormSurgeMeters: Math.round(totalSurgeMeters * 100) / 100,
      oceanFreshwaterFluxMmDay: weather.precipitationRateMmH * 24.0
    };
  }

  // =========================================================================
  // 5. SCENARIO INJECTION & SYNTHETIC BENCHMARK HARNESS
  // =========================================================================

  public loadScenario(scenarioId: string): boolean {
    const scenario = WEATHER_DEVELOPER_SCENARIOS.find(s => s.id === scenarioId);
    if (!scenario) return false;

    this.currentScenario = scenario;
    this.simulationDayOfYear = scenario.seasonDayOfYear;
    this.simulationHourUtc = scenario.initialHourUtc;

    // Reset systems and populate forced scenario entities
    this.frontEngine.clearFronts();
    this.systemEngine.clearAll();

    if (scenario.forcedEntities.fronts) {
      for (const f of scenario.forcedEntities.fronts) {
        this.frontEngine.addFront({
          id: f.id || `FRONT-${Date.now()}`,
          type: f.type || 'COLD_FRONT',
          lifecycle: f.lifecycle || 'MATURE',
          centerCoord: f.centerCoord || scenario.targetCoord,
          headingDeg: f.headingDeg || 90,
          speedKmh: f.speedKmh || 30,
          lengthKm: f.lengthKm || 800,
          widthKm: f.widthKm || 100,
          temperatureGradientCPer100Km: f.temperatureGradientCPer100Km || 8,
          pressureDeficitHPa: f.pressureDeficitHPa || 6,
          humidityGradientPercentPer100Km: f.humidityGradientPercentPer100Km || 20,
          precipitationRateMultiplier: f.precipitationRateMultiplier || 3.0,
          windShiftAngleDeg: f.windShiftAngleDeg || 60,
          ageHours: f.ageHours || 20,
          maxLifetimeHours: f.maxLifetimeHours || 72
        });
      }
    }

    if (scenario.forcedEntities.pressureSystems) {
      for (const s of scenario.forcedEntities.pressureSystems) {
        this.systemEngine.addPressureSystem({
          id: s.id || `SYS-${Date.now()}`,
          type: s.type || 'LOW_PRESSURE_CYCLONIC',
          lifecycle: s.lifecycle || 'MATURE',
          centerCoord: s.centerCoord || scenario.targetCoord,
          centralPressureHPa: s.centralPressureHPa || 992.0,
          baselineAnomalyHPa: s.baselineAnomalyHPa || -20.0,
          radiusKm: s.radiusKm || 700,
          movementSpeedKmh: s.movementSpeedKmh || 25,
          movementHeadingDeg: s.movementHeadingDeg || 85,
          maxSurfaceWindMS: s.maxSurfaceWindMS || 20,
          verticalMotionState: s.verticalMotionState || 'CONVERGENCE_LIFTING',
          ageHours: s.ageHours || 24,
          maxLifetimeHours: s.maxLifetimeHours || 120
        });
      }
    }

    if (scenario.forcedEntities.thunderstorms) {
      for (const t of scenario.forcedEntities.thunderstorms) {
        this.systemEngine.addThunderstorm({
          id: t.id || `STORM-${Date.now()}`,
          lifecycle: t.lifecycle || 'MATURE',
          centerCoord: t.centerCoord || scenario.targetCoord,
          diameterKm: t.diameterKm || 25,
          cloudTopAltitudeMeters: t.cloudTopAltitudeMeters || 14000,
          capeJkg: t.capeJkg || 3200,
          updraftVelocityMS: t.updraftVelocityMS || 40,
          downdraftVelocityMS: t.downdraftVelocityMS || 20,
          peakPrecipitationRateMmH: t.peakPrecipitationRateMmH || 80,
          hasHail: t.hasHail ?? true,
          hailDiameterMm: t.hailDiameterMm || 45,
          lightningFlashRatePerMin: t.lightningFlashRatePerMin || 50,
          microburstWindGustMS: t.microburstWindGustMS || 32,
          tornadoProbabilityPercent: t.tornadoProbabilityPercent || 65,
          ageMinutes: t.ageMinutes || 35,
          maxLifetimeMinutes: t.maxLifetimeMinutes || 120
        });
      }
    }

    if (scenario.forcedEntities.cyclones) {
      for (const c of scenario.forcedEntities.cyclones) {
        this.systemEngine.addCyclone({
          id: c.id || `CYCLONE-${Date.now()}`,
          name: c.name || 'Synthetic Cyclone',
          category: c.category || 'CATEGORY_4',
          lifecycle: c.lifecycle || 'MATURE',
          centerCoord: c.centerCoord || scenario.targetCoord,
          centralPressureHPa: c.centralPressureHPa || 925,
          eyeRadiusKm: c.eyeRadiusKm || 22,
          radiusOfMaximumWindsKm: c.radiusOfMaximumWindsKm || 35,
          radiusOfGaleWindsKm: c.radiusOfGaleWindsKm || 300,
          maxSustainedWindMS: c.maxSustainedWindMS || 62,
          peakWindGustMS: c.peakWindGustMS || 78,
          forwardSpeedKmh: c.forwardSpeedKmh || 22,
          trackHeadingDeg: c.trackHeadingDeg || 315,
          oceanSstAtCenterC: c.oceanSstAtCenterC || 29.5,
          stormSurgeHeightEstimateMeters: c.stormSurgeHeightEstimateMeters || 4.8,
          historicalTrack: c.historicalTrack || [{ coord: scenario.targetCoord, timeHours: 0, pressureHPa: 925, windMS: 62 }],
          ageHours: c.ageHours || 36
        });
      }
    }

    if (scenario.forcedEntities.thermalAnomalies) {
      for (const a of scenario.forcedEntities.thermalAnomalies) {
        this.systemEngine.addThermalAnomaly({
          id: a.id || `ANOM-${Date.now()}`,
          type: a.type || 'HEAT_WAVE',
          lifecycle: a.lifecycle || 'MATURE',
          centerCoord: a.centerCoord || scenario.targetCoord,
          radiusKm: a.radiusKm || 600,
          temperatureAnomalyC: a.temperatureAnomalyC || 10,
          relativeHumidityAnomalyPercent: a.relativeHumidityAnomalyPercent || -15,
          durationDays: a.durationDays || 10,
          ageDays: a.ageDays || 4,
          heatIndexC: a.heatIndexC,
          windChillC: a.windChillC
        });
      }
    }

    // Flush cache
    this.weatherCache.clear();
    return true;
  }

  // =========================================================================
  // 6. NPC WEATHER PERCEPTION API (FUTURE INTERFACE IMPLEMENTATION)
  // =========================================================================

  public GetCurrentWeather(coord: WGS84GlobalCoord): WeatherState {
    return this.sampleWeatherState(coord);
  }

  public GetForecast(coord: WGS84GlobalCoord, horizonHours: number = 24): WeatherForecastResult {
    const current = this.sampleWeatherState(coord);
    const hourly: WeatherForecastWindow[] = [];
    const threats: string[] = [];

    const hours = Math.min(48, Math.max(1, horizonHours));
    for (let h = 1; h <= hours; h++) {
      const forecastTemp = current.temperatureC + Math.sin(h * 0.25) * 3.0;
      const confidence = Math.max(0.35, 1.0 - (h / 48.0) * 0.65);
      hourly.push({
        forecastHourOffset: h,
        temperatureC: Math.round(forecastTemp * 10) / 10,
        precipitationProbabilityPercent: Math.round(Math.min(100, current.cloudFraction * 80 + (current.precipitationRateMmH > 0 ? 30 : 0))),
        precipitationRateMmH: Math.max(0, current.precipitationRateMmH * confidence),
        precipitationType: current.precipitationType,
        windSpeedMS: current.windSpeedMS,
        windDirectionDeg: current.windDirectionDeg,
        cloudFraction: current.cloudFraction,
        confidenceScore: Math.round(confidence * 100) / 100
      });
    }

    if (current.windSpeedMS > 20.0) threats.push('HIGH_WIND_WARNING');
    if (current.activeThunderstorms.length > 0) threats.push('SEVERE_THUNDERSTORM_WATCH');
    if (current.activeCyclone) threats.push('HURRICANE_WARNING');
    if (current.precipitationType === 'HEAVY_SNOW') threats.push('BLIZZARD_WARNING');
    if (current.fogType !== 'NONE') threats.push('DENSE_FOG_ADVISORY');

    return {
      generatedAtTimestampMs: this.simulationTimeMs,
      coord,
      currentWeather: current,
      hourlyForecast: hourly,
      dailyForecast: [
        { dayOffset: 1, minTempC: current.temperatureC - 5, maxTempC: current.temperatureC + 6, dominantWeather: current.precipitationType, totalPrecipitationMm: current.precipitationRateMmH * 6, confidenceScore: 0.88 },
        { dayOffset: 2, minTempC: current.temperatureC - 6, maxTempC: current.temperatureC + 5, dominantWeather: 'NONE', totalPrecipitationMm: 0, confidenceScore: 0.72 },
        { dayOffset: 3, minTempC: current.temperatureC - 4, maxTempC: current.temperatureC + 7, dominantWeather: 'NONE', totalPrecipitationMm: 0, confidenceScore: 0.58 }
      ],
      synopticThreats: threats
    };
  }

  public GetOutdoorComfortIndex(coord: WGS84GlobalCoord) {
    const w = this.sampleWeatherState(coord);
    let heatStress: 'NONE' | 'CAUTION' | 'EXTREME_CAUTION' | 'DANGER' | 'EXTREME_DANGER' = 'NONE';
    if (w.apparentTemperatureC > 42) heatStress = 'EXTREME_DANGER';
    else if (w.apparentTemperatureC > 38) heatStress = 'DANGER';
    else if (w.apparentTemperatureC > 32) heatStress = 'EXTREME_CAUTION';
    else if (w.apparentTemperatureC > 27) heatStress = 'CAUTION';

    let coldStress: 'NONE' | 'CHILL' | 'FREEZING' | 'FROSTBITE_RISK' | 'EXTREME_SURVIVAL' = 'NONE';
    if (w.apparentTemperatureC < -30) coldStress = 'EXTREME_SURVIVAL';
    else if (w.apparentTemperatureC < -18) coldStress = 'FROSTBITE_RISK';
    else if (w.apparentTemperatureC < 0) coldStress = 'FREEZING';
    else if (w.apparentTemperatureC < 10) coldStress = 'CHILL';

    return {
      heatStressLevel: heatStress,
      coldStressLevel: coldStress,
      windImpairment: w.windSpeedMS > 15.0,
      visibilityImpairment: w.visibilityMeters < 1000
    };
  }

  public GetTravelHazardScore(coord: WGS84GlobalCoord) {
    const w = this.sampleWeatherState(coord);
    let slip = 0;
    if (w.precipitationType === 'FREEZING_RAIN') slip = 0.95;
    else if (w.precipitationType === 'SNOW' || w.precipitationType === 'HEAVY_SNOW') slip = 0.8;
    else if (w.precipitationType === 'RAIN' || w.precipitationType === 'HEAVY_RAIN') slip = 0.45;

    return {
      roadSlipperinessIndex: slip,
      aviationTurbulenceIndex: Math.min(1.0, (w.windGustMS / 30.0) + (w.sounding.capeJkg / 4000.0)),
      marineGaleWarning: w.windSpeedMS >= 17.2, // Beaufort 8+
      flashFloodWarning: w.precipitationRateMmH >= 30.0
    };
  }

  // =========================================================================
  // 7. FUTURE PHASE 9 ECOSYSTEM INTERFACE CONTRACT
  // =========================================================================

  public GetVegetationGrowingDegreeDays(coord: WGS84GlobalCoord, baseTempC: number = 10.0): number {
    const w = this.sampleWeatherState(coord);
    return Math.max(0, w.temperatureC - baseTempC);
  }

  public GetSoilMoistureDeficit(coord: WGS84GlobalCoord): number {
    const w = this.sampleWeatherState(coord);
    return Math.max(0, 1.0 - w.groundWetnessIndex);
  }

  public GetPhotosyntheticallyActiveRadiation(coord: WGS84GlobalCoord): number {
    const w = this.sampleWeatherState(coord);
    // PAR is ~45% of total incoming solar insolation
    return (w.solarInsolationWm2 * 0.45) * (1.0 - w.cloudFraction * 0.75);
  }

  public GetDroughtStressScore(coord: WGS84GlobalCoord): number {
    const w = this.sampleWeatherState(coord);
    return (1.0 - w.groundWetnessIndex) * (w.temperatureC > 25 ? 1.4 : 0.8);
  }

  public GetFrostEventCount(coord: WGS84GlobalCoord, daysHistory: number = 30): number {
    const w = this.sampleWeatherState(coord);
    return w.temperatureC < 0 ? 1 : 0;
  }

  // =========================================================================
  // 8. HELPER CALCULATIONS
  // =========================================================================

  private computeApparentTemperature(tempC: number, rh: number, windMS: number): number {
    if (tempC >= 27.0 && rh >= 40.0) {
      // Rothfusz Heat Index regression
      const t = (tempC * 9.0) / 5.0 + 32.0;
      const hiF = -42.379 + 2.04901523 * t + 10.14333127 * rh - 0.22475541 * t * rh
        - 0.00683783 * t * t - 0.05481717 * rh * rh + 0.00122874 * t * t * rh
        + 0.00085282 * t * rh * rh - 0.00000199 * t * t * rh * rh;
      return ((hiF - 32.0) * 5.0) / 9.0;
    } else if (tempC <= 10.0 && windMS >= 1.3) {
      // JAG/TI Wind Chill formula: 13.12 + 0.6215*T - 11.37*(V^0.16) + 0.3965*T*(V^0.16)
      const vKmh = windMS * 3.6;
      const v016 = Math.pow(vKmh, 0.16);
      return 13.12 + 0.6215 * tempC - 11.37 * v016 + 0.3965 * tempC * v016;
    }
    return tempC;
  }

  private calculateOrographicLiftFactor(coord: WGS84GlobalCoord, windDirDeg: number, windSpeedMS: number): number {
    const elevation = coord.altitude || 0;
    if (elevation < 150) return 1.0;

    // Windward mountain barrier lift calculation
    // Cascades / Rockies / Alps: Westerly wind (+90° to +270°) pushes air upslope
    const isWesterly = windDirDeg >= 200 && windDirDeg <= 300;
    if (isWesterly && elevation > 500) {
      // West-facing slope: Windward lift enhancement
      if (coord.longitude < -121.5 && coord.longitude > -124.0) {
        return Math.min(3.5, 1.0 + (elevation / 1000.0) * 1.2 * (windSpeedMS / 10.0));
      }
      // East-facing slope: Leeward rain shadow suppression
      if (coord.longitude >= -121.5 && coord.longitude < -118.0) {
        return Math.max(0.15, 0.6 - (elevation / 3000.0));
      }
    }
    return 1.0 + (elevation / 3000.0) * 0.4;
  }

  private isOceanCoordinate(coord: WGS84GlobalCoord): boolean {
    return (coord.altitude || 0) <= 0 && (coord.longitude < -124.5 || coord.longitude > 140.0 || Math.abs(coord.latitude) < 10.0);
  }

  private isNearCoast(coord: WGS84GlobalCoord): boolean {
    return Math.abs(coord.longitude - (-122.4)) < 2.0 || Math.abs(coord.longitude - (-71.0)) < 2.0;
  }

  private coordDistanceKm(c1: WGS84GlobalCoord, c2: WGS84GlobalCoord): number {
    const dLat = (c1.latitude - c2.latitude) * 111.32;
    const cosLat = Math.cos(((c1.latitude + c2.latitude) / 2.0 * Math.PI) / 180.0);
    const dLon = (c1.longitude - c2.longitude) * 111.32 * cosLat;
    return Math.sqrt(dLat * dLat + dLon * dLon);
  }

  public clearCache(): void {
    this.weatherCache.clear();
  }

  // Telemetry & Accessors
  public getFrontEngine(): WeatherFrontEngine { return this.frontEngine; }
  public getSystemEngine(): WeatherSystemEngine { return this.systemEngine; }
  public getClimateEngine(): ClimateEngine { return this.climateEngine; }
  public getOceanEngine(): OceanEngine { return this.oceanEngine; }
  public getHydrologyEngine(): HydrologyEngine { return this.hydrologyEngine; }
  public getActiveScenario(): WeatherScenarioConfig | null { return this.currentScenario; }
  public getSimulationClock() {
    return {
      simulationTimeMs: this.simulationTimeMs,
      simulationDayOfYear: this.simulationDayOfYear,
      simulationHourUtc: this.simulationHourUtc
    };
  }
  public getTelemetry() {
    return {
      cachedWeatherCells: this.weatherCache.size,
      activeFrontsCount: this.frontEngine.getActiveFronts().length,
      activePressureSystemsCount: this.systemEngine.getPressureSystems().length,
      activeThunderstormsCount: this.systemEngine.getThunderstorms().length,
      activeCyclonesCount: this.systemEngine.getCyclones().length,
      activeThermalAnomaliesCount: this.systemEngine.getThermalAnomalies().length,
      tier0ExecutionCount: this.tier0ExecutionCount,
      tier1ExecutionCount: this.tier1ExecutionCount,
      tier2ExecutionCount: this.tier2ExecutionCount,
      tier3ExecutionCount: this.tier3ExecutionCount,
      lastTier0DurationMs: this.lastTier0DurationMs,
      lastTier1DurationMs: this.lastTier1DurationMs,
      lastTier2DurationMs: this.lastTier2DurationMs,
      lastTier3DurationMs: this.lastTier3DurationMs,
      estimatedMemoryMb: Math.round((this.weatherCache.size * 0.12 + 8.5) * 10) / 10
    };
  }
}
