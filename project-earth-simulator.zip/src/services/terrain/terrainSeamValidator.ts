/**
 * Project Earth: Phase 4 Terrain Seam Validator
 * Automated mathematical edge vertex & elevation continuity testing
 * across adjacent tile boundaries to prove seamless stitching (zero vertical cracks).
 */

import { TerrainTileManager } from './terrainTileManager';
import { TerrainLOD, SeamValidationBoundaryResult } from './terrainTypes';

export interface BoundaryPair {
  boundaryId: string;
  tileAId: string;
  tileBId: string;
  orientation: 'EAST_WEST' | 'NORTH_SOUTH';
}

export const ZION_BOUNDARIES: BoundaryPair[] = [
  {
    boundaryId: 'BND_SOUTH_EW',
    tileAId: 'PETILE_ZION_12N_322_4118', // SW
    tileBId: 'PETILE_ZION_12N_323_4118', // SE
    orientation: 'EAST_WEST'
  },
  {
    boundaryId: 'BND_NORTH_EW',
    tileAId: 'PETILE_ZION_12N_322_4119', // NW
    tileBId: 'PETILE_ZION_12N_323_4119', // NE
    orientation: 'EAST_WEST'
  },
  {
    boundaryId: 'BND_WEST_NS',
    tileAId: 'PETILE_ZION_12N_322_4118', // SW
    tileBId: 'PETILE_ZION_12N_322_4119', // NW
    orientation: 'NORTH_SOUTH'
  },
  {
    boundaryId: 'BND_EAST_NS',
    tileAId: 'PETILE_ZION_12N_323_4118', // SE
    tileBId: 'PETILE_ZION_12N_323_4119', // NE
    orientation: 'NORTH_SOUTH'
  }
];

export class TerrainSeamValidator {
  private manager: TerrainTileManager;

  constructor(manager: TerrainTileManager = TerrainTileManager.getInstance()) {
    this.manager = manager;
  }

  /**
   * Evaluates vertex elevation continuity across an adjacent boundary pair.
   * Samples along the mutual border and computes max and average vertical delta in millimeters.
   */
  public testBoundary(
    pair: BoundaryPair,
    lodA: TerrainLOD = 0,
    lodB: TerrainLOD = 0,
    sampleCount: number = 32
  ): SeamValidationBoundaryResult {
    const tileA = this.manager.loadTile(pair.tileAId, lodA);
    const tileB = this.manager.loadTile(pair.tileBId, lodB);

    const matA = tileA.lodElevationMatrices[lodA];
    const matB = tileB.lodElevationMatrices[lodB];

    const resA = matA.length;
    const resB = matB.length;

    let maxDiscontinuity = 0.0;
    let sumDiscontinuity = 0.0;
    const discrepancies: number[] = [];

    for (let i = 0; i < sampleCount; i++) {
      const t = i / (sampleCount - 1); // 0.0 to 1.0 along boundary

      let elevA = 0;
      let elevB = 0;

      if (pair.orientation === 'EAST_WEST') {
        // tileA is West, tileB is East
        // mutual border is tileA's East edge (column index resA-1) and tileB's West edge (column index 0)
        const rowIdxA = Math.min(resA - 1, Math.round(t * (resA - 1)));
        const rowIdxB = Math.min(resB - 1, Math.round(t * (resB - 1)));
        elevA = matA[rowIdxA][resA - 1];
        elevB = matB[rowIdxB][0];
      } else {
        // pair.orientation === 'NORTH_SOUTH'
        // tileA is South, tileB is North
        // mutual border is tileA's North edge (row index resA-1) and tileB's South edge (row index 0)
        const colIdxA = Math.min(resA - 1, Math.round(t * (resA - 1)));
        const colIdxB = Math.min(resB - 1, Math.round(t * (resB - 1)));
        elevA = matA[resA - 1][colIdxA];
        elevB = matB[0][colIdxB];
      }

      const diff = Math.abs(elevA - elevB);
      discrepancies.push(diff);
      if (diff > maxDiscontinuity) {
        maxDiscontinuity = diff;
      }
      sumDiscontinuity += diff;
    }

    const avgDiscontinuity = sumDiscontinuity / sampleCount;
    // Pass criterion: max discontinuity must be < 1.0 mm (0.001 m)
    const passed = maxDiscontinuity < 0.001;

    return {
      boundaryId: pair.boundaryId,
      tileAId: pair.tileAId,
      tileBId: pair.tileBId,
      orientation: pair.orientation,
      lodA,
      lodB,
      sampleCount,
      maxDiscontinuityMeters: maxDiscontinuity,
      averageDiscontinuityMeters: avgDiscontinuity,
      passed,
      notes: passed 
        ? `Continuous 0.00 mm vertex stitching verified across ${sampleCount} border vertices.`
        : `Discontinuity of ${(maxDiscontinuity * 1000).toFixed(2)} mm detected exceeding 1.0mm tolerance.`
    };
  }

  /**
   * Executes full suite of seam validation across all 4 boundaries at uniform and mixed LOD levels.
   */
  public runFullSeamSuite(): SeamValidationBoundaryResult[] {
    const results: SeamValidationBoundaryResult[] = [];

    // Test 1: All boundaries at LOD0 (Highest fidelity)
    ZION_BOUNDARIES.forEach((pair) => {
      results.push(this.testBoundary(pair, 0, 0, 32));
    });

    // Test 2: Cross-LOD boundaries (LOD0 adjacent to LOD1)
    results.push(this.testBoundary(ZION_BOUNDARIES[0], 0, 1, 32));
    results.push(this.testBoundary(ZION_BOUNDARIES[2], 1, 0, 32));

    return results;
  }
}
