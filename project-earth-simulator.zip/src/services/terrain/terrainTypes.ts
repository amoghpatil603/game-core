/**
 * Project Earth: Phase 4 Terrain Streaming & LOD Engine Types
 * Standardized interfaces for Terrain Tile Manager, LOD representations,
 * Geodetic Query API, Memory Management, Seam Validation, and Stress Testing.
 */

import { WGS84Coord, UTMCoord, ProjectEarthLocalCoord, UnrealEngineCoord } from '../../utils/geodeticMath';
import { RealTerrainTile } from '../../data/realEarthData';

export type TerrainLOD = 0 | 1 | 2 | 3;

export interface LODConfig {
  lod: TerrainLOD;
  name: string;
  gridResolution: number; // e.g. LOD0: 32x32, LOD1: 16x16, LOD2: 8x8, LOD3: 4x4
  sampleSpacingMeters: number; // e.g. LOD0: 16.5m, LOD1: 33m, LOD2: 66m, LOD3: 132m
  distanceThresholdMeters: number; // camera distance for this LOD
  vramCostMB: number;
}

export interface TerrainTileHeader {
  magic: string;          // Must be "PETH" (0x50455448)
  version: number;        // Must be 1
  headerSizeBytes: number;// 64 bytes
  compression: string;    // "NONE_RAW16"
  tileX: number;          // UTM Grid X (e.g. 322)
  tileY: number;          // UTM Grid Y (e.g. 4118)
  utmZone: number;        // 12
  utmZoneLetter: string;  // "S"
  tileSizeMeters: number; // 512.0
  minElevation: number;   // Meters above ellipsoid
  maxElevation: number;   // Meters above ellipsoid
  checksumSha256: string; // SHA-256 hash of payload
}

export interface RuntimeTerrainTile {
  tileId: string;
  tileX: number;
  tileY: number;
  utmOrigin: { easting: number; northing: number; zone: number };
  tileSizeMeters: number;
  header: TerrainTileHeader;
  baseElevationMatrix: number[][]; // Raw 32x32 DEM heights (LOD0)
  lodElevationMatrices: Record<TerrainLOD, number[][]>; // Pre-computed or dynamic LOD downsampled grids
  landCoverMatrix: number[][];
  currentLOD: TerrainLOD;
  targetLOD: TerrainLOD;
  loadState: 'unloaded' | 'pending' | 'loading' | 'loaded' | 'evicting' | 'error';
  lastAccessTimestamp: number;
  accessCount: number;
  cpuMemoryBytes: number;
  gpuMemoryBytes: number;
  loadLatencyMs: number;
  errorMessage?: string;
}

export interface TileNeighborGraph {
  north: string | null;
  south: string | null;
  east: string | null;
  west: string | null;
  northEast: string | null;
  northWest: string | null;
  southEast: string | null;
  southWest: string | null;
}

export interface StreamingQueueItem {
  tileId: string;
  tileX: number;
  tileY: number;
  targetLOD: TerrainLOD;
  priority: number; // Distance-based score (lower = higher priority)
  requestTimestamp: number;
  status: 'queued' | 'in_progress' | 'completed' | 'cancelled';
}

export interface TerrainMemoryStats {
  cpuUsageMB: number;
  cpuBudgetMB: number;
  gpuUsageMB: number;
  gpuBudgetMB: number;
  loadedTilesCount: number;
  maxLoadedTilesLimit: number;
  pendingTilesCount: number;
  evictedTilesCount: number;
  cacheHitRatio: number;
  averageLoadLatencyMs: number;
  isOverBudget: boolean;
}

export interface TerrainElevationQueryResult {
  wgs84: WGS84Coord;
  utm: UTMCoord;
  peLocal: ProjectEarthLocalCoord;
  ue: UnrealEngineCoord;
  elevationMeters: number;
  normal: { nx: number; ny: number; nz: number };
  slopeDegrees: number;
  aspectDegrees: number;
  tileId: string;
  activeLOD: TerrainLOD;
  interpolated: boolean;
  isValid: boolean;
  error?: string;
}

export interface SeamValidationBoundaryResult {
  boundaryId: string;
  tileAId: string;
  tileBId: string;
  orientation: 'NORTH_SOUTH' | 'EAST_WEST';
  lodA: TerrainLOD;
  lodB: TerrainLOD;
  sampleCount: number;
  maxDiscontinuityMeters: number;
  averageDiscontinuityMeters: number;
  passed: boolean; // Must be < 0.001 meters (1mm)
  notes: string;
}

export interface CameraStressSnapshot {
  cameraMode: 'stationary' | 'slow_walk' | 'sprint' | 'high_speed_flight' | 'direction_jitter' | 'zion_traverse';
  cameraPositionUTM: { easting: number; northing: number; altitude: number };
  cameraVelocityMPerSec: number;
  fps: number;
  frameTimeMs: number;
  tileLoadLatencyMs: number;
  streamingQueueDepth: number;
  loadedTiles: number;
  visibleTerrainGaps: number;
  lodTransitionErrors: number;
  activeLODBreakdown: Record<TerrainLOD, number>;
}

export interface TerrainQueryAPI {
  getElevationAtGeodetic(lat: number, lng: number): number | null;
  getTerrainNormalAtGeodetic(lat: number, lng: number): { nx: number; ny: number; nz: number } | null;
  getTerrainTile(lat: number, lng: number): RuntimeTerrainTile | null;
  getTerrainLOD(lat: number, lng: number): TerrainLOD | null;
  getTerrainMetadata(tileId: string): TerrainTileHeader | null;
}
