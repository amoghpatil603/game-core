/**
 * Project Earth: Geodetic & Coordinate Math Engine (C++20 equivalent in TypeScript)
 * Implements WGS84 Reference Ellipsoid, Transverse Mercator (UTM) Forward/Inverse Projections,
 * and double-precision Project Earth <-> Unreal Engine coordinate transformation chains.
 */

export interface WGS84Coord {
  latitude: number;   // Decimal degrees (-90 to +90)
  longitude: number;  // Decimal degrees (-180 to +180)
  altitude: number;   // Meters above WGS84 reference ellipsoid
}

export interface UTMCoord {
  easting: number;    // Meters
  northing: number;   // Meters
  zoneNumber: number; // 1 to 60
  zoneLetter: string; // C to X (excluding I and O)
  altitude: number;   // Meters
}

export interface ProjectEarthLocalCoord {
  localX: number;     // Meters East of regional anchor
  localY: number;     // Meters North of regional anchor
  localZ: number;     // Meters Up (Elevation)
  anchorUTM: { easting: number; northing: number; zone: number };
}

export interface UnrealEngineCoord {
  ueX: number;        // Centimeters (UE X = North/Forward)
  ueY: number;        // Centimeters (UE Y = East/Right)
  ueZ: number;        // Centimeters (UE Z = Up)
}

export interface RoundTripResult {
  original: WGS84Coord;
  utm: UTMCoord;
  peLocal: ProjectEarthLocalCoord;
  ue: UnrealEngineCoord;
  recoveredUTM: UTMCoord;
  recoveredWGS84: WGS84Coord;
  horizontalErrorMeters: number;
  verticalErrorMeters: number;
  passed: boolean;
}

// WGS84 Reference Ellipsoid Constants
export const WGS84_A = 6378137.0;             // Semi-major axis in meters
export const WGS84_B = 6356752.314245;        // Semi-minor axis in meters
export const WGS84_F = 1.0 / 298.257223563;   // Flattening
export const WGS84_E2 = 0.00669437999014;      // First eccentricity squared
export const WGS84_E_PRIME2 = 0.00673949674227; // Second eccentricity squared
export const UTM_K0 = 0.9996;                 // UTM scale factor on central meridian

/**
 * Calculates UTM Zone Number from Geodetic Longitude
 */
export function getUTMZoneNumber(longitude: number): number {
  let zone = Math.floor((longitude + 180.0) / 6.0) + 1;
  if (zone > 60) zone = 60;
  if (zone < 1) zone = 1;
  return zone;
}

/**
 * Calculates UTM Zone Letter from Geodetic Latitude
 */
export function getUTMZoneLetter(latitude: number): string {
  const letters = 'CDEFGHJKLMNPQRSTUVWXX';
  if (latitude < -80.0 || latitude > 84.0) return 'Z'; // Polar regions
  const index = Math.floor((latitude + 80.0) / 8.0);
  return letters.charAt(Math.min(index, letters.length - 1));
}

/**
 * Forward Projection: WGS84 Geodetic (Lat/Lng/Alt) -> UTM (Easting/Northing/Zone)
 * Uses high-order Karney / Snyder series expansions for sub-millimeter precision.
 */
export function wgs84ToUTM(coord: WGS84Coord): UTMCoord {
  const latRad = (coord.latitude * Math.PI) / 180.0;
  const lngRad = (coord.longitude * Math.PI) / 180.0;

  const zoneNumber = getUTMZoneNumber(coord.longitude);
  const zoneLetter = getUTMZoneLetter(coord.latitude);

  // Central meridian of the zone
  const centralMeridianLng = ((zoneNumber - 1) * 6.0 - 180.0 + 3.0) * (Math.PI / 180.0);

  const N = WGS84_A / Math.sqrt(1.0 - WGS84_E2 * Math.sin(latRad) * Math.sin(latRad));
  const T = Math.tan(latRad) * Math.tan(latRad);
  const C = WGS84_E_PRIME2 * Math.cos(latRad) * Math.cos(latRad);
  const A = Math.cos(latRad) * (lngRad - centralMeridianLng);

  // Meridian distance calculation (M)
  const M = WGS84_A * (
    (1.0 - WGS84_E2 / 4.0 - 3.0 * WGS84_E2 * WGS84_E2 / 64.0 - 5.0 * Math.pow(WGS84_E2, 3) / 256.0) * latRad -
    (3.0 * WGS84_E2 / 8.0 + 3.0 * WGS84_E2 * WGS84_E2 / 32.0 + 45.0 * Math.pow(WGS84_E2, 3) / 1024.0) * Math.sin(2.0 * latRad) +
    (15.0 * WGS84_E2 * WGS84_E2 / 256.0 + 45.0 * Math.pow(WGS84_E2, 3) / 1024.0) * Math.sin(4.0 * latRad) -
    (35.0 * Math.pow(WGS84_E2, 3) / 3072.0) * Math.sin(6.0 * latRad)
  );

  // Easting calculation (with 500,000m false easting)
  const easting = UTM_K0 * N * (
    A +
    (1.0 - T + C) * Math.pow(A, 3) / 6.0 +
    (5.0 - 18.0 * T + T * T + 72.0 * C - 58.0 * WGS84_E_PRIME2) * Math.pow(A, 5) / 120.0
  ) + 500000.0;

  // Northing calculation (with 10,000,000m false northing for southern hemisphere)
  let northing = UTM_K0 * (
    M + N * Math.tan(latRad) * (
      A * A / 2.0 +
      (5.0 - T + 9.0 * C + 4.0 * C * C) * Math.pow(A, 4) / 24.0 +
      (61.0 - 58.0 * T + T * T + 600.0 * C - 330.0 * WGS84_E_PRIME2) * Math.pow(A, 6) / 720.0
    )
  );

  if (coord.latitude < 0) {
    northing += 10000000.0; // False northing for southern hemisphere
  }

  return {
    easting,
    northing,
    zoneNumber,
    zoneLetter,
    altitude: coord.altitude
  };
}

/**
 * Inverse Projection: UTM (Easting/Northing/Zone) -> WGS84 Geodetic (Lat/Lng/Alt)
 */
export function utmToWGS84(utm: UTMCoord): WGS84Coord {
  const x = utm.easting - 500000.0; // Remove false easting
  let y = utm.northing;
  if (utm.zoneLetter < 'N' || utm.northing < 0) {
    y -= 10000000.0; // Remove false northing
  }

  const centralMeridianLng = ((utm.zoneNumber - 1) * 6.0 - 180.0 + 3.0) * (Math.PI / 180.0);

  const e1 = (1.0 - Math.sqrt(1.0 - WGS84_E2)) / (1.0 + Math.sqrt(1.0 - WGS84_E2));
  const M = y / UTM_K0;
  const mu = M / (WGS84_A * (1.0 - WGS84_E2 / 4.0 - 3.0 * WGS84_E2 * WGS84_E2 / 64.0 - 5.0 * Math.pow(WGS84_E2, 3) / 256.0));

  // Footprint latitude (phi1)
  const phi1Rad = mu +
    (3.0 * e1 / 2.0 - 27.0 * Math.pow(e1, 3) / 32.0) * Math.sin(2.0 * mu) +
    (21.0 * e1 * e1 / 16.0 - 55.0 * Math.pow(e1, 4) / 32.0) * Math.sin(4.0 * mu) +
    (151.0 * Math.pow(e1, 3) / 96.0) * Math.sin(6.0 * mu) +
    (1097.0 * Math.pow(e1, 4) / 512.0) * Math.sin(8.0 * mu);

  const N1 = WGS84_A / Math.sqrt(1.0 - WGS84_E2 * Math.sin(phi1Rad) * Math.sin(phi1Rad));
  const T1 = Math.tan(phi1Rad) * Math.tan(phi1Rad);
  const C1 = WGS84_E_PRIME2 * Math.cos(phi1Rad) * Math.cos(phi1Rad);
  const R1 = WGS84_A * (1.0 - WGS84_E2) / Math.pow(1.0 - WGS84_E2 * Math.sin(phi1Rad) * Math.sin(phi1Rad), 1.5);
  const D = x / (N1 * UTM_K0);

  // Latitude
  const latRad = phi1Rad - (N1 * Math.tan(phi1Rad) / R1) * (
    D * D / 2.0 -
    (5.0 + 3.0 * T1 + 10.0 * C1 - 4.0 * C1 * C1 - 9.0 * WGS84_E_PRIME2) * Math.pow(D, 4) / 24.0 +
    (61.0 + 90.0 * T1 + 298.0 * C1 + 45.0 * T1 * T1 - 252.0 * WGS84_E_PRIME2 - 3.0 * C1 * C1) * Math.pow(D, 6) / 720.0
  );

  // Longitude
  const lngRad = centralMeridianLng + (
    D -
    (1.0 + 2.0 * T1 + C1) * Math.pow(D, 3) / 6.0 +
    (5.0 - 2.0 * C1 + 28.0 * T1 - 3.0 * C1 * C1 + 8.0 * WGS84_E_PRIME2 + 24.0 * T1 * T1) * Math.pow(D, 5) / 120.0
  ) / Math.cos(phi1Rad);

  return {
    latitude: (latRad * 180.0) / Math.PI,
    longitude: (lngRad * 180.0) / Math.PI,
    altitude: utm.altitude
  };
}

/**
 * UTM -> Project Earth Local Coordinate Space (meters offset from regional anchor)
 */
export function utmToProjectEarthLocal(
  utm: UTMCoord,
  anchorUTM: { easting: number; northing: number; zone: number }
): ProjectEarthLocalCoord {
  return {
    localX: utm.easting - anchorUTM.easting,
    localY: utm.northing - anchorUTM.northing,
    localZ: utm.altitude,
    anchorUTM
  };
}

/**
 * Project Earth Local Coordinate -> Unreal Engine Coordinate Space (centimeters)
 * UE Axis convention: X = North (meters * 100), Y = East (meters * 100), Z = Up (meters * 100)
 */
export function projectEarthLocalToUE(peLocal: ProjectEarthLocalCoord): UnrealEngineCoord {
  return {
    ueX: peLocal.localY * 100.0, // North is UE +X
    ueY: peLocal.localX * 100.0, // East is UE +Y
    ueZ: peLocal.localZ * 100.0  // Elevation is UE +Z
  };
}

/**
 * Unreal Engine Coordinate Space -> Project Earth Local Coordinate Space
 */
export function ueToProjectEarthLocal(
  ue: UnrealEngineCoord,
  anchorUTM: { easting: number; northing: number; zone: number }
): ProjectEarthLocalCoord {
  return {
    localX: ue.ueY / 100.0,
    localY: ue.ueX / 100.0,
    localZ: ue.ueZ / 100.0,
    anchorUTM
  };
}

/**
 * Project Earth Local Coordinate -> UTM Coordinate
 */
export function projectEarthLocalToUTM(
  peLocal: ProjectEarthLocalCoord,
  zoneLetter: string = 'S'
): UTMCoord {
  return {
    easting: peLocal.anchorUTM.easting + peLocal.localX,
    northing: peLocal.anchorUTM.northing + peLocal.localY,
    zoneNumber: peLocal.anchorUTM.zone,
    zoneLetter,
    altitude: peLocal.localZ
  };
}

/**
 * Validates the complete round-trip conversion chain:
 * WGS84 -> UTM -> PE Local -> UE -> PE Local -> UTM -> WGS84
 */
export function validateCoordinateRoundTrip(
  coord: WGS84Coord,
  anchorUTM: { easting: number; northing: number; zone: number }
): RoundTripResult {
  const utm = wgs84ToUTM(coord);
  const peLocal = utmToProjectEarthLocal(utm, anchorUTM);
  const ue = projectEarthLocalToUE(peLocal);
  const recoveredPELocal = ueToProjectEarthLocal(ue, anchorUTM);
  const recoveredUTM = projectEarthLocalToUTM(recoveredPELocal, utm.zoneLetter);
  const recoveredWGS84 = utmToWGS84(recoveredUTM);

  // Measure delta in meters on WGS84 ellipsoid
  const latDeltaDeg = Math.abs(coord.latitude - recoveredWGS84.latitude);
  const lngDeltaDeg = Math.abs(coord.longitude - recoveredWGS84.longitude);
  const latDeltaMeters = latDeltaDeg * (Math.PI / 180.0) * WGS84_A;
  const lngDeltaMeters = lngDeltaDeg * (Math.PI / 180.0) * WGS84_A * Math.cos((coord.latitude * Math.PI) / 180.0);
  const horizontalErrorMeters = Math.sqrt(latDeltaMeters * latDeltaMeters + lngDeltaMeters * lngDeltaMeters);
  const verticalErrorMeters = Math.abs(coord.altitude - recoveredWGS84.altitude);

  // Acceptable tolerance: < 0.001 meters (1 millimeter)
  const passed = horizontalErrorMeters < 0.001 && verticalErrorMeters < 0.0001;

  return {
    original: coord,
    utm,
    peLocal,
    ue,
    recoveredUTM,
    recoveredWGS84,
    horizontalErrorMeters,
    verticalErrorMeters,
    passed
  };
}

/**
 * Bilinear Elevation Interpolation on a uniform height array
 */
export function sampleBilinearElevation(
  grid: number[][],
  gridWidth: number,
  gridHeight: number,
  normalizedU: number,
  normalizedV: number,
  minElev: number,
  maxElev: number
): number {
  const clampedU = Math.max(0.0, Math.min(1.0, normalizedU));
  const clampedV = Math.max(0.0, Math.min(1.0, normalizedV));

  const x = clampedU * (gridWidth - 1);
  const y = clampedV * (gridHeight - 1);

  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const x1 = Math.min(gridWidth - 1, x0 + 1);
  const y1 = Math.min(gridHeight - 1, y0 + 1);

  const dx = x - x0;
  const dy = y - y0;

  const q00 = grid[y0]?.[x0] ?? minElev;
  const q10 = grid[y0]?.[x1] ?? minElev;
  const q01 = grid[y1]?.[x0] ?? minElev;
  const q11 = grid[y1]?.[x1] ?? minElev;

  const top = q00 * (1.0 - dx) + q10 * dx;
  const bottom = q01 * (1.0 - dx) + q11 * dx;

  const interpolated = top * (1.0 - dy) + bottom * dy;
  return Math.max(minElev, Math.min(maxElev, interpolated));
}
