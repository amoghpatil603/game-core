export interface OceanTraits {
  openness: number;         // 0.0 to 1.0
  conscientiousness: number;// 0.0 to 1.0
  extraversion: number;     // 0.0 to 1.0
  agreeableness: number;    // 0.0 to 1.0
  neuroticism: number;      // 0.0 to 1.0
}

export interface NPC {
  id: string;
  name: string;
  age: number;
  gender: string;
  occupation: string;
  ocean: OceanTraits;
  drives: {
    nutrition: number;       // Deficit 0 (satisfied) to 1 (starving)
    hydration: number;       // Deficit 0 to 1
    sleep: number;           // Deficit 0 to 1
    thermal: number;         // Deficit 0 to 1
    safety: number;          // Deficit 0 to 1
    social: number;          // Deficit 0 to 1
    esteem: number;          // Deficit 0 to 1
    actualization: number;   // Deficit 0 to 1
  };
  cash: number;
  debt: number;
  stress: number;            // 0.0 to 1.0
  monthlyRent: number;
  monthlyUtilities: number;
  habits: { [key: string]: number }; // Action ID -> Multiplier
  history: string[];
  isPlayer: boolean;
}

export interface Relationship {
  fromId: string;
  toId: string;
  love: number;        // -1.0 to 1.0
  trust: number;       // -1.0 to 1.0
  respect: number;     // -1.0 to 1.0
  fear: number;        // 0.0 to 1.0
  jealousy: number;    // 0.0 to 1.0
  loyalty: number;     // 0.0 to 1.0
  dependency: number;  // 0.0 to 1.0
  forgiveness: number; // 0.0 to 1.0
  conflict: number;    // 0.0 to 1.0
}

export interface GoapAction {
  id: string;
  name: string;
  category: string;
  description: string;
  affects: {
    nutrition?: number;       // Delta (negative value decreases deficit, positive increases)
    hydration?: number;
    sleep?: number;
    thermal?: number;
    safety?: number;
    social?: number;
    esteem?: number;
    actualization?: number;
  };
  cashCost: number;
  cashIncome: number;
  energyCost: number;         // sleep deficit delta
  icon: string;
}

export interface LedgerEntry {
  id: string;
  timestamp: string; // In-game time (e.g., "Day 1, 08:00")
  description: string;
  amount: number;    // negative for expense, positive for income
  category: 'housing' | 'utilities' | 'groceries' | 'tax' | 'healthcare' | 'salary' | 'recreation' | 'debt';
}

export interface BibleChapter {
  id: string;
  volume: string;
  title: string;
  subTitle: string;
  sections: {
    title: string;
    content: string;
    equations?: string[];
    matrices?: string[][];
  }[];
}

export interface PADState {
  pleasure: number;   // -1.0 to 1.0
  arousal: number;    // -1.0 to 1.0
  dominance: number;  // -1.0 to 1.0
}

export interface CognitiveMemory {
  id: string;
  description: string;
  category: string;
  timestamp: number;     // Simulated ticks/hours elapsed since creation
  baseSalience: number;  // 0.0 to 1.0
  valence: number;       // -1.0 to 1.0
  layer: 'sensory' | 'working' | 'short-term' | 'episodic' | 'semantic' | 'procedural' | 'emotional';
  decayFactor: number;   // Current strength/retention level (0.0 to 1.0)
  associatedEntityId?: string; // Target NPC (e.g., 'Chloe Sterling', 'John Doe')
  isSuppressed?: boolean;      // Traumatic defense suppression flag
  reinforcementCount?: number; // Times recalled or reinforced
  distortionCount?: number;   // Times altered during consolidation or stress
  isFalseMemory?: boolean;     // Whether memory is distorted or composite
  associatedSkill?: string;    // For procedural skills/routines
}
